# -*- coding: utf-8 -*-

def updateTranslations():
    pass

