__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from qgis.core import QgsField

idTypes_map = {'10': "text", '2': "int4", '4': "int8",
               '3': "int4", '5': "int8", '6': "numeric(20,8)"}

'''create the fields in the existing layer. 
 The layer must be in edit mode. make sure excute the following code before call this function.
             if not self.m_SOURCE_LAYER.isEditable():
                self.m_SOURCE_LAYER.startEditing()
            # Start: create new field =======================================================================================
            self.m_SOURCE_LAYER.beginEditCommand("Added attribute")
'''
def createFields(field_names,field_names_type,layer):
    field_name_index = {}
    for i, field_name in enumerate(field_names):
        # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
        type = field_names_type[i]
        len_, prec_ = 0, 0
        if idTypes_map[str(type)] == "real":
            len_ = -1
            prec_ = -1
        elif idTypes_map[str(type)] == "numeric(20,8)":
            len_ = 20
            prec_ = 8
        field = QgsField(field_name, type, idTypes_map[str(type)], len_,
                             prec_)  # [TODO] rdedge_param.datasource, postgres, spatialite,file different command
        mAttributeId = -1
        if (not layer.addAttribute(field)):
            # failed to add new fields, may be already exists
            # check whether exists
            # try to get the index of the new field
            mAttributeId = layer.fields().indexFromName(field_name)
        else:
            # add sucess, get index of the new field
            mAttributeId = layer.fields().indexFromName(field_name)

        if mAttributeId == -1:
            layer.destroyEditCommand()
            raise GeoAlgorithmExecutionException(
                ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                    field.name(),
                    field.typeName())))
        field_name_index[field_name] = mAttributeId
    return field_name_index

'''get the fields type,
example:
 getFeildsInformation(layer,["id","area"])
 return [QVariant.Int,QVariant.Double]
'''
def getFeildsTypes(layer,fieldnamelist):
    if not isinstance(fieldnamelist,list):
        raise GeoAlgorithmExecutionException("getFeildsInformation: filednamelist must be list type!")
    ufields = layer.fields()
    if ufields.count() <= 0:
        raise GeoAlgorithmExecutionException("Error: Attribute table must have at least one field")
    types = {}

    fields_needed = []
    fields_needed.extend(fieldnamelist)
    for field in ufields:
        # initial read in has correct ordering...
        name = str(field.name())
        if name in fields_needed:
            types[name] = int(field.type())
    try:
        res = []
        for field in fieldnamelist:
            res.append(types[field])
    except KeyError as e:
        raise GeoAlgorithmExecutionException("%s not found in %s"% (field,layer.name()))
    return res