## Betweenness Centrality

Calculate the **betweenness centrality** of directed network using Betweenness functions in package "**Igraph**" or ' **NetworkX**".



**Roads Edge Layer**: edges table of "roads network".

**Edge ID Field**: ID field of "Roads Edge Layer".

**Edge Source Field**: source field of "Roads Edge Layer".

**Edge Target Field**: target field of "Roads Edge Layer".

**Edge Weight Field**: weight field of "Roads Edge Layer".

**Edge Reverse Weight Field**: reverse weight field of "Roads Edge Layer".

**Betweenness K**: If k is not None, use k node samples to estimate betweenness. The value of k <= n (n is the number of nodes in the graph). Higher values give better approximation.

**Packages**: "**Igraph**" or ' **NetworkX**", which functions can be used to calculate betweenness centrality.

**Specify Result's Field in Road Layer**: the field name of "Betweenness Centrality" results.

**Input Zone Layer** [Optional]: Polygon vector layer. This function aggregates "Betweenness Centrality" of network to each feature in the "Input Zone Layer."

**Zone ID Field** [Optional]: ID field of "Input Zone Layer".

**Specify Result's Field in Zone Layer**: the field name of "Betweenness Centrality" results in the "Input Zone Layer".

**Betweenness Centrality Layer**: Save the aggregated "Betweenness Centrality" to PostGIS table.



If check "Create Field in Zone Layer", the functions will create a field named  in the "zone layer", which records the "Betweenness Centrality" results.



If check "Create New Zone Layer", users can save the **Betweenness  Centrality** to file or database table (SpatiaLite table or PostGIS table).



If check "Open output file after running algorithm", the results will be open in QGIS automatically after finish calculation.

