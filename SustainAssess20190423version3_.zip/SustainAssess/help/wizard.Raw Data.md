### Select Raw Data for Sustainability Assessment

Select raw data that can be used to evaluate each sustainability indicators. 



Click on "**+**", users can new data from  **"Current Layers", "File", "PostGIS Table" to the data table.  In the data table, the tool will show the filename, file type, CRS, and Path of files.



Select one or multiple data records and click **"─"** ""button, users can remove the selected data from the data table.

Select one data record in the table and click **↑** or **↓** button, users can move the record.