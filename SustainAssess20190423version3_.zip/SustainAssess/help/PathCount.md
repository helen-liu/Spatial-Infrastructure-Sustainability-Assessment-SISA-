## Path Counts

Calculate the number of traffic flows on each edge in the road network.



**OD Pairs Layer**: Origin-Destination pairs.

**OD Pairs Weight Field**: weight field of  "OD pairs layer".

**Roads Layer**: vector layer of roads network.

**Roads Source Field**: Source field of "roads layer".

**Roads Target Field**: Target field of "roads layer".

**Roads Time Cost Field**: Time cost field of "roads layer".

**Roads Reverse Time Cost Field**: Reverse time cost field of "roads layer".

**Output: PathCount Field Name in Road Layer**: field name of "path count".

**Output:  Set the Accumulated Length Field Name in OD Layer [optional]**: field name of "accumulated length".

**Output: Set the Accumulated Time Field Name in OD Layer [optional]**: field name of "accumulated time".











**Input Zone Layer** [Optional]: Polygon vector layer. This function aggregates "Betweenness Centrality" of network to each feature in the "Input Zone Layer."

**Zone ID Field** [Optional]: ID field of "Input Zone Layer".

**Specify Result's Field in Zone Layer**: the field name of "Betweenness Centrality" results in the "Input Zone Layer".

**Betweenness Centrality Layer**: Save the aggregated "Betweenness Centrality" to PostGIS table.



If check "Create Field in Zone Layer", the functions will create a field named  in the "zone layer", which records the "Betweenness Centrality" results.



If check "Create New Zone Layer", users can save the **Betweenness  Centrality** to file or database table (SpatiaLite table or PostGIS table).



If check "Open output file after running algorithm", the results will be open in QGIS automatically after finish calculation.

