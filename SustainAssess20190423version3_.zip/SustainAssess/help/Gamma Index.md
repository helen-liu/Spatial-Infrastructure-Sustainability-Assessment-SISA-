## Gamma Index

Calculate the Gamma index of directed network:

**Gamma Index** considers relationships between the number of observed links and the number of possible links. A gamma index of 0.5 means that the network is 50% connected. Gamma index is an
efficient value to measure the progression of a network in time (Rodrigue et. al., 2017).

![1545949484429](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1545949484429.png)



**Input Zone Layer**: polygon layer defined the boundary of calculating **Gamma Index**. Each polygon in the "input zone layer" will have an "Gamma Index" value.  It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**ID Field**: ID field of the "Input Zone Layer"

**Roads Layer**: road network file. It <u>must be selected from database table (SpatiaLite or PostGIS table)</u>. 

**Source Field**: source field of "Roads Layer". If field name ‘source’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Target Field**: target field of "Roads Layer". If field name ‘target’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Cost Field**: cost field of "Roads Layer". When creating the **directed network**, "cost" is treated as "weight" of one edge segment. 

If field name ‘cost’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Reverse Cost Field**:  reverse cost field of "Roads Layer". When creating the **directed network**, "reverse cost" is treated as "weight" of one edge segment.

If field name ‘reverse_cost’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Output Field Name**: name of the field that saves "Gamma Index" values.

**Output Layer**: this tool can save results to temporary layer, shapefile (*.shp), database tables (SpatiaLite table or PostGIS table), or new field in "Input Zone Layer".



* If check "Open output file after running algorithm", the results will be open in QGIS automatically after finish calculation.

------

<u>Optional parameters</u>, if one of the E, V, P field name is "**[not set]**", then the tool will calculate the e, v, p values of the “Roads Layer”, and **create field "e_net", "v_net", "p_net" in the output layer**.

**E Field Name [Optional]**:  one field of "Roads Layer", recording "e" value of “Roads Layer”.  If field name ‘e_net’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**V Field Name [Optional]**: one field of "Roads Layer", recording "v" value of “Roads Layer”.  If field name ‘v_net’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**P Field Name [Optional]**:  one field of "Roads Layer", recording "p" value of “Roads Layer”.  If field name ‘p_net’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.



---

**Reference**:

* Rodrigue, J. P., Comtois, C., & Slack, B. (2017). The Geography of Transport Systems. Fourth Edition. New York: Routledge, 440 pages. ISBN 978-1138669574.