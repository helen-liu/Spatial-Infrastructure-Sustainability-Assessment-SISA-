## Compare Attributes

This tool compare the attribute(s) value of two input layers.



Comparison method:

**Comparison result = attribute value of "Input Layer 1"  (operator) attribute value of "Input Layer 2"** 

This tool support the 4 operators:  **+, —, *, /** (sum, minus, multiply, divide)



**Input Layer 1:** the first input layer. It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Input Layer 2:** the second input layer. It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Input Layer 1's Key Field**:  the key field of "input layer 1". 

**Input Layer 2's Key Field**:  the key field of "input layer 2".

**Input Layer 1's Field**:  the field to compare.

**Input Layer 2's Field**:  the field to compare.

**Operator**:  operators applied to comparison fields. 

after selecting the comparison fields for input layer 1 and 2, users can click button "**+**" to add the comparison fields into the "**Comparison Table**". 

click "**—**" to remove the comparison fields from "Comparison Table". 

**Output Layer**: layer or file to save the compared file. Its attribute fields are **same** as the comparison fields in "**Input Layer 1**", the key field is "Input Layer 1's Key Field". 