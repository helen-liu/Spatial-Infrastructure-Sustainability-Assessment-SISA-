## Normalization

Normalize the selected fields of Input Layer.



**Input Zone Layer**: Polygon vector file.  It can be files opened in QGIS or "Open from file" or "open from database table" (SpatiaLite table or PostGIS table)

**ID Field**: ID field of the "Input Zone Layer"

**Normalization Method**:  Available normalization methods in this tool include:

* Min-Max
* Standardization (Z-Score)
* Ranking
* Distance-to-Reference
* Categorical Scales

**Selected Fields**: normalize value of these selected fields. In the "**Alias**" field, users can type in the alias of the selected fields. "**Effect**" field designate the "*Positive*" or "*Negative*" effect of the corresponding field to the "Sustainability assessment".

**Normalization Results Layer**: save normalization results to temporal file or to file, or to database table (SpatiaLite table or PostGIS table).

____

![1545995733950](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1545995733950.png)