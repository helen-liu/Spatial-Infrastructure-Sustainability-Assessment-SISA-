## Correlation

Calculate the correlation coefficient between the selected fields of Input Layer.



**Input Zone Layer**: Polygon vector file.  It can be files opened in QGIS or "Open from file" or "open from database table" (SpatiaLite table or PostGIS table)

**Selected Fields**: calculate the correlations between these selected fields. In the "**Alias**" field, users can type in the alias of the selected fields. 

**Output Results File**: save correlation results to temporal file or to file, or to database table (SpatiaLite table or PostGIS table).

