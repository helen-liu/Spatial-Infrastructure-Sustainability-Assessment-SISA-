### Analyze Sustainability Assessment Results

Evaluate the uncertainty and sensitivity of sustainability assessment results. 



Click "**Uncertainty Analysis**" button to evaluate uncertainty of indicators' weights to sustainability assessment results.



Click "**Sensitivity Analysis**" button to evaluate sensitivity of indicators' value to sustainability assessment results.

