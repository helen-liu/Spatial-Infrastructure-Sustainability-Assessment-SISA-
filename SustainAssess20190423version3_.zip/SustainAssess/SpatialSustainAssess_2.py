# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SpatialSustainAssess
                                 A QGIS plugin
 Evaluating sustainability of objects from multiple dimensions
                              -------------------
        begin                : 2018-06-25
        git sha              : $Format:%H$
        copyright            : (C) 2018 by Mengmeng Helen Liu / Georgia Insitute of Technology
        email                : mengmeng.liu@gatech.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from qgis.core import QgsMessageLog
from PyQt4.QtCore import QTranslator, qVersion, QCoreApplication, Qt
from PyQt4.QtGui import QAction, QIcon, QFileDialog, QMenu

# Initialize Qt resources from file resources.py
# Import the code for the DockWidget
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from gui.maindockwidget_2 import SpatialSustainAssessDockWidget
from qgis import utils
import os.path
import sys
import inspect

cmd_folder = os.path.split(inspect.getfile(inspect.currentframe()))[0]
if cmd_folder not in sys.path:
    sys.path.insert(0, cmd_folder)

class SpatialSustainAssess:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgisInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface

        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale
        locale = 'en'
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'SpatialSustainAssess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.main_menu_name = self.tr("&Sustainability")
        self.submenu_test_name = self.tr(u'&Spatial Sustainability Assessment')

        # TODO: We are going to let the user set this up in a future iteration
        #self.toolbar = self.iface.addToolBar(u'SpatialSustainAssess')
        #self.toolbar.setObjectName(u'SpatialSustainAssess')

        #print "** INITIALIZING SpatialSustainAssess"

        self.pluginIsActive = False
        self.dockwidget = None
        #self.dockwidget = SpatialSustainAssessDockWidget()


    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('SpatialSustainAssess', message)


    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        ####---------------------------------------------------------------------
        # Check if the menu exists and get it
        self.main_menu = self.iface.mainWindow().findChild(QMenu, self.main_menu_name)  #self.main_menu_name = self.tr("&Sustainability")
        self.menubar = self.iface.mainWindow().menuBar()
        icon_path = ':/plugins/SustainAssess/icon.png'
        # If the menu does not exist, create it!
        #if not self.main_menu:
        self.main_menu = QMenu('&Sustainability', self.menubar)
        self.main_menu.setObjectName('&Sustainability')

        self.submenu1 = QMenu('&Spatial Sustainability Assessment', self.main_menu)
        self.submenu1.setObjectName('&Sustainability submenu')    #self.submenu_test_name = self.tr(u'&Spatial Sustainability Assessment')

        actions = self.iface.mainWindow().menuBar().actions()
        lastAction = actions[-1]
        self.iface.mainWindow().menuBar().insertMenu(lastAction, self.main_menu)

        ## Add action to main menu
        #action = QAction(QIcon("icon.png"), "Splugin", self.iface.mainWindow())
        action = QAction(QIcon(icon_path), "Wizard", self.iface.mainWindow())
        action.triggered.connect(self.run_Wizard)

        #reload plugin action
        reloadaction = QAction(QIcon(":/plugins/SustainAssess/icons/reload.png"), "reload6", self.iface.mainWindow())
        reloadaction.triggered.connect(self.run)

        # Finally, add all your actions to the main menu
        self.main_menu.addAction(self.submenu1.menuAction())
        self.menubar.addAction(self.main_menu.menuAction())
        self.main_menu.addAction(action)
        self.main_menu.addAction(reloadaction)

        self.actions.append(action)
            # self.actions.append(reloadaction)
        ProcessingConfig.initialize()
        ProcessingConfig.readSettings()
        QgsMessageLog.logMessage("I am here")
        ####---------------------------------------------------------------------

    def onClosePlugin(self):
        """Cleanup necessary items here when plugin dockwidget is closed"""

        #print "** CLOSING SpatialSustainAssess"

        # disconnects
        self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)

        # remove this statement if dockwidget is to remain
        # for reuse if plugin is reopened
        # Commented next statement since it causes QGIS crashe
        # when closing the docked window:
        self.dockwidget = None

        self.pluginIsActive = False


    def unload(self):
        #print "** UNLOAD SpatialSustainAssess"
        if self.dockwidget != None:
            self.dockwidget.setVisible(False)
            self.iface.removeDockWidget(self.dockwidget)
        """Removes the plugin menu item and icon from QGIS GUI."""
        self.main_menu.deleteLater()

        #self.submenu1.deleteLater()
        for action in self.actions:
            self.iface.unregisterMainWindowAction(action)
        # for action in self.actions:
        #     self.iface.removePluginMenu(
        #         self.tr(u'&Spatial Sustainability Assessment'),
        #         action)
            #self.iface.removeToolBarIcon(action)
        # remove the toolbar
        #del self.toolbar

    #--------------------------------------------------------------------------
    ## Define select output file function
    def select_output_file(self):
        ## you need import  QFileDialog from PyQt4.QtGui
        filename = QFileDialog.getSaveFileName(self.dockwidget, "Select Output File", "", '*.txt')

        ## from qgis.core import QgsMessageLog
        QgsMessageLog.logMessage('filename:'+filename, 'MyPlugin')

        self.dockwidget.lineEdit_Outputfile.setText(filename)

    def click_OK(self):
        ## click OK will save features information to the file
        filename = self.dockwidget.lineEdit_Outputfile.text()

        ## get the layers user choose from comboBox
        selectedLayerIndex = self.dockwidget.comboBox_LayerList.currentIndex()
        layers = self.iface.legendInterface().layers()
        selectedLayer = layers[selectedLayerIndex]

        ### get the filed name for each feature, which is the attribute of each feature
        fields = selectedLayer.fields()
        fieldnames = [field.name() for field in fields]

        ## write the fieldname for each feature into file
        output_file = open(filename, 'w')
        for f in selectedLayer.getFeatures():
            line = ','.join(str(f[x]) for x in fieldnames) + '\n'
            unicode_line = line.encode('utf-8')
            output_file.write(unicode_line)
        output_file.close()

    def click_Cancel(self):
        self.dockwidget.setVisible(False)

    def run(self):
        QgsMessageLog.logMessage("excute run6")



    def run_Wizard(self):
        """Run method that loads and starts the plugin"""

        if not self.pluginIsActive:
            self.pluginIsActive = True

            #print "** STARTING SpatialSustainAssess"

            # dockwidget may not exist if:
            #    first run of plugin
            #    removed on close (see self.onClosePlugin method)
            if self.dockwidget == None:
                # Create the dockwidget (after translation) and keep reference
                self.dockwidget = SpatialSustainAssessDockWidget()

            # connect to provide cleanup on closing of dockwidget
            self.dockwidget.closingPlugin.connect(self.onClosePlugin)

            ####---------------------------------------------------
            ## get current layers loaded in QGIS
            #layers = self.iface.canvas.layers()
            layers = self.iface.legendInterface().layers()
            layer_list = []
            for layer in layers:
                layer_list.append(layer.name())
            ####---------------------------------------------------

            ####----------------------------------------------------
            ### add the loaded layers in QGIS to combobox
            self.dockwidget.comboBox_LayerList.addItems(layer_list)

            ####----------------------------------------------------
            self.dockwidget.pushBt_SelectOutputFile.clicked.connect(self.select_output_file)

            ####------------------------------------------------------
            self.dockwidget.pushBt_OK.clicked.connect(self.click_OK)

            self.dockwidget.pushBt_Cancel.clicked.connect(self.click_Cancel)

            # show the dockwidget
            # TODO: fix to allow choice of dock location
            self.iface.addDockWidget(Qt.LeftDockWidgetArea, self.dockwidget)
            self.dockwidget.show()
            QgsMessageLog.logMessage("show dockwidet!")
