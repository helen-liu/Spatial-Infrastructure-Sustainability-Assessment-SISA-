# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SpatialSustainAssess
                                 A QGIS plugin
 Evaluating sustainability of objects from multiple dimensions
                              -------------------
        begin                : 2018-06-25
        git sha              : $Format:%H$
        copyright            : (C) 2018 by Mengmeng Helen Liu / Georgia Insitute of Technology
        email                : mengmeng.liu@gatech.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from qgis.core import QgsMessageLog
from qgis.PyQt.QtCore import QTranslator, qVersion, QCoreApplication, Qt
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QMenu, QWidget,QMessageBox
from qgis.PyQt.QtGui import QIcon

# Initialize Qt resources from file resources.py
# Import the code for the DockWidget

from gui.maindockwidget import SpatialSustainAssessDockWidget
from qgis import utils
import os.path
import sys
import inspect
from gui.wizards_menu.wizardWinClass import wizardWinClass
from gui.database_menu.DatabaseWinClass import DatabaseWinClass
from gui.geoprocee_menu.GeoprocessWinClass import GeoprocessWinClass
from gui.network_menu.NetworkAnalysisWinClass import NetworkAnalysisWinClass

# path
cmd_folder = os.path.split(inspect.getfile(inspect.currentframe()))[0]
if cmd_folder not in sys.path:
    sys.path.insert(0, cmd_folder)

class SpatialSustainAssess:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgisInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface

        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale
        locale = 'en'
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'SpatialSustainAssess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.main_menu_name = self.tr("&Sustainability")
        self.submenu_test_name = self.tr(u'&Spatial Sustainability Assessment')

        # TODO: We are going to let the user set this up in a future iteration
        #self.toolbar = self.iface.addToolBar(u'SpatialSustainAssess')
        #self.toolbar.setObjectName(u'SpatialSustainAssess')

        #print "** INITIALIZING SpatialSustainAssess"
        self.dockwidget = None
        #self.dockwidget = SpatialSustainAssessDockWidget()
        self.icons_folder = ':/plugins/SustainAssess/icons/'

        ## init database submenu
        # self.databaseWin = None
        self.connection_dic = {"server": "", "dbname": "", "user":"","password":""}

        ## init geoprocess menu
        self.geoprocessWin = None



    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('SpatialSustainAssess', message)


    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        ####---------------------------------------------------------------------
        # Check if the menu exists and get it
        self.main_menu = self.iface.mainWindow().findChild(QMenu, self.main_menu_name)  #self.main_menu_name = self.tr("&Sustainability")
        self.menubar = self.iface.mainWindow().menuBar()

        # If the menu does not exist, create it!
        #if not self.main_menu:
        self.main_menu = QMenu('&Sustainability', self.menubar)
        self.main_menu.setObjectName('&Sustainability')
        actions = self.iface.mainWindow().menuBar().actions()
        lastAction = actions[-1]
        self.iface.mainWindow().menuBar().insertMenu(lastAction, self.main_menu)

        ## submenu for 'database'   ---------------------------------------------------
        self.submenu_SetDatabase = QMenu('&Set Database', self.main_menu)
        self.submenu_SetDatabase.setObjectName('Submenu SetDatabase')    #self.submenu_test_name = self.tr(u'&Spatial Sustainability Assessment')

        self.databaseWin = DatabaseWinClass(self.iface)
        icon_path = self.icons_folder + 'dabase.png'
        action_SetDatabase = QAction(QIcon(icon_path), "&Init", self.iface.mainWindow())
        # action_SetDatabase.triggered.connect(lambda: self.databaseWin.SetDatabase(self.connection_dic))
        action_SetDatabase.triggered.connect(self.run_SetDatabase)

        ## submenu for 'Geoprocess'   ---------------------------------------------------
        self.submenu_Geoprocess = QMenu('&Geoprocess', self.main_menu)
        self.submenu_Geoprocess.setObjectName('Submenu Geoprocess')
        # self.geoprocessWin = GeoprocessWinClass(self.iface, self.connection_dic)

        ## Geoprocess action 1: create grid
        icon_path = self.icons_folder + 'geoprocess.jpg'
        action_CreateGrid = QAction(QIcon(icon_path), "&Create Grid", self.iface.mainWindow())
        # action_CreateGrid.triggered.connect(self.geoprocessWin.createGrid)
        action_CreateGrid.triggered.connect(self.run_CreateGrid)

        ## Geoprocess action 2: create Random Vector
        action_CreateRandomVector = QAction("&Create Random Vector", self.iface.mainWindow())
        # action_CreateRandomVector.triggered.connect(self.geoprocessWin.createRandomVector)
        action_CreateRandomVector.triggered.connect(self.run_CreateRandomVector)

        ## Geoprocess action 2: create Random Point
        action_CreateRandomPoint = QAction("&Create Random Point", self.iface.mainWindow())
        action_CreateRandomPoint.triggered.connect(self.run_CreateRandomPoint)

        ## Geoprocess action 3: create Buffer  TODO: to be implemented
        action_CreateBuffer = QAction("&Create Buffer", self.iface.mainWindow())
        action_CreateBuffer.triggered.connect(self.run_CreateBuffer)

        ## submenu for 'NetworkAnalysis'   ---------------------------------------------------
        self.submenu_NetworkAnalysis = QMenu('&Network Analysis', self.main_menu)
        self.submenu_Geoprocess.setObjectName('Submenu Network Analysis')
        ## initialize networkanlaysis window
        self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

        ## network analysis subsubmenu: Connectivity  ---------------------
        # self.subsubmenu_Connectivity = self.submenu_NetworkAnalysis.addMenu('&Connectivity')
        self.subsubmenu_Connectivity = QMenu('&Connectivity', self.submenu_NetworkAnalysis)
        ## Connectivity action 1: AlphaIndex    --------
        action_Connectivity_AlphaIndex = QAction("&Alpha Index", self.iface.mainWindow())
        action_Connectivity_AlphaIndex.triggered.connect(self.run_Connectivity_AlphaIndex)
        # action_Connectivity_AlphaIndex.triggered.connect(self.networkAnalysisWin.Connectivity_AlphaIndex)

        ## Connectivity action 2: BetaIndex     --------
        action_Connectivity_BetaIndex = QAction("&Beta Index", self.iface.mainWindow())
        action_Connectivity_BetaIndex.triggered.connect(self.run_Connectivity_BetaIndex)

        ## Connectivity action 3: GammaIndex    --------
        action_Connectivity_GammaIndex = QAction("&Gamma Index", self.iface.mainWindow())
        action_Connectivity_GammaIndex.triggered.connect(self.run_Connectivity_GammaIndex)

        ## Connectivity action 4: DetourIndex   --------
        action_Connectivity_DetourIndex = QAction("&Detour Index", self.iface.mainWindow())
        action_Connectivity_DetourIndex.triggered.connect(self.run_Connectivity_DetourIndex)

        ## network analysis subsubmenu: Accessibility ---------------------
        self.subsubmenu_Accessibility = QMenu('&Accessibility', self.submenu_NetworkAnalysis)
        ## Accessibility action 1: Neareast Distance, e.g. shortest distance to neareast park
        action_Accessibility_NeareastDistance = QAction("&Neareast Distance", self.iface.mainWindow())
        action_Accessibility_NeareastDistance.triggered.connect(self.run_Accessibility_NearestDistance)

        ## Accessibility action 2: Resources Within Distance, e.g. number of parks canbe access within 1km
        action_Accessibility_ResourcesWithinDistance = QAction("&Resources Within Distance", self.iface.mainWindow())
        action_Accessibility_ResourcesWithinDistance.triggered.connect(self.run_Accessibility_ResourcesWithinDistance)

        ## network analysis subsubmenu: Centrality    ---------------------
        ## TODO: implement centrality actions
        self.subsubmenu_Centrality = QMenu('&Centrality', self.submenu_NetworkAnalysis)

        action_Centrality_Betweenness = QAction("&Betweenness", self.iface.mainWindow())
        action_Centrality_Betweenness.triggered.connect(self.run_Centrality_Betweenness)

        action_Centrality_Closeness = QAction("&Closeness", self.iface.mainWindow())
        action_Centrality_Closeness.triggered.connect(self.run_Centrality_Closeness)

        action_Centrality_CrossClique = QAction("&Cross Clique", self.iface.mainWindow())
        action_Centrality_CrossClique.triggered.connect(self.run_Centrality_CrossClique)

        action_Centrality_Eigenvector = QAction("&Eigenvector", self.iface.mainWindow())
        action_Centrality_Eigenvector.triggered.connect(self.run_Centrality_Eigenvector)

        action_Centrality_Freeman = QAction("&Freeman", self.iface.mainWindow())
        action_Centrality_Freeman.triggered.connect(self.run_Centrality_Freeman)

        action_Centrality_Katz = QAction("&Katz", self.iface.mainWindow())
        action_Centrality_Katz.triggered.connect(self.run_Centrality_Katz)

        action_Centrality_PageRank = QAction("&PageRank", self.iface.mainWindow())
        action_Centrality_PageRank.triggered.connect(self.run_Centrality_PageRank)

        action_Centrality_Percolation = QAction("&Percolation", self.iface.mainWindow())
        action_Centrality_Percolation.triggered.connect(self.run_Centrality_Percolation)

        ## submenue for 'wizard'    ------------------------------------------------------
        self.submenu_wizard = QMenu('&Wizard', self.main_menu)
        self.submenu_wizard.setObjectName('&Submenu Wizard')

        # Create actions for 'wizard' (after translation) and keep reference
        # icon_path = ':/plugins/SustainAssess/icon.png'
        self.wizard = wizardWinClass(self.iface)
        icon_path = self.icons_folder + 'icon.png'
        actionStartWizard = QAction(QIcon(icon_path), "&Start Sustainability Evaluation", self.iface.mainWindow())
        actionStartWizard.triggered.connect(self.wizard.startWizards)

        # Finally, add all your actions to the main menu    ----------------------------------------------
        self.menubar.addAction(self.main_menu.menuAction())

        ## add actions of submenu to the mainmenu   -------------------------------
        self.main_menu.addAction(self.submenu_SetDatabase.menuAction())
        self.main_menu.addAction(self.submenu_Geoprocess.menuAction())
        self.main_menu.addAction(self.submenu_NetworkAnalysis.menuAction())
        self.main_menu.addAction(self.submenu_wizard.menuAction())

        ## add corresponding actions to each submenu    ----------------------------
        ## add actions to 'set Database'     -------------------
        self.submenu_SetDatabase.addAction(action_SetDatabase)

        ## add actions to 'Geoprocess'   -----------------------
        self.submenu_Geoprocess.addAction(action_CreateGrid)
        self.submenu_Geoprocess.addAction(action_CreateRandomVector)
        self.submenu_Geoprocess.addAction(action_CreateRandomPoint)
        self.submenu_Geoprocess.addAction(action_CreateBuffer)

        ## add actions to 'NetworkAnalysi'  --------------------
        self.submenu_NetworkAnalysis.addAction(self.subsubmenu_Connectivity.menuAction())
        self.submenu_NetworkAnalysis.addAction(self.subsubmenu_Accessibility.menuAction())
        self.submenu_NetworkAnalysis.addAction(self.subsubmenu_Centrality.menuAction())
        ## Connectivity actions
        self.subsubmenu_Connectivity.addAction(action_Connectivity_AlphaIndex)
        self.subsubmenu_Connectivity.addAction(action_Connectivity_BetaIndex)
        self.subsubmenu_Connectivity.addAction(action_Connectivity_DetourIndex)
        self.subsubmenu_Connectivity.addAction(action_Connectivity_GammaIndex)
        ## Accessibility actions
        self.subsubmenu_Accessibility.addAction(action_Accessibility_NeareastDistance)
        self.subsubmenu_Accessibility.addAction(action_Accessibility_ResourcesWithinDistance)
        ## Centrality actions: TODO: to be implemented
        self.subsubmenu_Centrality.addAction(action_Centrality_Betweenness)
        self.subsubmenu_Centrality.addAction(action_Centrality_Closeness)
        self.subsubmenu_Centrality.addAction(action_Centrality_CrossClique)
        self.subsubmenu_Centrality.addAction(action_Centrality_Eigenvector)
        self.subsubmenu_Centrality.addAction(action_Centrality_Freeman)
        self.subsubmenu_Centrality.addAction(action_Centrality_Katz)
        self.subsubmenu_Centrality.addAction(action_Centrality_PageRank)
        self.subsubmenu_Centrality.addAction(action_Centrality_Percolation)

        ## add actions to 'Wizard'   -------------------------
        self.submenu_wizard.addAction(actionStartWizard)


        ### append all actions into actions list    -------------------
        ## 'DataBase' actions
        self.actions.append(action_SetDatabase)

        ## 'Geoprocess' actions
        self.actions.append(action_CreateGrid)
        self.actions.append(action_CreateRandomVector)

        ## 'NetworkAnlaysis' actions
        ## Connectivity actions
        self.actions.append(action_Connectivity_AlphaIndex)
        self.actions.append(action_Connectivity_BetaIndex)
        self.actions.append(action_Connectivity_GammaIndex)
        self.actions.append(action_Connectivity_DetourIndex)
        ## Accessibility actions
        self.actions.append(action_Accessibility_NeareastDistance)
        self.actions.append(action_Accessibility_ResourcesWithinDistance)
        ## Centrality actions
        self.actions.append(action_Centrality_Betweenness)
        self.actions.append(action_Centrality_Closeness)
        self.actions.append(action_Centrality_CrossClique)
        self.actions.append(action_Centrality_Eigenvector)
        self.actions.append(action_Centrality_Freeman)
        self.actions.append(action_Centrality_Katz)
        self.actions.append(action_Centrality_PageRank)
        self.actions.append(action_Centrality_Percolation)

        ## actions of 'Wizard'
        self.actions.append(actionStartWizard)

        QgsMessageLog.logMessage("I am here")
        ####---------------------------------------------------------------------

    def onClosePlugin(self):
        """Cleanup necessary items here when plugin dockwidget is closed"""

        #print "** CLOSING SpatialSustainAssess"
        # disconnects
        self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)

        # remove this statement if dockwidget is to remain
        # for reuse if plugin is reopened
        # Commented next statement since it causes QGIS crashe
        # when closing the docked window:
        self.dockwidget = None

    def unload(self):
        #print "** UNLOAD SpatialSustainAssess"
        if self.dockwidget != None:
            self.dockwidget.setVisible(False)
            self.iface.removeDockWidget(self.dockwidget)

        ## unload database submenus
        if self.databaseWin != None:
            self.databaseWin.unload()

        ## unload networkAnalysis submenus
        if self.networkAnalysisWin != None:
            self.networkAnalysisWin.unload()

        ## unload wizard submenus
        if self.wizard != None:
            self.wizard.unload()


        """Removes the plugin menu item and icon from QGIS GUI."""
        self.main_menu.deleteLater()
        for action in self.actions:
            self.iface.unregisterMainWindowAction(action)

    def run(self):
        QgsMessageLog.logMessage("excute run6")


    def run_SetDatabase(self):
        #self.InitDatabaseWin = InitDataBaseWin(self)
        #self.detour_win.show()
        if not self.databaseWin:
            self.databaseWin = DatabaseWinClass(self.iface, self.connection_dic)

        self.databaseWin.SetDatabase()
        self.connection_dic = self.databaseWin.getConnectionDic()

    def run_CreateGrid(self):
        if self.databaseWin.testConnectionString()==True:
            if not self.geoprocessWin:
                self.geoprocessWin = GeoprocessWinClass(self.iface, self.connection_dic)

            self.geoprocessWin.createGrid()
            self.connection_dic = self.geoprocessWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_CreateRandomVector(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.geoprocessWin:
                self.geoprocessWin = GeoprocessWinClass(self.iface, self.connection_dic)

            self.geoprocessWin.createRandomVector()
            self.connection_dic = self.geoprocessWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_CreateRandomPoint(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.geoprocessWin:
                self.geoprocessWin = GeoprocessWinClass(self.iface, self.connection_dic)

            self.geoprocessWin.createRandomPoint()  ##TODO: check if need implement createRandomPoint()
            self.connection_dic = self.geoprocessWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_CreateBuffer(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.geoprocessWin:
                self.geoprocessWin = GeoprocessWinClass(self.iface, self.connection_dic)

            self.geoprocessWin.createBuffer()       ## TODO: createBuffer() to be implemented
            self.connection_dic = self.geoprocessWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Connectivity_AlphaIndex(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Connectivity_AlphaIndex
            self.networkAnalysisWin.Connectivity_AlphaIndex()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)


    def run_Connectivity_BetaIndex(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Connectivity_BetaIndex
            self.networkAnalysisWin.Connectivity_BetaIndex()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Connectivity_GammaIndex(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Connectivity_GammaIndex
            self.networkAnalysisWin.Connectivity_GammaIndex()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Connectivity_DetourIndex(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Connectivity_PRD (Detour Index)
            self.networkAnalysisWin.Connectivity_PRD()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Accessibility_NearestDistance(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Accessibility_NearestDistance
            self.networkAnalysisWin.Accessibility_NearestDistance()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Accessibility_ResourcesWithinDistance(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Accessibility_ResourcesWithinDistance
            self.networkAnalysisWin.Accessibility_ResourcesWithinDistance()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Centrality_Betweenness (self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Centrality_Betweenness  TODO: to be implement
            self.networkAnalysisWin.Centrality_Betweenness()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Centrality_Closeness(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Centrality_Closeness  TODO: to be implement Centrality_Closeness()
            self.networkAnalysisWin.Centrality_Closeness()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)


    def run_Centrality_CrossClique(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Centrality_CrossClique  TODO: to be implement Centrality_CrossClique()
            self.networkAnalysisWin.Centrality_CrossClique()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Centrality_Eigenvector(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Centrality_Eigenvector  TODO: to be implement Centrality_Eigenvector()
            self.networkAnalysisWin.Centrality_Eigenvector()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Centrality_Freeman(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Centrality_Freeman  TODO: to be implement Centrality_Freeman()
            self.networkAnalysisWin.Centrality_Freeman()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Centrality_Katz(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Centrality_Katz  TODO: to be implement Centrality_Katz()
            self.networkAnalysisWin.Centrality_Katz()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Centrality_PageRank(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Centrality_PageRank  TODO: to be implement Centrality_PageRank()
            self.networkAnalysisWin.Centrality_PageRank()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)

    def run_Centrality_Percolation(self):
        if self.databaseWin.testConnectionString() == True:
            if not self.networkAnalysisWin:
                self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)

            ## run actions related to Centrality_Percolation  TODO: to be implement Centrality_Percolation()
            self.networkAnalysisWin.Centrality_Percolation()
            self.connection_dic = self.networkAnalysisWin.getConnectionDic()
        else:
            # Show a message box
            result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
                                          QMessageBox.Yes | QMessageBox.No,
                                          QMessageBox.No)