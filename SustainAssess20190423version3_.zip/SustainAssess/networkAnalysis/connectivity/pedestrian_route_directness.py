# -*- coding: utf-8 -*-
import psycopg2
import math,time
import random,sys,os,re
## the parameters of the edges or network file, 
## based on which we calculate the Detour index
FIND_RADIUS = 200  # meters


def find_the_nearest_node(in_point,args):
    cur.execute('''
        select st_x(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s)),
               st_y(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s))
        '''%(str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid'],
             str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid']))
    row1 = cur.fetchone()
    layer_point = [row1[0],row1[1]]
    
    args['x'] = layer_point[0]
    args['y'] = layer_point[1]
    args['minx'] = layer_point[0] - FIND_RADIUS
    args['miny'] = layer_point[1] - FIND_RADIUS
    args['maxx'] = layer_point[0] + FIND_RADIUS
    args['maxy'] = layer_point[1] + FIND_RADIUS
    
    # Getting nearest source
    query1 = """
    SELECT %(source_field)s,%(target_field)s,
        ST_Distance(
            %(geometry)s,
            ST_GeomFromText('POINT(%(x)f %(y)f)', %(srid)d)
        ) AS dist,
        st_distance(
            st_startpoint(%(geometry)s),
            ST_GeomFromText('POINT(%(x)f %(y)f)', %(srid)d)
        ) as point_to_s,
        st_distance(
            st_endpoint(%(geometry)s),
            ST_GeomFromText('POINT(%(x)f %(y)f)', %(srid)d)
        ) as point_to_t
        FROM %(edge_table)s
        WHERE ST_SetSRID('BOX3D(%(minx)f %(miny)f, %(maxx)f %(maxy)f)'::BOX3D, %(srid)d)
            && %(geometry)s ORDER BY dist ASC LIMIT 1""" % args
    
    cur.execute(query1)
    row1 = cur.fetchone()
    if row1 is None:
        return -1,-1
    
    if len(row1) > 0:
        node_id,distance = row1[0],row1[3]
        if row1[3] >= row1[4]:
            node_id,distance = row1[1],row1[4]
    else:
        node_id,distance = -1,-1        
    return node_id,distance


def find_the_nearest_node2(in_point,args,cur=None,conn=None):
    cur.execute('''
        select st_x(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s)),
               st_y(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s))
        '''%(str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid'],
             str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid']))
    row1 = cur.fetchone()
    layer_point = [row1[0],row1[1]]
    
    args['x'] = layer_point[0]
    args['y'] = layer_point[1]
    args['minx'] = layer_point[0] - FIND_RADIUS
    args['miny'] = layer_point[1] - FIND_RADIUS
    args['maxx'] = layer_point[0] + FIND_RADIUS
    args['maxy'] = layer_point[1] + FIND_RADIUS
    
    # Getting nearest source
    query1 = """
    SELECT id,
        ST_Distance(
            %(node_geom)s,
            ST_GeomFromText('POINT(%(x)f %(y)f)', %(srid)d)
        ) AS dist
        FROM %(node_table)s
        WHERE ST_SetSRID('BOX3D(%(minx)f %(miny)f, %(maxx)f %(maxy)f)'::BOX3D, %(srid)d)
            && %(node_geom)s ORDER BY dist ASC LIMIT 1""" % args
    
    cur.execute(query1)
    row1 = cur.fetchone()
    if row1 is None:
        return -1,-1
    
    if len(row1) > 0:
        node_id,distance = row1[0],row1[1]
    else:
        node_id,distance = -1,-1        
    return node_id,distance

    
def prd(start_point,end_point,para_dic,cur=None,conn=None):
    # para_dic = {"boundary": {"schema": "", "name": "", "geom": "", "crs": ""},
    #             "regionbyway": {"schema": "", "name": "", "geom": "", "crs": "", "id": ""},
    #             "randomvector": {"schema": "", "name": "", "geom": "", "crs": ""},
    #             "rd_edge": {"schema": "", "name": "", "geom": "", "id": "", "source": "", "target": "",
    #                         "cost": "", "rv_cost": "", "crs": ""},
    #             "rd_node": {"schema": "", "name": "", "geom": "", "crs": ""},
    #             "msg": ""}
    args={}
    args['edge_table'] = para_dic["rd_edge"]["schema"]+"."+para_dic["rd_edge"]["name"]
    args['node_table'] = para_dic["rd_node"]["schema"]+"."+para_dic["rd_node"]["name"]
    args['node_geom'] = para_dic["rd_node"]["geom"]
    args['source_field'] = para_dic["rd_edge"]["source"]
    args['target_field'] = para_dic["rd_edge"]["target"]
    args['geometry'] = para_dic["rd_edge"]["geom"]
    args['srid'] = para_dic["rd_edge"]["crs"]
    args['from_srid'] = start_point[2]
    source_node_id,dis_s_point2node = find_the_nearest_node2(start_point, args,cur,conn)

    args['from_srid'] = end_point[2]
    target_node_id,dis_t_point2node = find_the_nearest_node2(end_point, args,cur,conn)
    prd = -1
    if source_node_id != -1 and target_node_id != -1:
        arg2={}
        arg2['id_field'] = para_dic["rd_edge"]["id"]
        arg2['source'] = source_node_id
        arg2['target'] = target_node_id
        arg2['source_field'] = para_dic["rd_edge"]["source"]
        arg2['target_field'] = para_dic["rd_edge"]["target"]
        arg2['cost_field'] = para_dic["rd_edge"]["cost"]
        arg2['reverse_cost_field'] = para_dic["rd_edge"]["rv_cost"]
        arg2['edge_table'] = para_dic["rd_edge"]["schema"]+"."+para_dic["rd_edge"]["name"]
        query2 = """SELECT * FROM pgr_dijkstra('SELECT %(id_field)s AS id, %(source_field)s as source, 
                                                %(target_field)s target, %(cost_field)s as cost, 
        %(reverse_cost_field)s as reverse_cost FROM %(edge_table)s ',%(source)s,%(target)s, true)"""% arg2
        cur.execute(query2)
        rows = cur.fetchall()
        try:
            actual_route_distance =  rows[-1][5] + dis_t_point2node + dis_s_point2node
        except:
            actual_route_distance = -1000
        
        
        arg3={'x1':start_point[0],'y1':start_point[1],
              'x2':end_point[0],'y2':end_point[1],'from_srid':start_point[2],'srid':para_dic["rd_edge"]["crs"]}
        query3 = '''select
            ST_Distance(
                st_transform(ST_GeomFromText('POINT(%(x1)f %(y1)f)', %(from_srid)d),%(srid)d),
                st_transform(ST_GeomFromText('POINT(%(x2)f %(y2)f)', %(from_srid)d),%(srid)d)
            ) AS dist
                '''%arg3
        cur.execute(query3)
        straight_line_distance = cur.fetchone()[0]
        prd = actual_route_distance/straight_line_distance
    return prd

def creat_path(id):
    pass
def create_random_vector(para_dic=None,cur=None,conn=None):
    # self.para_dic = {"input": {"schema": "", "name": "", "geom":"","crs": ""},
    #                  "line": {"length": -1, "number": -1},
    #                  "point": {"number": -1},
    #                  "checkbox": "point or line",
    #                  "output": {"schema": "", "name": "", "crs": ""},
    #                  "msg": ""
    #                  }
    num = para_dic["line"]["number"]
    out_name = para_dic["output"]["name"]
    result1 = re.match("^[0-9]", out_name)  # start with digit number
    result2 = re.match(".*[A-Z].*", out_name)  # contain Capital letter
    if result1 != None or result2 != None:
        out_name = '\"' + out_name + '\"'
    random_vector_table = para_dic["output"]["schema"]+"."+out_name

    in_name = para_dic["input"]["name"]
    result1 = re.match("^[0-9]", in_name)  # start with digit number
    result2 = re.match(".*[A-Z].*", in_name)  # contain Capital letter
    if result1 != None or result2 != None:
        in_name = '\"' + in_name + '\"'
    boundary_table = para_dic["input"]["schema"]+"."+in_name
    vector_length = para_dic["line"]["length"]

    batch_= 1000
    query = '''
            SELECT ST_Extent(%s) as bextent FROM %s;
            '''%(para_dic["input"]["geom"],boundary_table)
    try:
        cur.execute(query)
    except psycopg2.ProgrammingError:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print((exc_type, exc_obj, exc_tb.tb_lineno))
        msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
        return -1, msg1
    #"BOX(668847.132598878 400923.139123538,694105.805963132 434705.427685547)"
    box_str = cur.fetchone()[0]
    minx,miny = box_str.replace('BOX(','').replace(')','').split(',')[0].split(' ')
    maxx,maxy = box_str.replace('BOX(','').replace(')','').split(',')[1].split(' ')
    minx,miny,maxx,maxy = float(minx),float(miny),float(maxx),float(maxy)
    
    span_x = maxx - minx
    span_y = maxy - miny
    span_angle = 2*math.pi

    i = 0
    batch_query = "Begin;"
    batch_i = 0
    while i<num:
        r1 = random.random()
        r2 = random.random()
        r3 = random.random()
        
        x = minx + r1*span_x
        y = miny + r2*span_y
        angle = r3*span_angle
#         x_t = x + math.cos(angle)*1600
#         y_t = y + math.sin(angle)*1600
        
        x_t = x + math.cos(angle)*vector_length
        y_t = y + math.sin(angle)*vector_length
        arg={'id':i,'x1':x,'y1':y,'x2':x_t,'y2':y_t,
             'boundary_table':boundary_table,'random_vector':random_vector_table,
             'boundary_geom':para_dic["input"]["geom"],'boundary_crs':para_dic["input"]["crs"]}
        
        query2 = '''
                select ST_Contains(%(boundary_geom)s, ST_GeomFromText('LINESTRING(%(x1)f %(y1)f,%(x2)f %(y2)f)', %(boundary_crs)s)) 
                from %(boundary_table)s
                '''%arg
        cur.execute(query2)
        res = cur.fetchone()[0]

        if res == True:
            query3 = '''
                INSERT INTO %(random_vector)s(
                id, geom)
                    VALUES (%(id)s, ST_GeomFromText('LINESTRING(%(x1)f %(y1)f,%(x2)f %(y2)f)', %(boundary_crs)s));\n  
                '''%arg
            batch_query+=query3
            i = i + 1
            batch_i = batch_i + 1
            if batch_i%batch_==0:
                batch_query +="End;\n"
                try:
                    cur.execute(batch_query)
                except:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    print(exc_type, exc_obj, exc_tb.tb_lineno)
                    msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
                    return -1, msg1
                conn.commit()
                batch_query = "Begin;\n"
                batch_i=0
    if batch_i<batch_ and batch_i>0:
        batch_query += "End;\n"
        try:
            cur.execute(batch_query)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, exc_obj, exc_tb.tb_lineno)
            msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
            return -1, msg1
        conn.commit()
    msg = 'Create %(random_vector)s Successfully!\n' % arg
    return 1, msg

def cal_prds(para_dic=None,cur=None,conn=None):
    # self.para_dic = {
    #     "regionbyway": {"schema": "", "name": "", "geom": "", "crs": "", "id": ""},
    #     "rd_edge": {"schema": "", "name": "", "geom": "", "id": "", "source": "", "target": "",
    #                 "cost": "", "rv_cost": "", "crs": ""},
    #     "rd_node": {"schema": "", "name": "", "geom": "", "crs": ""},
    #     "randomvector": {"schema": "", "name": "", "geom": "", "crs": "",
    #                      "prd": ""},
    #     "msg": ""}

    # update s_area and t_area
    arg = {'randomvector': para_dic["randomvector"]["schema"]+"."+para_dic["randomvector"]["name"],
           'randomvector_geom':para_dic["randomvector"]["geom"],
           'regionbyway': para_dic["regionbyway"]["schema"]+"."+para_dic["regionbyway"]["name"],
           'regionbyway_id': para_dic["regionbyway"]["id"],
           'regionbyway_geom': para_dic["regionbyway"]["geom"],
           }
    update_query = '''
                    update %(randomvector)s
                    set s_area = t1.%(regionbyway_id)s
                    from %(regionbyway)s as t1
                    where ST_Contains(t1.%(regionbyway_geom)s,st_startpoint(%(randomvector)s.%(randomvector_geom)s));

                    update %(randomvector)s
                    set t_area = t1.%(regionbyway_id)s
                    from %(regionbyway)s as t1
                    where ST_Contains(t1.%(regionbyway_geom)s,st_endpoint(%(randomvector)s.%(randomvector_geom)s));
                    ''' % arg
    try:
        cur.execute(update_query)
    except psycopg2.ProgrammingError:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, exc_obj, exc_tb.tb_lineno)
        msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
        conn.commit()
        return -1, msg1
    conn.commit()

    # update prd
    query = '''
                select id,st_astext(st_startpoint(geom)),st_astext(st_endpoint(geom)),st_srid(geom)
                from %(randomvector)s
                    ''' % arg
    try:
        cur.execute(query)
    except psycopg2.ProgrammingError:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, exc_obj, exc_tb.tb_lineno)
        msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
        conn.commit()
        return -1, msg1
    rows = cur.fetchall()
    batch_num = 1000
    batch_i = 0
    batch_sql = "BEGIN;\n"
    for row in rows:
        id = row[0]
        x, y = str(row[1]).replace('POINT(', '').replace(')', '').split()
        startpoint = [float(x), float(y), int(row[3])]
        x, y = str(row[2]).replace('POINT(', '').replace(')', '').split()
        endpoint = [float(x), float(y), int(row[3])]
        prd_v = prd(startpoint, endpoint,para_dic,cur,conn)

        update_q = '''
                update %s set prd = %s where id = %s;\n
                    ''' % (para_dic["randomvector"]["schema"]+"."+para_dic["randomvector"]["name"], str(prd_v), str(id))
        batch_sql+=update_q
        batch_i+=1
        if batch_i%batch_num==0:
            batch_sql+="END;\n"
            try:
                cur.execute(batch_sql)
            except psycopg2.ProgrammingError:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print(exc_type, exc_obj, exc_tb.tb_lineno)
                msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
                conn.commit()
                return -1, msg1
            conn.commit()
            batch_sql = "BEGIN;\n"
    if batch_i>0:
        batch_sql += "END;\n"
        try:
            cur.execute(batch_sql)
        except psycopg2.ProgrammingError:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, exc_obj, exc_tb.tb_lineno)
            msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
            conn.commit()
            return -1, msg1
        conn.commit()
    return 1,"Process successfully!\n"

def yes_or_no(question):
    reply = str(eval(input(question+' (y/n): '))).lower().strip()
    if reply[0] == 'y':
        return True
    if reply[0] == 'n':
        return False
    else:
        return yes_or_no("Uhhhh... please enter ")

if __name__ == "__main__":
    ########################################################### parameters:
    # num of loops
    num_random_tables = 100
    schema = 'alt_2'
    # boundary
    boundary_schema = schema
    boundary_name = '285buffer3km'
    # regionbyway
    regionbyway_schema = schema
    regionbyway_name = 'regionbyway'
    regionbyway_id = "id"
    # random vector
    randomvector_schema = "rv"
    randomvector_name = 'rv_500'
    #randomvector_prd_fields_list[0] = current roadnetwork
    #randomvector_prd_fields_list[1] = high way under ground
    randomvector_prd_fields_list=['prd_cur','prd_under']

    # line length
    vector_len = 500
    vector_num = 15
    # road network
    rd_edge_schema = schema

    #rd_edge_name_list[0] = current roadnetwork
    #rd_edge_name_list[1] = edge table = high way under ground
    rd_edge_name_list = ["rdways_new","rdways_new"]
    rd_edge_id_field = 'gid'  ## id of the edge table
    rd_edge_source_field = 'source'
    rd_edge_target_field = 'target'
    rd_edge_cost = 'cost'
    rd_edge_reverse_cost = 'reverse_cost'


    # Create a new database connectiong:
    server, dbname, user, password = 'localhost', 'alt_routing', 'postgres', 'liu'
    conn = psycopg2.connect("dbname=%s user=%s password=%s" % (dbname, user, password))
    cur = conn.cursor()

    ############################################################################
    random_i = 0      #需要改
    for i in range(num_random_tables):
        random_i+=1
        my_dic = {"input": {"schema": boundary_schema, "name": boundary_name, "geom": "", "crs": ""},
                  "line": {"length": vector_len, "number": vector_num},
                  "point": {"number": -1},
                  "checkbox": "point or line",
                  "output": {"schema": randomvector_schema, "name": randomvector_name + "_" + str(random_i), "crs": ""},
                  "msg": ""
                  }
        boundary_geom = ""
        boundary_crs = -1
        regionbyway_geom_field = ''
        regionbyway_crs = -1

        sql_command = '''select * from (select * from geometry_columns) as t1
                                where t1.f_table_schema = '%(schema)s';
                                ;''' % (
            my_dic["input"])
        cur.execute(sql_command)
        rows = cur.fetchall()
        for row in rows:
            # 1: schema 2:table_name 3:geom 5:srid
            if row[2] == my_dic["input"]["name"]:
                my_dic["input"]["geom"] = row[3]
                my_dic["input"]["crs"] = row[5]
                my_dic["output"]["crs"] = row[5]
                boundary_geom = my_dic["input"]["geom"]
                boundary_crs = my_dic["input"]["crs"]
            if row[2] == regionbyway_name:
                regionbyway_geom_field = row[3]
                regionbyway_crs = row[5]
        if boundary_crs != regionbyway_crs:
            print("Please check Projection for boundary, regionbyway, and roadnetwork, inconsistency exist.")
            exit()

        sql_command = '''
                SELECT EXISTS (
                       SELECT 1
                       FROM   information_schema.tables 
                       WHERE  table_schema = '%(schema)s'
                       AND    table_name = '%(name)s'
                       );
                ''' % my_dic["output"]
        cur.execute(sql_command)
        bool_e = cur.fetchall()[0][0]
        if bool_e:
            question = "Random table %(schema)s.%(name)s exist. Do you want to overwrite it?" % my_dic["output"]
            # r = wait_key()
            y = yes_or_no(question)
            if y == False:
                exit()

        sql_create = '''
                 Drop table if exists %(schema)s.%(name)s;
                 CREATE TABLE %(schema)s.%(name)s
                 (
                   id integer,
                   geom geometry(LINESTRING,%(crs)s),
                   s_area integer,
                   t_area integer
                 )
                 WITH (
                   OIDS=FALSE
                 );
                ALTER TABLE %(schema)s.%(name)s
                   OWNER TO postgres; 
                       ''' % my_dic["output"]
        try:
            cur.execute(sql_create)
            conn.commit()
        except psycopg2.ProgrammingError:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, exc_obj, exc_tb.tb_lineno)
            msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
            print (-1, msg1)

        code, msg = create_random_vector(my_dic, cur, conn)
        print(msg)
        if code != 1:
            print("Create Failed!")
            exit()
        # update s_area and t_area
        num = my_dic["line"]["number"]
        out_name = my_dic["output"]["name"]
        result1 = re.match("^[0-9]", out_name)  # start with digit number
        result2 = re.match(".*[A-Z].*", out_name)  # contain Capital letter
        if result1 != None or result2 != None:
            out_name = '\"' + out_name + '\"'
        random_vector_table = my_dic["output"]["schema"] + "." + out_name

        in_name = my_dic["input"]["name"]
        result1 = re.match("^[0-9]", in_name)  # start with digit number
        result2 = re.match(".*[A-Z].*", in_name)  # contain Capital letter
        if result1 != None or result2 != None:
            in_name = '\"' + in_name + '\"'
        boundary_table = my_dic["input"]["schema"] + "." + in_name

        in_name = regionbyway_name
        result1 = re.match("^[0-9]", in_name)  # start with digit number
        result2 = re.match(".*[A-Z].*", in_name)  # contain Capital letter
        if result1 != None or result2 != None:
            in_name = '\"' + in_name + '\"'
        regionbyway_table = regionbyway_schema + "." + in_name

        arg = {'random_vector': random_vector_table, 'regionbyway_table': regionbyway_table,
               'regionbyway_geom': regionbyway_geom_field}
        update_query = '''
                            update %(random_vector)s
                            set s_area = t1.id
                            from %(regionbyway_table)s as t1
                            where ST_Contains(t1.%(regionbyway_geom)s,st_startpoint(%(random_vector)s.geom));

                            update %(random_vector)s
                            set t_area = t1.id
                            from %(regionbyway_table)s as t1
                            where ST_Contains(t1.%(regionbyway_geom)s,st_endpoint(%(random_vector)s.geom));
                            ''' % arg
        cur.execute(update_query)
        conn.commit()

        for j in range(2):
            start = time.time()
            rd_edge_name = rd_edge_name_list[j]
            rd_edge_geom_field = ""
            rd_edge_crs = -1

            rd_node_geom_field = ''
            rd_node_crs = -1
            rd_node_schema = rd_edge_schema
            rd_node_name = rd_edge_name + '_vertices_pgr'

            sql_command = '''select * from (select * from geometry_columns) as t1
                                    where t1.f_table_schema = '%(schema)s';
                                    ;''' % (
                my_dic["input"])
            cur.execute(sql_command)
            rows = cur.fetchall()
            for row in rows:
                # 1: schema 2:table_name 3:geom 5:srid
                if row[2] == rd_edge_name:
                    rd_edge_geom_field = row[3]
                    rd_edge_crs = row[5]
                if row[2] == rd_node_name:
                    rd_node_geom_field = row[3]
                    rd_node_crs = row[5]

            if boundary_crs != rd_edge_crs or boundary_crs != regionbyway_crs or rd_edge_crs != regionbyway_crs:
                print("Please check Projection for boundary, regionbyway, and roadnetwork, inconsistency exist.")
                exit()


            #create prd field
            sql_command = '''ALTER TABLE %s DROP COLUMN IF EXISTS %s;
                          ALTER TABLE %s ADD COLUMN %s numeric;'''%(random_vector_table,randomvector_prd_fields_list[j],
                                                                    random_vector_table, randomvector_prd_fields_list[j])
            cur.execute(sql_command)
            conn.commit()
            # update prd
            query = '''
                            select id,st_astext(st_startpoint(geom)),st_astext(st_endpoint(geom)),st_srid(geom)
                            from %s
                                ''' % random_vector_table
            cur.execute(query)
            rows = cur.fetchall()
            para_dic = {"boundary": {"schema": boundary_schema, "name": boundary_name, "geom": boundary_geom,
                                     "crs": boundary_crs},
                        "regionbyway": {"schema": regionbyway_schema, "name": regionbyway_name, "geom": "", "crs": "",
                                        "id": regionbyway_id},
                        "randomvector": {"schema": randomvector_schema, "name": randomvector_name + "_" + str(random_i),
                                         "geom": "geom", "crs": boundary_crs},
                        "rd_edge": {"schema": rd_edge_schema, "name": rd_edge_name, "geom": rd_edge_geom_field,
                                    "id": rd_edge_id_field, "source": rd_edge_source_field,
                                    "target": rd_edge_target_field,
                                    "cost": rd_edge_cost, "rv_cost": rd_edge_reverse_cost, "crs": rd_edge_crs},
                        "rd_node": {"schema": rd_node_schema, "name": rd_node_name, "geom": rd_node_geom_field,
                                    "crs": rd_node_crs},
                        "msg": ""}

            batch_num = 1000
            batch_i = 0
            batch_sql = "BEGIN;\n"
            for row in rows:
                id = row[0]
                x, y = str(row[1]).replace('POINT(', '').replace(')', '').split()
                startpoint = [float(x), float(y), int(row[3])]
                x, y = str(row[2]).replace('POINT(', '').replace(')', '').split()
                endpoint = [float(x), float(y), int(row[3])]
                prd_v = prd(startpoint, endpoint, para_dic, cur, conn)

                update_q = '''update %s set %s = %s where id = %s;\n''' % \
                           (random_vector_table,randomvector_prd_fields_list[j], str(prd_v), str(id))
                batch_sql += update_q
                batch_i += 1
                if batch_i % batch_num == 0:
                    batch_sql += "END;\n"
                    try:
                        cur.execute(batch_sql)
                    except psycopg2.ProgrammingError:
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        print(exc_type, exc_obj, exc_tb.tb_lineno)
                        msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
                        conn.commit()
                        exit()
                    conn.commit()
                    batch_sql = "BEGIN;\n"
                    batch_i = 0
            if batch_i > 0:
                batch_sql += "END;\n"
                try:
                    cur.execute(batch_sql)
                except psycopg2.ProgrammingError:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    print(exc_type, exc_obj, exc_tb.tb_lineno)
                    msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
                    conn.commit()
                    exit()
                conn.commit()
                # for row in rows:
                #     id = row[0]
                #     x, y = str(row[1]).replace('POINT(', '').replace(')', '').split()
                #     startpoint = [float(x), float(y), int(row[3])]
                #     x, y = str(row[2]).replace('POINT(', '').replace(')', '').split()
                #     endpoint = [float(x), float(y), int(row[3])]
                #
                #     prd_v = prd(startpoint, endpoint,para_dic,cur,conn)
                #
                #     update_q = '''
                #                 update %s
                #                 set %s = %s
                #                 where id = %s
                #                     ''' % (random_vector_table,
                #                            randomvector_prd_fields_list[j],str(prd_v), str(id))
                #     cur.execute(update_q)
                #     conn.commit()
            end = time.time()
            print("\tFinish Update %s in %s! Time cost: %s min\n"%(randomvector_prd_fields_list[j],
                                                                 random_vector_table,str((end-start)/60)))
