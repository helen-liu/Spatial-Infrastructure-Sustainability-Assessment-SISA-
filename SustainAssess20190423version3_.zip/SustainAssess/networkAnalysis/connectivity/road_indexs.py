# -*- coding: utf-8 -*-
import psycopg2
#import networkx as nx
from networkx import DiGraph,number_strongly_connected_components
import sys,os

def update_e(para_dic=None,conn=None,cur=None,update_field=None):

    if para_dic==None:
        arg1={
              'polygon_table':polygon_table,
              'edge_table':edge_table,
              'polygon_geom_field':polygon_geom_field,
              'edge_geom_field':edge_geom_field,
              'polygon_id_field':polygon_id_field,
              'update_field':"e"
              }
    else:
        arg1={'polygon_table':para_dic["polytable"]["schema"]+"."+para_dic["polytable"]["name"],
              'edge_table':para_dic["edge_table"]["schema"]+"."+para_dic["edge_table"]["name"],
              'polygon_geom_field':para_dic["polytable"]["geom"],
              'edge_geom_field':para_dic["edge_table"]["geom"],
              'polygon_id_field':para_dic["polytable"]["id"],
              'update_field':para_dic["update_fields"][update_field]
              }

    query1 = '''
        BEGIN;
        update %(polygon_table)s
        set %(update_field)s =0;
        
        update %(polygon_table)s
        set %(update_field)s = t3.total
        from (
            select t1.%(polygon_id_field)s as id, count(*) as total
            from %(polygon_table)s as t1 inner join %(edge_table)s as t2
            on st_intersects(t1.%(polygon_geom_field)s,t2.%(edge_geom_field)s)
            group by t1.%(polygon_id_field)s
        ) as t3
        where t3.id = %(polygon_table)s.%(polygon_id_field)s;
        END;
    '''% arg1
    try:
        cur.execute(query1)
    except psycopg2.ProgrammingError:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, exc_obj, exc_tb.tb_lineno)
        msg = str(exc_type)+str(exc_obj)+str(exc_tb.tb_lineno)
        return 0,msg
    conn.commit()
    msg = 'Update %(update_field)s Successfully!\n' % arg1
    return 1,msg

def update_v_old():
    arg1={'polygon_table':polygon_table,
          'node_table':node_table,
          'polygon_geom_field':polygon_geom_field,
          'node_geom_field':node_geom_field,
          'polygon_id_field':polygon_id_field
          }
    query1 = '''
        update %(polygon_table)s
        set v = t3.total
        from (
            select t1.%(polygon_id_field)s as id, count(*) as total
            from %(polygon_table)s as t1 left join %(node_table)s as t2
            on st_intersects(t1.%(polygon_geom_field)s,t2.%(node_geom_field)s)
            group by t1.%(polygon_id_field)s
        ) as t3
        where t3.id = %(polygon_table)s.%(polygon_id_field)s
    '''% arg1
    cur.execute(query1)
    conn.commit()
 
def update_v(para_dic=None,conn=None,cur=None,update_field=None):
    #because some edge end is out of the polygon, so it will be less when count directly using node table.
    #so here I use the edge table

    if para_dic==None:
        arg1={'polygon_table':polygon_table,
              'edge_table':edge_table,
              'polygon_geom_field':polygon_geom_field,
              'edge_geom_field':edge_geom_field,
              'polygon_id_field':polygon_id_field,
              'update_field': "v"
              }
    else:
        arg1={'polygon_table':para_dic["polytable"]["schema"]+"."+para_dic["polytable"]["name"],
              'edge_table':para_dic["edge_table"]["schema"]+"."+para_dic["edge_table"]["name"],
              'polygon_geom_field':para_dic["polytable"]["geom"],
              'edge_geom_field':para_dic["edge_table"]["geom"],
              'polygon_id_field':para_dic["polytable"]["id"],
              'update_field':para_dic["update_fields"][update_field]
              }
    # for each poly
    query3 = '''
            update %(polygon_table)s
            set %(update_field)s = 0;
            select %(polygon_id_field)s from %(polygon_table)s
            '''% arg1
    cur.execute(query3)
    rows = cur.fetchall()
    for row in rows:
        poly_id = row[0]
        arg1['poly_id'] = poly_id
        query1 = '''
                select t2.source as source,t2.target as target
                from 
                (select * from %(polygon_table)s where %(polygon_id_field)s=%(poly_id)s) as t1 inner join %(edge_table)s as t2
                on st_intersects(t1.%(polygon_geom_field)s,t2.%(edge_geom_field)s)
        '''% arg1
        cur.execute(query1)
        nodes = cur.fetchall()
        unique_list = []
        for node in nodes:
            if node[0] not in unique_list:
                unique_list.append(node[0])
            if node[1] not in unique_list:
                unique_list.append(node[1])
        
        num_ver = len(unique_list)
        arg1['num_ver'] = str(num_ver)
        update_query = '''
                        Begin;
                        update %(polygon_table)s
                        set %(update_field)s = %(num_ver)s
                        where %(polygon_id_field)s = %(poly_id)s;
                        End;
                        '''% arg1
        cur.execute(update_query)
        conn.commit()
    msg = 'Update %(update_field)s Successfully!\n'%arg1
    return 1, msg
    
def update_p(para_dic=None,conn=None,cur=None,update_field=None):

    if para_dic==None:
        arg1={'polygon_table':polygon_table,
              'edge_table':edge_table,
              'polygon_geom_field':polygon_geom_field,
              'edge_geom_field':edge_geom_field,
              'polygon_id_field':polygon_id_field,
              'update_field': "p",
              'source':"source",
              'target': "target",
              'dir':"dir"
              }
    else:
        arg1={'polygon_table':para_dic["polytable"]["schema"]+"."+para_dic["polytable"]["name"],
              'edge_table':para_dic["edge_table"]["schema"]+"."+para_dic["edge_table"]["name"],
              'polygon_geom_field':para_dic["polytable"]["geom"],
              'edge_geom_field':para_dic["edge_table"]["geom"],
              'polygon_id_field':para_dic["polytable"]["id"],
              'update_field':para_dic["update_fields"][update_field],
              'source': para_dic["edge_table"]["source"],
              'target': para_dic["edge_table"]["target"],
              'dir': para_dic["edge_table"]["dir"]
              }
    #get source_index, target_index, dir_index
    source_index, target_index, dir_index= -1, -1, -1
    query1 = '''
            SELECT *
            FROM information_schema.columns
            WHERE table_schema = '%(schema)s'
              AND table_name   = '%(name)s'
        '''%(para_dic["edge_table"])
    cur.execute(query1)
    rows = cur.fetchall()
    #get source_index
    index = -1
    for row in rows:
        index+=1
        if row[3]==arg1["source"]:
            source_index = index
        if row[3]==arg1["target"]:
            target_index = index
        if row[3]==arg1["dir"]:
            dir_index = index
    #get all polygon id and store them in id_list
    query1 = '''
        update %(polygon_table)s
        set %(update_field)s = 0;
        select id
        from %(polygon_table)s; 
    '''% arg1
    cur.execute(query1)
    rows = cur.fetchall()
    id_list = []
    for row in rows:
        id_list.append(row[0])
    
    #for each polygon calculate the p
    for mid in id_list:
        arg1['id'] = mid
        query2 = '''
                    drop table if exists temp_poly;
                    
                    select * into temp_poly from %(polygon_table)s where %(polygon_id_field)s=%(id)s;
                    
                    select t2.*
                    from temp_poly as t1 inner join %(edge_table)s as t2
                    on st_intersects(t1.%(polygon_geom_field)s,t2.%(edge_geom_field)s);
                    
                '''% arg1
        cur.execute(query2)
        edges = cur.fetchall()
        #d_network = nx.DiGraph()
        d_network = DiGraph()
        for e in edges:
            source = e[source_index]
            target = e[target_index]
            dir = e[dir_index]
            if dir=='B':
                d_network.add_edge(source,target)
                d_network.add_edge(target,source)
            if dir == 'FT':
                d_network.add_edge(source,target)
            if dir == 'TF':
                d_network.add_edge(target,source)
        #s_n = nx.number_strongly_connected_components(d_network)
        s_n = number_strongly_connected_components(d_network)
        arg1['p'] = s_n
        query_update = '''
                update %(polygon_table)s
                set %(update_field)s = %(p)s
                where %(polygon_id_field)s=%(id)s
                    '''% arg1
        cur.execute(query_update)
        conn.commit()
    msg = 'Update %(update_field)s Successfully!\n' % arg1
    return 1, msg

def update_gamma(para_dic=None,conn=None,cur=None,update_field=None):

    if para_dic==None:
        arg1={'polygon_table':polygon_table,
              'edge_table':edge_table,
              'polygon_geom_field':polygon_geom_field,
              'edge_geom_field':edge_geom_field,
              'polygon_id_field':polygon_id_field,
              "e":"e",
              "v":"v",
              "p":"p",
              'update_field': "gamma"
              }
    else:
        arg1={'polygon_table':para_dic["polytable"]["schema"]+"."+para_dic["polytable"]["name"],
              'edge_table':para_dic["edge_table"]["schema"]+"."+para_dic["edge_table"]["name"],
              'polygon_geom_field':para_dic["polytable"]["geom"],
              'edge_geom_field':para_dic["edge_table"]["geom"],
              'polygon_id_field':para_dic["polytable"]["id"],
              "e": para_dic["update_fields"]["e"],
              "v": para_dic["update_fields"]["v"],
              "p": para_dic["update_fields"]["p"],
              'update_field': para_dic["update_fields"][update_field],
              }
    query1 = '''
            select %(polygon_id_field)s,%(e)s,%(v)s,%(p)s from %(polygon_table)s; 
        '''%arg1
    cur.execute(query1)
    rows = cur.fetchall()
    for row in rows:
        pid,e,v,p = row
        gamma = float(e)/ float((3*(v -2)))
        arg1["pid"]=str(pid)
        arg1["gamma_value"] = str(gamma)
        query_update = '''
                    update %(polygon_table)s
                    set %(update_field)s = %(gamma_value)s
                    where %(polygon_id_field)s=%(pid)s
                    '''%arg1
        cur.execute(query_update)
        conn.commit()
    msg = 'Update %(update_field)s Successfully!\n' % arg1
    return 1, msg

def update_alpha(para_dic=None,conn=None,cur=None,update_field=None):

    if para_dic==None:
        arg1={'polygon_table':polygon_table,
              'edge_table':edge_table,
              'polygon_geom_field':polygon_geom_field,
              'edge_geom_field':edge_geom_field,
              'polygon_id_field':polygon_id_field,
              "e": "e",
              "v": "v",
              "p": "p",
              'update_field': "alpha"
              }
    else:
        arg1={'polygon_table':para_dic["polytable"]["schema"]+"."+para_dic["polytable"]["name"],
              'edge_table':para_dic["edge_table"]["schema"]+"."+para_dic["edge_table"]["name"],
              'polygon_geom_field':para_dic["polytable"]["geom"],
              'edge_geom_field':para_dic["edge_table"]["geom"],
              'polygon_id_field':para_dic["polytable"]["id"],
              "e": para_dic["update_fields"]["e"],
              "v": para_dic["update_fields"]["v"],
              "p": para_dic["update_fields"]["p"],
              'update_field': para_dic["update_fields"][update_field],
              }
    query1 = '''
            select %(polygon_id_field)s,%(e)s,%(v)s,%(p)s from %(polygon_table)s; 
        '''%arg1
    cur.execute(query1)
    rows = cur.fetchall()
    for row in rows:
        pid,e,v,p = row
        alpha = float(e - v + p)/float(2*v -5)
        arg1["pid"]=str(pid)
        arg1["alpha_value"] = str(alpha)
        query_update = '''
                    update %(polygon_table)s
                    set %(update_field)s = %(alpha_value)s
                    where %(polygon_id_field)s=%(pid)s
                    '''% arg1
        cur.execute(query_update)
        conn.commit()
    msg = 'Update %(update_field)s Successfully!\n' % arg1
    return 1, msg

def update_beta(para_dic=None,conn=None,cur=None,update_field=None):
    if para_dic==None:
        arg1={'polygon_table':polygon_table,
              'edge_table':edge_table,
              'polygon_geom_field':polygon_geom_field,
              'edge_geom_field':edge_geom_field,
              'polygon_id_field':polygon_id_field,
              "e": "e",
              "v": "v",
              "p": "p",
              'update_field': "beta"
              }
    else:
        arg1={'polygon_table':para_dic["polytable"]["schema"]+"."+para_dic["polytable"]["name"],
              'edge_table':para_dic["edge_table"]["schema"]+"."+para_dic["edge_table"]["name"],
              'polygon_geom_field':para_dic["polytable"]["geom"],
              'edge_geom_field':para_dic["edge_table"]["geom"],
              'polygon_id_field':para_dic["polytable"]["id"],
              "e": para_dic["update_fields"]["e"],
              "v": para_dic["update_fields"]["v"],
              "p": para_dic["update_fields"]["p"],
              'update_field': para_dic["update_fields"][update_field],
              }
    query1 = '''
            select %(polygon_id_field)s,%(e)s,%(v)s,%(p)s from %(polygon_table)s; 
        '''%arg1
    cur.execute(query1)
    rows = cur.fetchall()
    for row in rows:
        pid,e,v,p= row
        beta = float(e)/(float(v)+0.000001)
        arg1["pid"]=str(pid)
        arg1["beta_value"] = str(beta)
        query_update = '''
                    update %(polygon_table)s
                    set %(update_field)s = %(beta_value)s
                    where %(polygon_id_field)s=%(pid)s
                    '''% arg1
        cur.execute(query_update)
        conn.commit()
    msg = 'Update %(update_field)s Successfully!\n' % arg1
    return 1, msg

if __name__ == "__main__":
    #before update, you need to add column yourself
    #e: numeric v: numeric p: numeric
    #alter table atlanta.regionbyway add column e numeric, add column v numeric, add column p numeric;
    # ### the input variable of the program
    # polygon_table = 'atlanta.regionbyway' #'schema.tablename'
    # polygon_geom_field = 'geom' #geom field's name in polygon table
    # polygon_id_field = 'id'
    # edge_table = 'atlanta.rdways_285'
    # edge_geom_field = 'geom_epsg3520'
    # node_table = 'atlanta.rdways_285_vertices_pgr'
    # node_geom_field = 'the_geom'
    # dir_index = 20
    # # Create a new database connectiong:
    # server,dbname,user,password = 'localhost','atlanta_routing','postgres','liu'

    ### the input variable of the program
    database_schema = 'alt_2'
    polygon_table = 'slsbig.tract14_285'  # 'schema.tablename'
    polygon_geom_field = 'geom'  # geom field's name in polygon table
    polygon_id_field = 'id'
    edge_table = 'roadnetwork_home'
    edge_geom_field = 'geom_epsg3520'
    node_table = 'slsbig.rdways_vertices_pgr'
    node_geom_field = 'the_geom'

    source_index = 4
    target_index = 5
    dir_index = 24  ## the index of 'direction' field in the edge table, index starts 0

    # Create a new database connectiong:
    server, dbname, user, password = 'localhost', 'alt_routing', 'postgres', 'liu'

    ### the program body
    conn = psycopg2.connect("dbname=%s user=%s password=%s" % (dbname, user, password))
    cur = conn.cursor()

    '''
    count the number of road inside the specific polygon
    input parameter:
        arg1: dict, containi the polygon table, edge table, edge_geom_field, polygon_id_field
    return:
        if success: return 1,"success".
        if failed: return 0,error message.
    '''
    update_e()
    update_v()
    update_p()
    
    #alter table atlanta.regionbyway add column alpha numeric, add column gamma numeric, add column beta numeric;
    update_gamma()
    update_alpha()
    update_beta()
    