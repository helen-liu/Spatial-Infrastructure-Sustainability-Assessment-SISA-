# -*- coding: utf-8 -*-

##TODO: read the code and update the fuunction names to make it more general

import sys
import psycopg2
import time

# radius to find parks
#FIND_RADIUS = 5000
FIND_RADIUS = 800


def find_the_nearest_node2(in_point,args,cur=None,conn=None):
    #s = time.time()
    cur.execute('''
        select st_x(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s)),
               st_y(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s))
        '''%(str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid'],
             str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid']))
    row1 = cur.fetchone()
    layer_point = [row1[0],row1[1]]  ## in_point
    
    args['x'] = layer_point[0]
    args['y'] = layer_point[1]
    args['minx'] = layer_point[0] - FIND_RADIUS
    args['miny'] = layer_point[1] - FIND_RADIUS
    args['maxx'] = layer_point[0] + FIND_RADIUS
    args['maxy'] = layer_point[1] + FIND_RADIUS
    
    # Getting nearest source,, node_table is the nodes for the road network
    query1 = """
    SELECT id,
        ST_Distance(
            the_geom,
            ST_GeomFromText('POINT(%(x)f %(y)f)', %(srid)d)
        ) AS dist
        FROM %(node_table)s
        WHERE ST_SetSRID('BOX3D(%(minx)f %(miny)f, %(maxx)f %(maxy)f)'::BOX3D, %(srid)d)
            && the_geom ORDER BY dist ASC LIMIT 1""" % args
    
    cur.execute(query1)
    row1 = cur.fetchone()
    if row1 is None:
        return -1,-1
    
    if len(row1) > 0:
        node_id,distance = row1[0],row1[1]
    else:
        node_id,distance = -1,-1        
#     end = time.time()
#     print '        find_the_nearest_node2:'+str(end - s)
    return node_id,distance


def find_the_10nearest_polynodes(in_point,args,cur=None,conn=None):
    cur.execute('''
        select st_x(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s)),
               st_y(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s))
        '''%(str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid'],
             str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid']))
    row1 = cur.fetchone()
    layer_point = [row1[0],row1[1]]
    
    args['x'] = layer_point[0]
    args['y'] = layer_point[1]
    args['minx'] = layer_point[0] - FIND_RADIUS
    args['miny'] = layer_point[1] - FIND_RADIUS
    args['maxx'] = layer_point[0] + FIND_RADIUS
    args['maxy'] = layer_point[1] + FIND_RADIUS
    
    # Getting nearest source
    query1 = """
    SELECT id,
        st_astext(geom),
        ST_Distance(
            geom,
            ST_GeomFromText('POINT(%(x)f %(y)f)', %(srid)d)
        ) AS dist
        FROM %(parknode_table)s
        WHERE ST_SetSRID('BOX3D(%(minx)f %(miny)f, %(maxx)f %(maxy)f)'::BOX3D, %(srid)d)
            && geom ORDER BY dist ASC LIMIT 10""" % args
    
    cur.execute(query1)
    rows = cur.fetchall()
    return rows

def find_the_nearest_polygon(inpoint,args,cur=None,conn=None):
    #find 10 nearest polygon,points=[(id,'POINT(x,y)',dis),(id,'POINT(x,y)',dis),...]
    points=find_the_10nearest_polynodes(inpoint,args,cur,conn)
    
    #for each points, calculate the dijkstra distance
    nearest_id = -1
    dis = 999999
    if len(points) > 0 :
        source_node,dis_s_point2node = find_the_nearest_node2(inpoint,args,cur,conn)
        poly_id_list = []
        poly_id_notlist = []
        for p in points:
            id = p[0]
            x,y = str(p[1]).replace('POINT(','').replace(')','').split()
            point=[float(x),float(y),args['srid']]
            target_node,dis_t_point2node= find_the_nearest_node2(point,args,cur,conn)
            args['source'] = str(source_node)
            args['target'] = str(target_node)
            query2 = """SELECT * FROM pgr_dijkstra('SELECT %(id_field)s AS id, %(source_field)s as source, 
                                                    %(target_field)s target, %(cost_field)s as cost, 
            %(reverse_cost_field)s as reverse_cost FROM %(edge_table)s ',%(source)s,%(target)s, true)"""% args
            cur.execute(query2)
            rows = cur.fetchall()
            try:
                actual_route_distance =  rows[-1][5] + dis_t_point2node + dis_s_point2node
            except:
                actual_route_distance = -1000
            if actual_route_distance < dis:
                dis = actual_route_distance
                nearest_id = id
    else:
        actual_route_distance = -1000

    #select out the area
    area = 0
    if actual_route_distance>0:
        query_area = """select area from %s
                        where id = '%s'
        """%(args["parknode_table"],str(nearest_id))
        cur.execute(query_area)
        rows = cur.fetchall()
        try:
            area = float(rows[0][0])
        except:
            area = -1000

    #returen the distance of the point to polygon
    return nearest_id,actual_route_distance,area
    
"""
accessibility to parks of parcel j is:
accessibility_j = sum_i(area_park_i/(distance2_park_i ^2)), i = {1,2,...,n_j}
n_j = number of parks parcel j can access within 800 meters radium.
distance2_park_i is the route (real) distance of parcel j to park i

"""
def calc_accessibility(point,args,cur=None,conn=None):
    #point: [lon,lat,3520]
    s = time.time()
    id,dis,area = find_the_nearest_polygon(point, args,cur,conn)
    t = time.time()
    #print("calc_accessibilityt"+str(t - s))
    return id,dis,area

def update_accessibility_field(para_dic=None,cur=None,conn=None):
    # self.para_dic = {"park": {"schema": "", "name": "", "id":"","geom": "", "crs": ""},
    #                  "road_edge": {"schema": "", "name": "", "id":"","geom": "", "crs": "",
    #                                 "source":"", "target":"", "cost":"", "rv_cost":""},
    #                  "road_node": {"schema": "", "name": "", "id":"","geom": "", "crs": ""},
    #                  "random_point": {"schema": "", "name": "", "geom": "", "crs": "",
    #                                   "accessibility":"", "parkID":"","area_sum":""},
    #                  "msg": ""
    #                  }
    #create a temp points table (polygon --> points)
    random_vector_table = para_dic["random_point"]["schema"]+"."+para_dic["random_point"]["name"]
    arg1 = {'parktable':para_dic["park"]["schema"]+"."+para_dic["park"]["name"],
            'parktable_id':para_dic["park"]["id"],
           'parktable_geom':para_dic["park"]["geom"],
            'parknode_table':para_dic["park"]["schema"]+"."+para_dic["park"]["name"]+"_tempnode",
            'to_srid':para_dic["road_edge"]["crs"]}
    query_poly2points = '''
                     drop table if exists %(parknode_table)s;
                       SELECT g.%(parktable_id)s as id,
                            ST_Transform((ST_DumpPoints(g.%(parktable_geom)s)).geom,%(to_srid)s) as geom,
                            st_area(st_transform(%(parktable_geom)s,%(to_srid)s)) as area 
                             into %(parknode_table)s
                      FROM
                        (SELECT * from %(parktable)s
                        ) AS g
                    '''% arg1
             
    cur.execute(query_poly2points)
    #update accessibility
    #use the start point of random vector as the input point

    query = '''
                select id,st_astext(%(geom)s),st_srid(%(geom)s)
                from %(schema)s.%(name)s
                    '''%(para_dic["random_point"])
    cur.execute(query)
    rows = cur.fetchall()
    
    poly_id_list=[]
    poly_id_notlist = []
    
    for row in rows:
        id = row[0]
        x,y = str(row[1]).replace('POINT(','').replace(')','').split()
        startpoint=[float(x),float(y),int(row[2])]
        args={}
        #edge table and its fields
        args['edge_table'] = para_dic["road_edge"]["schema"]+"."+para_dic["road_edge"]["name"]
        args['id_field'] = para_dic["road_edge"]["id"]
        args['source_field'] = para_dic["road_edge"]["source"]
        args['target_field'] = para_dic["road_edge"]["target"]
        args['geometry'] = para_dic["road_edge"]["geom"]
        args['srid'] = para_dic["road_edge"]["crs"]
        args['cost_field'] = para_dic["road_edge"]["cost"]
        args['reverse_cost_field'] = para_dic["road_edge"]["rv_cost"]
        
        #node table and its fields
        args['node_table'] = para_dic["road_node"]["schema"]+"."+para_dic["road_node"]["name"]
        
        #temp park nodes table
        args['parknode_table'] = arg1["parknode_table"]
        args['park_crs']=para_dic["park"]["crs"]
        args['from_srid'] = startpoint[2]
        poly_id,accessiblity_v,area = calc_accessibility(startpoint,args,cur,conn)
        
        update_q = '''
                update %s
                set %s = %s,
                 %s_id = %s,
                 %s_area = %s
                where id = %s
                    ''' % (random_vector_table,
                           para_dic["random_point"]["accessibility"],str(accessiblity_v),
                           para_dic["random_point"]["accessibility"],str(poly_id),
                           para_dic["random_point"]["accessibility"],str(area),
                           str(id))
        cur.execute(update_q)
        conn.commit()
    return 1,"GOOD!"


##TODO: read the code and update the fuunction names to make it more general
"""
Calculate the number of parks one can access within specified meters radius 
(800m for parks, 3200m for hospitals).

"""
def calc_number_parks_within(in_point,args,cur=None,conn=None):
#     start = time.time()
    FIND_RADIUS_NUM_PARKS = args["radius"]
    cur.execute('''
        select st_x(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s)),
               st_y(st_transform(st_geomfromtext('POINT(%s %s)',%s),%s))
        '''%(str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid'],
             str(in_point[0]),str(in_point[1]),args['from_srid'],args['srid']))
    row1 = cur.fetchone()
    layer_point = [row1[0],row1[1]]
    
    args['x'] = layer_point[0]
    args['y'] = layer_point[1]
    args['minx'] = layer_point[0] - FIND_RADIUS_NUM_PARKS
    args['miny'] = layer_point[1] - FIND_RADIUS_NUM_PARKS
    args['maxx'] = layer_point[0] + FIND_RADIUS_NUM_PARKS
    args['maxy'] = layer_point[1] + FIND_RADIUS_NUM_PARKS
    
    query_time_s = time.time()
    # Getting nearest source
    # parknode_table is the points on the boundary of each park polygon
    query1 = """
    SELECT id,
        st_astext(geom),
        ST_Distance(
            geom,
            ST_GeomFromText('POINT(%(x)f %(y)f)', %(srid)d)
        ) AS dist,
        area
        FROM %(parknode_table)s
        WHERE ST_SetSRID('BOX3D(%(minx)f %(miny)f, %(maxx)f %(maxy)f)'::BOX3D, %(srid)d)
            && geom ORDER BY dist ASC""" % args
    
    cur.execute(query1)
    rows = cur.fetchall()
    query_time_t = time.time()
    #print('        query:'+str(query_time_t - query_time_s))
    poly_id_list=[]
    poly_area_list = []
    poly_access_list = []
    poly_route_dist_list = []
    poly_id_notlist = []
    target_node_list = []
    ### find the nearest road node (in the road network) to point 'in_point' as source_node
    source_node,dis_s_point2node = find_the_nearest_node2(in_point,args,cur,conn)

    for row in rows:
        myID = int(row[0])
        myPoint = row[1]
        myArea = row[3]

        if (myID not in poly_id_list) and (myID not in poly_id_notlist):
            x,y = str(myPoint).replace('POINT(','').replace(')','').split()
            myCurPoint = [float(x),float(y),args['srid']]
            ### find the nearest road node (in the road network) to point 'myCurPoint' as the target_node
            target_node,dis_t_point2node= find_the_nearest_node2(myCurPoint,args,cur,conn)
            target_node_list.append(target_node)

            ## find the shorest route distance between source_node and target_node using dijkstra algorithm
            args['source'] = source_node
            args['target'] = target_node
            query2 = """SELECT * FROM pgr_dijkstra('SELECT %(id_field)s AS id, %(source_field)s as source, 
                        %(target_field)s target, %(cost_field)s as cost,%(reverse_cost_field)s as reverse_cost 
                        FROM %(edge_table)s ',%(source)s,%(target)s, true)"""% args
            cur.execute(query2)
            query2_results = cur.fetchall()
            try:
                ## query2_results[-1][5] is the shorest route distance between source_node and target_node
                dist_dijkstra_s2t = query2_results[-1][5]
                actual_route_distance = dist_dijkstra_s2t  + dis_t_point2node + dis_s_point2node
            except:
                actual_route_distance = -1000

            #calculate accessibility:  area/ dist^2
            if actual_route_distance > 0:
                poly_id_list.append(myID)
                poly_route_dist_list.append(actual_route_distance)
                if myArea < 0:
                    raise "area should be larger than or equal to 0!"
                elif myArea > -0.5 and myArea < 0.5 :
                    ## if the access object is point, only distance and number of facilities is considered
                    ### only keep fist 6 digits after decimal
                    ### myArea = int(myArea * pow(10, 6)) / pow(10, 6)
                    myArea = 0.0
                    poly_area_list.append(myArea)
                    myAccess = 1.0 * pow(10, 6) / pow(actual_route_distance, 2)      ## multiply by 10^6 to convert area unit to km^2
                    poly_access_list.append(myAccess)
                else:
                    poly_area_list.append(myArea)
                    myAccess = myArea / pow(actual_route_distance, 2)
                    poly_access_list.append(myAccess)
            else:
                ### cannot find shorest distance
                poly_id_notlist.append(myID)

#            if actual_route_distance > 0 and actual_route_distance < FIND_RADIUS_NUM_PARKS:
#                poly_id_list.append(myID)
#                if myArea < 0:
#                    raise "area should be larger than 0!"
#                poly_area_list.append(myArea)
#            else:
#                poly_id_notlist.append(myID)


#     end = time.time()
#     print 'calc_number_parks_within :'+str(end - start)

    return poly_id_list,len(poly_id_list),poly_area_list,poly_access_list, poly_route_dist_list, target_node_list



##TODO: read the code and update the fuunction names to make it more general
def update_parks_number_field(para_dic=None, cur=None, conn=None):
    # self.para_dic = {"park": {"schema": "", "name": "", "id":"","geom": "", "crs": ""},
    #                  "road_edge": {"schema": "", "name": "", "id":"","geom": "", "crs": "",
    #                                 "source":"", "target":"", "cost":"", "rv_cost":""},
    #                  "road_node": {"schema": "", "name": "", "id":"","geom": "", "crs": ""},
    #                  "random_point": {"schema": "", "name": "", "geom": "", "crs": "",
    #                                   "radius":"", "f_parklist":""},
    #                  "msg": ""
    #                  }
    #create a temp points table (polygon --> points)
    random_vector_table = para_dic["random_point"]["schema"] + "." + para_dic["random_point"]["name"]
    arg1 = {'parktable': para_dic["park"]["schema"] + "." + para_dic["park"]["name"],
            'parktable_id': para_dic["park"]["id"],
            'parktable_geom': para_dic["park"]["geom"],
            'parknode_table': para_dic["park"]["schema"] + "." + para_dic["park"]["name"] + "_tempnode",
            'to_srid': para_dic["road_edge"]["crs"]}
    query_poly2points = '''
                     drop table if exists %(parknode_table)s;
                       SELECT g.%(parktable_id)s,
                            ST_Transform((ST_DumpPoints(g.%(parktable_geom)s)).geom,%(to_srid)s) as geom,
                            st_area(st_transform(%(parktable_geom)s,%(to_srid)s)) as area 
                             into %(parknode_table)s
                      FROM
                        (SELECT * from %(parktable)s
                        ) AS g
                    ''' % arg1

    cur.execute(query_poly2points)
    #update num_parks
    #use the start point of random vector as the input point
    query = '''
                select id,st_astext(%(geom)s),st_srid(%(geom)s)
                from %(schema)s.%(name)s
                    '''%(para_dic["random_point"])
    cur.execute(query)
    rows = cur.fetchall()
    for row in rows:
        id = row[0]
        # #### test the code by ML
        # if id == 5539:
        #     print 'check here'
        # else:
        #     continue

        x,y = str(row[1]).replace('POINT(','').replace(')','').split()
        startpoint=[float(x),float(y),int(row[2])]
        args={}
        #edge table and its fields
        args['edge_table'] = para_dic["road_edge"]["schema"] + "." + para_dic["road_edge"]["name"]
        args['id_field'] = para_dic["road_edge"]["id"]
        args['source_field'] = para_dic["road_edge"]["source"]
        args['target_field'] = para_dic["road_edge"]["target"]
        args['geometry'] = para_dic["road_edge"]["geom"]
        args['srid'] = para_dic["road_edge"]["crs"]
        args['cost_field'] = para_dic["road_edge"]["cost"]
        args['reverse_cost_field'] = para_dic["road_edge"]["rv_cost"]

        # node table and its fields
        args['node_table'] = para_dic["road_node"]["schema"] + "." + para_dic["road_node"]["name"]

        # temp park nodes table
        args['parknode_table'] = arg1["parknode_table"]
        args['park_crs'] = para_dic["park"]["crs"]
        args['from_srid'] = startpoint[2]
        args["radius"] = para_dic["random_point"]["radius"]
        
        poly_id_list, num, poly_area_list, poly_access_list, route_dist_list, target_node_list  = calc_number_parks_within(startpoint,args,cur,conn)

        # print 'finish calculte access'
        # print '[%s]' % ', '.join(map(str, poly_id_list))
        # print '\n'
        # print '[%s]' % ', '.join(map(str, poly_access_list))
        # print '\n'
        # print '[%s]' % ', '.join(map(str, route_dist_list))
        # print '\n'
        # print '[%s]' % ', '.join(map(str, target_node_list))

        ## update the random vector table, put cur_totalAccess for each of them.
        update_q = '''
                update %s
                set %s = '%s',
                %s_nums = %s,
                %s_areas = %s,
                %s_access = %s
                where id = %s
                    '''%(random_vector_table,
                         para_dic["random_point"]["f_parklist"],str(poly_id_list),
                         para_dic["random_point"]["f_parklist"],str(num),
                         para_dic["random_point"]["f_parklist"],str(sum(poly_area_list)),
                         para_dic["random_point"]["f_parklist"], str(sum(poly_access_list)),
                         str(id))
        cur.execute(update_q)
        conn.commit()
#     end = time.time()
#     print 'update_parks_number_field :'+str(end - start)
    return 1,"Update %s Sucessfully!"%para_dic["random_point"]["f_parklist"]

if __name__ == "__main__":
    #first, create a column name accessiblity,polyid
    #alter table sls.random_vector add column accessiblity numeric; 
    #alter table sls.random_vector add column accessiblity_id integer;
    #alter table sls.random_vector add column accessiblity_area integer;

    schema = 'slsbig'
    # parking polygon table and nodes table
    parktable = schema + '.park_dtl_285'
    parktable_id = 'id'
    parktable_geom = 'the_geom'

    parknode_table = schema + '.temp_poly2points_500'

    # road edge table and its fields
    edge_table = schema + '.rdways'
    random_vector_table = schema + '.random_vector_500'
    id_field = 'gid'
    source_field = 'source'
    target_field = 'target'
    cost_field = 'cost'
    reverse_cost_field = 'reverse_cost'
    geom_field = 'geom_epsg3520'
    srid = 3520
    # road nodes table
    node_table = schema + '.rdways_vertices_pgr'

    # radius to find parks, unit in meters, same as coordinate system of the source layer
    FIND_RADIUS = 800

    # radius to find number of parks, unit in meters, same as coordinate system of the source layer
    FIND_RADIUS_NUM_PARKS = 800   ## 800 meters is the maximum service area of a park, based on park design

    try:
        con_str = "dbname='atlanta_285' user='postgres' host='localhost' password='mliu0727'"
        print(con_str)
        conn = psycopg2.connect(con_str)
        cur = conn.cursor()
    except:
        print("I am unable to connect to the database")
    ##update_accessibility_field()
    ## ##TODO: read the code and update the fuunction names to make it more general
    update_parks_number_field()

