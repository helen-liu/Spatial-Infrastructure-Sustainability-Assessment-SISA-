# -*- coding: utf-8 -*-
# modified by liu, add save to input, i.e, create new field in the input file,
# use with class OutputVector_liu in outputs

import re
import os

from qgis.PyQt import uic
from qgis.PyQt.QtCore import QCoreApplication, QSettings
from qgis.PyQt.QtWidgets import QDialog, QMenu, QAction, QFileDialog
from qgis.PyQt.QtGui import QCursor
from qgis.gui import QgsEncodingFileDialog, QgsExpressionBuilderDialog
from qgis.core import (QgsDataSourceUri,QgsProject,
                       QgsCredentials,
                       QgsExpressionContext,
                       QgsExpressionContextUtils,
                       QgsExpression,
                       QgsExpressionContextScope)

from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.outputs import OutputVector
from SustainAssess.core.outputs import OutputVector_liu
from SustainAssess.core.outputs import OutputDirectory
from SustainAssess.gui.PostgisTableSelector import PostgisTableSelector
from qgis.utils import iface

pluginPath = os.path.split(os.path.dirname(__file__))[0]
WIDGET, BASE = uic.loadUiType(
    os.path.join(pluginPath, 'ui', 'widgetBaseSelector.ui'))


class OutputSelectionPanelextension(BASE, WIDGET):

    SAVE_TO_TEMP_FILE = QCoreApplication.translate(
        'OutputSelectionPanel', '[Save to temporary file]')
    SAVE_TO_TEMP_LAYER = QCoreApplication.translate(
        'OutputSelectionPanel', '[Create temporary layer]')

    def __init__(self, output, alg):
        super(OutputSelectionPanelextension, self).__init__(None)
        self.setupUi(self)

        self.output = output
        self.alg = alg

        if hasattr(self.leText, 'setPlaceholderText'):
            if isinstance(output, OutputVector_liu) \
                    and alg.provider.supportsNonFileBasedOutput():
                # use memory layers for temporary files if supported
                self.leText.setPlaceholderText(self.SAVE_TO_TEMP_LAYER)
            else:
                self.leText.setPlaceholderText(self.SAVE_TO_TEMP_FILE)

        self.btnSelect.clicked.connect(self.selectOutput)

    def selectOutput(self):
        if isinstance(self.output, OutputDirectory):
            self.selectDirectory()
        else:
            popupMenu = QMenu()

            if isinstance(self.output, OutputVector_liu) \
                    and self.alg.provider.supportsNonFileBasedOutput():
                # use memory layers for temporary files if supported
                actionSaveToTempFile = QAction(
                    self.tr('Create Temporary Layer'), self.btnSelect)
                actionSavetoInput = QAction(
                    self.tr('Save to the Input Layer...'), self.btnSelect)
            else:
                actionSaveToTempFile = QAction(
                    self.tr('Save to a Temporary File'), self.btnSelect)
            actionSaveToTempFile.triggered.connect(self.saveToTemporaryFile)
            popupMenu.addAction(actionSaveToTempFile)

            actionSavetoInput.triggered.connect(self.saveToInput)
            popupMenu.addAction(actionSavetoInput)

            actionSaveToFile = QAction(
                self.tr('Save to File...'), self.btnSelect)
            actionSaveToFile.triggered.connect(self.selectFile)
            popupMenu.addAction(actionSaveToFile)

            if isinstance(self.output, OutputVector_liu) \
                    and self.alg.provider.supportsNonFileBasedOutput():
                actionSaveToSpatialite = QAction(
                    self.tr('Save to SpatiaLite Table...'), self.btnSelect)
                actionSaveToSpatialite.triggered.connect(self.saveToSpatialite)
                popupMenu.addAction(actionSaveToSpatialite)
                actionSaveToPostGIS = QAction(
                    self.tr('Save to PostGIS Table...'), self.btnSelect)
                actionSaveToPostGIS.triggered.connect(self.saveToPostGIS)
                if hasattr(iface, "standalone"):
                    settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                         QSettings.NativeFormat)
                else:
                    settings = QSettings()
                settings.beginGroup('/PostgreSQL/connections/')
                names = settings.childGroups()
                settings.endGroup()
                actionSaveToPostGIS.setEnabled(bool(names))
                popupMenu.addAction(actionSaveToPostGIS)

            actionShowExpressionsBuilder = QAction(
                self.tr('Use Expression...'), self.btnSelect)
            actionShowExpressionsBuilder.triggered.connect(self.showExpressionsBuilder)
            popupMenu.addAction(actionShowExpressionsBuilder)

            popupMenu.exec_(QCursor.pos())
    def saveToInput(self):
        self.leText.setText('Save to Input Layer')

    def showExpressionsBuilder(self):
        dlg = QgsExpressionBuilderDialog(None, self.leText.text(), self, 'generic', self.expressionContext())
        dlg.setWindowTitle(self.tr('Expression based output'))
        if dlg.exec_() == QDialog.Accepted:
            self.leText.setText(dlg.expressionText())

    def expressionContext(self):
        context = QgsExpressionContext()
        context.appendScope(QgsExpressionContextUtils.globalScope())
        context.appendScope(QgsExpressionContextUtils.projectScope(QgsProject.instance()))
        processingScope = QgsExpressionContextScope()
        for param in self.alg.parameters:
            processingScope.setVariable('%s_value' % param.name, '')
        context.appendScope(processingScope)
        return context

    def saveToTemporaryFile(self):
        self.leText.setText('')

    def saveToPostGIS(self):
        dlg = PostgisTableSelector(self, self.output.name.lower())
        dlg.exec_()
        if dlg.connection:
            if hasattr(iface,"standalone"):
                settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                     QSettings.NativeFormat)
            else:
                settings = QSettings()
            mySettings = '/PostgreSQL/connections/' + dlg.connection
            dbname = settings.value(mySettings + '/database')
            user = settings.value(mySettings + '/username')
            host = settings.value(mySettings + '/host')
            port = settings.value(mySettings + '/port')
            password = settings.value(mySettings + '/password')
            uri = QgsDataSourceUri()
            uri.setConnection(host, str(port), dbname, user, password)
            uri.setDataSource(dlg.schema, dlg.table,
                              "the_geom" if self.output.hasGeometry() else None)

            connInfo = uri.connectionInfo()
            (success, user, passwd) = QgsCredentials.instance().get(connInfo, None, None)
            if success:
                QgsCredentials.instance().put(connInfo, user, passwd)
            self.leText.setText("postgis:" + uri.uri())

    def saveToSpatialite(self):
        fileFilter = self.output.tr('Spatialite files(*.sqlite)', 'OutputFile')

        if hasattr(iface, "standalone"):
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            settings = QSettings()
        if settings.contains('/Processing/LastOutputPath'):
            path = settings.value('/Processing/LastOutputPath')
        else:
            path = ProcessingConfig.getSetting(ProcessingConfig.OUTPUT_FOLDER)

        encoding = settings.value('/Processing/encoding', 'System')
        fileDialog = QgsEncodingFileDialog(
            self, self.tr('Save Spatialite'), path, fileFilter, encoding)
        fileDialog.setFileMode(QFileDialog.AnyFile)
        fileDialog.setAcceptMode(QFileDialog.AcceptSave)
        fileDialog.setOption(QFileDialog.DontConfirmOverwrite, True)

        if fileDialog.exec_() == QDialog.Accepted:
            files = fileDialog.selectedFiles()
            encoding = str(fileDialog.encoding())
            self.output.encoding = encoding
            fileName = str(files[0])
            selectedFileFilter = str(fileDialog.selectedNameFilter())
            if not fileName.lower().endswith(
                    tuple(re.findall("\*(\.[a-z]{1,10})", fileFilter))):
                ext = re.search("\*(\.[a-z]{1,10})", selectedFileFilter)
                if ext:
                    fileName += ext.group(1)
            settings.setValue('/Processing/LastOutputPath',
                              os.path.dirname(fileName))
            settings.setValue('/Processing/encoding', encoding)

            uri = QgsDataSourceUri()
            uri.setDatabase(fileName)
            uri.setDataSource('', self.output.name.lower(),
                              'the_geom' if self.output.hasGeometry() else None)# setDataSource(schema,table,geom)
            self.leText.setText("spatialite:" + uri.uri())

    def selectFile(self):
        fileFilter = self.output.getFileFilter(self.alg)

        if hasattr(iface, "standalone"):
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            settings = QSettings()
        if settings.contains('/Processing/LastOutputPath'):
            path = settings.value('/Processing/LastOutputPath')
        else:
            path = ProcessingConfig.getSetting(ProcessingConfig.OUTPUT_FOLDER)

        encoding = settings.value('/Processing/encoding', 'System')
        fileDialog = QgsEncodingFileDialog(
            self, self.tr('Save file'), path, fileFilter, encoding)
        fileDialog.setFileMode(QFileDialog.AnyFile)
        fileDialog.setAcceptMode(QFileDialog.AcceptSave)
        fileDialog.setOption(QFileDialog.DontConfirmOverwrite, False)

        if fileDialog.exec_() == QDialog.Accepted:
            files = fileDialog.selectedFiles()
            encoding = str(fileDialog.encoding())
            self.output.encoding = encoding
            fileName = str(files[0])
            selectedFileFilter = str(fileDialog.selectedNameFilter())
            if not fileName.lower().endswith(
                    tuple(re.findall("\*(\.[a-z]{1,10})", fileFilter))):
                ext = re.search("\*(\.[a-z]{1,10})", selectedFileFilter)
                if ext:
                    fileName += ext.group(1)
            self.leText.setText(fileName)
            settings.setValue('/Processing/LastOutputPath',
                              os.path.dirname(fileName))
            settings.setValue('/Processing/encoding', encoding)

    def selectDirectory(self):
        lastDir = ''
        dirName = QFileDialog.getExistingDirectory(self, self.tr('Select directory'),
                                                   lastDir, QFileDialog.ShowDirsOnly)
        self.leText.setText(dirName)

    def getValue(self):
        fileName = str(self.leText.text())
        context = self.expressionContext()
        exp = QgsExpression(fileName)
        if not exp.hasParserError():
            result = exp.evaluate(context)
            if not exp.hasEvalError():
                fileName = result
                if fileName.startswith("[") and fileName.endswith("]"):
                    fileName = fileName[1:-1]
        if fileName.strip() in ['', self.SAVE_TO_TEMP_FILE, self.SAVE_TO_TEMP_LAYER]:
            if isinstance(self.output, OutputVector_liu) \
                    and self.alg.provider.supportsNonFileBasedOutput():
                # use memory layers for temporary files if supported
                value = 'memory:'
            else:
                value = None
        elif fileName.strip() == "Save to Input Layer":
            value = "save2input:"
        elif fileName.startswith('memory:'):
            value = fileName
        elif fileName.startswith('postgis:'):
            value = fileName
        elif fileName.startswith('spatialite:'):
            value = fileName
        elif not os.path.isabs(fileName):
            value = ProcessingConfig.getSetting(
                ProcessingConfig.OUTPUT_FOLDER) + os.sep + fileName
        else:
            value = fileName

        return value
