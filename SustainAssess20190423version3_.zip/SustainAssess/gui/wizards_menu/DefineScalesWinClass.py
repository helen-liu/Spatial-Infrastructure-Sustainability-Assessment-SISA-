# -*- coding: utf-8 -*-
from PyQt4 import QtCore, QtGui
from DefineScales_UI import Ui_DefineScales
import os,sys
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class DefineScalesWin(QtGui.QDialog):
    def __init__(self,parent=None,connection_dic=None):
        QtGui.QDialog.__init__(self, parent=None)
        self.gotoWin = 2
        self.ui = Ui_DefineScales()
        self.my_parent = parent
        self.ui.setupUi(self)
        self.setup_signals()
        self.setup_scales()
        # Set default value for each combo box, which is selected scales last time user use this system

    def parent(self):
        return self.my_parent

    def setup_signals(self):
        QtCore.QObject.connect(self.ui.bt_Exit, QtCore.SIGNAL("clicked()"), self.click_exit)
        QtCore.QObject.connect(self.ui.bt_Next, QtCore.SIGNAL("clicked()"), self.click_next)
        QtCore.QObject.connect(self.ui.cb_Object, QtCore.SIGNAL("clicked()"), self.click_GotoWin_Object)
        QtCore.QObject.connect(self.ui.cb_Indicators, QtCore.SIGNAL("clicked()"), self.click_GotoWin_Indicators)

    '''
        Setup_scales() : define all the available values in each dropdown list.
        (1) Spatial scales
        (2) Temporal scales
    '''
    def setup_scales(self):
        # Set Up Available Values in ComboBox, which are all the spatial scales provided by system
        # reference the document: https://www2.census.gov/geo/pdfs/reference/GARM/Ch2GARM.pdf
        # Bounary Definitions: https://www.census.gov/geo/reference/garm.html
        self.ui.combo_DefineSpatialScale.addItem("Global")
        self.ui.combo_DefineSpatialScale.addItem("Nation")
        self.ui.combo_DefineSpatialScale.addItem("Regions")
        self.ui.combo_DefineSpatialScale.addItem("Divisions")
        self.ui.combo_DefineSpatialScale.addItem("States/Provinces")
        self.ui.combo_DefineSpatialScale.addItem("Counties")
        self.ui.combo_DefineSpatialScale.addItem("Census Tracts")
        self.ui.combo_DefineSpatialScale.addItem("Census Block Groups")
        self.ui.combo_DefineSpatialScale.addItem("Census Blocks")
        self.ui.combo_DefineSpatialScale.addItem("Traffic Analysis Zones")
        self.ui.combo_DefineSpatialScale.addItem("Metropolitan Areas")
        self.ui.combo_DefineSpatialScale.addItem("User Defined/Others")    # all other spatial scales not listed here

        # Set Up Available Values in ComboBox, which are all the temporal scales provided by system
        self.ui.combo_DefineTemporalScale.addItem("User Defined")
        self.ui.combo_DefineTemporalScale.addItem("Not Considered")

        # Initialize User's History Defined Scales, and make it as default selected
        self.init_scales()

    def click_exit(self):
        self.save2file()
        self.done(0)


    def click_next(self):
        self.save2file()
        self.gotoWin = 3
        self.done(1)

    def click_GotoWin_Object(self):
        self.gotoWin = 1
        self.done(1)

    def click_GotoWin_Indicators(self):
        self.gotoWin = 3
        self.done(1)


    '''
        init_scales(): get the user defined or selected scales last time, when using this component
        (1) read the scales info from log files
        (2) set the default selected values for each dropdown list, based on the info read from log files
    '''
    def init_scales(self):
        mySpatialScale, myTemporalScale = self.read4file()
        # Init Spatial Scales
        indexSpatial = self.ui.combo_DefineSpatialScale.findText(mySpatialScale, QtCore.Qt.MatchFixedString)
        if indexSpatial >= 0:
            self.ui.combo_DefineSpatialScale.setCurrentIndex(indexSpatial)

        # Init Temporal Scales
        indexTemporal = self.ui.combo_DefineTemporalScale.findText(myTemporalScale, QtCore.Qt.MatchFixedString)
        if indexTemporal >= 0:
            self.ui.combo_DefineTemporalScale.setCurrentIndex(indexTemporal)

    ''' 
        Get user's last selected scales from file "*__DefineScales.sus".
        (1) Spatial scales, = '' if the history info cannot match available values in dropdown list 
        (2) Temporal scales, = '' if the history info cannot match available values in dropdown list 
    '''
    def read4file(self):
        filename = os.path.basename(__file__).split(".")[0]+'__DefineScales.sus'
        mySpatialScale = _fromUtf8('')
        myTemporalScale = _fromUtf8('')
        if os.path.exists(filename):
            with open(filename, 'r') as outfile:
                # Read file line by line
                mylines = outfile.readlines()
            for line in mylines:
                if line.split(',')[0] == 'spatial':
                    # Get spatial scales
                    mySpatialScale = _fromUtf8(line.split(',')[1].split('\n')[0])
                elif line.split(',')[0] == 'temporal':
                    # Get Temporal Scales
                    myTemporalScale = _fromUtf8(line.split(',')[1].split('\n')[0])
                else:
                    print("Cannot Get User's History Scale Define!")
        return mySpatialScale, myTemporalScale

    '''  
        Save user's selected scales into file "*__DefineScales.sus". 
    '''
    def save2file(self):
        # Save the context in the text box into file
        # mySpatialText = str(self.ui.combo_DefineSpatialScale.currentText().toUtf8(), encoding="UTF-8")
        # myTemporalText = str(self.ui.combo_DefineTemporalScale.currentText().toUtf8(), encoding="UTF-8")
        mySpatialText = self.ui.combo_DefineSpatialScale.currentText()
        myTemporalText = self.ui.combo_DefineTemporalScale.currentText()

        filename = os.path.basename(__file__).split(".")[0]+'__DefineScales.sus'
        with open(filename, 'w') as outfile:
            outfile.write('spatial,' + mySpatialText + '\n')
            outfile.write('temporal,' + myTemporalText + '\n')

    def closeEvent(self, QCloseEvent):
        self.done(0)

    def get_GotoWin(self):
        return self.gotoWin