# -*- coding: utf-8 -*-
from PyQt4 import QtCore, QtGui
from DefineObject_UI import Ui_DefineObject
import os,sys
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class DefineObjectWin(QtGui.QDialog):
    def __init__(self,parent=None,connection_dic=None):
        QtGui.QDialog.__init__(self, parent=None)
        self.ui = Ui_DefineObject()
        self.gotoWin = 1
        self.ui.setupUi(self)
        self.setup_signals()
        self.my_parent = parent
        self.ui.tb_DefineObject.setText(self.read4file())

    def parent(self):
        return self.my_parent

    def setup_signals(self):
        QtCore.QObject.connect(self.ui.bt_Exit, QtCore.SIGNAL("clicked()"), self.click_exit)
        QtCore.QObject.connect(self.ui.bt_Next, QtCore.SIGNAL("clicked()"), self.click_next)
        QtCore.QObject.connect(self.ui.cb_Scales, QtCore.SIGNAL("clicked()"), self.click_GotoWin_Scale)

    def click_exit(self):
        self.save2file()
        self.done(0)

    def click_next(self):
        self.gotoWin = 2
        self.done(1)

    ''' 
        Get user's last defined objected from file "*__DefineScales.sus". 
        Return QString '',  if there is no info read from log file.
    '''
    def read4file(self):
        filename = os.path.basename(__file__).split(".")[0]+'__DefineObject.sus'
        str_text = _fromUtf8('')
        if os.path.exists(filename):
            # Read all contexts from the file
            with open(filename, 'r') as outfile:
                str_text = _fromUtf8(outfile.read())
        return str_text

    ''' 
        Save user's last defined objected from file "*__DefineScales.sus". 
    '''
    def save2file(self):
        # Save the context in the text box into file
        DefineObjectText = self.ui.tb_DefineObject.toPlainText()
        filename = os.path.basename(__file__).split(".")[0]+'__DefineObject.sus'
        with open(filename, 'w') as outfile:
            outfile.write(DefineObjectText)

    def closeEvent(self, QCloseEvent):
        self.done(0)

    def click_GotoWin_Scale(self):
        self.gotoWin = 2
        self.done(1)

    def get_GotoWin(self):
        return self.gotoWin

# if __name__ == "__main__":
#     import sys
#     app = QtGui.QApplication(sys.argv)
#     MainWin = testWin(app)
#     MainWin.show()
#     sys.exit(app.exec_())