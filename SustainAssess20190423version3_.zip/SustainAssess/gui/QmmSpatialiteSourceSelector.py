# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui
import os.path

from qgis.PyQt import uic
from qgis.core import QgsDataSourceUri
from qgis.PyQt.QtCore import QSettings,Qt,QDir,QFileInfo
from qgis.PyQt.QtWidgets import QTreeWidgetItem,QMessageBox,QFileDialog,QMenu,QAction,QDialogButtonBox
from qgis.PyQt.QtGui import QCursor,QIcon
from qgis.utils import iface
from SustainAssess.tools import spatialite
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

pluginPath = os.path.split(os.path.dirname(__file__))[0]
WIDGET, BASE = uic.loadUiType(
    os.path.join(pluginPath, 'ui', 'DlgPostgisTableSelector.ui'))

class QmmSpatialiteSourceSelector(BASE,WIDGET):

    def __init__(self,parent=None):
        super(QmmSpatialiteSourceSelector, self).__init__(parent)
        self.connection = None
        self.table = None
        self.schema = None
        self.geofield = None
        self.setupUi(self)
        self.parent = parent
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        if self.standalone:
            # it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            # it is run in QGIS
            settings = QSettings()
        settings.beginGroup("/SpatiaLite/connections/")
        stored_connections = settings.childGroups()
        settings.endGroup()
        for n in stored_connections:
            item = ConnectionItem(n,'db')
            self.treeConnections.addTopLevelItem(item)

        def itemExpanded(item):
            try:
                if item.level=='db':
                    item.populateDB()
                elif item.levle=='schema':
                    item.populateSechema()
                else:
                    pass
            except Exception as e:
                print(e.message)
                pass
        self.treeConnections.itemExpanded.connect(itemExpanded)
        self.treeConnections.setContextMenuPolicy(Qt.CustomContextMenu)
        self.refreshTreeWidget()
        self.setUpSignal()

    def refreshTreeWidget(self):
        self.treeConnections.clear()
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        settings.beginGroup("/SpatiaLite/connections/")
        names = settings.childGroups()
        settings.endGroup()
        for n in names:
            item = ConnectionItem(n,'db')
            self.treeConnections.addTopLevelItem(item)

    def testConnection(self):
        pass
    def setUpSignal(self):
        # get OK button
        self.btnOK = self.buttonBox.button(QDialogButtonBox.Ok)
        #get Close button
        self.btnCancel = self.buttonBox.button(QDialogButtonBox.Cancel)

        self.btnOK.clicked.connect(self.on_click_btnOK)
        self.btnCancel.clicked.connect(self.on_click_btnCancel)
        self.treeConnections.customContextMenuRequested.connect(self.contextMenu_item)
        self.treeConnections.clicked.connect(self.on_click_tree)
    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self,parent):
        self._parent = parent

    def on_click_tree(self):
        item = self.treeConnections.currentItem()
        if isinstance(item,TableItem):
            self.textTableName.setText(item.table)
            self.connection = item.connection
            self.schema = item.schema
            self.table = item.table
            self.geofield = item.geofield
    def on_click_btn_New(self):
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        lastUsedDir = settings.value("/UI/lastSpatiaLiteDir", QDir.homePath())
        filename,ext = QFileDialog.getOpenFileName(self,'Open SpatiaLite Database File',lastUsedDir,"SpatiaLite(*.sqlite *.db *.sqlite3 *.db3 *.s3db)")
        if not filename:
            return
        settings.setValue("/SpatiaLite/connections/" + QFileInfo(filename).fileName() + "/sqlitepath", filename)
        path = os.path.dirname(filename)
        settings.setValue("/UI/lastSpatiaLiteDir",path)
        self.refreshTreeWidget()
    def on_click_btn_Create(self):
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        lastUsedDir = settings.value("/UI/lastSpatiaLiteDir", QDir.homePath())
        filename = QFileDialog.getSaveFileName(self,'Create SpatiaLite Database File',lastUsedDir,"SpatiaLite(*.sqlite *.db *.sqlite3 *.db3 *.s3db)")

        if not filename:
            return
        uri = QgsDataSourceUri()
        uri.setDatabase(filename)
        #trying to create spatialite database
        try:
            db = spatialite.GeoDB(uri=uri)
        except spatialite.DbError as e:
            QMessageBox.critical(None, "Create SpatiaLite database",
                                  "Failed to create the database: %s"%(e.message))
            raise GeoAlgorithmExecutionException(
                "Couldn't connect to database:\n%s" % e.message)
        #successful create spatialite database
        # add connection
        settings.setValue("/SpatiaLite/connections/" + QFileInfo(filename).fileName() + "/sqlitepath", filename)
        path = os.path.dirname(filename)
        settings.setValue("/UI/lastSpatiaLiteDir",path)
        self.refreshTreeWidget()
    def on_click_btnOK(self):
        if self.textTableName.text()=="":
            return
        con_name = self.connection
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        baseKey = "/SpatiaLite/connections/"
        settings.setValue(baseKey + "selected", con_name)
        super(QmmSpatialiteSourceSelector, self).accept()

    def on_click_btnCancel(self):
        super(QmmSpatialiteSourceSelector, self).reject()

    def on_click_btn_Del(self):
        item = self.treeConnections.currentItem()
        con_name = item.connection
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        baseKey = "/SpatiaLite/connections/"
        settings.remove(baseKey + con_name)
        self.refreshTreeWidget()
        self.treeConnections.repaint()
    def contextMenu_item(self):
        popupmenu = QMenu()
        newAction = QAction(self.tr('New Connection...'), self)
        createAction = QAction(self.tr('Create Database...'), self)
        deleteAction = QAction(self.tr('Delete Connection...'), self)

        popupmenu.addAction(newAction)
        popupmenu.addAction(createAction)
        popupmenu.addAction(deleteAction)

        newAction.triggered.connect(self.on_click_btn_New)
        createAction.triggered.connect(self.on_click_btn_Create)
        deleteAction.triggered.connect(self.on_click_btn_Del)

        popupmenu.exec_(QCursor.pos())


class TableItem(QTreeWidgetItem):
    def __init__(self, connection,table,geofield,schema='',level='table'):
        #level='db','schema','table', However, in Spatialite, schema is different with PostGIS.
        self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'mIconTableLayer.png'))
        self.level = level
        self.schema = schema
        self.table = table
        self.geofield = geofield
        QTreeWidgetItem.__init__(self)
        self.connection = connection
        self.setText(0, table)
        self.setIcon(0, self.tableIcon)
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True

class ConnectionItem(QTreeWidgetItem):

    def __init__(self, connection,level):
        #level='db','schema','table', However, in Spatialite, schema is different with PostGIS.
        self.connIcon = QIcon(os.path.join(pluginPath,'images','mIconSpatialite.png'))
        self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'mIconTableLayer.png'))
        self.level = level
        QTreeWidgetItem.__init__(self)
        self.setChildIndicatorPolicy(QTreeWidgetItem.ShowIndicator)
        self.connection = connection
        self.setText(0, connection)
        self.setIcon(0, self.connIcon)
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
    def populateDB(self):
        if self.childCount() != 0:
            return
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        path = settings.value("/SpatiaLite/connections/" + self.connection + "/sqlitepath")
        uri = QgsDataSourceUri()
        uri.setDatabase(path)
        try:
            db = spatialite.GeoDB(uri=uri)
        except spatialite.DbError as e:
            raise GeoAlgorithmExecutionException(
                "Couldn't connect to database:\n%s" % e.message)
        # def _runSQL(sql):
        #     try:
        #         db._exec_sql_and_commit(str(sql))
        #     except spatialite.DbError as e:
        #         raise GeoAlgorithmExecutionException(
        #             'Error creating output Spatialite table:\n%s' % str(e))
        #sql_schemas = "SELECT name FROM sqlite_master WHERE type='table';"
        sql_schemas = "SELECT f_table_name,f_geometry_column FROM geometry_columns;"
        try:
            c = db.con.cursor()
            c.execute(sql_schemas)
            tables = c.fetchall()
            for table in tables:
                item = TableItem(self.connection,table[0],table[1],'','table')
                self.addChild(item)
        except Exception as e:
            raise GeoAlgorithmExecutionException(
                'Error selecting table:\n%s' % str(e))
        db.con.close()
