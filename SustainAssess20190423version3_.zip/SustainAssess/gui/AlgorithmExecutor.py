# -*- coding: utf-8 -*-

"""
***************************************************************************
    AlgorithmExecutor.py
    ---------------------
    Date                 : August 2012
    Copyright            : (C) 2012 by Victor Olaya
    Email                : volayaf at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""


__author__ = 'Victor Olaya'
__date__ = 'August 2012'
__copyright__ = '(C) 2012, Victor Olaya'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import sys

from qgis.PyQt.QtCore import QSettings, QCoreApplication
from qgis.core import QgsFeature, QgsVectorFileWriter
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.gui.Postprocessing import handleAlgorithmResults
from SustainAssess.tools import dataobjects
from SustainAssess.tools.system import getTempFilename
from SustainAssess.tools import vector
from SustainAssess.core.SilentProgress import SilentProgress
from qgis.utils import iface

def runalg(alg, progress=None):
    """Executes a given algorithm, showing its progress in the
    progress object passed along.

    Return true if everything went OK, false if the algorithm
    could not be completed.
    """
    try:
        alg.execute(progress or SilentProgress())
        return True
    except GeoAlgorithmExecutionException as e:
        ProcessingLog.addToLog(sys.exc_info()[0], ProcessingLog.LOG_ERROR)
        if progress is not None:
            progress.error(e.msg)
        return False


def runalgIterating(alg, paramToIter, progress):
    # Generate all single-feature layers
    if hasattr(iface, "standalone"):
        settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                             QSettings.NativeFormat)
    else:
        settings = QSettings()
    systemEncoding = settings.value('/UI/encoding', 'System')
    layerfile = alg.getParameterValue(paramToIter)
    layer = dataobjects.getObjectFromUri(layerfile, False)
    feat = QgsFeature()
    filelist = []
    outputs = {}
    provider = layer.dataProvider()
    features = vector.features(layer)
    for feat in features:
        output = getTempFilename('shp')
        filelist.append(output)
        writer = QgsVectorFileWriter(output, systemEncoding,
                                     provider.fields(), provider.geometryType(), layer.crs())
        writer.addFeature(feat)
        del writer

    # store output values to use them later as basenames for all outputs
    for out in alg.outputs:
        outputs[out.name] = out.value

    # now run all the algorithms
    for i, f in enumerate(filelist):
        alg.setParameterValue(paramToIter, f)
        for out in alg.outputs:
            filename = outputs[out.name]
            if filename:
                filename = filename[:filename.rfind('.')] + '_' + str(i) \
                    + filename[filename.rfind('.'):]
            out.value = filename
        progress.setText(tr('Executing iteration %s/%s...' % (str(i), str(len(filelist)))))
        progress.setPercentage(i * 100 / len(filelist))
        if runalg(alg, progress):
            handleAlgorithmResults(alg, None, False)
        else:
            return False

    return True


def tr(string, context=''):
    if context == '':
        context = 'AlgorithmExecutor'
    return QCoreApplication.translate(context, string)
