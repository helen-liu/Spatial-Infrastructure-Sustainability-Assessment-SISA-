# -*- coding: utf-8 -*-

"""
***************************************************************************
    InputLayerSelectorPanel.py
    ---------------------
    Date                 : August 2012
    Copyright            : (C) 2012 by Victor Olaya
    Email                : volayaf at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qingsong Liu & Mengmeng Liu'
__date__ = 'August 2018'
__copyright__ = '(C) 2018, Qingsong Liu & Mengmeng Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

from qgis.PyQt import uic
from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtGui import QIcon,QCursor
from qgis.PyQt.QtWidgets import QFileDialog,QMenu,QAction
from qgis.utils import iface
from qgis.gui import QgsDialog
from qgis.core import QgsDataSourceUri
from SustainAssess.gui.QmmSpatialiteSourceSelector import QmmSpatialiteSourceSelector
from SustainAssess.gui.QmmPostGISSourceSelector import QmmPostGISSourceSelector
pluginPath = os.path.split(os.path.dirname(__file__))[0]
WIDGET, BASE = uic.loadUiType(
    os.path.join(pluginPath, 'ui', 'widgetLayerSelector.ui'))


class InputLayerRDBMSelectorPanel(BASE, WIDGET):

    def __init__(self, options, param):
        super(InputLayerRDBMSelectorPanel, self).__init__(None)
        self.setupUi(self)

        self.btnIterate.setIcon(
            QIcon(os.path.join(pluginPath, 'images', 'iterate.png')))
        self.btnIterate.hide()

        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True

        self.param = param

        for (name, value) in options:
            self.cmbText.addItem(name, value)

        self.btnSelect.clicked.connect(self.showSelectInput)

    def showSelectInput(self):
        popupMenu = QMenu()
        actionOpenfromFile = QAction(self.tr('Open from File...'),self.btnSelect)
        actionOpenfromFile.triggered.connect(self.openFromFile)
        popupMenu.addAction(actionOpenfromFile)

        actionOpenFromSpatialite = QAction(
            self.tr('Open from SpatiaLite Table...'), self.btnSelect)
        actionOpenFromSpatialite.triggered.connect(self.openFromSpatialite)
        popupMenu.addAction(actionOpenFromSpatialite)

        actionOpenfromPostGIS = QAction(
            self.tr('Open from PostGIS Table...'), self.btnSelect)
        actionOpenfromPostGIS.triggered.connect(self.openFromPostGIS)

        if hasattr(iface, "standalone"):
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            settings = QSettings()
        settings.beginGroup('/PostgreSQL/connections/')
        names = settings.childGroups()
        settings.endGroup()
        actionOpenfromPostGIS.setEnabled(bool(names))
        popupMenu.addAction(actionOpenfromPostGIS)

        popupMenu.exec_(QCursor.pos())

    def openFromSpatialite(self):
        fileFilter = 'SpatiaLite files(*.sqlite)'
        if hasattr(iface, "standalone"):
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            settings = QSettings()
        if settings.contains('/Processing/LastOutputPath'):
            path = settings.value('/Processing/LastInputPath')
        else:
            path = None
        encoding = settings.value('/Processing/encoding','System')
        dlg = QmmSpatialiteSourceSelector(self)
        if dlg.exec_()==QgsDialog.Accepted:
            connection = dlg.connection
            schema = dlg.schema
            table = dlg.table
            path = settings.value('/SpatiaLite/connections/'+connection+'/sqlitepath')
            dirname = os.path.dirname(path)
            settings.setValue('/Processing/LastInputPath',dirname)
            settings.setValue('/Processing/encoding',encoding)
            uri = QgsDataSourceUri()
            uri.setDatabase(path)
            uri.setDataSource(dlg.schema, dlg.table, dlg.geofield)# setDataSource(schema,table,geom)
            uri_text = "spatialite:" + uri.uri()
            item_text = "spatialite:"+connection+"."+table
            ind = self.cmbText.findText(item_text)
            if ind == -1:
                self.cmbText.addItem(item_text,{"connection":connection,"schema":schema,"table":table,"geofield":dlg.geofield,"path":path,'uri':uri_text})
                curind = self.cmbText.findText(item_text)
                self.cmbText.setCurrentIndex(curind)
            else:
                self.cmbText.setCurrentIndex(ind)
    def openFromPostGIS(self):
        if hasattr(iface, "standalone"):
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            settings = QSettings()
        encoding = settings.value('/Processing/encoding','System')
        dlg = QmmPostGISSourceSelector(self)
        if dlg.exec_()==QgsDialog.Accepted:
            connection = dlg.connection
            schema = dlg.schema
            table = dlg.table
            geofield =dlg.geofield
            type = dlg.type
            srid = dlg.srid
            settings.setValue('/Processing/encoding',encoding)

            baseKey = "/PostgreSQL/connections/" + connection
            service = settings.value(baseKey + "/service")
            host = settings.value(baseKey + "/host")
            port = settings.value(baseKey + "/port")
            database = settings.value(baseKey + "/database")
            username = settings.value(baseKey + "/username")
            password = settings.value(baseKey + "/password")
            authcfg = settings.value(baseKey + "/authcfg")
            publicOnly = settings.value(baseKey + "/publicOnly")
            geometryColumnsOnly = settings.value(baseKey + "/geometryColumnsOnly")
            dontResolveType = settings.value(baseKey + "/dontResolveType")
            allowGeometrylessTables = settings.value(baseKey + "/allowGeometrylessTables")
            sslmode = settings.value(baseKey + "/sslmode")
            saveUsername = settings.value(baseKey + "/saveUsername")
            savePassword = settings.value(baseKey + "/savePassword")
            estimatedMetadata = settings.value(baseKey + "/estimatedMetadata")
            uri = QgsDataSourceUri()
            authcfg = ""
            if (service):
                uri.setConnection(service, database,
                                  username, password,
                                  sslmode,
                                  authcfg)
            else:
                uri.setConnection(host, port, database,
                                  username, password,
                                  sslmode, authcfg)
            uri.setDataSource(schema,table,geofield)
            uri.setSrid(str(srid))
            uri_text = "postgis:" + uri.uri()
            item_text = "postgis:"+connection+"."+schema+"."+table+"("+geofield+":"+type+";srid:"+str(srid)+")"
            ind = self.cmbText.findText(item_text)
            if ind == -1:
                self.cmbText.addItem(item_text,{'uri':uri_text})
                curind = self.cmbText.findText(item_text)
                self.cmbText.setCurrentIndex(curind)
                self.cmbText.currentIndexChanged.emit(curind)
            else:
                self.cmbText.setCurrentIndex(ind)
    def openFromFile(self):
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        text = str(self.cmbText.currentText())
        if os.path.isdir(text):
            path = text
        elif os.path.isdir(os.path.dirname(text)):
            path = os.path.dirname(text)
        elif settings.contains('/Processing/LastInputPath'):
            path = str(settings.value('/Processing/LastInputPath'))
        else:
            path = ''

        filename,ext = QFileDialog.getOpenFileName(self, self.tr('Select file'),
                                               path, self.tr('All files (*.*);;') + self.param.getFileFilter())
        if filename:
            settings.setValue('/Processing/LastInputPath',
                              os.path.dirname(str(filename)))
            item_text = filename
            ind = self.cmbText.findText(item_text)
            if ind == -1:
                self.cmbText.addItem(item_text,{'uri':item_text})
                self.cmbText.setCurrentIndex(self.cmbText.count() - 1)
            else:
                self.cmbText.setCurrentIndex(ind)

    def getValue(self):
        return self.cmbText.itemData(self.cmbText.currentIndex())
