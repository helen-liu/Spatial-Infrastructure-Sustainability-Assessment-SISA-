# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SpatialSustainAssessDockWidget
                                 A QGIS plugin
 Evaluating sustainability of objects from multiple dimensions
                             -------------------
        begin                : 2018-06-25
        git sha              : $Format:%H$
        copyright            : (C) 2018 by Mengmeng Helen Liu / Georgia Insitute of Technology
        email                : mengmeng.liu@gatech.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from qgis.core import QgsMessageLog
from PyQt4 import QtGui
from PyQt4.QtCore import pyqtSignal
from SpatialSustainAssess_dockwidget_base_ui import Ui_SpatialSustainAssessDockWidgetBase
from PyQt4.QtGui import  QFileDialog

# FORM_CLASS, _ = uic.loadUiType(os.path.join(
#     os.path.dirname(__file__), 'SpatialSustainAssess_dockwidget_base.ui'))
#
#
# class SpatialSustainAssessDockWidget(QtGui.QDockWidget, FORM_CLASS):
class SpatialSustainAssessDockWidget(QtGui.QDockWidget, Ui_SpatialSustainAssessDockWidgetBase):
    closingPlugin = pyqtSignal()

    def __init__(self, iface, parent=None):
        """Constructor."""
        super(SpatialSustainAssessDockWidget, self).__init__(parent)
        # Set up the user interface from Designer.
        # After setupUI you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.dockwidget_ui = Ui_SpatialSustainAssessDockWidgetBase()
        self.dockwidget_ui.setupUi(self)
        self.iface = iface

        self.load_data()
        ####----------------------------------------------------
        self.dockwidget_ui.pushBt_SelectOutputFile.clicked.connect(self.select_output_file)

        ####------------------------------------------------------
        self.dockwidget_ui.pushBt_OK.clicked.connect(self.click_OK)

        self.dockwidget_ui.pushBt_Cancel.clicked.connect(self.click_Cancel)


    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()

        # --------------------------------------------------------------------------
        ## Define select output file function

    def select_output_file(self):
        ## you need import  QFileDialog from PyQt4.QtGui
        filename = QFileDialog.getSaveFileName(self.dockwidget_ui, "Select Output File", "", '*.txt')

        ## from qgis.core import QgsMessageLog
        QgsMessageLog.logMessage('filename:' + filename, 'MyPlugin')

        self.dockwidget_ui.lineEdit_Outputfile.setText(filename)

    def click_OK(self):
        ## click OK will save features information to the file
        filename = self.dockwidget_ui.lineEdit_Outputfile.text()

        ## get the layers user choose from comboBox
        selectedLayerIndex = self.dockwidget_ui.comboBox_LayerList.currentIndex()
        layers = self.iface.legendInterface().layers()
        selectedLayer = layers[selectedLayerIndex]

        ### get the filed name for each feature, which is the attribute of each feature
        fields = selectedLayer.fields()
        fieldnames = [field.name() for field in fields]

        ## write the fieldname for each feature into file
        output_file = open(filename, 'w')
        for f in selectedLayer.getFeatures():
            line = ','.join(str(f[x]) for x in fieldnames) + '\n'
            unicode_line = line.encode('utf-8')
            output_file.write(unicode_line)
        output_file.close()

    def click_Cancel(self):
        self.dockwidget_ui.setVisible(False)

    def load_data(self):
        ####---------------------------------------------------
        ## get current layers loaded in QGIS
        # layers = self.iface.canvas.layers()
        self.layers = self.iface.legendInterface().layers()
        layer_list = []
        for layer in self.layers:
            layer_list.append(layer.name())
        ####---------------------------------------------------

        ####----------------------------------------------------
        ### add the loaded layers in QGIS to combobox
        self.dockwidget_ui.comboBox_LayerList.addItems(layer_list)

    def events_handle(self):
        pass

    def get_data(self):
        return self.layers