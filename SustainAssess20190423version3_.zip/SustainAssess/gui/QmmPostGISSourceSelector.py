# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui
import os.path,json

from qgis.PyQt import uic
from qgis.core import QgsDataSourceUri
from qgis.PyQt.QtCore import QSettings,Qt
from qgis.PyQt.QtWidgets import QTreeWidgetItem,QMessageBox,QDialog,QMenu,QAction,QDialogButtonBox
from qgis.PyQt.QtGui import QCursor,QIcon
from qgis.utils import iface
from SustainAssess.tools import postgis
from SustainAssess.gui.database_menu.QmmPgNewConnection import QmmPgNewConnection
from SustainAssess.core.parameters import ParameterVector_RDBMS
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

pluginPath = os.path.split(os.path.dirname(__file__))[0]
WIDGET, BASE = uic.loadUiType(
    os.path.join(pluginPath, 'ui', 'DlgPostgisTableSelector.ui'))

class QmmPostGISSourceSelector(BASE,WIDGET):
    TYPE_MAP= {ParameterVector_RDBMS.VECTOR_TYPE_POINT:["POINT","MULTIPOINT","GEOMETRY"],
               ParameterVector_RDBMS.VECTOR_TYPE_POLYGON: ["POLYGON", "MULTIPOLYGON","GEOMETRY"],
               ParameterVector_RDBMS.VECTOR_TYPE_LINE: ["LINESTRING", "MULTILINESTRING", "GEOMETRY"]}
    def __init__(self,parent=None,slient=True):
        super(QmmPostGISSourceSelector, self).__init__(parent)
        self.connection = None
        self.table = None
        self.schema = None
        self.geofield = None
        self.setupUi(self)
        self.parent = parent
        self.standalone = False
        self.slient = slient
        if hasattr(iface, 'standalone'):
            self.standalone = True
        if self.standalone:
            # it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            # it is run in QGIS
            settings = QSettings()
        settings.beginGroup("/PostgreSQL/connections/")
        stored_connections = settings.childGroups()
        settings.endGroup()
        for n in stored_connections:
            item = ConnectionItem(n,'db')
            self.treeConnections.addTopLevelItem(item)

        self.treeConnections.itemExpanded.connect(self.itemExpanded)
        self.treeConnections.setContextMenuPolicy(Qt.CustomContextMenu)

        self.refreshTreeWidget()
        self.setUpSignal()
    def populate(self,item):
        if item.childCount() != 0:
            return
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        baseKey = "/PostgreSQL/connections/" + item.connection
        service = settings.value(baseKey + "/service")
        host = settings.value(baseKey + "/host")
        port = settings.value(baseKey + "/port")
        database = settings.value(baseKey + "/database")
        username = settings.value(baseKey + "/username")
        password = settings.value(baseKey + "/password")
        authcfg = settings.value(baseKey + "/authcfg")
        publicOnly = settings.value(baseKey + "/publicOnly")
        geometryColumnsOnly = settings.value(baseKey + "/geometryColumnsOnly")
        dontResolveType = settings.value(baseKey + "/dontResolveType")
        allowGeometrylessTables = settings.value(baseKey + "/allowGeometrylessTables")

        try:
            sslmode = settings.value(baseKey + "/sslmode", type=int)
            # sslmode = settings.value("sslmode", QgsDataSourceUri.SslPrefer, type=int)
        except TypeError:
            sslmode = QgsDataSourceUri.SslPrefer
        saveUsername = settings.value(baseKey + "/saveUsername")
        savePassword = settings.value(baseKey + "/savePassword")
        estimatedMetadata = settings.value(baseKey + "/estimatedMetadata")
        uri = QgsDataSourceUri()
        authcfg=""
        if (service):
            uri.setConnection(service, database,
                              username, password,
                              sslmode,
                               authcfg)
        else:
            uri.setConnection(host, port, database,
                              username, password,
                              sslmode,authcfg)
        try:
            db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                               dbname=uri.database(), user=uri.username(), passwd=uri.password())
            if not self.slient:
                QMessageBox.information(self,"Test connection",
                                    "Connection to %s was successful"%(item.connection))
        except postgis.DbError as e:
            QMessageBox.information(self,"Test connection",
                                     "Connection failed - consult message log for details.\n\nCouldn't connect to database:\n%s" % e.message)
            # raise GeoAlgorithmExecutionException(
            #     "Couldn't connect to database:\n%s" % e.message)
            return False
        if item.level =='db':
            schemas = db.list_schemas()
            for schema in schemas:
                childitem = SchemaItem(item.connection,schema[1] , 'schema')
                item.addChild(childitem)
        elif item.level=='schema':
            for geotable in ['geography_columns','geometry_columns']:
                table_sql = "Select * from %s where f_table_schema='%s';" % (geotable,item.schema)
                c = db.con.cursor()
                c.execute(table_sql)
                tables = c.fetchall()
                tablelist = []
                tablenamelist = []
                for table in tables:
                    name,geofield,type,srid = table[2],table[3],table[6],table[5]
                    tablelist.append([name,geofield,type,srid])
                    tablenamelist.append(name)
                for st in self.parent.param.shapetype:
                    if st == ParameterVector_RDBMS.VECTOR_ROAD_NETWORK:
                        for table in tablelist:
                            if table[0]+"_vertices_pgr" in tablenamelist:
                                childitem = TableItem(item.connection,item.schema,table[0],table[1],table[2],table[3],'table')
                                item.addChild(childitem)
                    elif st == ParameterVector_RDBMS.VECTOR_TYPE_ANY:
                        for table in tablelist:
                            childitem = TableItem(item.connection,item.schema,table[0],table[1],table[2],table[3],'table')
                            item.addChild(childitem)
                    else:
                        TYPES = self.TYPE_MAP[st]
                        for table in tablelist:
                            if table[2] in TYPES:
                                childitem = TableItem(item.connection,item.schema,table[0],table[1],table[2],table[3],'table')
                                item.addChild(childitem)
        db.con.close()

    def itemExpanded(self,item):
        try:
            self.populate(item)
        except Exception as e:
            print(e)
            pass
    def refreshTreeWidget(self):
        self.treeConnections.clear()
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        settings.beginGroup("/PostgreSQL/connections/")
        names = settings.childGroups()
        settings.endGroup()
        for n in names:
            item = ConnectionItem(n,'db')
            self.treeConnections.addTopLevelItem(item)

    def testConnection(self):
        pass
    def setUpSignal(self):
        # get OK button
        self.btnOK = self.buttonBox.button(QDialogButtonBox.Ok)
        #get Close button
        self.btnCancel = self.buttonBox.button(QDialogButtonBox.Cancel)

        self.btnOK.clicked.connect(self.on_click_btnOK)
        self.btnCancel.clicked.connect(self.on_click_btnCancel)
        self.treeConnections.customContextMenuRequested.connect(self.contextMenu_item)
        self.treeConnections.clicked.connect(self.on_click_tree)
        self.treeConnections.itemDoubleClicked.connect(self.on_double_click_tree)
    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self,parent):
        self._parent = parent
    def on_double_click_tree(self):
        item = self.treeConnections.currentItem()
        if isinstance(item,TableItem):
            self.textTableName.setText(item.table)
            self.connection = item.connection
            self.schema = item.schema
            self.table = item.table
            self.geofield = item.geofield
            self.type = item.type
            self.srid = item.srid
            self.btnOK.click()

    def on_click_tree(self):
        item = self.treeConnections.currentItem()
        if isinstance(item,TableItem):
            self.textTableName.setText(item.table)
            self.connection = item.connection
            self.schema = item.schema
            self.table = item.table
            self.geofield = item.geofield
            self.type = item.type
            self.srid = item.srid

    def on_click_btn_New(self):
        dlg_newconnection = QmmPgNewConnection(self)
        if dlg_newconnection.exec_()==QDialog.Accepted:
            #链接成功
            print("on_click_btn_New sucess.")
            self.refreshTreeWidget()
        else:
            print("on_click_btn_New failed.")
        self.refreshTreeWidget()

    def on_click_btnOK(self):
        if self.textTableName.text()=="":
            return
        con_name = self.connection
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        baseKey = "/PostgreSQL/connections/"
        settings.setValue(baseKey + "selected", con_name)
        super(QmmPostGISSourceSelector, self).accept()

    def on_click_btnCancel(self):
        super(QmmPostGISSourceSelector, self).reject()

    def on_click_btn_Del(self):
        item = self.treeConnections.currentItem()
        con_name = item.connection
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        baseKey = "/PostgreSQL/connections/"
        settings.remove(baseKey + con_name)
        self.refreshTreeWidget()
        self.treeConnections.repaint()
    def contextMenu_item(self):
        popupmenu = QMenu()
        newAction = QAction(self.tr('New Connection...'), self)
        deleteAction = QAction(self.tr('Delete Connection...'), self)

        popupmenu.addAction(newAction)
        popupmenu.addAction(deleteAction)

        newAction.triggered.connect(self.on_click_btn_New)
        deleteAction.triggered.connect(self.on_click_btn_Del)

        popupmenu.exec_(QCursor.pos())


class TableItem(QTreeWidgetItem):
    def __init__(self, connection,schema,table,geofield,type,srid, level='table'):
        #level='db','schema','table', However, in Spatialite, schema is different with PostGIS.
        if type in ['POINT','MULTIPOINT']:
            self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_point.png'))
        elif type in ['POLYGON','MULTIPOLYGON']:
            self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_polygon.png'))
        elif type in ['LINESTRING','MULTILINESTRING']:
            self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_line.png'))
        else:
            self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_unknown.png'))
        self.level = level
        self.schema = schema
        self.table = table
        self.geofield = geofield
        self.type = type
        self.srid = srid
        QTreeWidgetItem.__init__(self)
        self.connection = connection
        self.setText(0, table)
        self.setIcon(0, self.tableIcon)
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
class SchemaItem(QTreeWidgetItem):
    def __init__(self, connection,schema='public',level='schema'):
        #level='db','schema','table', However, in Spatialite, schema is different with PostGIS.
        self.Icon = QIcon(os.path.join(pluginPath, 'images', 'namespace.png'))
        self.level = level
        self.schema = schema
        QTreeWidgetItem.__init__(self)
        self.setChildIndicatorPolicy(QTreeWidgetItem.ShowIndicator)
        self.connection = connection
        self.setText(0, schema)
        self.setIcon(0, self.Icon)
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
class ConnectionItem(QTreeWidgetItem):
    def __init__(self, connection,level):
        #level='db','schema','table', However, in Spatialite, schema is different with PostGIS.
        self.connIcon = QIcon(os.path.join(pluginPath,'images','postgis.png'))
        self.level = level
        QTreeWidgetItem.__init__(self)
        self.setChildIndicatorPolicy(QTreeWidgetItem.ShowIndicator)
        self.connection = connection
        self.setText(0, connection)
        self.setIcon(0, self.connIcon)
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
