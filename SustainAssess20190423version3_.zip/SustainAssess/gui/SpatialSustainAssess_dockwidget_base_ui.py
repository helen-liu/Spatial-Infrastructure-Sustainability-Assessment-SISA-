# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'SpatialSustainAssess_dockwidget_base.ui'
#
# Created: Tue Jun 26 11:38:27 2018
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_SpatialSustainAssessDockWidgetBase(object):
    def setupUi(self, SpatialSustainAssessDockWidgetBase):
        SpatialSustainAssessDockWidgetBase.setObjectName(_fromUtf8("SpatialSustainAssessDockWidgetBase"))
        SpatialSustainAssessDockWidgetBase.resize(927, 621)
        self.dockWidgetContents = QtGui.QWidget()
        self.dockWidgetContents.setObjectName(_fromUtf8("dockWidgetContents"))

        self.formLayout = QtGui.QFormLayout(self.dockWidgetContents)
        self.formLayout.setFieldGrowthPolicy(QtGui.QFormLayout.AllNonFixedFieldsGrow)
        self.formLayout.setLabelAlignment(QtCore.Qt.AlignCenter)
        self.formLayout.setFormAlignment(QtCore.Qt.AlignLeading|QtCore.Qt.AlignLeft|QtCore.Qt.AlignTop)
        self.formLayout.setObjectName(_fromUtf8("formLayout"))

        ## define a label
        self.label_SelectLayer = QtGui.QLabel(self.dockWidgetContents)
        self.label_SelectLayer.geometry()

        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_SelectLayer.setFont(font)
        self.label_SelectLayer.setObjectName(_fromUtf8("pushBt_SelectLayer"))
        #self.formLayout.setWidget(0, QtGui.QFormLayout.LabelRole, self.label_SelectLayer)

        ## define a comboBox
        self.comboBox_LayerList = QtGui.QComboBox(self.dockWidgetContents)
        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.comboBox_LayerList.sizePolicy().hasHeightForWidth())
        self.comboBox_LayerList.setSizePolicy(sizePolicy)
        self.comboBox_LayerList.setBaseSize(QtCore.QSize(4, 20))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.comboBox_LayerList.setFont(font)
        self.comboBox_LayerList.setEditable(False)
        self.comboBox_LayerList.setFrame(False)
        self.comboBox_LayerList.setObjectName(_fromUtf8("comboBox_LayerList"))
        #self.formLayout.setWidget(0, QtGui.QFormLayout.FieldRole, self.comboBox_LayerList)

        ### Add the label and comboBox into formlayout
        self.formLayout.addRow(self.label_SelectLayer, self.comboBox_LayerList)

        ## Define label for outputfile
        self.label_OutputFile = QtGui.QLabel(self.dockWidgetContents)
        self.label_OutputFile.setAlignment(QtCore.Qt.AlignCenter)

        font = QtGui.QFont()
        font.setPointSize(12)
        self.label_OutputFile.setFont(font)
        self.label_OutputFile.setObjectName(_fromUtf8("label_OutputFile"))
        #self.formLayout.setWidget(1, QtGui.QFormLayout.LabelRole, self.label_OutputFile)

        ## Define pushbutton for outputfile
        self.pushBt_SelectOutputFile = QtGui.QPushButton(self.dockWidgetContents)
        # sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Minimum, QtGui.QSizePolicy.Minimum)
        # sizePolicy.setHorizontalStretch(5)
        # sizePolicy.setVerticalStretch(0)
        # sizePolicy.setHeightForWidth(self.pushBt_SelectOutputFile.sizePolicy().hasHeightForWidth())
        # self.pushBt_SelectOutputFile.setSizePolicy(sizePolicy)
        font = QtGui.QFont()
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.pushBt_SelectOutputFile.setFont(font)
        self.pushBt_SelectOutputFile.setObjectName(_fromUtf8("pushBt_SelectOutputFile"))
        # self.formLayout.setWidget(1, QtGui.QFormLayout.FieldRole, self.pushBt_SelectOutputFile)

        ### Add the label and pushbutton for outputfile into formlayout
        self.formLayout.addRow(self.label_OutputFile, self.pushBt_SelectOutputFile)

        ## Define lineEdit to show the result of output file
        self.lineEdit_Outputfile = QtGui.QLineEdit(self.dockWidgetContents)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.lineEdit_Outputfile.setFont(font)
        self.lineEdit_Outputfile.setObjectName(_fromUtf8("lineEdit_Outputfile"))
        ## add the lineEdit into the formlayout
        self.formLayout.setWidget(2, QtGui.QFormLayout.FieldRole, self.lineEdit_Outputfile)

        ## Define pushbutton for OK to save the file
        self.pushBt_OK = QtGui.QPushButton(self.dockWidgetContents)

        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushBt_OK.setFont(font)
        self.pushBt_OK.setObjectName(_fromUtf8("pushBt_OK"))
        #self.formLayout.setWidget(3, QtGui.QFormLayout.LabelRole, self.pushBt_OK)

        self.pushBt_Cancel = QtGui.QPushButton(self.dockWidgetContents)
        self.pushBt_Cancel.setEnabled(True)
        font = QtGui.QFont()
        font.setPointSize(12)
        self.pushBt_Cancel.setFont(font)
        self.pushBt_Cancel.setObjectName(_fromUtf8("pushBt_Cancel"))
        self.formLayout.setWidget(3, QtGui.QFormLayout.FieldRole, self.pushBt_Cancel)
        #self.gridLayout.addLayout(self.formLayout, 1, 0, 1, 1)

        ## Add pushbutton OK and Cancel into the formlayout
        self.formLayout.addRow(self.pushBt_OK, self.pushBt_Cancel)

        ## setWidget for the main window
        SpatialSustainAssessDockWidgetBase.setWidget(self.dockWidgetContents)

        self.retranslateUi(SpatialSustainAssessDockWidgetBase)
        QtCore.QMetaObject.connectSlotsByName(SpatialSustainAssessDockWidgetBase)

    def retranslateUi(self, SpatialSustainAssessDockWidgetBase):
        SpatialSustainAssessDockWidgetBase.setWindowTitle(_translate("SpatialSustainAssessDockWidgetBase", "Spatial Sustainability Assessment", None))
        self.label_SelectLayer.setText(_translate("SpatialSustainAssessDockWidgetBase", " Select Layer ", None))
        self.label_OutputFile.setText(_translate("SpatialSustainAssessDockWidgetBase", " Select Output File ", None))
        self.pushBt_SelectOutputFile.setText(_translate("SpatialSustainAssessDockWidgetBase", " ... ", None))
        self.pushBt_OK.setText(_translate("SpatialSustainAssessDockWidgetBase", " OK ", None))
        self.pushBt_Cancel.setText(_translate("SpatialSustainAssessDockWidgetBase", " Cancel ", None))

