# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui
import os.path,json

from qgis.PyQt import uic
from qgis.PyQt.QtCore import QSettings,Qt,QRegExp
from qgis.PyQt.QtGui import QRegExpValidator
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import QgsDataSourceUri
from SustainAssess.tools import postgis
from qgis.gui import QgsAuthConfigSelect

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

pluginPath = os.path.split(os.path.dirname(__file__))[0]
pluginPath = os.path.split(pluginPath)[0]
WIDGET, BASE = uic.loadUiType(
    os.path.join(pluginPath, 'ui', 'qgspgnewconnectionbase.ui'))

class QmmPgNewConnection(BASE,WIDGET):

    def __init__(self,parent=None,name=None, winflag=None):
        super(QmmPgNewConnection, self).__init__(parent.iface.mainWindow())
        self.setupUi(self)
        self.signalSetUp()
        self.parent = parent
        self.mOriginalConnName=name
        self.b_testConnection = False
        self.standalone = False
        self.mAuthConfigSelect = QgsAuthConfigSelect(self,"postgres")
        self.cbxSSLmode.addItem("disable", QgsDataSourceUri.SslDisable )
        self.cbxSSLmode.addItem("allow", QgsDataSourceUri.SslAllow )
        self.cbxSSLmode.addItem("prefer", QgsDataSourceUri.SslPrefer )
        self.cbxSSLmode.addItem("require", QgsDataSourceUri.SslRequire)
        self.cbxSSLmode.addItem("verify-ca", QgsDataSourceUri.SslVerifyCa )
        self.cbxSSLmode.addItem("verify-full", QgsDataSourceUri.SslVerifyFull )
        self.tabAuthentication.insertTab(1, self.mAuthConfigSelect, "Configurations")

        if (self.mOriginalConnName):
            #populate the dialog with the information stored for the connection
            # populate the fields with the stored setting parameters
            if hasattr(self.parent.iface, 'standalone'):
                self.standalone = True
            if self.standalone:
                # it is standalone application
                settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                     QSettings.NativeFormat)
            else:
                # it is run in QGIS
                settings = QSettings()

            key = "/PostgreSQL/connections/" + self.mOriginalConnName
            self.txtService.setText(settings.value(key + "/service"))
            self.txtHost.setText(settings.value(key + "/host"))
            port = settings.value(key + "/port")
            if (port== ""):
                port = "5432"
            self.txtPort.setText(port)
            self.txtDatabase.setText(settings.value(key + "/database"))
            self.cb_publicSchemaOnly.setChecked(settings.value(key + "/publicOnly", "false")=='true')
            self.cb_geometryColumnsOnly.setChecked(settings.value(key + "/geometryColumnsOnly", 'false')=='true')
            self.cb_dontResolveType.setChecked(settings.value(key + "/dontResolveType", 'false')=='true')
            self.cb_allowGeometrylessTables.setChecked(settings.value(key + "/allowGeometrylessTables", 'false')=='true')
            #Ensure that cb_publicSchemaOnly is set correctly
            self.on_cb_geometryColumnsOnly_clicked()

            self.cb_useEstimatedMetadata.setChecked( settings.value( key + "/estimatedMetadata", 'false' )=='true' )
            self.cbxSSLmode.setCurrentIndex( self.cbxSSLmode.findData( int(settings.value( key + "/sslmode", QgsDataSourceUri.SslPrefer ))))
            if ( settings.value( key + "/saveUsername" ) == "true" ):
                self.txtUsername.setText( settings.value( key + "/username" ) )
                self.chkStoreUsername.setChecked(True)

            if ( settings.value( key + "/savePassword" ) == "true" ):
                self.txtPassword.setText( settings.value( key + "/password" ) )
                self.chkStorePassword.setChecked(True)

            if (settings.contains(key + "/save")):
                self.txtUsername.setText(settings.value(key + "/username"))
                self.chkStoreUsername.setChecked( not self.txtUsername.text())

                if (settings.value(key + "/save") == "true"):
                    self.txtPassword.setText( settings.value( key + "/password" ) )
                    self.chkStorePassword.setChecked(True)

            authcfg = settings.value(key + "/authcfg")
            self.mAuthConfigSelect.setConfigId(authcfg)
            if (authcfg!='' and authcfg is not None):
                self.tabAuthentication.setCurrentIndex(self.tabAuthentication.indexOf(self.mAuthConfigSelect))
            self.txtName.setText(self.mOriginalConnName)
        self.txtName.setValidator(QRegExpValidator(QRegExp("[^\\/]*")))

    def signalSetUp(self):
        self.btn_test.clicked.connect(self.on_btnConnect_clicked)
        self.cb_geometryColumnsOnly.stateChanged.connect(self.on_cb_geometryColumnsOnly_clicked)
        self.buttonBox.helpRequested.connect(self.on_buttonBox_helpRequested)

    def testConnection(self,silent=False):
        uri = QgsDataSourceUri()
        authcfg=""
        if (self.txtService.text()):
            uri.setConnection(self.txtService.text(), self.txtDatabase.text(),
                              self.txtUsername.text(), self.txtPassword.text(),
                              int(self.cbxSSLmode.itemData(self.cbxSSLmode.currentIndex())),
                               authcfg)
        else:
            uri.setConnection(self.txtHost.text(), self.txtPort.text(), self.txtDatabase.text(),
                              self.txtUsername.text(), self.txtPassword.text(),
                              int(self.cbxSSLmode.itemData(self.cbxSSLmode.currentIndex())),
                                                          authcfg)

        try:
            db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                               dbname=uri.database(), user=uri.username(), passwd=uri.password())
            if not silent:
                QMessageBox.information(self,"Test connection",
                                    "Connection to %s was successful"%(self.txtDatabase.text()))
            self.b_testConnection = True
            return True
        except postgis.DbError as e:
            if not silent:
                QMessageBox.information(self,"Test connection",
                                     "Connection failed - consult message log for details.\n\nCouldn't connect to database:\n%s" % e.message)
            self.b_testConnection = False
            # raise GeoAlgorithmExecutionException(
            #     "Couldn't connect to database:\n%s" % e.message)
            return False

    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self,parent):
        self._parent = parent

    def accept(self):
        if self.testConnection(True):
            if hasattr(self.parent.iface, 'standalone'):
                self.standalone = True
            if self.standalone:
                #it is standalone application
                settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                     QSettings.NativeFormat)
            else:
                #it is run in QGIS
                settings = QSettings()
            baseKey = "/PostgreSQL/connections/"
            settings.setValue(baseKey + "selected", self.txtName.text())
            hasAuthConfigID = not self.mAuthConfigSelect.configId()==""
            #hasAuthConfigID=False
            if ((not hasAuthConfigID) and self.chkStorePassword.isChecked() and
                QMessageBox.question(self,
                         "Saving passwords",
                         "WARNING: You have opted to save your password. "
                         "It will be stored in plain text in your project files and in your home "
                         "directory on Unix-like systems, or in your user profile on Windows. "
                         "If you do not want this to happen, please press the Cancel button.\n",
                         QMessageBox.Ok or QMessageBox.Cancel ) == QMessageBox.Cancel):
                return
            # warn if entry was renamed to an existing connection
            if ((self.mOriginalConnName is not None or self.mOriginalConnName==self.txtName.text()) and
            (settings.contains(baseKey + self.txtName.text() + "/service" ) or
            settings.contains(baseKey + self.txtName.text() + "/host" ) ) and
            QMessageBox.question(self,
                                  "Save connection",
                                  "Should the existing connection %s be overwritten?"%self.txtName.text(),
                                  QMessageBox.Ok or QMessageBox.Cancel) == QMessageBox.Cancel ):
                return

            # on rename delete the original entry first
            if (self.mOriginalConnName is not None and self.mOriginalConnName != self.txtName.text() ):
                settings.remove(baseKey + self.mOriginalConnName)
                settings.sync()

            baseKey += self.txtName.text()
            settings.setValue(baseKey + "/service", self.txtService.text() )
            settings.setValue(baseKey + "/host", self.txtHost.text() )
            settings.setValue(baseKey + "/port", self.txtPort.text() )
            settings.setValue(baseKey + "/database", self.txtDatabase.text() )
            settings.setValue(baseKey + "/username", self.txtUsername.text() if self.chkStoreUsername.isChecked() else "")
            settings.setValue(baseKey + "/password",
                              self.txtPassword.text() if(self.chkStorePassword.isChecked() and not hasAuthConfigID) else "" )
            settings.setValue(baseKey + "/authcfg", self.mAuthConfigSelect.configId() )
            settings.setValue(baseKey + "/publicOnly", self.cb_publicSchemaOnly.isChecked() )
            settings.setValue(baseKey + "/geometryColumnsOnly", self.cb_geometryColumnsOnly.isChecked() )
            settings.setValue(baseKey + "/dontResolveType", self.cb_dontResolveType.isChecked())
            settings.setValue(baseKey + "/allowGeometrylessTables", self.cb_allowGeometrylessTables.isChecked())
            settings.setValue(baseKey + "/sslmode", int(self.cbxSSLmode.itemData(self.cbxSSLmode.currentIndex())))
            settings.setValue(baseKey + "/saveUsername", "true" if self.chkStoreUsername.isChecked() else "false")
            settings.setValue(baseKey + "/savePassword", "true" if self.chkStorePassword.isChecked() and not hasAuthConfigID else "false" )
            settings.setValue(baseKey + "/estimatedMetadata", self.cb_useEstimatedMetadata.isChecked())

            # remove old save setting
            settings.remove(baseKey + "/save")
            super(QmmPgNewConnection, self).accept()
        else:
            QMessageBox.information(self, "Test connection",
                                    "Connection failed - consult message log for details.\n\nCouldn't connect to database:\n")
            return

    def on_btnConnect_clicked(self):
        #print("test")
        self.testConnection()

    def on_cb_geometryColumnsOnly_clicked(self):
        if (self.cb_geometryColumnsOnly.checkState() == Qt.Checked):
            self.cb_publicSchemaOnly.setEnabled(False)
        else:
            self.cb_publicSchemaOnly.setEnabled(True)

    def on_buttonBox_helpRequested(self):
        # [TODO]
        pass




