# -*- coding: utf-8 -*-
from PyQt5 import QtCore, QtGui
import os.path,json

from qgis.PyQt import uic
from qgis.PyQt.QtCore import QSettings,Qt
from qgis.PyQt.QtWidgets import QTreeWidgetItem,QDialog,QMenu,QAction
from qgis.PyQt.QtGui import QCursor,QIcon
from SustainAssess.gui.database_menu.QmmPgNewConnection import QmmPgNewConnection
from qgis.utils import iface
try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

pluginPath = os.path.split(os.path.dirname(__file__))[0]
pluginPath = os.path.split(pluginPath)[0]
WIDGET, BASE = uic.loadUiType(
    os.path.join(pluginPath, 'ui', 'DlgDatabaseSelector.ui'))

class Database(BASE,WIDGET):

    def __init__(self,parent=None,name=None, winflag=None):
        super(Database, self).__init__(parent.iface.mainWindow())
        self.setupUi(self)
        self.parent = parent
        self.iface = self.parent.iface
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.treeConnections.setContextMenuPolicy(Qt.CustomContextMenu)
        self.refreshTreeWidget()
        self.setUpSignal()

    def refreshTreeWidget(self):
        self.treeConnections.clear()
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        settings.beginGroup("/PostgreSQL/connections/")
        names = settings.childGroups()
        settings.endGroup()
        for n in names:
            item = connectionItem(n)
            self.treeConnections.addTopLevelItem(item)

    def testConnection(self):
        pass
    def setUpSignal(self):
        self.btn_New.clicked.connect(self.on_click_btn_New)
        self.btn_Edit.clicked.connect(self.on_click_btn_Edit)
        self.btn_Select.clicked.connect(self.on_click_btn_Select)
        self.btn_Cancel.clicked.connect(self.on_click_btn_Cancel)
        self.treeConnections.customContextMenuRequested.connect(self.contextMenu_item)

    @property
    def parent(self):
        return self._parent

    @parent.setter
    def parent(self,parent):
        self._parent = parent

    def on_click_btn_New(self):
        dlg_newconnection = QmmPgNewConnection(self)
        if dlg_newconnection.exec_()==QDialog.Accepted:
            #链接成功
            print("on_click_btn_New sucess.")
            self.refreshTreeWidget()
        else:
            print("on_click_btn_New failed.")
    def on_click_btn_Edit(self):
        item = self.treeConnections.currentItem()
        con_name = item.connection
        dlg_editconnection = QmmPgNewConnection(self,con_name)
        if dlg_editconnection.exec_()==QDialog.Accepted:
            self.refreshTreeWidget()
        else:
            print("on_click_btn_Edit Cancel.")
    def on_click_btn_Select(self):
        item = self.treeConnections.currentItem()
        con_name = item.connection
        if hasattr(self.parent.iface, 'standalone'):
            self.standalone = True
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        baseKey = "/PostgreSQL/connections/"
        settings.setValue(baseKey + "selected", con_name)
        super(Database, self).accept()

    def on_click_btn_Cancel(self):
        super(Database, self).reject()

    def on_click_btn_Del(self):
        item = self.treeConnections.currentItem()
        con_name = item.connection
        if hasattr(self.parent.iface, 'standalone'):
            self.standalone = True
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        baseKey = "/PostgreSQL/connections/"
        settings.remove(baseKey + con_name)
        self.refreshTreeWidget()
        self.treeConnections.repaint()
    def contextMenu_item(self):
        popupmenu = QMenu()
        newAction = QAction(self.tr('New Connection'), self)
        editAction = QAction(self.tr('Edit Connection'), self)
        deleteAction = QAction(self.tr('Delete Connection'), self)

        popupmenu.addAction(newAction)
        popupmenu.addAction(editAction)
        popupmenu.addAction(deleteAction)

        newAction.triggered.connect(self.on_click_btn_New)
        editAction.triggered.connect(self.on_click_btn_Edit)
        deleteAction.triggered.connect(self.on_click_btn_Del)

        popupmenu.exec_(QCursor.pos())

class connectionItem(QTreeWidgetItem):
    def __init__(self,connection):
        self.connIcon = QIcon(os.path.join(pluginPath,"images","postgis.png"))
        QTreeWidgetItem.__init__(self)
        self.setChildIndicatorPolicy(QTreeWidgetItem.ShowIndicator)
        self.connection = connection
        self.setText(0, self.connection)
        self.setIcon(0,self.connIcon)