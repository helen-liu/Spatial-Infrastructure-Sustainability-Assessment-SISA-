# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'InitDataBase_UI.ui'
#
# Created: Sat Jun 10 16:39:48 2017
#      by: PyQt4 UI code generator 4.10.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Init_Database(object):
    def setupUi(self, Init_DataBase):
        Init_DataBase.setObjectName(_fromUtf8("Init_DataBase"))
        Init_DataBase.resize(442, 469)
        self.buttonBox = QtGui.QDialogButtonBox(Init_DataBase)
        self.buttonBox.setGeometry(QtCore.QRect(70, 420, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName(_fromUtf8("buttonBox"))
        self.label = QtGui.QLabel(Init_DataBase)
        self.label.setGeometry(QtCore.QRect(20, 40, 91, 21))
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(Init_DataBase)
        self.label_2.setGeometry(QtCore.QRect(20, 100, 70, 21))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label_3 = QtGui.QLabel(Init_DataBase)
        self.label_3.setGeometry(QtCore.QRect(20, 160, 91, 21))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.label_4 = QtGui.QLabel(Init_DataBase)
        self.label_4.setGeometry(QtCore.QRect(20, 220, 91, 21))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.text_server = QtGui.QLineEdit(Init_DataBase)
        self.text_server.setGeometry(QtCore.QRect(120, 40, 291, 27))
        self.text_server.setObjectName(_fromUtf8("text_server"))
        self.text_database = QtGui.QLineEdit(Init_DataBase)
        self.text_database.setGeometry(QtCore.QRect(120, 100, 291, 27))
        self.text_database.setObjectName(_fromUtf8("text_database"))
        self.text_user = QtGui.QLineEdit(Init_DataBase)
        self.text_user.setGeometry(QtCore.QRect(120, 160, 291, 27))
        self.text_user.setObjectName(_fromUtf8("text_user"))
        self.text_password = QtGui.QLineEdit(Init_DataBase)
        self.text_password.setGeometry(QtCore.QRect(120, 220, 291, 27))
        self.text_password.setEchoMode(QtGui.QLineEdit.Password)
        self.text_password.setObjectName(_fromUtf8("text_password"))
        self.Btn_Test = QtGui.QPushButton(Init_DataBase)
        self.Btn_Test.setGeometry(QtCore.QRect(40, 420, 112, 34))
        self.Btn_Test.setObjectName(_fromUtf8("Btn_Test"))
        self.label_5 = QtGui.QLabel(Init_DataBase)
        self.label_5.setGeometry(QtCore.QRect(20, 280, 91, 21))
        self.label_5.setObjectName(_fromUtf8("label_5"))
        self.text_message = QtGui.QTextEdit(Init_DataBase)
        self.text_message.setGeometry(QtCore.QRect(120, 290, 291, 91))
        self.text_message.setObjectName(_fromUtf8("text_message"))
        self.checkBox_savepw = QtGui.QCheckBox(Init_DataBase)
        self.checkBox_savepw.setGeometry(QtCore.QRect(120, 250, 171, 25))
        self.checkBox_savepw.setObjectName(_fromUtf8("checkBox_savepw"))

        self.retranslateUi(Init_DataBase)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("accepted()")), Init_DataBase.accept)
        QtCore.QObject.connect(self.buttonBox, QtCore.SIGNAL(_fromUtf8("rejected()")), Init_DataBase.reject)
        QtCore.QMetaObject.connectSlotsByName(Init_DataBase)

    def retranslateUi(self, Init_DataBase):
        Init_DataBase.setWindowTitle(_translate("Init_DataBase", "Init Database Connection", None))
        self.label.setText(_translate("Init_DataBase", "Sever", None))
        self.label_2.setText(_translate("Init_DataBase", "Database", None))
        self.label_3.setText(_translate("Init_DataBase", "User Name", None))
        self.label_4.setText(_translate("Init_DataBase", "Password", None))
        self.Btn_Test.setText(_translate("Init_DataBase", "Test", None))
        self.label_5.setText(_translate("Init_DataBase", "Message:", None))
        self.checkBox_savepw.setText(_translate("Init_DataBase", "Save Password", None))

