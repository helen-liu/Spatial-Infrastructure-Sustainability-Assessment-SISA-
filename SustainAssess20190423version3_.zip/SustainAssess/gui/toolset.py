# -*- coding: utf-8 -*-
import re,psycopg2,sys,math,random,os

def old_encrypt(key, s):
    #b = bytearray(str(s).encode("utf-8"))
    b = bytearray(str(s))
    n = len(b)  # 求出 b 的字节数
    c = bytearray(n * 2)
    j = 0
    for i in range(0, n):
        b1 = b[i]
        b2 = b1 ^ key  # b1 = b2^ key
        c1 = b2 % 16
        c2 = b2 // 16  # b2 = c2*16 + c1
        c1 = c1 + 66
        c2 = c2 + 66  # c1,c2都是0~15之间的数,加上65就变成了A-P 的字符的编码
        c[j] = c1
        c[j + 1] = c2
        j = j + 2
    return c.decode("gbk")
    #return c
def encrypt(key,s):
    return s
def old_decrypt(key, s):
    #c = bytearray(str(s).encode("utf-8"))
    c = bytearray(str(s))
    n = len(c)  # 计算 b 的字节数
    if n % 2 != 0:
        return ""
    n = n // 2
    b = bytearray(n)
    j = 0
    for i in range(0, n):
        c1 = c[j]
        c2 = c[j + 1]
        j = j + 2
        c1 = c1 - 66
        c2 = c2 - 66
        b2 = c2 * 16 + c1
        b1 = b2 ^ key
        b[i] = b1
    try:
        return b.decode("gbk")
        #return b
    except:
        return "failed"
def decrypt(key,s):
    return s

def create_random_vector(para_dic=None, cur=None, conn=None):
    # self.para_dic = {"input": {"schema": "", "name": "", "geom": "", "crs": ""},
    #                  "line": {"length": -1, "number": -1},
    #                  "point": {"number": -1},
    #                  "checkbox": "point",
    #                  "output": {"schema": "", "name": "", "geom": "", "crs": ""},
    #                  "msg": ""
    #                  }
    num = para_dic["line"]["number"]
    out_name = para_dic["output"]["name"]
    result1 = re.match("^[0-9]", out_name)  # start with digit number
    result2 = re.match(".*[A-Z].*", out_name)  # contain Capital letter
    if result1 != None or result2 != None:
        out_name = '\"' + out_name + '\"'
    random_vector_table = para_dic["output"]["schema"] + "." + out_name

    in_name = para_dic["input"]["name"]
    result1 = re.match("^[0-9]", in_name)  # start with digit number
    result2 = re.match(".*[A-Z].*", in_name)  # contain Capital letter
    if result1 != None or result2 != None:
        in_name = '\"' + in_name + '\"'
    polygon_table = para_dic["input"]["schema"] + "." + in_name
    vector_length = para_dic["line"]["length"]

    batch_ = 1000
    query = '''
            SELECT ST_Extent(%s) as bextent FROM %s;
            ''' % (para_dic["input"]["geom"],polygon_table)
    try:
        cur.execute(query)
    except psycopg2.ProgrammingError:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, exc_obj, exc_tb.tb_lineno)
        msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
        return -1, msg1
    # "BOX(668847.132598878 400923.139123538,694105.805963132 434705.427685547)"
    box_str = cur.fetchone()[0]
    minx, miny = box_str.replace('BOX(', '').replace(')', '').split(',')[0].split(' ')
    maxx, maxy = box_str.replace('BOX(', '').replace(')', '').split(',')[1].split(' ')
    minx, miny, maxx, maxy = float(minx), float(miny), float(maxx), float(maxy)

    span_x = maxx - minx
    span_y = maxy - miny
    span_angle = 2 * math.pi

    i = 0
    batch_query = "Begin;"
    batch_i = 0
    while i < num:
        r1 = random.random()
        r2 = random.random()
        r3 = random.random()

        x = minx + r1 * span_x
        y = miny + r2 * span_y
        angle = r3 * span_angle
        #         x_t = x + math.cos(angle)*1600
        #         y_t = y + math.sin(angle)*1600

        x_t = x + math.cos(angle) * vector_length
        y_t = y + math.sin(angle) * vector_length
        arg = {'id': i, 'x1': x, 'y1': y, 'x2': x_t, 'y2': y_t, 'polygon_table': polygon_table,
               "polygeom":para_dic["input"]["geom"],
               'random_vector': random_vector_table,"crs":para_dic["input"]["crs"]}

        query2 = '''
                select ST_Contains(%(polygeom)s, ST_GeomFromText('LINESTRING(%(x1)f %(y1)f,%(x2)f %(y2)f)', %(crs)s)) 
                from %(polygon_table)s
                ''' % arg
        cur.execute(query2)
        res = cur.fetchone()[0]

        if res == True:
            query3 = '''
                INSERT INTO %(random_vector)s(
                id, geom)
                    VALUES (%(id)s, ST_GeomFromText('LINESTRING(%(x1)f %(y1)f,%(x2)f %(y2)f)', %(crs)s));\n  
                ''' % arg
            batch_query += query3
            i = i + 1
            batch_i = batch_i + 1
            if batch_i % batch_ == 0:
                batch_query += "End;\n"
                try:
                    cur.execute(batch_query)
                except:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    print(exc_type, exc_obj, exc_tb.tb_lineno)
                    msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
                    return -1, msg1
                conn.commit()
                batch_query = "Begin;\n"
                batch_i = 0
    if batch_i < batch_ and batch_i > 0:
        batch_query += "End;\n"
        try:
            cur.execute(batch_query)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, exc_obj, exc_tb.tb_lineno)
            msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
            return -1, msg1
        conn.commit()
    msg = 'Populate %(random_vector)s Successfully!\n' % arg
    return 1, msg

def create_random_point(para_dic=None, cur=None, conn=None):
    # self.para_dic = {"input": {"schema": "", "name": "", "geom": "", "crs": ""},
    #                  "line": {"length": -1, "number": -1},
    #                  "point": {"number": -1},
    #                  "checkbox": "point",
    #                  "output": {"schema": "", "name": "", "geom": "", "crs": ""},
    #                  "msg": ""
    #                  }
    num = para_dic["point"]["number"]
    out_name = para_dic["output"]["name"]
    result1 = re.match("^[0-9]", out_name)  # start with digit number
    result2 = re.match(".*[A-Z].*", out_name)  # contain Capital letter
    if result1 != None or result2 != None:
        out_name = '\"' + out_name + '\"'
    random_table = para_dic["output"]["schema"] + "." + out_name

    in_name = para_dic["input"]["name"]
    result1 = re.match("^[0-9]", in_name)  # start with digit number
    result2 = re.match(".*[A-Z].*", in_name)  # contain Capital letter
    if result1 != None or result2 != None:
        in_name = '\"' + in_name + '\"'
    polygon_table = para_dic["input"]["schema"] + "." + in_name

    batch_ = 1000
    query = '''
            SELECT ST_Extent(%s) as bextent FROM %s;
            ''' % (para_dic["input"]["geom"],polygon_table)
    try:
        cur.execute(query)
    except psycopg2.ProgrammingError:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, exc_obj, exc_tb.tb_lineno)
        msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
        return -1, msg1
    # "BOX(668847.132598878 400923.139123538,694105.805963132 434705.427685547)"
    box_str = cur.fetchone()[0]
    minx, miny = box_str.replace('BOX(', '').replace(')', '').split(',')[0].split(' ')
    maxx, maxy = box_str.replace('BOX(', '').replace(')', '').split(',')[1].split(' ')
    minx, miny, maxx, maxy = float(minx), float(miny), float(maxx), float(maxy)

    span_x = maxx - minx
    span_y = maxy - miny
    span_angle = 2 * math.pi

    i = 0
    batch_query = "Begin;"
    batch_i = 0
    while i < num:
        r1 = random.random()
        r2 = random.random()

        x = minx + r1 * span_x
        y = miny + r2 * span_y

        arg = {'id': i, 'x1': x, 'y1': y, 'polygon_table': polygon_table,
               "polygeom":para_dic["input"]["geom"],
               'random_point': random_table,"crs":para_dic["input"]["crs"]}

        query2 = '''
                select ST_Contains(%(polygeom)s, ST_GeomFromText('POINT(%(x1)f %(y1)f)', %(crs)s)) 
                from %(polygon_table)s
                ''' % arg
        cur.execute(query2)
        res = cur.fetchone()[0]

        if res == True:
            query3 = '''
                INSERT INTO %(random_point)s(
                id, geom)
                    VALUES (%(id)s, ST_GeomFromText('POINT(%(x1)f %(y1)f)', %(crs)s));\n  
                ''' % arg
            batch_query += query3
            i = i + 1
            batch_i = batch_i + 1
            if batch_i % batch_ == 0:
                batch_query += "End;\n"
                try:
                    cur.execute(batch_query)
                except:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    print(exc_type, exc_obj, exc_tb.tb_lineno)
                    msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
                    return -1, msg1
                conn.commit()
                batch_query = "Begin;\n"
                batch_i = 0
    if batch_i < batch_ and batch_i > 0:
        batch_query += "End;\n"
        try:
            cur.execute(batch_query)
        except:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, exc_obj, exc_tb.tb_lineno)
            msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
            return -1, msg1
        conn.commit()
    msg = 'Populate %(random_point)s Successfully!\n' % arg
    return 1, msg

def testLayerExists(para_dic=None,cur=None,conn=None):
    #TODO:later
    #para_dic = {"output":{"schema":"","name":"",}}
        if para_dic["output"]["name"]=="": return -3,"Null String!\n"
        schema = self.para_dic["output"]["schema"]
        type = self.para_dic["output"]["type"]
        if schema=="":
            schema = "public"
        field_exist=False
        table = self.para_dic["output"]["name"]

        result1 = re.match("^[0-9]", table)#start with digit number
        result2 = re.match(".*[A-Z].*",table)#contain Capital letter
        if result1!=None or result2!=None:
            return -2,"Output Name invalid!"

        test_layer_command = '''
                SELECT EXISTS(
                SELECT 1 FROM geometry_columns
                WHERE f_table_schema = '%s' AND f_table_name = '%s');
        ''' % (schema, table)
        try:
            self.cur.execute(test_layer_command)
            field_exist = self.cur.fetchall()[0][0]
        except psycopg2.ProgrammingError:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, exc_obj, exc_tb.tb_lineno)
            msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
            self.ui.text_message.setText(msg1)
            return -1, msg1

        if field_exist:
            test_layer_command = '''
                    SELECT EXISTS(
                    SELECT 1 FROM geometry_columns
                    WHERE f_table_schema = '%s' AND f_table_name = '%s' AND type='%s');
            ''' % (schema, table,type)
            try:
                self.cur.execute(test_layer_command)
                geom_exist = self.cur.fetchall()[0][0]
            except psycopg2.ProgrammingError:
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print(exc_type, exc_obj, exc_tb.tb_lineno)
                msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
                self.ui.text_message.setText(msg1)
                return -1, msg1
            if geom_exist:
                return 1, schema + "." + table + " exists! Will overwrite!\n"
            else:
                return 2, schema + "." + table + " exists but with different Geo Type!\n Will Delete and Create!\n"
        else:
            return 0, schema + "." + table + " not exists! Will Create!\n"

def testFieldExists(para_dic=None,cur=None,conn=None):
    #para_dic = {"schema":"","name":"","field":""}
        if para_dic["name"]=="": return -3,"Empty Table Name!\n"
        schema = para_dic["schema"]
        if schema=="":
            schema = "public"
        field_exist=False
        table = para_dic["name"]

        result1 = re.match("^[0-9]", table)#start with digit number
        result2 = re.match(".*[A-Z].*",table)#contain Capital letter
        if result1!=None or result2!=None:
            table='\"' + table + '\"'

        field_name = para_dic["field"]
        test_fielsd_command = '''
                        SELECT EXISTS(
                        SELECT 1 FROM information_schema.columns
                        WHERE table_schema = '%s' AND table_name = '%s' AND column_name = '%s');
                ''' % (schema, table, field_name)
        try:
            cur.execute(test_fielsd_command)
            field_exist = cur.fetchall()[0][0]
            if field_exist:
                return 1, field_name + " exists! Will overwrite!\n"
            else:
                return 0, field_name + " not exists! Will Create!\n"
        except psycopg2.ProgrammingError:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print(exc_type, exc_obj, exc_tb.tb_lineno)
            msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
            return -1, msg1

def addField(para_dic=None,cur=None,conn=None):
    # para_dic = {"schema":"","name":"","field":""}
    if para_dic["name"] == "": return -3, "Empty Table Name!\n"
    schema = para_dic["schema"]
    if schema == "":
        schema = "public"
    para_dic["schema"] = schema

    table = para_dic["name"]
    result1 = re.match("^[0-9]", table)  # start with digit number
    result2 = re.match(".*[A-Z].*", table)  # contain Capital letter
    if result1 != None or result2 != None:
        table = '\"' + table + '\"'
    para_dic["name"] = table

    sql_create = '''
         ALTER TABLE %(schema)s.%(name)s DROP COLUMN IF EXISTS %(field)s;
         ALTER TABLE %(schema)s.%(name)s ADD COLUMN %(field)s numeric; 
               ''' % para_dic
    try:
        cur.execute(sql_create)
        conn.commit()
    except psycopg2.ProgrammingError:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, exc_obj, exc_tb.tb_lineno)
        msg1 = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
        return -1, msg1

    return 1, "Create Fields Successfully!"

### get the real path of the parent directory of current file's directory
def get_file_parent_dir_path():
    from os.path import dirname
    from os.path import abspath
    """return the path of the parent directory of current file's directory """
    realpath = os.path.dirname(os.path.realpath(__file__))
    path_sep = os.path.sep
    components = realpath.split(path_sep)
    return path_sep.join(components[:-1])

### get the real path of the parent directory of current file's directory
def get_file_grandparent_dir_path():
    from os.path import dirname
    from os.path import abspath
    """return the path of the parent's parent directory of current file's directory """
    # current_dir_path = dirname(abspath(__file__))
    realpath = os.path.dirname(os.path.realpath(__file__))
    path_sep = os.path.sep
    components = realpath.split(path_sep)
    return path_sep.join(components[:-2])