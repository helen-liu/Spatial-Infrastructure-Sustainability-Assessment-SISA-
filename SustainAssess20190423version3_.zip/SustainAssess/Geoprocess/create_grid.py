# -*- coding: utf-8 -*-

import sys
import psycopg2
import time
import math
#firsto<connect the database


def createGrid(para_dic=None,conn=None,cur=None):
    #create table in postgres akron.grid_2000
    # self.para_dic = {"gridtable": {"schema": "", "name": "", "crs": "", "size": -1},
    #                  "boudary": {"xmin": 0, "ymin": 0, "xmax": 0, "ymax": 0}}
    arg1 = para_dic
    #creat blocks based on xmin,ymin,xmax,ymax
    xmin,ymin = para_dic["boudary"]["xmin"],para_dic["boudary"]["ymin"]#663258.00,397446.53
    xmax,ymax = para_dic["boudary"]["xmax"],para_dic["boudary"]["ymax"]#697961.25,437944.19
    lgh = para_dic["gridtable"]["size"]#400   ## the unit is the same as the spatial reference
    table_name = "%(schema)s.%(name)s"%arg1["gridtable"]
    blocks={}
    x_c,y_c = xmin,ymax
    id = 0
    while True:
        while True:
            geo_string = 'MULTIPOLYGON(((%.5f %.5f,%.5f %.5f,%.5f %.5f,%.5f %.5f,%.5f %.5f)))'%(x_c,y_c,x_c+lgh,y_c,x_c+lgh,y_c-lgh,x_c,y_c-lgh,x_c,y_c)
            blocks[id] = geo_string
            sql_c = '''INSERT INTO %s(
                    id, geom)
                     VALUES (%s,ST_GeomFromText('%s',3520));'''%(table_name,str(id),geo_string)
            id=id + 1

            cur.execute(sql_c)
            conn.commit()
            if y_c - lgh>=ymin:
                y_c = y_c - lgh
            else:
                break
        if x_c + lgh <=xmax:
            x_c = x_c + lgh
            y_c = ymax
        else:
            break
    msg = 'Grid process in table %(schema)s.%(name)s Successfully!\n' % arg1["gridtable"]
    return 1,msg
if __name__ == '__main__':
    try:
        con_str = "dbname='atlanta_285' user='postgres' host='localhost' password='mliu0727'"
        print(con_str)
        db_connection = psycopg2.connect(con_str)
        db_cursor = db_connection.cursor()
    except:
        print("I am unable to connect to the database")