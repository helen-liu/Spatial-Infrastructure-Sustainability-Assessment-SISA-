# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SpatialSustainAssess
                                 A QGIS plugin
 Evaluating sustainability of objects from multiple dimensions
                              -------------------
        begin                : 2018-06-25
        git sha              : $Format:%H$
        copyright            : (C) 2018 by Mengmeng Helen Liu / Georgia Insitute of Technology
        email                : mengmeng.liu@gatech.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from qgis.core import QgsMessageLog
import SustainAssess.tools.dataobjects
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.gui.MessageDialog import MessageDialog
from SustainAssess.gui.AlgorithmDialog import AlgorithmDialog
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.gui.MessageBarProgress import MessageBarProgress
from SustainAssess.gui.AlgorithmExecutor import runalg
from SustainAssess.gui.Postprocessing import handleAlgorithmResults
from qgis.PyQt.QtWidgets import QDialog,QAction,QFileDialog,QMenu,QWidget,QMessageBox
from qgis.PyQt.QtCore import QTranslator,qVersion,QCoreApplication,QObject
from qgis.PyQt.QtGui import QIcon
import os.path
import sys
import inspect
from SustainAssess.gui.database_menu.Database import Database
from SustainAssess.algs.sustain.Wizard import Wizard
from SustainAssess.algs.sustain.SustainAlgorithmProvider import SustainAlgorithmProvider
from SustainAssess.algs.sustain.share import algList,algNameList,standalone
# path
cmd_folder = os.path.split(inspect.getfile(inspect.currentframe()))[0]
if cmd_folder not in sys.path:
    sys.path.insert(0, cmd_folder)


class SpatialSustainAssess_qs(QObject):
    """QGIS Plugin Implementation."""
    providers=[]
    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgisInterface
        """
        # Save reference to the QGIS interface
        super(SpatialSustainAssess_qs, self).__init__()
        self.iface = iface

        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale
        locale = 'en'
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'SpatialSustainAssess_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.main_menu_name = self.tr("&Sustainability")
        self.submenu_test_name = self.tr(u'&Spatial Sustainability Assessment')

        # TODO: We are going to let the user set this up in a future iteration
        #self.toolbar = self.iface.addToolBar(u'SpatialSustainAssess')
        #self.toolbar.setObjectName(u'SpatialSustainAssess')

        self.icons_folder = ':/plugins/SustainAssess/icons/'

        ## init database submenu
        # self.databaseWin = None
        self.connection_dic = {"server": "", "dbname": "", "user":"","password":""}

        ## init geoprocess menu
        self.geoprocessWin = None
        provider = SustainAlgorithmProvider()
        self.providers.append(provider)
        ProcessingConfig.initialize()
        ProcessingConfig.readSettings()

    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('SpatialSustainAssess', message)


    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        ####---------------------------------------------------------------------
        # Check if the menu exists and get it
        self.main_menu = self.iface.mainWindow().findChild(QMenu, self.main_menu_name)  #self.main_menu_name = self.tr("&Sustainability")
        self.menubar = self.iface.mainWindow().menuBar()

        self.main_menu = QMenu('&Sustainability', self.menubar)
        self.main_menu.setObjectName('&Sustainability')

        actions = self.iface.mainWindow().menuBar().actions()
        lastAction = actions[-1]
        self.iface.mainWindow().menuBar().insertMenu(lastAction, self.main_menu)
        self.menu_path = {}
        self.menu_path["Sustainability"] = self.main_menu
        for provider in self.providers:
            algs = provider.alglist
            for alg in algs:
                algList[alg.name] = alg
                algNameList.append(alg.name)

        ## submenu for 'database'   ---------------------------------------------------
        self.submenu_SetDatabase = QMenu('&Set Database', self.main_menu)
        self.submenu_SetDatabase.setObjectName('setDatabase')    #self.submenu_test_name = self.tr(u'&Spatial Sustainability Assessment')
        icon_path = os.path.join(self.icons_folder,'dabase.png')
        action_SetDatabase = QAction(QIcon(icon_path),"&Database",self.iface.mainWindow())
        action_SetDatabase.triggered.connect(self.on_click_setDatabase_init)
        self.submenu_SetDatabase.addAction(action_SetDatabase)
        self.main_menu.addAction(self.submenu_SetDatabase.menuAction())
        #[TODO] add results dialog

        for algname in algNameList:
            alg = algList[algname]
            alg_menu_path = alg.menu_path
            alg_menu_path_list = alg_menu_path.split("/")
            menu_action = algname
            alg_menu_path_list_before_menu_action = alg_menu_path_list[1:-1]
            parent_menu_str = alg_menu_path_list[0]

            menus_keys = self.menu_path.keys()
            for child_menu_str in alg_menu_path_list_before_menu_action:
                cur_path = parent_menu_str + "/" + child_menu_str
                if cur_path not in menus_keys:
                    #menu not exit, need creat
                    q_menu = QMenu(child_menu_str, self.main_menu)
                    q_menu.setObjectName(child_menu_str)
                    self.menu_path[cur_path] = q_menu
                    self.menu_path[parent_menu_str].addAction(q_menu.menuAction())
                else:
                    #menu exist, do nothing
                    pass
                parent_menu_str = cur_path
            #add the action menu to cur_menu
            cur_path = parent_menu_str + "/" + menu_action
            icon_path = alg.getIcon()
            action = QAction(QIcon(icon_path), menu_action, self.main_menu)
            action.setObjectName(cur_path)
            action.triggered.connect(self.executeAlgorithm)
            self.menu_path[parent_menu_str].addAction(action)
            self.menu_path[cur_path] = action
            self.actions.append(action)

        self.wizard = Wizard(self.actions,algList)
        self.submenu_Wizard = QMenu('&Wizard', self.main_menu)
        self.submenu_Wizard.setObjectName('Wizard')
        icon_path = self.icons_folder + 'icon.png'
        actionStartWizard = QAction(QIcon(icon_path), "&Start Sustainability Evaluation", self.iface.mainWindow())
        actionStartWizard.triggered.connect(self.wizard.show)
        self.submenu_Wizard.addAction(actionStartWizard)
        self.main_menu.addAction(self.submenu_Wizard.menuAction())

        QgsMessageLog.logMessage("I am here")
        ####---------------------------------------------------------------------

    def onClosePlugin(self):
        """Cleanup necessary items here when plugin dockwidget is closed"""

        # remove this statement if dockwidget is to remain
        # for reuse if plugin is reopened
        # Commented next statement since it causes QGIS crashe
        # when closing the docked window:
        pass

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        self.main_menu.deleteLater()
        for action in self.actions:
            self.iface.unregisterMainWindowAction(action)

    def executeAlgorithm(self):
        item = self.sender()
        algname = item.objectName()
        algname = algname.split("/")[-1]
        alg = algList[algname]
        if isinstance(alg, GeoAlgorithm):
            message = alg.checkBeforeOpeningParametersDialog()
            if message:
                dlg = MessageDialog()
                dlg.setTitle(self.tr('Error executing algorithm'))
                dlg.setMessage(
                    self.tr('<h3>This algorithm cannot '
                            'be run :-( </h3>\n%s') % message)
                dlg.exec_()
                return
            alg = alg.getCopy()
            if (alg.getVisibleParametersCount() + alg.getVisibleOutputsCount()) > 0:
                dlg = alg.getCustomParametersDialog()
                if not dlg:
                    dlg = AlgorithmDialog(alg)
                canvas = self.iface.mapCanvas()
                prevMapTool = canvas.mapTool()
                dlg.show()
                dlg.exec_()
                if canvas.mapTool() != prevMapTool:
                    try:
                        canvas.mapTool().reset()
                    except:
                        pass
                    canvas.setMapTool(prevMapTool)
                canvas.refresh()
                if dlg.executed:
                    showRecent = ProcessingConfig.getSetting(
                        ProcessingConfig.SHOW_RECENT_ALGORITHMS)
                    if showRecent:
                        self.addRecentAlgorithms(True)
            else:
                progress = MessageBarProgress()
                runalg(alg, progress)
                handleAlgorithmResults(alg, progress)
                progress.close()

    def addRecentAlgorithms(self,b):
        pass
    def on_click_setDatabase_init(self):
        win_database = Database(self)
        if win_database.exec_()==QDialog.Accepted:
            #链接成功
            print("on_click_setDatabase_init sucess.")
        else:
            print("on_click_setDatabase_init failed.")

    # def run_CreateRandomVector(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.geoprocessWin:
    #             self.geoprocessWin = GeoprocessWinClass(self.iface, self.connection_dic)
    #
    #         self.geoprocessWin.createRandomVector()
    #         self.connection_dic = self.geoprocessWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    # def run_CreateRandomPoint(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.geoprocessWin:
    #             self.geoprocessWin = GeoprocessWinClass(self.iface, self.connection_dic)
    #
    #         self.geoprocessWin.createRandomPoint()  ##TODO: check if need implement createRandomPoint()
    #         self.connection_dic = self.geoprocessWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    # def run_CreateBuffer(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.geoprocessWin:
    #             self.geoprocessWin = GeoprocessWinClass(self.iface, self.connection_dic)
    #
    #         self.geoprocessWin.createBuffer()       ## TODO: createBuffer() to be implemented
    #         self.connection_dic = self.geoprocessWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    # def run_Connectivity_AlphaIndex(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Connectivity_AlphaIndex
    #         self.networkAnalysisWin.Connectivity_AlphaIndex()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    #
    # def run_Connectivity_BetaIndex(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Connectivity_BetaIndex
    #         self.networkAnalysisWin.Connectivity_BetaIndex()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!", QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    # def run_Connectivity_GammaIndex(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Connectivity_GammaIndex
    #         self.networkAnalysisWin.Connectivity_GammaIndex()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    # def run_Connectivity_DetourIndex(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Connectivity_PRD (Detour Index)
    #         self.networkAnalysisWin.Connectivity_PRD()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    # def run_Accessibility_NearestDistance(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Accessibility_NearestDistance
    #         self.networkAnalysisWin.Accessibility_NearestDistance()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    # def run_Accessibility_ResourcesWithinDistance(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Accessibility_ResourcesWithinDistance
    #         self.networkAnalysisWin.Accessibility_ResourcesWithinDistance()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)

    # def run_Centrality_Betweenness (self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Centrality_Betweenness  TODO: to be implement
    #         self.networkAnalysisWin.Centrality_Betweenness()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)
    #
    # def run_Centrality_Closeness(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Centrality_Closeness  TODO: to be implement Centrality_Closeness()
    #         self.networkAnalysisWin.Centrality_Closeness()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)
    #
    #
    # def run_Centrality_CrossClique(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Centrality_CrossClique  TODO: to be implement Centrality_CrossClique()
    #         self.networkAnalysisWin.Centrality_CrossClique()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)
    #
    # def run_Centrality_Eigenvector(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Centrality_Eigenvector  TODO: to be implement Centrality_Eigenvector()
    #         self.networkAnalysisWin.Centrality_Eigenvector()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)
    #
    # def run_Centrality_Freeman(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Centrality_Freeman  TODO: to be implement Centrality_Freeman()
    #         self.networkAnalysisWin.Centrality_Freeman()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)
    #
    # def run_Centrality_Katz(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Centrality_Katz  TODO: to be implement Centrality_Katz()
    #         self.networkAnalysisWin.Centrality_Katz()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)
    #
    # def run_Centrality_PageRank(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Centrality_PageRank  TODO: to be implement Centrality_PageRank()
    #         self.networkAnalysisWin.Centrality_PageRank()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)
    #
    # def run_Centrality_Percolation(self):
    #     if self.databaseWin.testConnectionString() == True:
    #         if not self.networkAnalysisWin:
    #             self.networkAnalysisWin = NetworkAnalysisWinClass(self.iface, self.connection_dic)
    #
    #         ## run actions related to Centrality_Percolation  TODO: to be implement Centrality_Percolation()
    #         self.networkAnalysisWin.Centrality_Percolation()
    #         self.connection_dic = self.networkAnalysisWin.getConnectionDic()
    #     else:
    #         # Show a message box
    #         result = QMessageBox.question(self.iface.mainWindow(), 'Message', "Please Set Up Database First!",
    #                                       QMessageBox.Yes | QMessageBox.No,
    #                                       QMessageBox.No)