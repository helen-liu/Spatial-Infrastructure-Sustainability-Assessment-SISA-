# -*- coding: utf-8 -*-

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import math
from SustainAssess.gui.AlgorithmExecutor import runalg,runalgIterating
from qgis.PyQt.QtGui import QIcon,QFont,QCursor,QColor, QPalette
from qgis.PyQt.QtWidgets import QAbstractItemView,QApplication,QMessageBox,QWidget,QVBoxLayout,QPushButton,\
                    QScrollArea,QFrame,QSpacerItem,QSizePolicy,QLabel,QHBoxLayout,QTableWidget,\
                    QTableWidgetItem,QComboBox,QCheckBox
from qgis.PyQt.QtCore import QVariant,QRect,QSize,QItemSelectionModel
from qgis.core import (QgsField,QgsProject,QgsFields,
                       QgsFeature,QgsDataSourceUri,QgsMapLayer)
from SustainAssess.gui.OutputSelectionPanel import OutputSelectionPanel
from qgis.PyQt.QtCore import Qt,NULL
from SustainAssess.gui.InputLayerRDBMSelectorPanel import InputLayerRDBMSelectorPanel
from qgis.gui import QgsCollapsibleGroupBox
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.gui.AlgorithmDialogBase import AlgorithmDialogBase
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterSelection,ParameterRaster
from SustainAssess.core.parameters import ParameterTableField,ParameterNumber
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector,OutputRaster, OutputTable,OutputVector_liu
from SustainAssess.gui.NumberInputPanel import NumberInputPanel
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.tools import dataobjects,postgis,spatialite
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.gui.Postprocessing import handleAlgorithmResults
pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class Normalization(GeoAlgorithm):

    POLY_ZONE_VECTOR = 'POLY_ZONE_VECTOR' #poly_layer REGION_BY_WAYS_LAYER
    POLY_ZONE_ID_FIELD = 'POLY_ZONE_ID_FIELD'

    NORMALIZATION_METHOD = 'NORMALIZATION_METHOD'
    NORMALIZATION_METHOD_OPTIONS = ['Min-Max','Standard (Z-Score)','Ranking','Distance-to-Reference','Categorical-Scales']
    REFERENCE_NUM = 'REFERENCE_NUM'
    OUTPUT_LAYER = 'OUTPUT_LAYER'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Indicator Analysis/Normalization"
        self.name, self.i18n_name = self.trAlgorithm('Normalization')
        self.group, self.i18n_group = self.trAlgorithm('Geoprocess')
        self.addParameter(ParameterVector_RDBMS(self.POLY_ZONE_VECTOR,
                                          self.tr('Input Zone Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterTableField(self.POLY_ZONE_ID_FIELD,
                                          self.tr('ID Field'),self.POLY_ZONE_VECTOR,defalut="id"))
        self.addParameter(ParameterSelection(self.NORMALIZATION_METHOD, self.tr('Normalization Method'),
                                             self.NORMALIZATION_METHOD_OPTIONS, 0))
        self.addParameter(ParameterNumber(self.REFERENCE_NUM, self.tr('Reference Number'), default=None))
        self.addOutput(OutputVector(self.OUTPUT_LAYER, self.tr('Normalization Layer Output')))

    def getCustomParametersDialog(self):
        self.dlg = NormalizationDialog(self)
        return self.dlg

    def processAlgorithm(self, progress):
        self.progress = progress
        paramInput = self.getParameterFromName(self.POLY_ZONE_VECTOR)
        self.m_POLY_ZONE_VECTOR = paramInput.getLayerObject()
        self.m_POLY_ZONE_ID_FIELD = self.getParameterValue(self.POLY_ZONE_ID_FIELD)
        self.m_POLY_ZONE_ID_FIELD_TYPE = None
        self.m_NORMALIZATION_METHOD = self.NORMALIZATION_METHOD_OPTIONS[self.getParameterValue(self.NORMALIZATION_METHOD)]
        self.m_OUTPUT_LAYER = self.getOutputValue(self.OUTPUT_LAYER)
        if self.dlg.widgets["REFERENCE_NUM"].isVisible():
            self.m_REFERENCE_NUM = self.getParameterValue(self.REFERENCE_NUM)
            if self.m_REFERENCE_NUM==0:
                QMessageBox.critical(None, ("Reference Number"),
                                     ("Please set reference number larger than 0!"))
                return
        select_widget = self.dlg.selected_widget
        nrows = select_widget.rowCount()-1
        fields_ = []
        alias = {}
        effects = [] # 0:positive,1:negative
        for i in range(nrows):
            item_t = select_widget.item(i,0)
            key = item_t.text()
            if key =="":
                raise("error row count")
            fields_.append(key)
            item_t = select_widget.item(i, 1)
            text = item_t.text()
            if text =="":
                text = fields_[i]
            alias[key] = text
            item_w = select_widget.cellWidget(i, 2)
            effects.append(item_w.currentIndex())
        #--------1.read raw data into memory;---------------------------------------------------------------------------
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_POLY_ZONE_VECTOR.selectedFeatureCount() > 0:
            feats = self.m_POLY_ZONE_VECTOR.getSelectedFeatures()
            count = int(self.m_POLY_ZONE_VECTOR.selectedFeatureCount())
        else:
            feats = self.m_POLY_ZONE_VECTOR.getFeatures()
            count = int(self.m_POLY_ZONE_VECTOR.featureCount())

        fields = self.m_POLY_ZONE_VECTOR.fields()
        if fields.count() <= 0:
            raise Exception("Error: Attribute table must have at least one field")
        df = {}
        types = {}
        order = []
        fid = {"fid": []}

        for field in fields:
            # initial read in has correct ordering...
            name = str(field.name())
            if name in fields_:
                df[name] = {}
                types[name] = int(field.type())
                order.append(name)
            if name == self.m_POLY_ZONE_ID_FIELD:
                self.m_POLY_ZONE_ID_FIELD_TYPE = int(field.type())
        for current, feat in enumerate(feats):
            id_ = feat[self.m_POLY_ZONE_ID_FIELD]
            for name in fields_:
                val = feat[name]
                df[name][id_] = val
            fid["fid"].append(feat.id())
        # --------2.normalization;--------------------------------------------------------------------------------------
        #['Min-Max', 'Standardization(Z-Score)', 'Ranking', 'Distance-to-Reference', 'Categorical-Scales']
        if self.m_NORMALIZATION_METHOD==self.NORMALIZATION_METHOD_OPTIONS[0]: #"Max-Min"
            max_list = [0] * len(fields_)
            min_list = [0] * len(fields_)
            #get min
            for i,f in enumerate(fields_):
                data_ = df[f]
                data_2 = []
                for xi in data_.values():
                    if xi != NULL:
                        data_2.append(float(xi))
                data_ = data_2
                # mean_ = sum(data_) / len(data_)
                # varRes = sum([(xi - mean_) ** 2 for xi in data_]) / (len(data_) - 1)
                max_list[i], min_list[i] = max(data_), min(data_)
            #normalize
            for i, f in enumerate(fields_):
                data_ = df[f]
                span = max_list[i] - min_list[i]
                if effects[i]==0:# Positive
                    for key in data_.keys():
                        if data_[key] != NULL:
                            data_[key] = (data_[key]-min_list[i]) / span
                else: # negative
                    for key in data_.keys():
                        if data_[key] != NULL:
                            data_[key] = 1.0 - (data_[key]-min_list[i]) / span

        elif self.m_NORMALIZATION_METHOD==self.NORMALIZATION_METHOD_OPTIONS[1]: #"Standardization(Z-Score)"
            # get total number
            max_list = [0] * len(fields_)
            min_list = [0] * len(fields_)
            mean_list = [0] * len(fields_)
            var_list = [0] * len(fields_)
            #get min
            for i,f in enumerate(fields_):
                data_ = df[f]
                data_2 = []
                for xi in data_.values():
                    if xi != NULL:
                        data_2.append(float(xi))
                data_ = data_2
                mean_list[i] = sum(data_) / len(data_)
                var_list[i] = math.sqrt(sum([(xi - mean_list[i]) ** 2 for xi in data_]) / (len(data_) - 1))
                max_list[i], min_list[i] = max(data_), min(data_)
            #normalize
            for i, f in enumerate(fields_):
                data_ = df[f]
                span = max_list[i] - min_list[i]
                if effects[i] == 0:  # Positive
                    for key in data_.keys():
                        if data_[key] != NULL:
                            data_[key] = (data_[key]-mean_list[i]) / var_list[i]
                else: # negative
                    for key in data_.keys():
                        if data_[key] != NULL:
                            data_[key] = -1.0 * (data_[key]-mean_list[i]) / var_list[i]


        elif self.m_NORMALIZATION_METHOD==self.NORMALIZATION_METHOD_OPTIONS[2]: # Ranking
            for i,f in enumerate(fields_):
                data_ = df[f]
                keys = data_.keys()
                if effects[i]==0: #Positive
                    data_2 = [data_[key] for key in keys]
                else: # Negative
                    data_2 = [-1.0* data_[key] for key in keys]
                rankdata = self.rankdata(data_2)
                for i,key in enumerate(keys):
                    data_[key] = rankdata[i]

        elif self.m_NORMALIZATION_METHOD==self.NORMALIZATION_METHOD_OPTIONS[3]: # Distance-to-Reference
            for i, f in enumerate(fields_):
                data_ = df[f]
                ref = self.m_REFERENCE_NUM
                if effects[i] == 0:  # Positive
                    for key in data_.keys():
                        if data_[key] != NULL:
                            data_[key] = (data_[key] - ref) / ref
                else: # negative
                    for key in data_.keys():
                        if data_[key] != NULL:
                            data_[key] = -1.0 * (data_[key] - ref) / ref
        else:
            pass
        # --------3.write output;--------------------------------------------------------------------------------------
        # write the data to the output
        idTypes_map = {'10': "text", '2': "integer", '4': "bigint",
                       '3': "integer", '5': "bigint"}
        fields_add = QgsFields()
        fields_add.append(QgsField(self.m_POLY_ZONE_ID_FIELD, self.m_POLY_ZONE_ID_FIELD_TYPE,
                               idTypes_map[str(self.m_POLY_ZONE_ID_FIELD_TYPE)], 10, 0))
        for f in fields_:
            qfield_ = QgsField(alias[f], QVariant.Double, 'numeric(20,10)', 20, 10)
            # qfield_.setAlias(alias[f])
            fields_add.append(qfield_)

        writer = self.getOutputFromName(self.OUTPUT_LAYER).getVectorWriter(
            fields_add,self.m_POLY_ZONE_VECTOR.wkbType(),self.m_POLY_ZONE_VECTOR.crs())

        polys = self.m_POLY_ZONE_VECTOR.getFeatures()
        count = int(self.m_POLY_ZONE_VECTOR.featureCount())
        ft = QgsFeature()
        ind = 0
        for poly in polys:
            id_ = poly[self.m_POLY_ZONE_ID_FIELD]
            attr = [id_]
            for f in fields_:
                attr.append(df[f][id_])
            ft.setAttributes(attr)
            ft.setGeometry(poly.geometry())
            writer.addFeature(ft)
            ind += 1
        del writer
        progress.setPercentage(int(100))

    def rank_simple(self,vector):
        return sorted(range(len(vector)), key=vector.__getitem__)

    def rankdata(self,a, method='min'):
        #https://stackoverflow.com/questions/3071415/efficient-method-to-calculate-the-rank-vector-of-a-list-in-python
        n = len(a)
        ivec = self.rank_simple(a)
        svec = [a[rank] for rank in ivec]
        sumranks = 0
        dupcount = 0
        newarray = [0] * n
        for i in range(n):
            sumranks += i
            dupcount += 1
            if i == n - 1 or svec[i] != svec[i + 1]:
                for j in range(i - dupcount + 1, i + 1):
                    if method == 'average':
                        averank = sumranks / float(dupcount) + 1
                        newarray[ivec[j]] = averank
                    elif method == 'max':
                        newarray[ivec[j]] = i + 1
                    elif method == 'min':
                        newarray[ivec[j]] = i + 1 - dupcount + 1
                    else:
                        raise NameError('Unsupported method')

                sumranks = 0
                dupcount = 0

        return newarray

class NormalizationDialog(AlgorithmDialogBase):
    def __init__(self,alg):
        AlgorithmDialogBase.__init__(self,alg)

        self.alg = alg
        self.checkBoxes = {}
        self.mainWidget = self.MainPanel()
        self.setMainWidget()
        self.iterateButtons = {}

        self.cornerWidget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0,0,0,5) #void QLayout::setContentsMargins(int left, int top, int right, int bottom)
        self.tabWidget.setStyleSheet("QTabBar::tab { height: 30px; }")
        #self.runAsBatchButton = QPushButton(self.tr("Run as batch process..."))
        #self.runAsBatchButton.clicked.connect(self.runAsBatch)
        #layout.addWidget(self.runAsBatchButton)
        # self.cornerWidget.setLayout(layout)
        # self.tabWidget.setCornerWidget(self.cornerWidget)

        QgsProject.instance().layerWasAdded.connect(self.layerAdded_normalization)
        QgsProject.instance().layersWillBeRemoved.connect(self.layersWillBeRemoved_normalization)

    def MainPanel(self):
        myForm = QWidget()
        myForm.setObjectName("From")
        myForm.resize(400,200) #resize(int w, int h)
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Preferred)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}
        self.labels = {}
        # add 1 parameter ParameterVector_RDBMS=========================================================
        param = self.alg.parameters[0]
        layers = dataobjects.getVectorLayers(param.shapetype) # 2 Polygon
        items = []
        for layer in layers:
            items.append((layer.name(), layer))

        widget = InputLayerRDBMSelectorPanel(items, param)
        widget.cmbText.name = param.name
        widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)
        self.widgets[param.name] = widget

        desc = param.description
        label = QLabel(desc)
        # label.setToolTip(tooltip)
        self.labels[param.name] = label

        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)
        # add parameter Fields
        param = self.alg.parameters[1]
        item = QComboBox()
        desc = param.description
        label = QLabel(desc)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        self.widgets[param.name] = item


        # add 2 parameter Normalization Method=========================================================
        param = self.alg.parameters[2]
        desc = param.description
        label = QLabel(desc)
        # label.setToolTip(tooltip)
        self.labels[param.name] = label
        item = QComboBox()
        item.addItems(param.options)
        if param.default:
            item.setCurrentIndex(param.default)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        self.widgets[param.name] = item


        def indchanged(ind):
            param = self.alg.getParameterFromName(self.alg.REFERENCE_NUM)
            if ind == 3:
                self.widgets["REFERENCE_NUM"].show()
                param.hidden=False
                self.labels["REFERENCE_NUM"].show()
            else:
                self.widgets["REFERENCE_NUM"].hide()
                param.hidden=True
                self.labels["REFERENCE_NUM"].hide()
        item.currentIndexChanged.connect(indchanged)
        # add
        param = self.alg.getParameterFromName(self.alg.REFERENCE_NUM)
        desc = param.description
        label = QLabel(desc)
        self.labels[param.name] = label
        item = NumberInputPanel(param.default, param.min, param.max,
                                param.isInteger)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        self.widgets[param.name] = item
        self.widgets["REFERENCE_NUM"].hide()
        param.hidden=True
        self.labels["REFERENCE_NUM"].hide()

        # add fields
        widget_2 = QWidget()
        widget_2.setObjectName("widget_2")
        widget_2.resize(400, 550)
        self.horizontalLayout = QHBoxLayout(widget_2)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setMargin(0)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.label = QLabel(widget_2)
        font = QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.verticalLayout_6.addWidget(self.label)
        self.unselected_widget = QTableWidget(widget_2)
        self.unselected_widget.setObjectName("unselected_widget")
        # self.unselected_widget.resize(100,550)
        self.verticalLayout_6.addWidget(self.unselected_widget)
        self.horizontalLayout.addLayout(self.verticalLayout_6)
        self.unselected_widget.insertColumn(0)
        self.unselected_widget.setHorizontalHeaderItem(0,QTableWidgetItem("Fields"))
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        self.unselected_widget.setSizePolicy(sizePolicy)
        self.unselected_widget.setMinimumSize(QSize(50, 250))

        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.select_btn = QPushButton(widget_2)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.select_btn.sizePolicy().hasHeightForWidth())
        self.select_btn.setSizePolicy(sizePolicy)
        self.select_btn.setMaximumSize(QSize(30, 30))
        self.select_btn.setObjectName("select_btn")
        self.verticalLayout_5.addWidget(self.select_btn)
        self.deselect_btn = QPushButton(widget_2)

        self.deselect_btn.setSizePolicy(sizePolicy)
        self.deselect_btn.setMaximumSize(QSize(30, 30))
        self.deselect_btn.setObjectName("deselect_btn")
        self.verticalLayout_5.addWidget(self.deselect_btn)

        self.horizontalLayout.addLayout(self.verticalLayout_5)


        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.label_2 = QLabel(widget_2)
        font = QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_4.addWidget(self.label_2)
        self.selected_widget = QTableWidget(widget_2)
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        self.selected_widget.setSizePolicy(sizePolicy)

        self.pop_tableview(self.selected_widget)
        self.selected_widget.setObjectName("selected_widget")
        self.verticalLayout_4.addWidget(self.selected_widget)
        self.horizontalLayout.addLayout(self.verticalLayout_4)

        self.selected_widget.setAlternatingRowColors(True)
        self.selected_widget.setSortingEnabled(True)
        self.selected_widget.setDragEnabled(False)
        self.selected_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.selected_widget.setDragDropOverwriteMode(False)
        self.selected_widget.setDefaultDropAction(Qt.MoveAction)
        self.selected_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.selected_widget.setSelectionBehavior(QAbstractItemView.SelectItems)
        #self.selected_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.unselected_widget.setAlternatingRowColors(True)
        self.unselected_widget.setSortingEnabled(True)
        self.unselected_widget.setDragEnabled(False)
        self.unselected_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.unselected_widget.setDragDropOverwriteMode(False)
        self.unselected_widget.setDefaultDropAction(Qt.MoveAction)
        self.unselected_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.unselected_widget.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.unselected_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.label_2.setText("Selected Fields")
        self.select_btn.setText(">")
        self.deselect_btn.setText("<")

        self.label.setText("Available Fields")

        self.widgets["selection"] = widget_2

        desc = "Select Fields:"
        label = QLabel(desc)
        # label.setToolTip(tooltip)
        self.labels["selection"] = label

        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget_2)


        output = self.alg.outputs[0]
        label = QLabel(output.description)
        widget_out = OutputSelectionPanel(output, self.alg)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, widget_out)
        self.widgets[output.name] = widget_out

        check = QCheckBox()
        check.setText(self.tr('Open output file after running algorithm'))
        check.setChecked(False)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, check)
        self.checkBoxes[output.name] = check

        self.init_signals()
        ind = widget.cmbText.currentIndex()
        widget.cmbText.currentIndexChanged.emit(ind)
        return myForm

    def init_signals(self):
        self.select_btn.clicked.connect(self._select)
        self.deselect_btn.clicked.connect(self._deselect)

        self.unselected_widget.itemDoubleClicked.connect(self._select)
        self.selected_widget.itemDoubleClicked.connect(self._deselect)

        #self.selected_widget.keyPressEvent.connect(self.keypress)

    def pop_tableview(self,table):
        #table = QTableWidget(table)
        colnames = ["Fields","Alias","Effect"]
        ncol = len(colnames)
        data = [[""],[""],[""]]

        for i in range(ncol):
            table.insertColumn(i)
            table.setHorizontalHeaderItem(i,QTableWidgetItem(colnames[i]))
        nrow = len(data[0])
        ncol = len(data)
        for i in range(nrow):
            table.insertRow(i)
        for j in range(ncol):
            for i in range(nrow):
                item_t = QTableWidgetItem(str(data[j][i]))
                item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                if j==1:
                    item_t.setFlags(Qt.ItemIsSelectable |  Qt.ItemIsEnabled | Qt.ItemIsEditable)
                table.setItem(i,j,item_t)

    def _select(self):
        self._do_move_f2t(self.unselected_widget, self.selected_widget)

    def _deselect(self):
        self._do_move_t2f(self.unselected_widget, self.selected_widget)

    def _do_move_t2f(self, fromList, toList):
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        if len(targets)==0:
            return
        target = targets[0]
        t_row = toList.row(target)
        t_col = toList.column(target)
        if t_col!=0:
            return
        try:
            ind = self.fieldslist.index(target.text())
        except:
            return

        prev_from_item = toList.item(t_row,t_col)
        fromList.setItem(ind,0,toList.takeItem(t_row, t_col))
        toList.removeRow(t_row)

        fromList.setCurrentCell(ind,0,QItemSelectionModel.Select)
        fromList.scrollToItem(prev_from_item)

    def _do_move_f2t(self, fromList, toList):
        recover = False
        temp = None
        add_to_last = True
        insert = False
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        nrows = toList.rowCount()
        # No selection
        if len(targets)==0:
            # find the first empty element
            for i in range(nrows):
                t_i = toList.item(i,0)
                if t_i.text()=="":
                    t_row = toList.row(t_i)
                    t_col = toList.column(t_i)
                    break
        else:
            # has selection
            target = targets[0]
            t_row = toList.row(target)
            t_col = toList.column(target)
            if t_col!=0:
                t_col = 0
                t_row = nrows - 1
            else:

                if target.text()!="":
                    recover=True
                    temp = target.text()
                    add_to_last = False
                    insert = True

        if t_row==-1:
            return
        if add_to_last:
            toList.insertRow(nrows)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(nrows,0,item_t)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            toList.setItem(nrows, 1, item_t)

        if insert:
            toList.insertRow(t_row+1)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(t_row+1,0,item_t)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            toList.setItem(t_row+1, 1, item_t)
            combo_box_options = ["Positive", "Negative"]
            combo = QComboBox()
            for t in combo_box_options:
                combo.addItem(t)
            toList.setCellWidget(t_row+1,2,combo)
            t_row = t_row + 1
        for item in fromList.selectedItems():
            f_row = fromList.row(item)
            f_col = fromList.column(item)
            prev_from_item = fromList.item(f_row,f_col)
            toList.setItem(t_row,t_col,fromList.takeItem(f_row,f_col))
            combo_box_options = ["Positive", "Negative"]
            combo = QComboBox()
            for t in combo_box_options:
                combo.addItem(t)
            toList.setCellWidget(t_row,2,combo)
            fromList.scrollToItem(prev_from_item)

        # if recover:
        #     ind = self.fieldslist.index(temp)
        #     fromList.setItem(ind, 0, QTableWidgetItem(temp))
        toList.clearSelection()
        toList.setCurrentCell(t_row, 0, QItemSelectionModel.Select)
        #toList.setCurrentCell(t_row, 1, QItemSelectionModel.Select)

    def runAsBatch(self):
        pass

    def setParamValues(self):
        params = self.alg.parameters
        outputs = self.alg.outputs

        for param in params:
            if param.hidden:
                continue
            if not self.setParamValue(
                    param, self.widgets[param.name]):
                raise AlgorithmDialogBase.InvalidParameterValue(
                    param, self.widgets[param.name])

        for output in outputs:
            if output.hidden:
                continue
            output.value = self.widgets[output.name].getValue()
            if isinstance(output, (OutputRaster, OutputVector, OutputTable,OutputVector_liu)):
                output.open = self.checkBoxes[output.name].isChecked()
        return True

    def setParamValue(self, param, widget, alg=None):
        if isinstance(param, ParameterRaster):
            return param.setValue(widget.getValue())
        elif isinstance(param,(ParameterVector_RDBMS)):
            return param.setValue(widget.getValue())
        elif isinstance(param, (ParameterVector)):
            try:
                return param.setValue(widget.itemData(widget.currentIndex()))
            except:
                return param.setValue(widget.getValue())
        elif isinstance(param, ParameterSelection):
            return param.setValue(widget.currentIndex())
        elif isinstance(param, ParameterTableField):
            if param.optional and widget.currentIndex() == 0:
                return param.setValue(None)
            return param.setValue(widget.currentText())

    def accept(self):
        self.settings.setValue("/Processing/dialogBase", self.saveGeometry())
        checkCRS = ProcessingConfig.getSetting(ProcessingConfig.WARN_UNMATCHING_CRS)
        try:
            self.setParamValues()
            if checkCRS and not self.alg.checkInputCRS():
                reply = QMessageBox.question(self, self.tr("Unmatching CRS's"),
                                             self.tr('Layers do not all use the same CRS. This can '
                                                     'cause unexpected results.\nDo you want to '
                                                     'continue?'),
                                             QMessageBox.Yes | QMessageBox.No,
                                             QMessageBox.No)
                if reply == QMessageBox.No:
                    return

            msg = self.alg._checkParameterValuesBeforeExecuting()
            if msg:
                QMessageBox.warning(
                    self, self.tr('Unable to execute algorithm'), msg)
                return
            self.btnRun.setEnabled(False)
            self.btnClose.setEnabled(False)
            buttons = self.iterateButtons
            self.iterateParam = None

            for i in range(len(buttons.values())):
                button = buttons.values()[i]
                if button.isChecked():
                    self.iterateParam = buttons.keys()[i]
                    break

            self.progressBar.setMaximum(0)
            self.lblProgress.setText(self.tr('Processing algorithm...'))
            # Make sure the Log tab is visible before executing the algorithm
            try:
                self.tabWidget.setCurrentIndex(1)
                self.repaint()
            except:
                pass

            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))

            self.setInfo(
                self.tr('<b>Algorithm %s starting...</b>') % self.alg.name)

            if self.iterateParam:
                if runalgIterating(self.alg, self.iterateParam, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
            else:
                command = self.alg.getAsCommand()
                if command:
                    ProcessingLog.addToLog(
                        ProcessingLog.LOG_ALGORITHM, command)
                if runalg(self.alg, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
        except AlgorithmDialogBase.InvalidParameterValue as e:
            try:
                self.buttonBox.accepted.connect(lambda:
                                                e.widget.setPalette(QPalette()))
                palette = e.widget.palette()
                palette.setColor(QPalette.Base, QColor(255, 255, 0))
                e.widget.setPalette(palette)
                self.lblProgress.setText(
                    self.tr('<b>Missing parameter value: %s</b>') % e.parameter.description)
                return
            except:
                QMessageBox.critical(self,
                                     self.tr('Unable to execute algorithm'),
                                     self.tr('Wrong or missing parameter values'))
    def finish(self):
        keepOpen = ProcessingConfig.getSetting(ProcessingConfig.KEEP_DIALOG_OPEN)

        if self.iterateParam is None:
            if not handleAlgorithmResults(self.alg, self, not keepOpen):
                self.resetGUI()
                return

        self.executed = True
        self.setInfo('Algorithm %s finished' % self.alg.name)
        QApplication.restoreOverrideCursor()

        if not keepOpen:
            self.close()
        else:
            self.resetGUI()
            if self.alg.getHTMLOutputsCount() > 0:
                self.setInfo(
                    self.tr('HTML output has been generated by this algorithm.'
                            '\nOpen the results dialog to check it.'))
    def closeEvent(self, evt):
        QgsProject.instance().layerWasAdded.disconnect(self.layerAdded_normalization)
        QgsProject.instance().layersWillBeRemoved.disconnect(self.layersWillBeRemoved_normalization)
        super(NormalizationDialog, self).closeEvent(evt)

    def layerAdded_normalization(self,layer):
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    if dataobjects.canUseVectorLayer(layer, param.shapetype):
                        widget = self.widgets[param.name]
                        if isinstance(widget, InputLayerRDBMSelectorPanel) and hasattr(widget.cmbText, 'addItem'):
                            widget = widget.cmbText
                        widget.addItem(layer.name(), layer)
        elif layer.type() == QgsMapLayer.RasterLayer and dataobjects.canUseRasterLayer(layer):
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText
                    widget.addItem(self.getExtendedLayerName(layer), layer)

    def layersWillBeRemoved_normalization(self,layers):
        for layer in layers:
            self.layerRemoved(layer)

    def layerRemoved(self, layer):
        layer = QgsProject.instance().mapLayer(layer)
        widget = None
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    widget = self.widgets[param.name]
                    if isinstance(widget, InputLayerRDBMSelectorPanel):
                        widget = widget.cmbText

                        if widget is not None:
                            idx = widget.findData(layer)
                            if idx != -1:
                                widget.removeItem(idx)
                            widget = None

        elif layer.type() == QgsMapLayer.RasterLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText

                    if widget is not None:
                        idx = widget.findData(layer)
                        if idx != -1:
                            widget.removeItem(idx)
                        widget = None

    def updateDependentFields(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        layer = sender.itemData(sender.currentIndex())
        if not layer:
            return
        widget = self.unselected_widget
        widget_sele = self.selected_widget
        widget.setRowCount(0)
        widget_sele.setRowCount(0)

        wid_ID = self.widgets["POLY_ZONE_ID_FIELD"]
        wid_ID.clear()

        fieldTypes = [QVariant.Int, QVariant.Double, QVariant.LongLong,
                      QVariant.UInt, QVariant.ULongLong]
        idTypes = [QVariant.String, QVariant.Int, QVariant.LongLong,
                   QVariant.UInt, QVariant.ULongLong]

        def Spatialite2qgis(type):
            typeTrans = {"INT": QVariant.Int, "INTEGER": QVariant.Int, "TINYINT": QVariant.Int,
                         "SMALLINT": QVariant.Int, "MEDIUMINT": QVariant.LongLong, "BIGINT": QVariant.LongLong,
                         "UNSIGNED BIG INT": QVariant.LongLong, "INT2": QVariant.Int, "INT8": QVariant.LongLong,
                         "INTEGER": QVariant.LongLong, "CHARACTER": QVariant.String, "VARCHAR": QVariant.String,
                         "VARYING CHARACTER": QVariant.String, "NCHAR": QVariant.String,
                         "NATIVE CHARACTER": QVariant.String,
                         "NVARCHAR": QVariant.String, "TEXT": QVariant.String, "REAL": QVariant.Double,
                         "DOUBLE": QVariant.Double, "DOUBLE PRECISION": QVariant.Double, "FLOAT": QVariant.Double,
                         "REAL": QVariant.Double, "NUMERIC": QVariant.Double, "DECIMAL": QVariant.Double,
                         "BOOLEAN": QVariant.Int, "DATE": QVariant.String, "DATETIME": QVariant.String}
            ind = type.find("(")
            if ind > 0:
                type = type[0:ind]
            if type in typeTrans.keys():
                return typeTrans[type]
            else:
                return None
        def Postg2qgis(type):
            Postg2qgis = {"bigint": QVariant.LongLong, "varbinary": QVariant.ByteArray,
                          "char": QVariant.String, "varchar": QVariant.String, "integer": QVariant.Int,
                          "numeric": QVariant.Double, "decimal": QVariant.Double, "real": QVariant.Double,
                          "double": QVariant.Double, "date": QVariant.String, "time": QVariant.Time,
                          "timestamp": QVariant.String, "int": QVariant.Int, "int2": QVariant.Int,
                          "int4": QVariant.Int, "int8": QVariant.LongLong, "text": QVariant.String,
                          "float4": QVariant.Double, "float8": QVariant.Double, "float64": QVariant.Double}

            ind = type.find("(")
            if ind > 0:
                type = type[0:ind]
            if type in Postg2qgis.keys():
                return Postg2qgis[type]
            else:
                return None

        fieldNames = []
        idfieldNames = []
        idfieldTypes = []
        # ============for ParameterVector_RDBMS
        if isinstance(layer, dict):
            if "uri" in layer.keys():
                uri = layer["uri"]
                if uri.startswith(u"spatialite:"):
                    uri = uri[len(u"spatialite:"):]
                    uri = QgsDataSourceUri(uri)
                    try:
                        db = spatialite.GeoDB(uri)
                    except postgis.DbError as e:
                        raise GeoAlgorithmExecutionException(
                            "Couldn't connect to database:\n%s" % e.message)
                        # return False
                    sql_fields = 'pragma table_info(%s)' % (uri.table())
                    c = db.con.cursor()
                    c.execute(sql_fields)
                    fields = c.fetchall()
                    for field in fields:
                        type = field[2]
                        if not fieldTypes or (Spatialite2qgis(type) is not None and Spatialite2qgis(type) in fieldTypes):
                            fieldNames.append(field[1])
                        if not idTypes or (Spatialite2qgis(type) is not None and Spatialite2qgis(type) in idTypes):
                            idfieldNames.append(str(field[1]))
                            idfieldTypes.append(str(Spatialite2qgis(type)))
                elif uri.startswith(u"postgis:"):
                    uri = uri[len(u"postgis:"):]
                    uri = QgsDataSourceUri(uri)
                    try:
                        db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                                           dbname=uri.database(), user=uri.username(), passwd=uri.password())
                    except postgis.DbError as e:
                        raise GeoAlgorithmExecutionException(
                            "Couldn't connect to database:\n%s" % e.message)
                        # return False
                    fields = db.get_table_fields(uri.table(), uri.schema())
                    for field in fields:
                        type = field.data_type
                        if not fieldTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in fieldTypes):
                            fieldNames.append(field.name)
                        if not idTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in idTypes):
                            idfieldNames.append(str(field.name))
                            idfieldTypes.append(str(Postg2qgis(type)))
                else:
                    layer = dataobjects.getObjectFromUri(uri)
                    for field in layer.fields():
                        if not fieldTypes or field.type() in fieldTypes:
                            fieldNames.append(str(field.name()))
                        if not idTypes or field.type() in idTypes:
                            idfieldNames.append(str(field.name()))
                            idfieldTypes.append(str(field.type()))
        else:
            for field in layer.fields():
                if not fieldTypes or field.type() in fieldTypes:
                    fieldNames.append(str(field.name()))
                if not idTypes or field.type() in idTypes:
                    idfieldNames.append(str(field.name()))
                    idfieldTypes.append(str(field.type()))
        nrow = len(fieldNames)
        self.fieldslist = list(fieldNames)

        for i in range(len(idfieldNames)):
            wid_ID.addItem(str(idfieldNames[i]),idfieldTypes[i])
        self.idfiled = wid_ID.currentText()
        for i in range(nrow):
            widget.insertRow(i)
            item_t = QTableWidgetItem(str(self.fieldslist[i]))
            item_t.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable)
            widget.setItem(i,0,item_t)
        widget_sele.insertRow(0)
        widget_sele.setItem(0,0,QTableWidgetItem(""))
        widget_sele.setItem(0,1,QTableWidgetItem(""))
