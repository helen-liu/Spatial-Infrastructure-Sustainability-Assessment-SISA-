# -*- coding: utf-8 -*-

"""
***************************************************************************
    MoranILocal.py
    ---------------------
    Date                 : Jan 2019
    Copyright            : Mengmeng Liu and Qingsong Liu'
    Email                : qliu20@kent.edu
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

import rpy2
import rpy2.robjects as robjects
import rpy2.rlike.container as rlc

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QVariant
from qgis.core import QgsFeatureRequest,QgsField,NULL
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm

from SustainAssess.core.parameters import ParameterFile,ParameterNumber
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.ProcessingLog import ProcessingLog

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
# os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class MoranI_Local(GeoAlgorithm):

    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_INPUT_FIELD = 'POLY_INPUT_FIELD'  #
    WEIGHT_OBJECT = "WEIGHT_OBJECT"
    ALTERNATIVE_HYPOTHESIS= 'ALTERNATIVE_HYPOTHESIS'
    ALTERNATIVE_HYPOTHESIS_OPTIONS = ['GREATER','LESS','TWO.SIDED']
    SIMULATION_NUMBER = 'SIMULATION_NUMBER'

    P_VALUE_ADJUSTMENT = "P_VALUE_ADJUSTMENT"
    P_VALUE_ADJUSTMENT_OPTIONS = ["none","bonferroni","holm","hochberg","hommel","fdr"]

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Spatial Statistics/Local Moran\'s I"
        self.name, self.i18n_name = self.trAlgorithm('Local Moran\'s I')
        self.group, self.i18n_group = self.trAlgorithm('Spatial Statistics')
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterTableField(self.POLY_INPUT_FIELD,
                                          self.tr('Input Field'),self.POLY_VECTOR))
        self.addParameter(ParameterFile(self.WEIGHT_OBJECT, self.tr('Weights File'),optional=False,ext='gal'))

        self.addParameter(ParameterSelection(self.ALTERNATIVE_HYPOTHESIS,
                                             self.tr('Alternative Hypothesis:'),
                                             self.ALTERNATIVE_HYPOTHESIS_OPTIONS, 0))
        self.addParameter(ParameterNumber(self.SIMULATION_NUMBER, self.tr('Number of Simulation:'), default=99))
        # self.addParameter(ParameterSelection(self.P_VALUE_ADJUSTMENT,
        #                                      self.tr('P value adjustment:'),
        #                                      self.P_VALUE_ADJUSTMENT_OPTIONS, 0))

    def processAlgorithm(self, progress):
        paramInput = self.getParameterFromName(self.POLY_VECTOR)
        self.m_POLY_VECTOR = paramInput.getLayerObject()
        self.m_POLY_INPUT_FIELD = self.getParameterValue(self.POLY_INPUT_FIELD)

        self.m_WEIGHT_OBJECT = self.getParameterValue(self.WEIGHT_OBJECT)

        self.m_ALTERNATIVE_HYPOTHESIS = \
            self.ALTERNATIVE_HYPOTHESIS_OPTIONS[self.getParameterValue(self.ALTERNATIVE_HYPOTHESIS)]
        # self.m_P_VALUE_ADJUSTMENT = \
        #     self.P_VALUE_ADJUSTMENT_OPTIONS[self.getParameterValue(self.P_VALUE_ADJUSTMENT)]
        self.m_P_VALUE_ADJUSTMENT ='none'
        self.m_SIMULATION_NUMBER = self.getParameterValue(self.SIMULATION_NUMBER)

        provider = self.m_POLY_VECTOR.dataProvider()
        sRs = provider.crs()
        projString = str(sRs.toProj4())
        # 2. get r function
        self.init_Rfunc()
        progress.setPercentage(int(25))
        # get id field from gal file
        r_command1 = '''con <- file("%s", open="r")
                        line <- unlist(strsplit(readLines(con, 1), " "))
                        x <- subset(line, nchar(line) > 0)
                        if (length(x) == 1L) {
                          n <- as.integer(x[1])
                          shpfile <- as.character(NA)
                          ind <- as.character(NA)
                        } else if (length(x) == 4L) {
                          n <- as.integer(x[2])
                          shpfile <- as.character(x[3])
                          ind <- as.character(x[4])
                        } else stop ("Invalid header line in GAL file")
                        ind
                        '''%(self.m_WEIGHT_OBJECT)
        res = robjects.r(r_command1)
        id_field = robjects.r("ind")
        id_field = id_field.rx(1)[0]

        req = QgsFeatureRequest()
        req.setFlags(QgsFeatureRequest.NoGeometry)

        feats = self.m_POLY_VECTOR.getFeatures(req)
        count = int(self.m_POLY_VECTOR.featureCount())

        fields = self.m_POLY_VECTOR.fields()
        if fields.count() <= 0:
            raise Exception("Error: Attribute table must have at least one field")
        df = {}
        types = {}
        order = []
        fid = {"fid": []}
        Coords = []
        fields_needed = [id_field,self.m_POLY_INPUT_FIELD]
        for field in fields:
            # initial read in has correct ordering...
            name = str(field.name())
            if name in fields_needed:
                df[name] = []
                types[name] = int(field.type())
                order.append(name)

        for current, feat in enumerate(feats):
            for f in fields_needed:
                val = feat[f]
                if val!=NULL:
                    df[f].append(feat[f])
                else:
                    if types[f]==10:
                        df[f].append(robjects.NA_Character)  # [TODO] check the type
                    else:
                        df[f].append(robjects.NA_Real) # [TODO] check the type
            fid["fid"].append(feat.id())

        progress.setPercentage(int(25))
        tmp = []
        for key in order:
            if types[key] == 10:
                tmp.append((str(key), self.as_character_(robjects.StrVector(df[key]))))
            else:
                tmp.append((str(key), robjects.FloatVector(df[key])))
        try:
            data_frame = rlc.OrdDict(tmp)
        except:
            data_frame = rlc.OrdDict(tmp)

        data_frame = robjects.DataFrame(data_frame)

        robjects.r.assign(str("r_input"), data_frame)
        # version 1
        arg1 = {"input": "r_input",
                "id_field":id_field,
                "weight_object": self.m_WEIGHT_OBJECT,
                "input_field": self.m_POLY_INPUT_FIELD,
                "alternative": (self.m_ALTERNATIVE_HYPOTHESIS).lower(),
                "p_value_adj":self.m_P_VALUE_ADJUSTMENT,
                "nsim":str(self.m_SIMULATION_NUMBER)
                }
        # r_command = '''saveRDS(r_input,"C:/Users/qliu20/Kent/temp/r_input.rds")'''
        # robjects.r(r_command)
        r_command = '''            
                    require(spdep)
                    input <- %(input)s
                    nsim = %(nsim)s
                    alternative='%(alternative)s'
                    
                    # read *.gal,*.gal.wgt
                    nb <- read.gal('%(weight_object)s',region.id=NULL,override.id = TRUE)
                    hasWeight <- FALSE
                    if(file.exists('%(weight_object)s.wgt'))
                        hasWeight <- TRUE
                    dlist <- NULL
                    if(hasWeight)
                        dlist <- read.galwht('%(weight_object)s.wgt',region.id=attr(nb,"region.id"))
                    
                    # deal with NA, need to remove corresponding vertex from neighborhood list
                    nalist <- which(is.na(input$%(input_field)s))
                    nb_new = nb
                    
                    n<-length(nb_new)
                    #remove vertex
                    for (ind in nalist) {
                        neighb = nb_new[[ind]]
                        nb_new[[ind]]= as.integer(c(0))
                        if (length(neighb)==1 && neighb==0 )
                            next
                        for (ind_n in neighb) {
                            remains = !nb_new[[ind_n]] %%in%% c(ind)
                            nb_new[[ind_n]]<-nb_new[[ind_n]][remains]
                            if(hasWeight)
                                dlist[[ind_n]]<-dlist[[ind_n]][remains]
                        }
                    }
                    #make sure that the no neighbor vertex is 0
                    for (i in 1:n) {
                      if(length(nb_new[[i]])==0){
                        nb_new[[i]]=as.integer(c(0))
                      }
                    }
                    if(hasWeight){
                        for (i in 1:n) {
                            neighb = nb_new[[i]]
                            if(length(neighb)==1 && neighb==0){
                                dlist[[i]]=numeric()
                            }
                        }
                    }
                    style <- 'W'
                    weight = nb2listw(nb_new, glist=dlist, style= style, zero.policy=TRUE)
                    
                    if (n<1) stop("non-positive number of entities")
                    cardnb <- card(weight$neighbours)
                    if (any(is.na(unlist(weight$weights))))
                      stop("NAs in general weights list")
                    
                    m_input<-as.matrix(input$%(input_field)s)
                    a1 = which(!is.na(m_input))
                        
                    n_remain <- sum(!(1:n %%in%% nalist))
                    res_sim <- matrix(NA,nrow=n_remain,ncol=nsim+1)
                    for (i in 1:nsim){
                       temp = sample(input$%(input_field)s[a1])
                       temp_e = matrix(NA,nrow=n,ncol=1)
                       temp_e[a1] = temp
                       t<- localmoran_liu(temp_e[,1], weight, zero.policy=TRUE,na.action=na.omit,
                                                                alternative='%(alternative)s', p.adjust.method='none',adjust.x=TRUE)
                       res_sim[,i]<-t[,"Ii"]
                       #print(i)
                    }

                    output <- local({
                    localmoran_liu(input$%(input_field)s, weight, zero.policy=TRUE,na.action=na.omit, 
                            alternative='%(alternative)s', p.adjust.method='%(p_value_adj)s',adjust.x=TRUE)
                    })
                    # calculate significance
                    res_sim[,nsim+1] <- output[,'Ii']
                    pval <- matrix(NA,nrow=n_remain,ncol=1)
                    for (i in 1:n_remain) {
                      rankres <- rank(res_sim[i,])
                      xrank <- rankres[length(res_sim[i,])]
                      diff <- nsim - xrank
                      diff <- ifelse(diff > 0, diff, 0)
                      if (alternative == "less") 
                        pval_t <- punif((diff + 1)/(nsim + 1), lower.tail=FALSE)
                      else if (alternative == "greater") 
                        pval_t <- punif((diff + 1)/(nsim + 1))
                      if (!is.finite(pval_t) || pval_t < 0 || pval_t > 1) 
                        warning("Out-of-range p-value: reconsider test arguments")
                      pval[i,1] <- pval_t
                    }
                    
                    pval_extend = matrix(NA,nrow=n,ncol=1)
                    pval_extend[!(1:n %%in%% nalist)] = pval
                    
                    output_extend = matrix(NA,nrow=n,ncol=5)
                    output_extend[!(1:n %%in%% nalist)] = output
                    moran_lagged = matrix(NA, nrow = n,ncol = 1)
                    
                     for(i in 1:n){
                       if(cardnb[i]>0){
                           res<-matrix(0,nrow = 1,ncol = n)
                           res[1,weight$neighbours[[i]]] <-weight$weights[[i]]
                           moranlag_temp <- res[a1]%%*%%m_input[a1]
                           moran_lagged[i,1]<-moranlag_temp
                           }
                     }
                     
                     mean_v <-mean(m_input[a1])
                     input_mean<-m_input>=mean_v
                     
                     b1 <- which(!is.na(moran_lagged))
                     mean_lagged <-mean(moran_lagged[b1])
                     lagged_mean<-moran_lagged>=mean_lagged
                     
                     hl_output <- matrix(0,nrow = n,ncol = 1)
                     for (i in 1:n) {
                       if(is.na(input_mean[i,1]) || is.na(lagged_mean[i,1]) || is.na(pval_extend[i,1])){
                          hl_output[i,1] <- NA
                       }else if(input_mean[i,1]==TRUE && lagged_mean[i,1]==TRUE && pval_extend[i,1]<=0.05){
                          hl_output[i,1] <- 1
                       }else if(input_mean[i,1]==FALSE && lagged_mean[i,1]==TRUE && pval_extend[i,1]<=0.05){
                          hl_output[i,1] <- 2
                       }else if(input_mean[i,1]==FALSE && lagged_mean[i,1]==FALSE && pval_extend[i,1]<=0.05){
                          hl_output[i,1] <- 3
                       }else if(input_mean[i,1]==TRUE && lagged_mean[i,1]==FALSE && pval_extend[i,1]<=0.05){
                          hl_output[i,1] <- 4
                       }else{
                          hl_output[i,1] <- 0
                       }
                     }
                ''' % arg1
        
        res = robjects.r(r_command)
        output = robjects.r("output_extend")
        pval = robjects.r("pval_extend")
        hilo_output = robjects.r("hl_output")
        moran_lagged = robjects.r("moran_lagged")
        # output.rx(1, 1)
        # output.rx('17031220400', True)
        # output.nrow

        #create 5 colums ["li","e_li","var_li","z_li","pr"]
        #add field to the ROAD NETWORK LAYER
        if not self.m_POLY_VECTOR.isEditable():
            self.m_POLY_VECTOR.startEditing()
        #start: create new field =======================================================================================
        #attr_added = ["li","e_li","var_li","z_li","pr","hi_lo","sim_pr"]
        attr_added = ["lisa_i", "lisa_p", "lisa_cl","lisa_lag"]
        attr_index=[]
        field_added = []
        self.m_POLY_VECTOR.beginEditCommand("Added attribute")
        for field_name in attr_added:
            # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
            if field_name=="lisa_cl":
                field = QgsField(field_name, QVariant.String, 'text')
            else:
                field = QgsField(field_name, QVariant.Double, 'numeric(20,8)', 20, 8)#[TODO] rdedge_param.datasource, postgres, spatialite,file different command
            field_added.append(field)
            mAttributeId = -1
            if (not self.m_POLY_VECTOR.addAttribute(field)):
                #failed to add new fields, may be already exists
                #check whether exists
                # try to get the index of the new field
                fields = self.m_POLY_VECTOR.fields()
                for indx in range(fields.count()):
                    if fields[indx].name() == field_name:
                        mAttributeId = indx
                        break
                if mAttributeId==-1:
                    #not exists, and add failed
                    self.m_POLY_VECTOR.destroyEditCommand()
                    QMessageBox.critical(None, ("Failed to add field"),
                                         ("Failed to add field '%1' of type '%2'. Is the field name unique?" % (
                                         field.name(),
                                         field.typeName())))
                    return

            if mAttributeId==-1:
                # add sucess, get index of the new field
                fields = self.m_POLY_VECTOR.fields()
                for indx in range(fields.count()):
                    if fields[indx].name() == field_name:
                        mAttributeId = indx
                    if mAttributeId != -1:
                        break

            if mAttributeId == -1:
                self.m_POLY_VECTOR.destroyEditCommand()
                QMessageBox.critical(None, ("Failed to add field"),
                                     ("Failed to add field '%1' of type '%2'. Is the field name unique?" % (
                                         field.name(),
                                         field.typeName())))
                return

            attr_index.append(mAttributeId)

        # assign output to layer
        # update value with new fields
        # request = QgsFeatureRequest()
        # request.setFlags(QgsFeatureRequest.NoGeometry)
        # is only update select features
        # request.setFilterFids( layer.selectedFeaturesIds() )
        # fit = QgsFeatureIterator(self.m_POLY_VECTOR.getFeatures(request))  # fit:QgsFeatureIterator
        # feat = QgsFeature()
        rownum = 0
        if count!=output.nrow:
            QMessageBox.critical(None, ("Failed to update"),
                                 ("The Local moran's I count is not equal with features!" ))
            return
        rownum=1
        feats = self.m_POLY_VECTOR.getFeatures(req)
        for current, feat in enumerate(feats):
            #if feat[id_field].name()!=
            for id, mAttributeId in enumerate(attr_index):
                self.m_POLY_VECTOR.changeAttributeValue(feat.id(), mAttributeId, None)
            value = output.rx(rownum, True)
            if (self.any_(self.is_na_(value))[0]==True):
                rownum+=1
                continue
            # tvalue = [value.rx(i+1)[0] for i in range(len(value))]
            # tvalue.append(hilo_output.rx(rownum,)[0])
            # tvalue.append(pval.rx(rownum, )[0])
            tvalue = []
            tvalue.append(output.rx(rownum,1)[0])#Ii
            tvalue.append(pval.rx(rownum,1)[0])#sim_pr
            hl = hilo_output.rx(rownum,1)[0]
            val = NULL
            if hl==0:
                val="Not Significant"
            elif hl==1.0:
                val = "High-High"
            elif hl==2.0:
                val = "Low-High"
            elif hl==3.0:
                val = "Low-Low"
            elif hl==4.0:
                val = "High-Low"
            tvalue.append(val) #hi_low
            tvalue.append(moran_lagged.rx(rownum,1)[0])#moran_lag
            for id,mAttributeId in enumerate(attr_index):
                v = tvalue[id]
                field_added[id].convertCompatible(v)
                self.m_POLY_VECTOR.changeAttributeValue(feat.id(), mAttributeId, v)
            rownum += 1

        self.m_POLY_VECTOR.endEditCommand()
        modify = self.m_POLY_VECTOR.isModified()
        if modify:
            suc = self.m_POLY_VECTOR.commitChanges()
            if not suc:
                errors = self.m_POLY_VECTOR.commitErrors()
                msg = ''
                for err in errors:
                    msg += str(err) + "\n"
                ProcessingLog.addToLog(ProcessingLog.LOG_ERROR, msg)
                QMessageBox.critical(None, ("Failed to update Edge Table"),
                                     (
                                         "Failed to update Edge Table,Please check the processing.log for more details."))
                return
        #end
        progress.setPercentage(int(100))

    def createSpatialDataset(self, vectType, Coords, data, projString):
        if vectType == 0:
            # For points, coordinates must be input as a matrix, hense the extra bits below...
            # Not sure if this will work for multipoint features?
            spatialData = self.SpatialPoints_(self.matrix_(self.unlist_(Coords), \
                                                           nrow=len(Coords), byrow=True),
                                              proj4string=self.CRS_(projString))
            return self.SpatialPointsDataFrame_(spatialData, data)  # , match_ID = True )
            # kwargs = {'match.ID':"FALSE"}
            # return SpatialPointsDataFrame( spatialData, data, **kwargs )
        elif vectType == 1:
            spatialData = self.SpatialLines_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialLinesDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        elif vectType == 2:
            spatialData = self.SpatialPolygons_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialPolygonsDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        else:
            return ""

    # Helper function to get coordinates of input geometry
    # Does not require knowledge of input geometry type
    # Return: Appends R type geometry to input list
    def getNextGeometry(self, Coords, feat):
        geom = feat.geometry()
        if geom.type() == 0:
            Coords.append(self.getPointCoords(geom, feat.id()))
            return True
        elif geom.type() == 1:
            Coords.append(self.getLineCoords(geom, feat.id()))
            return True
        elif geom.type() == 2:
            Coords.append(self.getPolygonCoords(geom, feat.id()))
            return True
        else:
            return False

    # Function to retrieve QgsGeometry (point) coordinates
    # and convert to a format that can be used by R
    # Return: Item of class Matrix (R class)
    def getPointCoords(self, geom, fid):
        if geom.isMultipart():
            points = geom.asMultiPoint()  # multi_geom is a multipoint
            return [self.convertToXY(point) for point in points]
        else:
            point = geom.asPoint()  # multi_geom is a point
            return self.convertToXY(point)

        # Function to retrieve QgsGeometry (polygon) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Polygons (R class)

    def getPolygonCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            polygon = geom.asMultiPolygon()  # multi_geom is a multipolygon
            for lines in polygon:
                for line in lines:
                    keeps.append(self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                            nrow=len([self.convertToXY(point) for point in line]),
                                                            byrow=True)))
            return self.Polygons_(keeps, fid)
        else:
            lines = geom.asPolygon()  # multi_geom is a polygon
            Polygon = [self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                  nrow=len([self.convertToXY(point) for point in line]), byrow=True))
                       for line in lines]
            return self.Polygons_(Polygon, fid)

        # Function to retrieve QgsGeometry (line) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Lines (R class)

    def getLineCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            lines = geom.asMultiPolyline()  # multi_geom is a multipolyline
            for line in lines:
                for line in lines:
                    keeps.append(self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                         nrow=len([self.convertToXY(point) for point in line]),
                                                         byrow=True)))
            return self.Lines_(keeps, str(fid))
        else:
            line = geom.asPolyline()  # multi_geom is a line
            Line = self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                           nrow=len([self.convertToXY(point) for point in line]), byrow=True))
            return self.Lines_(Line, str(fid))

    def convertToXY(self, inPoint):
        return [inPoint.x(), inPoint.y()]

    def init_Rfunc(self):
        robjects.r("require(%s)" % ("sp"))[0]
        robjects.r("require(%s)" % ("spdep"))[0]
        self.CRS_ = robjects.r.get('CRS', mode='function')
        self.Polygon_ = robjects.r.get('Polygon', mode='function')
        self.Polygons_ = robjects.r.get('Polygons', mode='function')
        self.SpatialPolygons_ = robjects.r.get('SpatialPolygons', mode='function')
        self.Line_ = robjects.r.get('Line', mode='function')
        self.Lines_ = robjects.r.get('Lines', mode='function')
        self.SpatialLines_ = robjects.r.get('SpatialLines', mode='function')
        self.SpatialPoints_ = robjects.r.get('SpatialPoints', mode='function')
        self.SpatialPointsDataFrame_ = robjects.r.get('SpatialPointsDataFrame', mode='function')
        self.SpatialLinesDataFrame_ = robjects.r.get('SpatialLinesDataFrame', mode='function')
        self.SpatialPolygonsDataFrame_ = robjects.r.get('SpatialPolygonsDataFrame', mode='function')

        self.as_character_ = robjects.r.get('as.character', mode='function')
        self.data_frame_ = robjects.r.get('data.frame', mode='function')
        self.matrix_ = robjects.r.get('matrix', mode='function')
        self.unlist_ = robjects.r.get('unlist', mode='function')

        self.poly2nb_ = robjects.r.get('poly2nb', mode='function')
        self.nb2listw_ = robjects.r.get('nb2listw', mode='function')
        # moran.test(x, listw, randomisation=TRUE, zero.policy = NULL,alternative = "greater", rank = FALSE, na.action = na.fail, spChk = NULL, adjust.n = TRUE)
        self.moran_test_ = robjects.r.get('localmoran', mode='function')
        self.dim_ = robjects.r.get('dim',mode='function')
        self.any_ = robjects.r.get('any',mode='function')
        self.is_na_ = robjects.r.get('is.na', mode='function')
        r_fun='''# Copyright 2001-18 by Roger Bivand
                # revised by Qingsong Liu
                
                localmoran_liu <- function(x, listw, zero.policy=NULL, na.action=na.fail, 
                    alternative = "greater", p.adjust.method="none", mlvar=TRUE,
                    spChk=NULL, adjust.x=FALSE) {
                        stopifnot(is.vector(x))
                    if (!inherits(listw, "listw"))
                        stop(paste(deparse(substitute(listw)), "is not a listw object"))
                    if (is.null(zero.policy))
                        zero.policy <- get("zeroPolicy", envir = .spdepOptions)
                    stopifnot(is.logical(zero.policy))
                    if (!is.null(attr(listw$neighbours, "self.included")) &&
                        attr(listw$neighbours, "self.included"))
                        stop("Self included among neighbours")
                    if (is.null(spChk)) spChk <- get.spChkOption()
                    if (spChk && !chkIDs(x, listw))
                        stop("Check of data and weights ID integrity failed")
                    if (!is.numeric(x))
                        stop(paste(deparse(substitute(x)), "is not a numeric vector"))
                    NAOK <- deparse(substitute(na.action)) == "na.pass"
                    x <- na.action(x)
                    na.act <- attr(x, "na.action")
                        rn <- attr(listw, "region.id")
                    n_liu <- length(listw$neighbours)
                    if (!is.null(na.act)) {
                        subset <- !(1:length(listw$neighbours) %in% na.act)
                        listw$neighbours <- subset(listw$neighbours, subset, zero.policy=zero.policy)
                        listw$weights <- subset(listw$weights, subset, zero.policy=zero.policy)
                        excl <- class(na.act) == "exclude"
                    }
                    n <- length(listw$neighbours)
                    if (n != length(x))stop("Different numbers of observations")
                    res <- matrix(nrow=n, ncol=5)
                        if (alternative == "two.sided") Prname <- "Pr(z != 0)"
                        else if (alternative == "greater") Prname <- "Pr(z > 0)"
                        else Prname <- "Pr(z < 0)"
                    colnames(res) <- c("Ii", "E.Ii", "Var.Ii", "Z.Ii", Prname)
                    if (adjust.x) {
                          nc <- card(listw$neighbours) > 0L
                      xx <- mean(x[nc], na.rm=NAOK)
                    } else {
                      xx <- mean(x, na.rm=NAOK)
                    }
                    z <- x - xx 
                    lz <- lag.listw(listw, z, zero.policy=zero.policy, NAOK=NAOK)
                
                    if (mlvar) {
                          if (adjust.x) {
                            s2 <- sum(z[nc]^2, na.rm=NAOK)/sum(nc)
                          } else {
                            s2 <- sum(z^2, na.rm=NAOK)/n
                          }
                    } else {
                          if (adjust.x) {
                            s2 <- sum(z[nc]^2, na.rm=NAOK)/(sum(nc)-1) 
                          } else {
                            s2 <- sum(z^2, na.rm=NAOK)/(n-1) 
                          }
                        }
                    res[,1] <- (z/s2) * lz
                    Wi <- sapply(listw$weights, sum) 
                    res[,2] <- -Wi / (n-1) 
                
                    if (mlvar)  {
                          if (adjust.x) {
                            b2 <- (sum(z[nc]^4, na.rm=NAOK)/sum(nc))/(s2^2)
                          } else {
                            b2 <- (sum(z^4, na.rm=NAOK)/n)/(s2^2)
                          }
                    } else {
                          if (adjust.x) {
                            b2 <- (sum(z[nc]^4, na.rm=NAOK)/(sum(nc)-1))/(s2^2) 
                          } else {
                            b2 <- (sum(z^4, na.rm=NAOK)/(n-1))/(s2^2)
                          }
                        }
                        
                    Wi2 <- sapply(listw$weights, function(x) sum(x^2)) 
                    A <- (n-b2) / (n-1)
                    B <- (2*b2 - n) / ((n-1)*(n-2))
                        res[,3] <- A*Wi2 + B*(Wi^2 - Wi2) - res[,2]^2
                # Changed to Sokal (1998) VIi
                #	 C <- Wi^2 / ((n-1)^2) # == res[,2]^2
                #	 Wikh2 <- sapply(listw$weights, function(x) {
                #	   if(is.null(x)) 0 else 1 - (crossprod(x,x))
                #	 })
                #        res[,3] <- A*Wi2 + B*Wikh2 - C
                    res[,4] <- (res[,1] - res[,2]) / sqrt(res[,3])
                        if (alternative == "two.sided") pv <- 2 * pnorm(abs(res[,4]), 
                        lower.tail=FALSE)
                        else if (alternative == "greater")
                            pv <- pnorm(res[,4], lower.tail=FALSE)
                        else pv <- pnorm(res[,4])
                    res[,5] <- p.adjustSP(pv, listw$neighbours, method=p.adjust.method)
                    if (!is.null(na.act) && excl) {
                        res <- naresid(na.act, res)
                    }
                        if (!is.null(rn)) rownames(res) <- rn[!(1:n_liu %in% na.act)]
                    attr(res, "call") <- match.call()
                    if (!is.null(na.act)) attr(res, "na.action") <- na.act
                    class(res) <- c("localmoran", class(res))
                    res
                }'''
        robjects.r(r_fun)