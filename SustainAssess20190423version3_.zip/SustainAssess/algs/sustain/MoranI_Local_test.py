import pysal as ps
import numpy as np
np.random.seed(10)
w = ps.open(ps.examples.get_path("desmith.gal")).read()
f = ps.open(ps.examples.get_path("desmith.txt"))
y = np.array(f.by_col['z'])
lm = ps.Moran_Local(y, w, transformation="r", permutations=99)
lm.q