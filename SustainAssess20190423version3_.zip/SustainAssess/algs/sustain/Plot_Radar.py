# -*- coding: utf-8 -*-

"""
***************************************************************************
    Plot_Histogram.py
    ---------------------
    Date                 : Jan 2019
    Copyright            : Mengmeng Liu and Qingsong Liu'
    Email                : qliu20@kent.edu
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import share
import rpy2.robjects as robjects
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import QgsFeatureRequest
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputDirectory
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
# os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class Plot_Radar(GeoAlgorithm):
    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_INPUT_FIELD = 'POLY_INPUT_FIELD'  #
    OUTPUTDIR = "OUTPUTDIR"

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Results Visualization/Radar Chart"
        self.name, self.i18n_name = self.trAlgorithm('Radar Chart')
        self.group, self.i18n_group = self.trAlgorithm('Plot')
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Uncertainty Result Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.POLY_INPUT_FIELD,
                                          self.tr('Key Field'),self.POLY_VECTOR))
        self.addOutput(OutputDirectory(self.OUTPUTDIR,
                                       self.tr('Directory to Save Charts')))
    def processAlgorithm(self, progress,
                         source_param=None,m_IDField=None,filedir=None):
        if not source_param:
            source_param = self.getParameterFromName(self.POLY_VECTOR)
            m_IDField = self.getParameterValue(self.POLY_INPUT_FIELD)
            filedir = self.getOutputValue(self.OUTPUTDIR)

        sourceLayer = source_param.getLayerObject()

        fields = sourceLayer.fields()
        topITEMS = share.TOPITEMS   #["Economic","Environmental","Social","Resilient","Composite"]
        topITEMS_ALIAS = share.TOPITEMS_ALIAS # {"Economic":"Eco", "Environmental":"Env", "Social":"Soc", "Resilient":"Res", "Composite":"Comp"}

        filedir = filedir.replace("\\","/")
        dimensions = []
        for fi in fields:
            for item in topITEMS:
                if item.lower().startswith(str(fi.name()).lower()):
                    dimensions.append(fi.name())


        m_MULTIFIELDS = []
        m_MULTIFIELDS.append(m_IDField)
        # m_MULTIFIELDS.extend(dimensions)
        for d in dimensions:
            name = d[0:3]
            m_MULTIFIELDS.append(name.lower() + "_cil")
            m_MULTIFIELDS.append(name.lower() + "_cih")
            m_MULTIFIELDS.append(d)
        m_MULTIFIELDS.append("conflel")
        # m_MULTIFIELDS = [id,Economic,eco_cil,eco_cih,...,conflel]
        field_indexes = [sourceLayer.fields().indexFromName(f) for f in m_MULTIFIELDS]
        checkfields = [True if idx==-1 else False for idx in field_indexes]
        if sum(checkfields)>0:
            msg = ""
            for i,ch in enumerate(checkfields):
                if ch:
                    msg+=" "+m_MULTIFIELDS[i]
                msg+=" don't exist, please make sure that this layer is from Uncertainty Analysis tool!"
            raise GeoAlgorithmExecutionException(msg)

        request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes(field_indexes)
        feats = sourceLayer.getFeatures(request)
        count = int(sourceLayer.featureCount())
        dim = len(dimensions)

        metafile = os.path.join(filedir, "RadarChart.meta")
        out = open(metafile,"w")
        out.write("Input Layer= "+sourceLayer.dataProvider().dataSourceUri()+"\n")
        out.write("num_axes=%d\n"%(dim))
        out.write("order_=%s\n" % (",".join(['"'+str(d)+'"' for d in dimensions])))
        for i,inFeat in enumerate(feats):
            data_ = [inFeat[idx] for idx in field_indexes]
            good_ = True
            for d_ in data_:
                if str(d_)!= "nan" or str(d_)!="NULL":
                    continue
                else:
                    if float(d_)>1 or float(d_)<0:
                        good_ = False
                        QMessageBox.critical(None, ("Error"),
                                             ("Please make sure this layer is normalised and all value are from 0 to 1!"))
                        break
            if good_ ==False:
                break
            id_ = data_[0]
            mydata = []
            for di,d in enumerate(dimensions):
                tempdata = [data_[-1]]
                tempdata.extend(data_[1+di*3:1+di*3+3])
                temp1 = []
                for t in tempdata:
                    st = str(t)
                    if st=='nan':
                        st = "NULL"
                    temp1.append(st)
                temp = "%s=c(%s)"%(d,",".join([str(t) for t in temp1]))
                mydata.append(temp)
            args = {"num_axes":dim,
                    "order_":",".join(['"'+str(d)+'"' for d in dimensions]),
                    "mydata":",".join(mydata),
                    "filename": filedir+"/"+"radar_"+str(id_)+".png"}

            r_command='''
            library(ggplot2)
            # library(ggrepel)
            
            num_axes = %(num_axes)d  # 3
            order_ = c(%(order_)s) # c("Env_1","Soc_3","Res_4","Eco_2")
            mydata=data.frame(%(mydata)s)
                              #Env_1=c(0.9,0.61,0.8,0.75),Soc_3=c(0.85,0.45,0.85,0.82),
                              #Res_4=c(0.95,0.62,0.79,0.73),Eco_2=c(0.9,0.43,0.8,0.55))
            
            
            coord_radar <- function (theta = "x", start = 0, direction = 1) 
            {
              # get from http://www.cmap.polytechnique.fr/~lepennec/R/Radar/RadarAndParallelPlots.html
              theta <- match.arg(theta, c("x", "y"))
              r <- if (theta == "x") 
                "y"
              else "x"
              ggproto("CordRadar", CoordPolar, theta = theta, r = r, start = start, 
                      direction = sign(direction),
                      is_linear = function(coord) {
                        TRUE
                        })
            }
            
              data_test = data.frame(x=seq(0, 360, by= 360/num_axes),
                       y=rep(1,num_axes+1))
                y_t = numeric()
                for (v in seq(1,num_axes)) {
                  y_t = append(y_t,mydata[order_[v]][3,1])
                }
                y_t = append(y_t,mydata[order_[1]][3,1])
                y_t = append(y_t,mydata[order_[1]][2,1])
                for (v in seq(num_axes,1,-1)) {
                  y_t = append(y_t,mydata[order_[v]][2,1])
                }
                
                poly_1 = data.frame(x=c(seq(0, 360, by= 360/num_axes),seq(360, 0, by= -360/num_axes)),
                                    y = y_t
                                    # y=c(mydata[order_[1]][3,1],mydata[order_[2]][3,1],mydata[order_[3]][3,1],mydata[order_[1]][3,1],
                                    #     mydata[order_[1]][2,1],mydata[order_[3]][2,1],mydata[order_[2]][2,1],mydata[order_[1]][2,1])
                )
                
                y_t = numeric()
                for (v in seq(1,num_axes)) {
                  y_t = append(y_t,mydata[order_[v]][4,1])
                }
                y_t = append(y_t,mydata[order_[1]][4,1])
                data_paths = data.frame(x=  seq(0, 360, by= 360/num_axes),          
                                        y = y_t)
              x_t = c(0)
              x_t = append(x_t,seq(0,360,by=360/num_axes)[1:num_axes]) # c(0,0,120,240)
              y_t = c(0)
              y_t = append(y_t,rep(1.1,num_axes)) # c(0,1.1,1.1,1.1)
              names_t = c("0")
              names_t = append(names_t,rep("1",num_axes)) # c("0","1","1","1")
              labels_coord= data.frame(x=x_t,y=y_t,names=names_t)
              
              x_t = seq(0,360,by=360/num_axes)[1:num_axes]+5 # c(0+5,120+5,240+5)
              y_t = numeric()
              for (v in seq(1,num_axes)) {
                y_t = append(y_t,mydata[order_[v]][4,1])
              }
              names_t = character()
              for (v in seq(1,num_axes)) {
                names_t = append(names_t,sprintf("%%0.2f",mydata[order_[v]][4,1]))
              }
              labels_data = data.frame(x=x_t,
                                       y=y_t,
                                       names=names_t)
              x_t = seq(0,360,by=360/num_axes)[1:num_axes]+5 ## c(0+5,120+5,240+5)
              y_t = rep(1.1,num_axes)  #c(1.1,1.1,1.1)
              names_t = character()
              for (v in seq(1,num_axes)) {
                key = order_[v]
                names_t = append(names_t,
                    sprintf("%%s\nC=%%2.0f%%%%,CI=[%%0.2f,%%0.2f]",key,mydata[key][1,1]*100,mydata[key][2,1],mydata[key][3,1]))
              }
              labels_dim = data.frame(x=x_t,y=y_t,
                                      names=names_t)
            
              
              g <- ggplot()+xlim(0,360)+ylim(0,1.2)
              # g <- g + coord_polar()
              g <- g + geom_path(aes(x=x,y=y),data = data_test)
            
              g <- g + geom_polygon(aes(x=x,y=y),data = poly_1,fill="#ABB2B9",colour="black",linetype="dashed")
              
              g <- g + geom_path(aes(x=x,y=y),data = data_paths)
              g <- g + geom_path(aes(x=x,y=y),data.frame(x=c(0,0),y=c(0,1)))+
                geom_path(aes(x=x,y=y),data.frame(x=c(0,120),y=c(0,1)))+
                geom_path(aes(x=x,y=y),data.frame(x=c(0,240),y=c(0,1)))
              g <- g + geom_text(aes(x=x,y=y,label=names),data = labels_coord,size=5)
              g <- g + geom_text(aes(x=x,y=y,label=names),data = labels_data,size=5)
              g <- g + geom_text(aes(x=x,y=y,label=names),data = labels_dim,size=4,hjust=0)
              g <- g + coord_radar() + theme_void()
              png(file="%(filename)s",width = 1000, height = 800)
              par(mar=c(0,0,0,0)+0.1)
              plot(g)
              dev.off()
            '''%(args)
            # out.write(r_command)
            # break
            res = robjects.r(r_command)
            out.write("%s\n"%os.path.join(filedir,"radar_"+str(id_)+".png"))
            progress.setPercentage(int(0.0+i*1.0/count*100))
        out.close()



