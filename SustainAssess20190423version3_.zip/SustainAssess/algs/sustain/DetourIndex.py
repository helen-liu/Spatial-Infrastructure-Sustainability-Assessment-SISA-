# -*- coding: utf-8 -*-

"""
***************************************************************************
    DetourIndex.py
    ---------------------
    Date                 : 2018 Aug
    Copyright            : (C) 2018 by Liu
    Email                : qliu20@kent.edu
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Jan 2019'
__copyright__ = '(C) 2019, Mengmeng Liu and Qingsong Liu'
__revision__ = '$Format:%H$'

import os
import re

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QVariant
from qgis.core import ( QgsGeometry, NULL, QgsField, QgsSpatialIndex,
                       QgsPointXY, QgsFeature,QgsDistanceArea)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterTableField,ParameterString
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector_liu
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.core.ProcessingLog import ProcessingConfig
from networkx import DiGraph,dijkstra_path_length
from networkx.exception import NetworkXNoPath
pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class DetourIndex(GeoAlgorithm):

    POLY_VECTOR = 'POLY_VECTOR' #POLYGON
    POLY_ID_FIELD = 'POLY_ID_FIELD'

    RANDOM_VECTOR_LAYER = 'RANDOM_VECTOR_LAYER' # POLYLINE
    RANDOM_VECTOR_ID_FIELD = 'RANDOM_VECTOR_ID_FIELD'

    EDGE_LAYER = 'EDGE_LAYER'
    EDGE_SOURCE_FIELD = 'EDGE_SOURCE_FIELD'
    EDGE_TARGET_FIELD = 'EDGE_TARGET_FIELD'
    COST_FIELD = 'COST_FIELD'
    REVERSE_COST_FIELD = 'REVERSE_COST_FIELD'
    HIGHWAY = 'HIGHWAY'

    OUTPUT_FIELD = 'OUTPUT_FIELD'
    OUTPUT = 'OUTPUT'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Connectivity/Detour Index"
        self.name, self.i18n_name = self.trAlgorithm('Detour Index')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')
        self.precision = 0.0

        self.addParameter(ParameterVector_RDBMS(self.RANDOM_VECTOR_LAYER,
                                                self.tr('Input Random Vector Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_LINE]))
        self.addParameter(ParameterTableField(self.RANDOM_VECTOR_ID_FIELD,
                                              self.tr('ID Field of Random Vector Layer'), self.RANDOM_VECTOR_LAYER, defalut="id"))
        self.addParameter(ParameterVector_RDBMS(self.EDGE_LAYER,
                                                self.tr('Roads Layer'), [ParameterVector_RDBMS.VECTOR_ROAD_NETWORK]))
        self.addParameter(ParameterTableField(self.EDGE_SOURCE_FIELD,
                                              self.tr('Source Field'), self.EDGE_LAYER, defalut="source"))
        self.addParameter(ParameterTableField(self.EDGE_TARGET_FIELD,
                                              self.tr('Target Field'), self.EDGE_LAYER, defalut="target"))
        self.addParameter(ParameterTableField(self.COST_FIELD,
                                              self.tr('Cost Field'), self.EDGE_LAYER, defalut="cost"))
        self.addParameter(ParameterTableField(self.REVERSE_COST_FIELD,
                                              self.tr('Reverse Cost Field'), self.EDGE_LAYER, defalut="reverse_cost"))
        self.addParameter(ParameterTableField(self.HIGHWAY,
                                              self.tr('Highway Indicator(1 or 0)'), self.EDGE_LAYER, optional=True))
        # self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
        #                                   self.tr('Input Zone Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON],optional=True))
        # self.addParameter(ParameterTableField(self.POLY_ID_FIELD,
        #                                       self.tr('ID Field'), self.POLY_VECTOR, defalut="geoid",optional=True))

        self.addParameter(ParameterString(self.OUTPUT_FIELD,
                                          self.tr('Output Field Name'), "detour"))
        self.addOutput(OutputVector_liu(self.OUTPUT, self.tr('Output Layer')))

    def check(self,progress):
        b_continue = True
        # check Output Field Name
        self.m_OUTPUT_FIELD = self.getParameterValue(self.OUTPUT_FIELD)
        len_ = len(self.m_OUTPUT_FIELD)
        msg= ""
        if len_>=13:
            msg+= "Output Field Name must less than 13 characters.\n"
        if not re.match("^[A-Za-z0-9_]*$", self.m_OUTPUT_FIELD):
            msg+= "Output Field Name can only be a-z,A-Z,1-9,_"
        if msg:
            b_continue = False
            raise GeoAlgorithmExecutionException(msg)
        return b_continue
    # def isHighWay(self,a):
    #     if a is None: return None
    #     isHW = True
    #     if a<80:
    #         isHW = False
    #     return isHW
    def isHighWay(self,a):
        try:
            a_int = int(a)
        except:
            raise GeoAlgorithmExecutionException("Error: Highway field must be int type(1: is highway, 0: is not highway).")
        if a is None: return None
        if a!=1 and a!=0:
            raise GeoAlgorithmExecutionException("Error: Highway field must be (1: is highway, 0: is not highway).")
        isHW = True
        if a_int==0:
            ## if speed < 80km/h, then it is not highway
            isHW = False
        return isHW
    def processAlgorithm(self, progress):
        # checks parameters
        self.check(progress)

        # paramInput = self.getParameterFromName(self.POLY_VECTOR)
        # if paramInput.value:
        #     self.m_POLY_VECTOR = paramInput.getLayerObject()
        # self.m_POLY_ID_FIELD = self.getParameterValue(self.POLY_ID_FIELD)

        paramInput1 = self.getParameterFromName(self.RANDOM_VECTOR_LAYER)
        self.m_RANDOM_VECTOR_LAYER = paramInput1.getLayerObject()
        self.m_RANDOM_VECTOR_ID_FIELD = self.getParameterValue(self.RANDOM_VECTOR_ID_FIELD)

        paramInput2 = self.getParameterFromName(self.EDGE_LAYER)
        self.m_EDGE_LAYER = paramInput2.getLayerObject()

        self.m_EDGE_SOURCE_FIELD = self.getParameterValue(self.EDGE_SOURCE_FIELD)
        self.m_EDGE_TARGET_FIELD = self.getParameterValue(self.EDGE_TARGET_FIELD)
        self.m_COST_FIELD = self.getParameterValue(self.COST_FIELD)
        self.m_REVERSE_COST_FIELD = self.getParameterValue(self.REVERSE_COST_FIELD)
        self.m_HIGHWAY = self.getParameterValue(self.HIGHWAY)

        self.m_OUTPUT_FIELD = self.getParameterValue(self.OUTPUT_FIELD)
        self.m_OUTPUT = self.getOutputFromName(self.OUTPUT)

        save2input = self.m_OUTPUT.value=="save2input:"

        self.EUCLIDEAN_FIELD = "euc_d" #Straight-line distance" of point i and point j is the Euclidean distance between them.
        self.NETWORK_FIELD = "net_d" # "Route distance" of point i and point j is the real distance between them in the directed road network.
        field_names = [self.EUCLIDEAN_FIELD,self.NETWORK_FIELD, self.m_OUTPUT_FIELD]
        field_names_type = [QVariant.Double, QVariant.Double, QVariant.Double]

        field_name_index = {}
        idTypes_map = {'10': "text", '2': "integer", '4': "bigint",
                       '3': "integer", '5': "bigint",'6': "numeric(20,8)"}
        ''' -5:BIGINT   QVariant::LongLong
            -3:VARBINARY QVariant::ByteArray
            1: CHAR QVariant::String
            12: VARCHAR QVariant::String
            4: INTEGER QVariant::Int
            3:     //NUMERIC and DECIMAL  QVariant::Double;
            7:     //REAL  QVariant::Double;
            8:     //DOUBLE QVariant::Double;
            9:    //DATE  QVariant::String; // don't know why it doesn't like QVariant::Date
            10:    //TIME  QVariant::Time;
            11:    //TIMESTAMP QVariant::String; // don't know why it doesn't like QVariant::DateTime
            // Everything else just dumped as a string.  QVariant::String;
        '''

        # init writer===================================================================================================
        outFeat = None
        writer = None
        if save2input==True:
            # create filed in the input Random Vector Layer
            # add field to the Input Random Vector LAYER====================================================
            if not self.m_RANDOM_VECTOR_LAYER.isEditable():
                self.m_RANDOM_VECTOR_LAYER.startEditing()
            # Start: create new field =======================================================================================
            self.m_RANDOM_VECTOR_LAYER.beginEditCommand("Added attribute")
            for i,field_name in enumerate(field_names):
                # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
                type = field_names_type[i]
                len_,prec_ = None,None
                if idTypes_map[str(type)]=="real":
                    len_ = -1
                    prec_ = -1
                elif idTypes_map[str(type)]=="numeric(20,8)":
                    len_ = 20
                    prec_ = 8
                if len_ and prec_:
                    field = QgsField(field_name, type, idTypes_map[str(type)],len_,prec_)  # [TODO] rdedge_param.datasource, postgres, spatialite,file different command
                else:
                    field = QgsField(field_name, type, idTypes_map[str(type)])
                mAttributeId = -1
                if (not self.m_RANDOM_VECTOR_LAYER.addAttribute(field)):
                    # failed to add new fields, may be already exists
                    # check whether exists
                    # try to get the index of the new field
                    fields = self.m_RANDOM_VECTOR_LAYER.fields()
                    for indx in range(fields.count()):
                        if fields[indx].name() == field_name:
                            mAttributeId = indx
                            break
                    if mAttributeId == -1:
                        # not exists, and add failed
                        self.m_RANDOM_VECTOR_LAYER.destroyEditCommand()
                        QMessageBox.critical(None, ("Failed to add field"),
                                             ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                                 field.name(),
                                                 field.typeName())))
                        return
                else:
                    # add sucess, get index of the new field
                    fields = self.m_RANDOM_VECTOR_LAYER.fields()
                    for indx in range(fields.count()):
                        if fields[indx].name() == field_name:
                            mAttributeId = indx
                        if mAttributeId != -1:
                            break

                if mAttributeId == -1:
                    self.m_RANDOM_VECTOR_LAYER.destroyEditCommand()
                    QMessageBox.critical(None, ("Failed to add field"),
                                         ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                             field.name(),
                                             field.typeName())))
                    return
                field_name_index[field_name] = mAttributeId
            # End: create new field ========================================================================================
        else:
            # create new Layer
            geometryType = self.m_RANDOM_VECTOR_LAYER.wkbType()
            fields = []
            ufields = self.m_RANDOM_VECTOR_LAYER.fields()
            if ufields.count() <= 0:
                raise Exception("Error: Attribute table must have at least one field")
            types = {}

            fields_needed = [self.m_RANDOM_VECTOR_ID_FIELD]
            for field in ufields:
                # initial read in has correct ordering...
                name = str(field.name())
                if name in fields_needed:
                    types[name] = int(field.type())

            fields.append(QgsField(self.m_RANDOM_VECTOR_ID_FIELD, types[self.m_RANDOM_VECTOR_ID_FIELD],
                                   idTypes_map[str(types[self.m_RANDOM_VECTOR_ID_FIELD])]))
            for i,field_name in enumerate(field_names):
                type = field_names_type[i]
                len_, prec_ = None, None
                if idTypes_map[str(type)] == "real":
                    len_ = -1
                    prec_ = -1
                elif idTypes_map[str(type)] == "numeric(20,8)":
                    len_ = 20
                    prec_ = 8
                if len_ and prec_:
                    fields.append(QgsField(field_name, type, idTypes_map[str(type)], len_, prec_))
                else:
                    fields.append(QgsField(field_name, type, idTypes_map[str(type)]))
            writer = self.m_OUTPUT.getVectorWriter(fields, geometryType, self.m_RANDOM_VECTOR_LAYER.crs(),
                                                   {"pk":self.m_RANDOM_VECTOR_ID_FIELD})
            outFeat = QgsFeature()
        progress.setPercentage(int(10))

        # init points spatial index=====================================================================================
        idx = QgsSpatialIndex()
        edge_data = {}

        # create spatial index for the edge ends without the highway ends
        feats = self.m_EDGE_LAYER.getFeatures()
        idset=set()
        for ft in feats:
            edge_data[ft.id()] = [ft[self.m_EDGE_SOURCE_FIELD], ft[self.m_EDGE_TARGET_FIELD],
                                  ft[self.m_COST_FIELD], ft[self.m_REVERSE_COST_FIELD],
                                  self.isHighWay(ft[self.m_HIGHWAY] if self.m_HIGHWAY else None),QgsGeometry(ft.geometry())]
            idset.add(ft.id())
        # find the points set which on the highway
        highwayPointSet = set()
        if self.m_HIGHWAY:
            for id in idset:
                e = edge_data[id]
                if e[4]:
                    highwayPointSet.add(e[0])
                    highwayPointSet.add(e[1])

        indexPointSset = set()
        indPointsData = {}
        for id in idset:
            e = edge_data[id]
            sourceID,targetID = e[0],e[1]
            fGeom = e[5]
            if fGeom.isMultipart():
                raise GeoAlgorithmExecutionException(
                    "The Road Network should not be MultiPolyline!")
            vertices = fGeom.asPolyline()
            startP, endP = vertices[0], vertices[-1]

            if sourceID not in highwayPointSet and sourceID not in indexPointSset:
                indexPointSset.add(sourceID)
                pnt = QgsPointXY(startP.x(),startP.y())
                indPointsData[sourceID] = pnt
                geom = QgsGeometry.fromPointXY(pnt)
                f = QgsFeature(sourceID)
                f.setGeometry(geom)
                idx.insertFeature(f)
            if targetID not in highwayPointSet and targetID not in indexPointSset:
                indexPointSset.add(targetID)
                pnt = QgsPointXY(endP.x(),endP.y())
                indPointsData[targetID] = pnt
                geom = QgsGeometry.fromPointXY(pnt)
                f = QgsFeature(targetID)
                f.setGeometry(geom)
                idx.insertFeature(f)

        # create road network===========================================================================================
        d_network = DiGraph()
        for id in idset:
            e = edge_data[id]
            source,target,cost,reverse_cost,_,_ = e
            if (cost < 10000 and cost > 0):
                d_network.add_edge(source, target, weight = cost)
            if (reverse_cost < 10000 and reverse_cost > 0):
                d_network.add_edge(target, source, weight=reverse_cost)

        # for each random vector
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_RANDOM_VECTOR_LAYER.selectedFeatureCount() > 0:
            feats = self.m_RANDOM_VECTOR_LAYER.getSelectedFeatures()
            count = int(self.m_RANDOM_VECTOR_LAYER.selectedFeatureCount())
        else:
            feats = self.m_RANDOM_VECTOR_LAYER.getFeatures()
            count = int(self.m_RANDOM_VECTOR_LAYER.featureCount())
        for current,ft in enumerate(feats):
            fGeom = QgsGeometry(ft.geometry())
            vertices = fGeom.asPolyline()
            sourceP, targetP = vertices[0],vertices[-1]
            # get the nearest vertice from the source and target in the network

            sInd = idx.nearestNeighbor(sourceP,1)
            tInd = idx.nearestNeighbor(targetP,1)
            # calculate the shortest distance
            # if tInd[0]==100579 and sInd[0]==64603:
            try:
                pathlen = dijkstra_path_length(d_network, sInd[0], tInd[0], "weight")
            except NetworkXNoPath as e:
                ProcessingLog.addToLog(ProcessingLog.LOG_WARNING, str(e))
                progress.setInfo(str(e))
                pathlen=NULL

            vals = {}
            # total distance
            if pathlen!=NULL:
                distance = QgsDistanceArea()
                distance.setSourceCrs(self.m_RANDOM_VECTOR_LAYER.crs().srsid())
                # project_ellipsoid = QgsProject.instance().readEntry('Measure', '/Ellipsoid',
                #                                                     'NONE')[0]
                # distance.setEllipsoid(project_ellipsoid)

                dis_source = distance.measureLine(sourceP,indPointsData[sInd[0]])
                dis_target = distance.measureLine(indPointsData[tInd[0]],targetP)
                route_dis = dis_source + pathlen + dis_target

                # direct distance
                straight_dis = distance.measureLine(sourceP, targetP)
                prd = route_dis/straight_dis

                # field_names = [self.EUCLIDEAN_FIELD,self.NETWORK_FIELD, self.m_OUTPUT_FIELD]
                vals[self.EUCLIDEAN_FIELD] = straight_dis
                vals[self.NETWORK_FIELD] = route_dis
                vals[self.m_OUTPUT_FIELD] = prd
            else:
                vals[self.EUCLIDEAN_FIELD] = NULL
                vals[self.NETWORK_FIELD] = NULL
                vals[self.m_OUTPUT_FIELD] = NULL
            # update fields
            if save2input==True:
                for key in field_names:
                    self.m_RANDOM_VECTOR_LAYER.changeAttributeValue(ft.id(), field_name_index[key],
                                                            vals[key])
            else:
                id_ = ft[self.m_RANDOM_VECTOR_ID_FIELD]
                attr = [id_]
                for field_name in field_names:
                    attr.append(vals[field_name])
                outFeat.setAttributes(attr)
                outFeat.setGeometry(ft.geometry())
                writer.addFeature(outFeat)
            progress.setPercentage(int(10+current*1.0/count*85))

        # save the update===============================================================================================
        if save2input==True:
            # commit changes
            self.m_RANDOM_VECTOR_LAYER.endEditCommand()
            modify = self.m_RANDOM_VECTOR_LAYER.isModified()
            if modify:
                suc = self.m_RANDOM_VECTOR_LAYER.commitChanges()
                if not suc:
                    errors = self.m_RANDOM_VECTOR_LAYER.commitErrors()
                    msg = ''
                    for err in errors:
                        msg += str(err) + "\n"
                    ProcessingLog.addToLog(ProcessingLog.LOG_ERROR, msg)
                    QMessageBox.critical(None, ("Failed to update Zone Layer"),
                                         ("Failed to update Zone Layer,Please check the processingliu.log for more details."))
                    return
            self.m_OUTPUT.layer = self.m_RANDOM_VECTOR_LAYER
            self.m_OUTPUT.description = self.m_RANDOM_VECTOR_LAYER.name()
        else:
            del writer
        progress.setPercentage(int(100))