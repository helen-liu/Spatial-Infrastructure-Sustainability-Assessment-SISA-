# -*- coding: utf-8 -*-
__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu, Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,math
import random

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsWkbTypes, QgsGeometry, QgsFields, QgsField, QgsSpatialIndex,
                       QgsPointXY, QgsFeature, QgsFeatureRequest,QgsRectangle)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterNumber
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector
from SustainAssess.tools import dataobjects, vector

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class RandomVectorsLayer(GeoAlgorithm):

    VECTOR = 'VECTOR'
    VECTOR_LENGTH = 'VECTOR_LENGTH'
    VECTOR_NUMBER = 'VECTOR_NUMBER'
    OUTPUT = 'OUTPUT'

    def getIcon(self):
        #[TODO] set the random vector icon
        return QIcon(os.path.join(pluginPath, 'images', 'ftools', 'random_points.png'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Geoprocess/Create Random Vector"
        self.name, self.i18n_name = self.trAlgorithm('Create Random Vector')
        self.group, self.i18n_group = self.trAlgorithm('Vector creation tools')
        self.addParameter(ParameterVector_RDBMS(self.VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterNumber(self.VECTOR_NUMBER,
                                          self.tr('Vectors Number'), 1, None, 1))
        self.addParameter(ParameterNumber(self.VECTOR_LENGTH,
                                          self.tr('Vector Length'), 0.0, None, 0.0))

        self.addOutput(OutputVector(self.OUTPUT, self.tr('Random Vectors Output:')))

    def processAlgorithm(self, progress):
        paramInput = self.getParameterFromName(self.VECTOR)
        self.m_VECTOR = None
        if paramInput.value is not None:
            self.m_VECTOR = paramInput.getLayerObject()

        vectorCount = int(self.getParameterValue(self.VECTOR_NUMBER))
        vectorLength = float(self.getParameterValue(self.VECTOR_LENGTH))
        #[TODO] create vector algorithm
        bbox = self.m_VECTOR.extent()
        idxLayer = vector.spatialindex(self.m_VECTOR)

        span_x = bbox.width()
        span_y = bbox.height()
        span_angle = 2 * math.pi
        request = QgsFeatureRequest()

        fields = QgsFields()
        fields.append(QgsField('id', QVariant.Int, 'integer', 10, 0))
        writer = self.getOutputFromName(self.OUTPUT).getVectorWriter(
            fields, QgsWkbTypes.LineString, self.m_VECTOR.crs(),{"pk":"id"})

        i_points = 0
        while i_points<vectorCount:
            # generate the start point
            r1 = random.random()
            r2 = random.random()
            x = bbox.xMinimum() + r1 * span_x
            y = bbox.yMinimum() + r2 * span_y
            pnt_start = QgsPointXY(x, y)
            pnt_start_geom = QgsGeometry.fromPointXY(pnt_start)

            # check whether the start points are in the polygons
            start_bool, end_bool = False, False
            # check the start point
            ids = idxLayer.intersects(QgsRectangle(x-2.5,y-2.5,x+2.5,y+2.5))
            if len(ids)>0:
                request = QgsFeatureRequest().setFilterFids(ids).setSubsetOfAttributes([])
                for f in self.m_VECTOR.getFeatures(request):
                    tmpGeom = QgsGeometry(f.geometry())
                    if pnt_start_geom.within(tmpGeom):
                        start_bool = True
                        break

            if start_bool:
                # start point in the polygons
                # generate the end point, 10 chances
                i=0
                while i<100:
                    r3 = random.random()
                    angle = r3 * span_angle
                    x_t = x + math.cos(angle) * vectorLength
                    y_t = y + math.sin(angle) * vectorLength
                    pnt_end = QgsPointXY(x_t, y_t)
                    pnt_end_geom = QgsGeometry.fromPointXY(pnt_end)
                    # for the end point
                    ids = idxLayer.intersects(QgsRectangle(x_t-2.5,y_t-2.5,x_t+2.5,y_t+2.5))
                    if len(ids) > 0:
                        request = QgsFeatureRequest().setFilterFids(ids).setSubsetOfAttributes([])
                        for f in self.m_VECTOR.getFeatures(request):
                            tmpGeom = QgsGeometry(f.geometry())
                            if pnt_end_geom.within(tmpGeom):
                                end_bool = True
                                break
                    if end_bool:
                        break
                    i+=1

                if end_bool:
                    geom = QgsGeometry.fromPolylineXY([pnt_start, pnt_end])
                    # if both points are in the polygons, then continue, else generate another pair
                    if start_bool and end_bool:
                        f = QgsFeature(i_points)
                        f.initAttributes(1)
                        f.setFields(fields)
                        f.setAttribute('id',i_points)
                        f.setGeometry(geom)
                        writer.addFeature(f)
                        i_points+=1
        del writer
