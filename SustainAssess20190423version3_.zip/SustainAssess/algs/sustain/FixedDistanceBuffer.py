# -*- coding: utf-8 -*-

"""
***************************************************************************
    FixedDistanceBuffer.py
    ---------------------
    Date                 : August 2012
    Copyright            : (C) 2012 by Victor Olaya
    Email                : volayaf at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Victor Olaya'
__date__ = 'August 2012'
__copyright__ = '(C) 2012, Victor Olaya'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

from qgis.PyQt.QtGui import QIcon

from qgis.core import QgsWkbTypes

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterBoolean
from SustainAssess.core.parameters import ParameterNumber
from SustainAssess.core.outputs import OutputVector
from SustainAssess.core.parameters import ParameterVector_RDBMS
from . import Buffer as buff
from SustainAssess.tools import dataobjects

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class FixedDistanceBuffer(GeoAlgorithm):

    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'
    FIELD = 'FIELD'
    DISTANCE = 'DISTANCE'
    SEGMENTS = 'SEGMENTS'
    DISSOLVE = 'DISSOLVE'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'ftools', 'buffer.png'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Geoprocess/Create Buffer/Fixed Distance Buffer"
        self.name, self.i18n_name = self.trAlgorithm('Fixed Distance Buffer')
        self.group, self.i18n_group = self.trAlgorithm('Vector geometry tools')
        self.addParameter(ParameterVector_RDBMS(self.INPUT,
                                          self.tr('Input Layer'), [ParameterVector.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterNumber(self.DISTANCE,
                                          self.tr('Distance'), default=10.0))
        self.addParameter(ParameterNumber(self.SEGMENTS,
                                          self.tr('Segments'), 1, default=5))
        self.addParameter(ParameterBoolean(self.DISSOLVE,
                                           self.tr('Dissolve Result'), False))

        self.addOutput(OutputVector(self.OUTPUT, self.tr('Fixed Distance Buffer Output')))

    def processAlgorithm(self, progress):
        #[TODO] test the algorithm
        paramInput = self.getParameterValue(self.INPUT)
        if paramInput["p"] in [ParameterVector_RDBMS.INPUT_TYPE_LAYERS]:
            layer = dataobjects.getObjectFromUri(
                paramInput["data"])
        elif paramInput["p"]==ParameterVector_RDBMS.INPUT_TYPE_DATABASE:
            uri_text = paramInput["data"]["uri"]
            if uri_text.startswith(u"spatialite:"):
                uri_text = uri_text[len(u"spatialite:"):]
                layer = dataobjects.getObjectFromUri(uri_text)
            elif uri_text.startswith(u"postgis:"):
                uri_text = uri_text[len(u"postgis:"):]
                layer = dataobjects.getObjectFromUri(uri_text)
            else:
                layer = dataobjects.getObjectFromUri(uri_text)

        distance = self.getParameterValue(self.DISTANCE)
        dissolve = self.getParameterValue(self.DISSOLVE)
        segments = int(self.getParameterValue(self.SEGMENTS))

        writer = self.getOutputFromName(
            self.OUTPUT).getVectorWriter(layer.fields().toList(),
                                         QgsWkbTypes.Polygon, layer.crs())

        buff.buffering(progress, writer, distance, None, False, layer,
                       dissolve, segments)
