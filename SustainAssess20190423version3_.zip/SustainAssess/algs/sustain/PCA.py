# -*- coding: utf-8 -*-

"""
***************************************************************************
    Correlation.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Qingsong Liu
    Email                : qliu20@kent.edu
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
from qgis.PyQt.QtGui import QIcon,QFont,QCursor,QColor, QPalette
from qgis.PyQt.QtWidgets import QAbstractItemView,QApplication,QWidget,QVBoxLayout,QPushButton,\
                QScrollArea,QFrame,QSpacerItem,QSizePolicy,QLabel,QHBoxLayout,QTableWidget,\
                QTableWidgetItem,QComboBox,QMessageBox
from qgis.PyQt.QtCore import QVariant,QRect,QSize,QItemSelectionModel
from qgis.core import (QgsProject,QgsDataSourceUri,QgsMapLayer)
from SustainAssess.gui.OutputSelectionPanel import OutputSelectionPanel
from qgis.PyQt.QtCore import Qt,NULL
from SustainAssess.gui.InputLayerRDBMSelectorPanel import InputLayerRDBMSelectorPanel
from qgis.gui import QgsCollapsibleGroupBox
from SustainAssess.gui.NumberInputPanel import NumberInputPanel
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.gui.AlgorithmDialogBase import AlgorithmDialogBase
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterVector,ParameterNumber
from SustainAssess.core.parameters import ParameterRaster
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.gui.AlgorithmExecutor import runalg,runalgIterating
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.tools import dataobjects,postgis,spatialite
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.core.outputs import OutputFile
from SustainAssess.gui.Postprocessing import handleAlgorithmResults
from scipy import stats
import numpy as np
from sklearn.decomposition import PCA
import rpy2.robjects as robjects
import rpy2.rlike.container as rlc

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class PCAAlgorithm(GeoAlgorithm):

    POLY_ZONE_VECTOR = 'POLY_ZONE_VECTOR' #poly_layer REGION_BY_WAYS_LAYER
    POLY_ZONE_ID_FIELD = 'POLY_ZONE_ID_FIELD'
    PCA_ACCU_VARIANCE_RATE = "PCA_ACCU_VARIANCE_RATE"
    FACTOR_LOADING_PC = 'FACTOR_LOADING_PC'
    OUTPUT_AS_TEXT = 'OUTPUT_AS_TEXT'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Indicator Analysis/PCA"
        self.name, self.i18n_name = self.trAlgorithm('PCA')
        self.group, self.i18n_group = self.trAlgorithm('Indicator Analysis')
        self.addParameter(ParameterVector_RDBMS(self.POLY_ZONE_VECTOR,
                                          self.tr('Input Zone Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(
            ParameterNumber(self.PCA_ACCU_VARIANCE_RATE, self.tr('Threshold of PCA Accumulation Variance'),
                            minValue=0.0, maxValue=1.0, default=0.9, optional=False))
        self.addParameter(
            ParameterNumber(self.FACTOR_LOADING_PC, self.tr('Factor Loading Ratio of Pinciple Component (PC)'),
                            minValue=0.0, maxValue=1.0, default=0.9, optional=False))
        self.addOutput(OutputFile(self.OUTPUT_AS_TEXT, self.tr('Output PCA Results'), 'pca'))
    def getCustomParametersDialog(self):
        self.dlg = PCADialog(self)
        return self.dlg
    def processAlgorithm(self, progress):
        self.progress = progress
        paramInput = self.getParameterFromName(self.POLY_ZONE_VECTOR)
        self.m_POLY_ZONE_VECTOR = paramInput.getLayerObject()
        self.m_PCA_ACCU_VARIANCE_RATE = self.getParameterValue(self.PCA_ACCU_VARIANCE_RATE)
        self.m_FACTOR_LOADING_PC = self.getParameterValue(self.FACTOR_LOADING_PC)
        self.m_OUTPUT_AS_TEXT = self.getOutputValue(self.OUTPUT_AS_TEXT)

        select_widget = self.dlg.selected_widget
        nrows = select_widget.rowCount()-1
        fields_ = []
        alias = {}
        for i in range(nrows):
            item_t = select_widget.item(i,0)
            key = item_t.text()
            if key =="":
                raise("error row count")
            fields_.append(key)
            item_t = select_widget.item(i, 1)
            text = item_t.text()
            if text =="":
                text = fields_[i]
            alias[key] = text

        #--------1.read network into memory;---------------------
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_POLY_ZONE_VECTOR.selectedFeatureCount() > 0:
            feats = self.m_POLY_ZONE_VECTOR.getSelectedFeatures()
            count = int(self.m_POLY_ZONE_VECTOR.selectedFeatureCount())
        else:
            feats = self.m_POLY_ZONE_VECTOR.getFeatures()
            count = int(self.m_POLY_ZONE_VECTOR.featureCount())
        #--------2.construct the diagraph;----------------
        fields = self.m_POLY_ZONE_VECTOR.fields()
        if fields.count() <= 0:
            raise Exception("Error: Attribute table must have at least one field")
        df = {}
        types = {}
        order = []
        fid = {"fid": []}
        for field in fields:
            # initial read in has correct ordering...
            name = str(field.name())
            if name in fields_:
                df[name] = []
                types[name] = int(field.type())
                order.append(name)
        for current, feat in enumerate(feats):
            for name in fields_:
                val = feat[name]
                if val!=NULL:
                    df[name].append(feat[name])
                else:
                    df[name].append(np.nan)
            fid["fid"].append(feat.id())

        progress.setPercentage(int(20))
        # import pickle
        # pickle.dump(df,open(r"C:\Users\qliu20\Kent\temp\test_mm_desk\qs_test_data\df.save","wb"))
        # pickle.dump(order, open(r"C:\Users\qliu20\Kent\temp\test_mm_desk\qs_test_data\order.save", "wb"))
        temp = []
        for i, i_key in enumerate(order):
            x = np.array(df[i_key], dtype=np.float64)
            if np.all(np.logical_not(x != 0)):
                temp.append(i_key)
        for key in temp:
            order.remove(key)
            progress.setInfo("<span style=\"color:red\">Remove Feature %s, Please check!</span>" % (key))
        corr_mat = np.empty((len(order),len(order)),dtype= np.float64)
        corr_mat_p = np.empty((len(order),len(order)),dtype= np.float64)

        for i,i_key in enumerate(order):
            for j,j_key in enumerate(order):
                if i==j:
                    corr_mat[i,j] = 1.0
                elif i<j:
                    x = np.array(df[i_key],dtype=np.float64)
                    y = np.array(df[j_key],dtype=np.float64)

                    xy_remain = np.logical_not(np.logical_or(np.isnan(x),np.isnan(y)))
                    x1 = x[xy_remain]
                    y1 = y[xy_remain]
                    cp,p_value = stats.pearsonr(x1,y1)
                    corr_mat[i,j] = cp
                    corr_mat_p[i,j] = p_value
                    corr_mat[j,i] = cp
                    corr_mat_p[j,i] = p_value

        total_ = np.sum(np.abs(corr_mat),axis=0)
        xy_remain = np.array([True] * count, dtype=np.bool)
        for o in order:
            x = np.array(df[o], dtype=np.float64)
            xy_remain = np.logical_and(np.logical_not(np.isnan(x)), xy_remain)
        data_ = np.empty((np.sum(xy_remain), len(order)), dtype=np.float64)
        for i,o in enumerate(order):
            data_[:,i] = np.array(df[o],dtype=np.float64)[xy_remain]
        pca = PCA(n_components=len(order))
        pca.fit(data_)

        lambda_pca = pca.singular_values_
        components_ = pca.components_
        explained_variance_ = pca.explained_variance_
        explained_variance_ratio_ = pca.explained_variance_ratio_
        '''
            components_ = np.array([[ 0.71941293, -0.29306121, -0.62973023],
                                   [-0.06289103,  0.87542316, -0.47924838],
                                   [ 0.69172954,  0.38438186,  0.61135982]])
            lambda_pca = array([9.91293270e-01, 5.50053987e-01, 5.57581282e-17])
            explained_variance_ = np.array([4.91331174e-01, 1.51279694e-01, 1.55448443e-33])
            explained_variance_ratio_ = np.array([7.64585846e-01, 2.35414154e-01, 2.41901360e-33])
        '''
        # looking for 90% variance
        i = 0
        sum = 0.0
        remain = np.array([False] * len(order))
        while i < len(order):
            sum += explained_variance_ratio_[i]
            remain[i] = True
            if sum >= self.m_PCA_ACCU_VARIANCE_RATE:
                break
            i += 1
        remain_order = []
        if np.sum(remain)<len(order):
            lambda_pca = lambda_pca[remain]
            components_ = components_[remain]
            explained_variance_ratio_ = explained_variance_ratio_[remain]
            explained_variance_ = explained_variance_[remain]
            for i,t in enumerate(remain):
                if t:
                    remain_order.append(order[i])

        def setZores(array, idx):
            '''
            array: must be two dimensions
            idx: list or scalar, indicating the index to be setting to zore
            return new array
            '''
            if array.ndim != 2:
                return None
            tempArray = np.array(array, copy=True)
            if not isinstance(idx, list):
                idx = [idx]
            # set row to zores
            for i in idx:
                tempArray[i, :] = [0.0] * array.shape[1]
            # set collumn to zores
            for j in idx:
                tempArray[:, j] = [0.0] * array.shape[0]
            return tempArray

        # for each dimension to select factors
        featset = set()
        featOdr = {}
        for i in range(np.sum(remain)):
            #     i = 0
            maxc = np.max(components_[i, :]) * self.m_FACTOR_LOADING_PC
            boolmaxc = np.abs(components_[i, :]) > maxc
            idx_remove = np.where(np.logical_not(boolmaxc))  # (array(1),)
            idx_remain = np.where(boolmaxc)  # (array(0,2),)
            idx_n = np.sum(boolmaxc)

            if idx_n==0:
                continue
            elif idx_n==1:
                featset.add(idx_remain[0][0])
                featOdr[i]=[idx_remain[0][0]]
            else:
                a = setZores(corr_mat, idx_remove[0].tolist())
                np.fill_diagonal(a, 0)
                a = np.abs(a)
                iteri = 0
                while iteri < idx_n * (idx_n - 1) / 2:
                    # find the largest correlation value and index
                    ind = np.unravel_index(np.argmax(a), a.shape)  # (0,2)
                    i_cur, j_cur = ind
                    if a[i_cur][j_cur] > 0.8:  # pearson correlation > 0.8
                        if corr_mat_p[i_cur][j_cur] < 0.01:  # p_value < .01
                            # significant correlation
                            # calculate to remove which (i_pre or j_pre)
                            temp = i_cur
                            if total_[i_cur] > total_[j_cur]:
                                temp = j_cur
                            # remove temp index
                            a = setZores(a, temp)
                        iteri += 1
                    else:
                        break
                f_b = np.where(a > 0)
                temp = f_b[0].flatten().tolist()
                temp.extend(f_b[1].flatten().tolist())
                featset.update(temp)
                featOdr[i]=temp
        str_feat = {}
        for f in featOdr.keys():
            temp = featOdr[f]
            str_feat[f] = []
            for t in temp:
                str_feat[f].append(order[t])
        f_out = open(self.m_OUTPUT_AS_TEXT,"w")
        # write correlation matrix
        f_out.write(","+",".join(order)+"\n")
        for i,key in enumerate(order):
            f_out.write('%s,%s\n'%(order[i],",".join(["%0.3f"%(d) for d in corr_mat[i,:]])))
        f_out.write('%s,%s\n' % ("Sum(abs)", ",".join(["%0.3f" % (d) for d in total_])))
        f_out.write("\n\n")
        # write principle components
        f_out.write(",%s\n"%(",".join(["PC%d"%i for i,d in enumerate(remain_order)])))
        f_out.write("%s,%s\n"%("EigenValue",",".join(["%0.3f"%(d) for i, d in enumerate(lambda_pca)])))
        f_out.write("%s,%s\n" % ("Explained Variance Ratio",
                                 ",".join(["%0.3f" % (d) for i, d in enumerate(explained_variance_ratio_)])))
        f_out.write("%s,%s\n" % ("Explained Variance",
                                 ",".join(["%0.3f" % (d) for i, d in enumerate(explained_variance_)])))
        f_out.write("\n\n")
        # write Eigen vector
        f_out.write(",%s\n" % (",".join(["PC%d" % i for i, d in enumerate(remain_order)])))
        for j in range(components_.shape[1]):
            f_out.write('%s'%order[j])
            for i in range(components_.shape[0]):
                f_out.write(',%s'% ("%0.3f"%components_[i,j]))
                if order[j] in str_feat[i]:
                    f_out.write("*")
            f_out.write("\n")
        featset = sorted(list(featset))
        f_out.write("\n\n")
        f_out.write('%s,%s\n' % ("Fields Selected by PCA", ",".join([order[i] for i in featset])))
        f_out.close()
        progress.setPercentage(int(100))

class PCADialog(AlgorithmDialogBase):
    def __init__(self,alg):
        AlgorithmDialogBase.__init__(self,alg)

        self.alg = alg
        self.mainWidget = self.MainPanel()
        self.setMainWidget()
        self.iterateButtons = {}

        self.cornerWidget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0,0,0,5) #void QLayout::setContentsMargins(int left, int top, int right, int bottom)
        self.tabWidget.setStyleSheet("QTabBar::tab { height: 30px; }")
        #self.runAsBatchButton = QPushButton(self.tr("Run as batch process..."))
        #self.runAsBatchButton.clicked.connect(self.runAsBatch)
        #layout.addWidget(self.runAsBatchButton)
        # self.cornerWidget.setLayout(layout)
        # self.tabWidget.setCornerWidget(self.cornerWidget)

        QgsProject.instance().layerWasAdded.connect(self.layerAdded_corr)
        QgsProject.instance().layersWillBeRemoved.connect(self.layersWillBeRemoved_corr)

    def MainPanel(self):
        myForm = QWidget()
        myForm.setObjectName("From")
        myForm.resize(400,200) #resize(int w, int h)
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 10, QSizePolicy.Minimum, QSizePolicy.Preferred)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.valueItems = {}
        self.widgets = {}
        self.labels = {}
        # add 1 parameter ParameterVector_RDBMS=========================================================================
        layers = dataobjects.getVectorLayers([2]) # 2 Polygon
        items = []
        for layer in layers:
            items.append((layer.name(), layer))
        param = self.alg.parameters[0]
        widget = InputLayerRDBMSelectorPanel(items, param)
        widget.cmbText.name = param.name
        widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)
        self.valueItems[param.name] = widget

        desc = param.description
        label = QLabel(desc)
        # label.setToolTip(tooltip)
        self.labels[param.name] = label
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)
        self.widgets[param.name] = widget
        # add 2 parameter ParameterVector_RDBMS=========================================================================
        name = self.alg.PCA_ACCU_VARIANCE_RATE
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        item = NumberInputPanel(param.default, param.min, param.max, param.isInteger)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        self.valueItems[param.name] = item

        # add 2 parameter ParameterVector_RDBMS=========================================================================
        name = self.alg.FACTOR_LOADING_PC
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        item = NumberInputPanel(param.default, param.min, param.max, param.isInteger)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        self.valueItems[param.name] = item

        # add 3 parameter ParameterVector_RDBMS=========================================================================
        widget_2 = QWidget()
        widget_2.setObjectName("widget_2")
        widget_2.resize(400, 550)
        self.horizontalLayout = QHBoxLayout(widget_2)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setMargin(0)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.label = QLabel(widget_2)
        font = QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.verticalLayout_6.addWidget(self.label)
        self.unselected_widget = QTableWidget(widget_2)
        self.unselected_widget.setObjectName("unselected_widget")

        self.verticalLayout_6.addWidget(self.unselected_widget)
        self.horizontalLayout.addLayout(self.verticalLayout_6)
        self.unselected_widget.insertColumn(0)
        self.unselected_widget.setHorizontalHeaderItem(0,QTableWidgetItem("Fields"))
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        self.unselected_widget.setSizePolicy(sizePolicy)
        self.unselected_widget.setMinimumSize(QSize(100, 250))

        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.select_btn = QPushButton(widget_2)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.select_btn.sizePolicy().hasHeightForWidth())
        self.select_btn.setSizePolicy(sizePolicy)
        self.select_btn.setMaximumSize(QSize(30, 30))
        self.select_btn.setObjectName("select_btn")
        self.verticalLayout_5.addWidget(self.select_btn)
        self.deselect_btn = QPushButton(widget_2)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.deselect_btn.sizePolicy().hasHeightForWidth())
        self.deselect_btn.setSizePolicy(sizePolicy)
        self.deselect_btn.setMaximumSize(QSize(30, 30))
        self.deselect_btn.setObjectName("deselect_btn")
        self.verticalLayout_5.addWidget(self.deselect_btn)

        self.horizontalLayout.addLayout(self.verticalLayout_5)


        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.label_2 = QLabel(widget_2)
        font = QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_4.addWidget(self.label_2)
        self.selected_widget = QTableWidget(widget_2)
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        self.selected_widget.setSizePolicy(sizePolicy)
        self.pop_tableview(self.selected_widget)

        self.selected_widget.setObjectName("selected_widget")
        self.verticalLayout_4.addWidget(self.selected_widget)
        self.horizontalLayout.addLayout(self.verticalLayout_4)

        self.selected_widget.setAlternatingRowColors(True)
        self.selected_widget.setSortingEnabled(True)
        self.selected_widget.setDragEnabled(False)
        self.selected_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.selected_widget.setDragDropOverwriteMode(False)
        self.selected_widget.setDefaultDropAction(Qt.MoveAction)
        self.selected_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.selected_widget.setSelectionBehavior(QAbstractItemView.SelectItems)
        #self.selected_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.unselected_widget.setAlternatingRowColors(True)
        self.unselected_widget.setSortingEnabled(True)
        self.unselected_widget.setDragEnabled(False)
        self.unselected_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.unselected_widget.setDragDropOverwriteMode(False)
        self.unselected_widget.setDefaultDropAction(Qt.MoveAction)
        self.unselected_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.unselected_widget.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.unselected_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.label_2.setText("Selected Fields")
        self.select_btn.setText(">")
        self.deselect_btn.setText("<")

        self.label.setText("Available Fields")

        self.valueItems["selection"] = widget_2

        desc = "Select Fields:"
        label = QLabel(desc)
        # label.setToolTip(tooltip)
        self.labels["selection"] = label

        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget_2)
        self.widgets["selection"] = widget_2

        output = self.alg.outputs[0]
        label = QLabel(output.description)
        widget_out = OutputSelectionPanel(output, self.alg)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, widget_out)
        self.valueItems[output.name] = widget_out

        self.init_signals()
        ind = widget.cmbText.currentIndex()
        widget.cmbText.currentIndexChanged.emit(ind)
        return myForm

    def init_signals(self):
        self.select_btn.clicked.connect(self._select)
        self.deselect_btn.clicked.connect(self._deselect)

        self.unselected_widget.itemDoubleClicked.connect(self._select)
        self.selected_widget.itemDoubleClicked.connect(self._deselect)

        #self.selected_widget.keyPressEvent.connect(self.keypress)

    def pop_tableview(self,table):
        #table = QTableWidget(table)
        colnames = ["Fields","Alias"]
        ncol = len(colnames)
        data = [[""],[""]]

        for i in range(ncol):
            table.insertColumn(i)
            table.setHorizontalHeaderItem(i,QTableWidgetItem(colnames[i]))
        nrow = len(data[0])
        ncol = len(data)
        for i in range(nrow):
            table.insertRow(i)
        for j in range(ncol):
            for i in range(nrow):
                item_t = QTableWidgetItem(str(data[j][i]))
                item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                if j==1:
                    item_t.setFlags(Qt.ItemIsSelectable |  Qt.ItemIsEnabled | Qt.ItemIsEditable)
                table.setItem(i,j,item_t)

    def _select(self):
        self._do_move_f2t(self.unselected_widget, self.selected_widget)

    def _deselect(self):
        self._do_move_t2f(self.unselected_widget, self.selected_widget)

    def _do_move_t2f(self, fromList, toList):
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        if len(targets)==0:
            return
        target = targets[0]
        t_row = toList.row(target)
        t_col = toList.column(target)
        if t_col!=0:
            return
        try:
            ind = self.fieldslist.index(target.text())
        except:
            return

        prev_from_item = toList.item(t_row,t_col)
        fromList.setItem(ind,0,toList.takeItem(t_row, t_col))
        toList.removeRow(t_row)

        fromList.setCurrentCell(ind,0,QItemSelectionModel.Select)
        fromList.scrollToItem(prev_from_item)

    def _do_move_f2t(self, fromList, toList):
        recover = False
        temp = None
        add_to_last = True
        insert = False
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        nrows = toList.rowCount()
        # No selection
        if len(targets)==0:
            # find the first empty element
            for i in range(nrows):
                t_i = toList.item(i,0)
                if t_i.text()=="":
                    t_row = toList.row(t_i)
                    t_col = toList.column(t_i)
                    break
        else:
            # has selection
            target = targets[0]
            t_row = toList.row(target)
            t_col = toList.column(target)
            if t_col!=0:
                t_col = 0
                t_row = nrows - 1
            else:

                if target.text()!="":
                    recover=True
                    temp = target.text()
                    add_to_last = False
                    insert = True

        if t_row==-1:
            return
        if add_to_last:
            toList.insertRow(nrows)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(nrows,0,item_t)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            toList.setItem(nrows, 1, item_t)
        if insert:
            toList.insertRow(t_row+1)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(t_row+1,0,item_t)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            toList.setItem(t_row+1, 1, item_t)
            t_row = t_row + 1
        for item in fromList.selectedItems():
            f_row = fromList.row(item)
            f_col = fromList.column(item)
            prev_from_item = fromList.item(f_row,f_col)
            toList.setItem(t_row,t_col,fromList.takeItem(f_row,f_col))
            fromList.scrollToItem(prev_from_item)
        # if recover:
        #     ind = self.fieldslist.index(temp)
        #     fromList.setItem(ind, 0, QTableWidgetItem(temp))
        toList.clearSelection()
        toList.setCurrentCell(t_row, 0, QItemSelectionModel.Select)
        #toList.setCurrentCell(t_row, 1, QItemSelectionModel.Select)
    def runAsBatch(self):
        pass

    def setParamValues(self):
        params = self.alg.parameters
        outputs = self.alg.outputs

        for param in params:
            if param.hidden:
                continue
            if not self.setParamValue(
                    param, self.valueItems[param.name]):
                raise AlgorithmDialogBase.InvalidParameterValue(
                    param, self.valueItems[param.name])

        for output in outputs:
            if output.hidden:
                continue
            output.value = self.valueItems[output.name].getValue()
        return True

    def setParamValue(self, param, widget, alg=None):
        if isinstance(param, ParameterRaster):
            return param.setValue(widget.getValue())
        elif isinstance(param,(ParameterVector_RDBMS)):
            return param.setValue(widget.getValue())
        elif isinstance(param, (ParameterVector)):
            try:
                return param.setValue(widget.itemData(widget.currentIndex()))
            except:
                return param.setValue(widget.getValue())
        elif isinstance(param, (ParameterNumber)):
            return param.setValue(widget.getValue())
    def accept(self):

        # try:
        #     self.alg.execute(self)
        #     return True
        # except GeoAlgorithmExecutionException as e:
        #     ProcessingLog.addToLog(sys.exc_info()[0], ProcessingLog.LOG_ERROR)
        #     return False
        self.settings.setValue("/Processing/dialogBase", self.saveGeometry())

        checkCRS = ProcessingConfig.getSetting(ProcessingConfig.WARN_UNMATCHING_CRS)
        try:
            self.setParamValues()
            if checkCRS and not self.alg.checkInputCRS():
                reply = QMessageBox.question(self, self.tr("Unmatching CRS's"),
                                             self.tr('Layers do not all use the same CRS. This can '
                                                     'cause unexpected results.\nDo you want to '
                                                     'continue?'),
                                             QMessageBox.Yes | QMessageBox.No,
                                             QMessageBox.No)
                if reply == QMessageBox.No:
                    return

            msg = self.alg._checkParameterValuesBeforeExecuting()
            if msg:
                QMessageBox.warning(
                    self, self.tr('Unable to execute algorithm'), msg)
                return
            self.btnRun.setEnabled(False)
            self.btnClose.setEnabled(False)
            buttons = self.iterateButtons
            self.iterateParam = None

            for i in range(len(buttons.values())):
                button = buttons.values()[i]
                if button.isChecked():
                    self.iterateParam = buttons.keys()[i]
                    break

            self.progressBar.setMaximum(0)
            self.lblProgress.setText(self.tr('Processing algorithm...'))
            # Make sure the Log tab is visible before executing the algorithm
            try:
                self.tabWidget.setCurrentIndex(1)
                self.repaint()
            except:
                pass

            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))

            self.setInfo(
                self.tr('<b>Algorithm %s starting...</b>') % self.alg.name)

            if self.iterateParam:
                if runalgIterating(self.alg, self.iterateParam, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
            else:
                command = self.alg.getAsCommand()
                if command:
                    ProcessingLog.addToLog(
                        ProcessingLog.LOG_ALGORITHM, command)
                if runalg(self.alg, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
        except AlgorithmDialogBase.InvalidParameterValue as e:
            try:
                self.buttonBox.accepted.connect(lambda:
                                                e.widget.setPalette(QPalette()))
                palette = e.widget.palette()
                palette.setColor(QPalette.Base, QColor(255, 255, 0))
                e.widget.setPalette(palette)
                self.lblProgress.setText(
                    self.tr('<b>Missing parameter value: %s</b>') % e.parameter.description)
                return
            except:
                QMessageBox.critical(self,
                                     self.tr('Unable to execute algorithm'),
                                     self.tr('Wrong or missing parameter values'))
    def finish(self):
        keepOpen = ProcessingConfig.getSetting(ProcessingConfig.KEEP_DIALOG_OPEN)

        if self.iterateParam is None:
            if not handleAlgorithmResults(self.alg, self, not keepOpen):
                self.resetGUI()
                return

        self.executed = True
        self.setInfo('Algorithm %s finished' % self.alg.name)
        QApplication.restoreOverrideCursor()

        if not keepOpen:
            self.close()
        else:
            self.resetGUI()
            if self.alg.getHTMLOutputsCount() > 0:
                self.setInfo(
                    self.tr('HTML output has been generated by this algorithm.'
                            '\nOpen the results dialog to check it.'))
    def closeEvent(self, evt):
        QgsProject.instance().layerWasAdded.disconnect(self.layerAdded_corr)
        QgsProject.instance().layersWillBeRemoved.disconnect(self.layersWillBeRemoved_corr)
        super(PCADialog, self).closeEvent(evt)

    def layerAdded_corr(self,layer):
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    if dataobjects.canUseVectorLayer(layer, param.shapetype):
                        widget = self.valueItems[param.name]
                        if isinstance(widget, InputLayerRDBMSelectorPanel) and hasattr(widget.cmbText, 'addItem'):
                            widget = widget.cmbText
                        widget.addItem(layer.name(), layer)
        elif layer.type() == QgsMapLayer.RasterLayer and dataobjects.canUseRasterLayer(layer):
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.valueItems[param.name].cmbText
                    widget.addItem(self.getExtendedLayerName(layer), layer)

    def layersWillBeRemoved_corr(self,layers):
        for layer in layers:
            self.layerRemoved(layer)
    def layerRemoved(self, layer):
        layer = QgsProject.instance().mapLayer(layer)
        widget = None
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector_RDBMS,ParameterVector)):
                    widget = self.valueItems[param.name]
                    if isinstance(widget, InputLayerRDBMSelectorPanel):
                        widget = widget.cmbText

                        if widget is not None:
                            idx = widget.findData(layer)
                            if idx != -1:
                                widget.removeItem(idx)
                            widget = None

        elif layer.type() == QgsMapLayer.RasterLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.valueItems[param.name].cmbText

                    if widget is not None:
                        idx = widget.findData(layer)
                        if idx != -1:
                            widget.removeItem(idx)
                        widget = None

    def updateDependentFields(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        layer = sender.itemData(sender.currentIndex())
        if not layer:
            return
        widget = self.unselected_widget
        widget_sele = self.selected_widget
        widget.setRowCount(0)
        widget_sele.setRowCount(0)
        fieldTypes = []

        fieldTypes = [QVariant.Int, QVariant.Double, QVariant.LongLong,
                          QVariant.UInt, QVariant.ULongLong]
        def Spatialite2qgis(type):
            typeTrans={"INT":QVariant.Int,"INTEGER":QVariant.Int,"TINYINT":QVariant.Int,
                        "SMALLINT":QVariant.Int,"MEDIUMINT":QVariant.LongLong,"BIGINT":QVariant.LongLong,
                        "UNSIGNED BIG INT":QVariant.LongLong,"INT2":QVariant.Int,"INT8":QVariant.LongLong,
                        "INTEGER":QVariant.LongLong,"CHARACTER":QVariant.String,"VARCHAR":QVariant.String,
                        "VARYING CHARACTER":QVariant.String,"NCHAR":QVariant.String,"NATIVE CHARACTER":QVariant.String,
                        "NVARCHAR":QVariant.String,"TEXT":QVariant.String,"REAL":QVariant.Double,
                        "DOUBLE":QVariant.Double,"DOUBLE PRECISION":QVariant.Double,"FLOAT":QVariant.Double,
                        "REAL":QVariant.Double,"NUMERIC":QVariant.Double,"DECIMAL":QVariant.Double,
                        "BOOLEAN":QVariant.Int,"DATE":QVariant.String,"DATETIME":QVariant.String}
            ind = type.find("(")
            if ind > 0:
                type = type[0:ind]
            if type in typeTrans.keys():
                return typeTrans[type]
            else:
                return None
        def Postg2qgis(type):
            Postg2qgis = {"bigint":QVariant.LongLong,"varbinary":QVariant.ByteArray,
                        "char":QVariant.String,"varchar":QVariant.String,"integer":QVariant.Int,
                        "numeric":QVariant.Double, "decimal":QVariant.Double,"real":QVariant.Double,
                        "double":QVariant.Double,"date":QVariant.String,"time":QVariant.Time,
                        "timestamp":QVariant.String,"int":QVariant.Int,"int2":QVariant.Int,
                        "int4":QVariant.Int,"int8":QVariant.LongLong,"text":QVariant.String,
                        "float4":QVariant.Double,"float8":QVariant.Double,"float64":QVariant.Double}

            ind = type.find("(")
            if ind > 0:
                type = type[0:ind]
            if type in Postg2qgis.keys():
                return Postg2qgis[type]
            else:
                return None
        fieldNames = set()
        # ============for ParameterVector_RDBMS
        if isinstance(layer, dict):
            if "uri" in layer.keys():
                uri = layer["uri"]
                if uri.startswith(u"spatialite:"):
                    uri = uri[len(u"spatialite:"):]
                    uri = QgsDataSourceUri(uri)
                    try:
                        db = spatialite.GeoDB(uri)
                    except postgis.DbError as e:
                        raise GeoAlgorithmExecutionException(
                            "Couldn't connect to database:\n%s" % e.message)
                        # return False
                    sql_fields = 'pragma table_info(%s)' % (uri.table())
                    c = db.con.cursor()
                    c.execute(sql_fields)
                    fields = c.fetchall()
                    for field in fields:
                        type = field[2]
                        if not fieldTypes or (Spatialite2qgis(type) is not None and Spatialite2qgis(type) in fieldTypes):
                            fieldNames.add(field[1])
                elif uri.startswith(u"postgis:"):
                    uri = uri[len(u"postgis:"):]
                    uri = QgsDataSourceUri(uri)
                    try:
                        db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                                           dbname=uri.database(), user=uri.username(), passwd=uri.password())
                    except postgis.DbError as e:
                        raise GeoAlgorithmExecutionException(
                            "Couldn't connect to database:\n%s" % e.message)
                        # return False
                    fields = db.get_table_fields(uri.table(), uri.schema())
                    for field in fields:
                        type = field.data_type
                        if not fieldTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in fieldTypes):
                            fieldNames.add(field.name)
                else:
                    layer = dataobjects.getObjectFromUri(uri)
                    for field in layer.fields():
                        if not fieldTypes or field.type() in fieldTypes:
                            fieldNames.add(str(field.name()))
        else:
            for field in layer.fields():
                if not fieldTypes or field.type() in fieldTypes:
                    fieldNames.add(str(field.name()))
        nrow = len(fieldNames)
        self.fieldslist = list(fieldNames)

        for i in range(nrow):
            widget.insertRow(i)
            item_t = QTableWidgetItem(str(self.fieldslist[i]))
            item_t.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable)
            widget.setItem(i,0,item_t)
        widget_sele.insertRow(0)
        widget_sele.setItem(0,0,QTableWidgetItem(""))
        widget_sele.setItem(0,1,QTableWidgetItem(""))