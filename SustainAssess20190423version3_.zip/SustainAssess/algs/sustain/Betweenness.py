# -*- coding: utf-8 -*-

"""
***************************************************************************
    Betweenness.py
    ---------------------
    Date                 : Jan 2019
    Copyright            : (C) 2018 Qingsong Liu and Mengmeng Liu
    Email                : qliu2018@kent.edu
***************************************************************************

"""

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,sys
import random

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsField, QgsFeature, QgsFeatureRequest,QgsFeatureIterator,NULL)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterNumber
from SustainAssess.core.parameters import ParameterTableField,ParameterCreateField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from networkx import DiGraph
from igraph import Graph
from heapq import heappush, heappop
from itertools import count
import time
pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class Betweenness(GeoAlgorithm):

    POLY_ZONE_VECTOR = 'POLY_ZONE_VECTOR' #poly_layer REGION_BY_WAYS_LAYER
    POLY_ZONE_ID_FIELD = 'POLY_ZONE_ID_FIELD'

    RD_EDGE_LAYER = 'RD_EDGE_LAYER'
    RD_EDGE_LAYER_ID = 'RD_EDGE_LAYER_ID'

    RD_EDGE_LAYER_SOURCE_FIELD = 'RD_EDGE_LAYER_SOURCE_FIELD'
    RD_EDGE_LAYER_TARGET_FIELD = 'RD_EDGE_LAYER_TARGET_FIELD'

    RD_EDGE_LAYER_WEIGHT_FIELD = 'RD_EDGE_LAYER_WEIGHT_FIELD'
    RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD = 'RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD'

    CUTOFF = 'CUTOFF'

    PACKAGE = 'PACKAGE'
    # PACKAGE_OPTIONS = ['IGRAPH','NETWORKX']

    OUTPUT_FIELD_RD_EDGE = 'OUTPUT_FIELD_RD_EDGE'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Centrality/Betweenness"
        self.name, self.i18n_name = self.trAlgorithm('Betweenness')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')
        self.precision = 0.0

        self.addParameter(ParameterVector_RDBMS(self.RD_EDGE_LAYER,
                                                self.tr('Roads Edge Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_LINE]))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_ID,
                                          self.tr('Edge ID Field'),self.RD_EDGE_LAYER,defalut="id"))

        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_SOURCE_FIELD,
                                          self.tr('Edge Source Field'),self.RD_EDGE_LAYER,defalut="source"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_TARGET_FIELD,
                                          self.tr('Edge Target Field'),self.RD_EDGE_LAYER,defalut="target"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_WEIGHT_FIELD,
                                          self.tr('Edge Weight Field'),self.RD_EDGE_LAYER,defalut="cost"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD,
                                          self.tr('Edge Reverse Weight Field'),self.RD_EDGE_LAYER,defalut="reverse_cost"))

        self.addParameter(ParameterNumber(self.CUTOFF,self.tr('Cutoff Value of Path Length'), default=0))
        # self.addParameter(ParameterSelection(self.PACKAGE, self.tr('Packages:'),
        #                                      self.PACKAGE_OPTIONS, 0))
        self.addParameter(ParameterCreateField(self.OUTPUT_FIELD_RD_EDGE,self.tr('Betweenness Result\'s Field in Road Layer'),
                                self.RD_EDGE_LAYER))

    def processAlgorithm(self, progress):
        self.progress = progress
        # zoneparam = self.getParameterFromName(self.POLY_ZONE_VECTOR)
        # self.m_POLY_ZONE_VECTOR = None
        # if zoneparam.value is not None:
        #     self.m_POLY_ZONE_VECTOR = zoneparam.getLayerObject()
        # self.m_POLY_ZONE_ID_FIELD = self.getParameterValue(self.POLY_ZONE_ID_FIELD)

        rdedge_param = self.getParameterFromName(self.RD_EDGE_LAYER)
        self.m_RD_EDGE_LAYER = rdedge_param.getLayerObject()
        self.m_RD_EDGE_LAYER_ID = self.getParameterValue(self.RD_EDGE_LAYER_ID)
        # self.m_RD_EDGE_LAYER_WEIGHT = self.getParameterValue(self.RD_EDGE_LAYER_WEIGHT)

        self.m_RD_EDGE_LAYER_SOURCE_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_SOURCE_FIELD)
        self.m_RD_EDGE_LAYER_TARGET_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_TARGET_FIELD)
        self.m_RD_EDGE_LAYER_WEIGHT_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_WEIGHT_FIELD)
        self.m_RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD)
        self.m_CUTOFF = self.getParameterValue(self.CUTOFF)
        self.m_PACKAGE = "IGRAPH"
        self.m_BETWEENNESS_K = 0
        # self.m_BETWEENNESS_K = self.getParameterValue(self.BETWEENNESS_K)
        # self.m_PACKAGE = self.PACKAGE_OPTIONS[self.getParameterValue(self.PACKAGE)]
        self.m_OUTPUT_FIELD_RD_EDGE = self.getParameterValue(self.OUTPUT_FIELD_RD_EDGE)

        # self.m_CHECK_OUTPUT_AS_FIELD = self.getParameterValue(self.CHECK_OUTPUT_AS_FIELD)
        # self.m_OUTPUT_FIELD_ZONE = self.getParameterValue(self.OUTPUT_FIELD_ZONE)
        #
        # self.m_CHECK_OUTPUT_AS_LAYER = self.getParameterValue(self.CHECK_OUTPUT_AS_LAYER)
        # self.m_OUTPUT_LAYER = self.getOutputFromName(self.OUTPUT_LAYER)

        #add field to the ROAD NETWORK LAYER
        if not self.m_RD_EDGE_LAYER.isEditable():
            self.m_RD_EDGE_LAYER.startEditing()
        #start: create new field =======================================================================================
        field_name = self.m_OUTPUT_FIELD_RD_EDGE
        self.m_RD_EDGE_LAYER.beginEditCommand("Added attribute")
        # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
        field = QgsField(field_name, QVariant.Double, 'numeric(20,10)', 20, 10)#[TODO] rdedge_param.datasource, postgres, spatialite,file different command
        field_reverse = QgsField(field_name+'_re', QVariant.Double, 'numeric(20,10)', 20, 10)
        mAttributeId = -1
        mAttributeId_re = -1
        if (not self.m_RD_EDGE_LAYER.addAttribute(field)):
            #failed to add new fields, may be already exists
            #check whether exists
            # try to get the index of the new field
            fields = self.m_RD_EDGE_LAYER.fields()
            for indx in range(fields.count()):
                if fields[indx].name() == field_name:
                    mAttributeId = indx
                    break
            if mAttributeId==-1:
                #not exists, and add failed
                self.m_RD_EDGE_LAYER.destroyEditCommand()
                raise GeoAlgorithmExecutionException(
                    "Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                        field.name(),
                        field.typeName()))

        if (not self.m_RD_EDGE_LAYER.addAttribute(field_reverse)):
            #failed to add new fields, may be already exists
            #check whether exists
            # try to get the index of the new field
            fields = self.m_RD_EDGE_LAYER.fields()
            for indx in range(fields.count()):
                # print fields[indx].name()
                if fields[indx].name() == field_name:
                    mAttributeId = indx
                    break
            if mAttributeId==-1:
                #not exists, and add failed
                self.m_RD_EDGE_LAYER.destroyEditCommand()
                raise GeoAlgorithmExecutionException(
                    "Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                        field.name(),
                        field.typeName()))

        if mAttributeId==-1 or mAttributeId_re==-1:
            # add sucess, get index of the new field
            fields = self.m_RD_EDGE_LAYER.fields()
            for indx in range(fields.count()):
                # print fields[indx].name()
                if fields[indx].name() == field_name:
                    mAttributeId = indx
                if fields[indx].name() == field_name+'_re':
                    mAttributeId_re = indx
                if mAttributeId != -1 and mAttributeId_re!=-1:
                    break

        if mAttributeId == -1 or mAttributeId_re==-1:
            self.m_RD_EDGE_LAYER.destroyEditCommand()
            raise GeoAlgorithmExecutionException(
                "Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                    field.name(),
                    field.typeName()))

        # end: create new field ========================================================================================
        # start: 1.read network into memory; 2.construct the diagraph; 3. compute betweenness index=====================
        #--------1.read network into memory;---------------------
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_RD_EDGE_LAYER.selectedFeatureCount() > 0:
            feats = self.m_RD_EDGE_LAYER.getSelectedFeatures()
            count = int(self.m_RD_EDGE_LAYER.selectedFeatureCount())
        else:
            feats = self.m_RD_EDGE_LAYER.getFeatures()
            count = int(self.m_RD_EDGE_LAYER.featureCount())
        #--------2.construct the diagraph;----------------
        bt = {}
        start_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "Start time:%s\n" % (str(start_time)))
        if self.m_PACKAGE=="NETWORKX":
            d_network = DiGraph()
            for current, feat in enumerate(feats):
                id = feat[self.m_RD_EDGE_LAYER_ID]
                source = feat[self.m_RD_EDGE_LAYER_SOURCE_FIELD]
                target = feat[self.m_RD_EDGE_LAYER_TARGET_FIELD]
                # cost = feat[self.m_RD_EDGE_LAYER_COST_FIELD]
                # re_cost = feat[self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD]
                weight = feat[self.m_RD_EDGE_LAYER_WEIGHT_FIELD]
                re_weight = feat[self.m_RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD]
                if (weight !=NULL and weight > 0):
                    d_network.add_edge(source, target,weight=weight)
                if (weight !=NULL and re_weight > 0):
                    d_network.add_edge(target, source,weight = re_weight)

            progress.setPercentage(int(10))
            #--------3. compute betweenness index---------------------
            k=None
            if self.m_BETWEENNESS_K>0:
                k = self.m_BETWEENNESS_K
            bt = self.edge_betweenness_centrality(d_network,k=k,weight='weight')
            progress.setPercentage(int(90))
            end_time = time.time()
            ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "NetworkX laps:%s\n" % (str(end_time - start_time)))
            # end: 1.read network into memory; 2.construct the diagraph; 3. compute betweenness index=======================
        elif self.m_PACKAGE=='IGRAPH':
            edges=[]
            idn = 0
            for current, feat in enumerate(feats):
                id = feat[self.m_RD_EDGE_LAYER_ID]
                source = feat[self.m_RD_EDGE_LAYER_SOURCE_FIELD]
                target = feat[self.m_RD_EDGE_LAYER_TARGET_FIELD]
                weight = feat[self.m_RD_EDGE_LAYER_WEIGHT_FIELD]
                re_weight = feat[self.m_RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD]

                if (weight !=NULL and weight > 0):
                    edges.append({"source": source, "target": target, "weight": weight})
                if (weight !=NULL and re_weight > 0):
                    edges.append({"source": target, "target": source, "weight": re_weight})
                progress.setPercentage(int(0+idn*1.0*10/count))
                idn+=1

            g = Graph.DictList({}, edges,directed=True)
            coff = None
            if self.m_CUTOFF>0:
                coff = self.m_CUTOFF
            res = g.edge_betweenness(directed=True,cutoff=coff,weights="weight")
            progress.setPercentage(int(55))
            for i in range(g.ecount()):
                s = g.vs[g.es[i].source]["name"]
                t = g.vs[g.es[i].target]["name"]
                bt[(s,t)] = res[i]/(g.vcount()*1.0)/(g.vcount()*1.0-1)
            end_time = time.time()
            ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "Igraph laps:%s\n" % (str(end_time - start_time)))
            progress.setPercentage(int(60))
        #start: write results===========================================================================================
        ## write the results to the fields in RD_EDGE_LAYER------------
        # update value with new fields
        request = QgsFeatureRequest()
        request.setFlags(QgsFeatureRequest.NoGeometry)
        # is only update select features
        # request.setFilterFids( layer.selectedFeaturesIds() )
        fit = QgsFeatureIterator(self.m_RD_EDGE_LAYER.getFeatures(request))  # fit:QgsFeatureIterator
        feat = QgsFeature()
        rownum = 0
        idn=0
        while (fit.nextFeature(feat)):
            self.m_RD_EDGE_LAYER.changeAttributeValue(feat.id(), mAttributeId, 0.0)
            self.m_RD_EDGE_LAYER.changeAttributeValue(feat.id(), mAttributeId_re, 0.0)
            id = feat[self.m_RD_EDGE_LAYER_ID]
            source = feat[self.m_RD_EDGE_LAYER_SOURCE_FIELD]
            target = feat[self.m_RD_EDGE_LAYER_TARGET_FIELD]
            weight = feat[self.m_RD_EDGE_LAYER_WEIGHT_FIELD]
            re_weight = feat[self.m_RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD]
            if weight != NULL and weight>0:
                value = bt[(source, target)]
                field.convertCompatible(value)
                self.m_RD_EDGE_LAYER.changeAttributeValue(feat.id(), mAttributeId, value)
            if re_weight != NULL and re_weight>0:
                value = bt[(target,source)]
                field.convertCompatible(value)
                self.m_RD_EDGE_LAYER.changeAttributeValue(feat.id(), mAttributeId_re, value)
            rownum += 1
            progress.setPercentage(int(60 + idn * 1.0 * 40 / count))
            idn += 1
        self.m_RD_EDGE_LAYER.endEditCommand()
        modify = self.m_RD_EDGE_LAYER.isModified()
        if modify:
            suc = self.m_RD_EDGE_LAYER.commitChanges()
            if not suc:
                errors = self.m_RD_EDGE_LAYER.commitErrors()
                msg = ''
                for err in errors:
                    msg+=str(err)+"\n"
                ProcessingLog.addToLog(ProcessingLog.LOG_ERROR,msg)
                QMessageBox.critical(None, ("Failed to update Edge Table"),
                                     ("Failed to update Edge Table,Please check the processing.log for more details." ))
                return
        # ## write the results to the fields in POLY_ZONE_VECTOR------------
        # if self.m_POLY_ZONE_VECTOR is not None:
        #     if self.m_CHECK_OUTPUT_AS_FIELD and self.m_OUTPUT_FIELD_ZONE:
        #         # create a field in POLY_ZONE_VECTOR
        #         if not self.m_POLY_ZONE_VECTOR.isEditable():
        #             self.m_POLY_ZONE_VECTOR.startEditing()
        #         # start: create new field =======================================================================================
        #         field_name = self.m_OUTPUT_FIELD_ZONE
        #         self.m_POLY_ZONE_VECTOR.beginEditCommand("Add attribute")
        #         field = QgsField(field_name, QVariant.Double, 'numeric(20,10)', 20,
        #                          10)  # [TODO] rdedge_param.datasource, postgres, spatialite,file different command
        #         mAttributeId = -1
        #         if (not self.m_POLY_ZONE_VECTOR.addAttribute(field)):
        #             # failed to add new fields, may be already exists
        #             # check whether exists
        #             # try to get the index of the new field
        #             fields = self.m_POLY_ZONE_VECTOR.fields()
        #             for indx in range(fields.count()):
        #                 print fields[indx].name()
        #                 if fields[indx].name() == field_name:
        #                     mAttributeId = indx
        #                     break
        #             if mAttributeId == -1:
        #                 # not exists, and add failed
        #                 self.m_POLY_ZONE_VECTOR.destroyEditCommand()
        #                 QMessageBox.critical(None, ("Failed to add field"),
        #                                      ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
        #                                          field.name(),
        #                                          field.typeName())))
        #                 return
        #
        #         if mAttributeId == -1:
        #             # add sucess, get index of the new field
        #             fields = self.m_POLY_ZONE_VECTOR.fields()
        #             for indx in range(fields.count()):
        #                 print fields[indx].name()
        #                 if fields[indx].name() == field_name:
        #                     mAttributeId = indx
        #                     break
        #
        #         if mAttributeId == -1 :
        #             self.m_POLY_ZONE_VECTOR.destroyEditCommand()
        #             QMessageBox.critical(None, ("Failed to add field"),
        #                                  ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
        #                                      field.name(),
        #                                      field.typeName())))
        #             return
        #
        #         # create spatial index for the edge table
        #         if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
        #                 and self.m_RD_EDGE_LAYER.selectedFeatureCount() > 0:
        #             idx = QgsSpatialIndex(self.m_RD_EDGE_LAYER.getSelectedFeatures())
        #         else:
        #             idx = QgsSpatialIndex(self.m_RD_EDGE_LAYER.getFeatures())
        #
        #         # for each poly
        #         if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
        #                 and self.m_POLY_ZONE_VECTOR.selectedFeatureCount() > 0:
        #             polys = self.m_POLY_ZONE_VECTOR.getSelectedFeatures()
        #             count = int(self.m_POLY_ZONE_VECTOR.selectedFeatureCount())
        #         else:
        #             polys = self.m_POLY_ZONE_VECTOR.getFeatures()
        #             count = int(self.m_POLY_ZONE_VECTOR.featureCount())
        #         for current, poly in enumerate(polys):
        #             # get the intersect edge
        #             geom = vector.snapToPrecision(poly.geometry(), self.precision)
        #             bbox = vector.bufferedBoundingBox(geom.boundingBox(), 0.51 * self.precision)
        #             intersects = idx.intersects(bbox)
        #             #snap to presicion
        #             selection =[]
        #             for i in intersects:
        #                 request = QgsFeatureRequest().setFilterFid(i)
        #                 rd_line = next(self.m_RD_EDGE_LAYER.getFeatures(request))
        #                 tmpGeom = vector.snapToPrecision(rd_line.geometry(), self.precision)
        #                 res = False
        #                 res = tmpGeom.intersects(geom)
        #                 if res==True:
        #                     selection.append(rd_line)
        #             # aggregate
        #             c_aggre = 0
        #             t_aggre = 0
        #             for edge in selection:
        #                 bt = edge[self.m_OUTPUT_FIELD_RD_EDGE]
        #                 bt_re = edge[self.m_OUTPUT_FIELD_RD_EDGE+"_re"]
        #                 weight = feat[self.m_RD_EDGE_LAYER_WEIGHT_FIELD]
        #                 re_weight = feat[self.m_RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD]
        #                 if weight != NULL:
        #                     c_aggre+=1
        #                     t_aggre+=bt
        #                 if re_weight != NULL:
        #                     c_aggre += 1
        #                     t_aggre += bt_re
        #             a_aggre = 0
        #             if c_aggre>0:
        #                 a_aggre = t_aggre/c_aggre
        #             # write the value
        #             self.m_POLY_ZONE_VECTOR.changeAttributeValue(poly.id(), mAttributeId, a_aggre)
        #         #commit changes
        #         self.m_POLY_ZONE_VECTOR.endEditCommand()
        #         modify = self.m_POLY_ZONE_VECTOR.isModified()
        #         if modify:
        #             suc = self.m_POLY_ZONE_VECTOR.commitChanges()
        #             if not suc:
        #                 errors = self.m_POLY_ZONE_VECTOR.commitErrors()
        #                 msg = ''
        #                 for err in errors:
        #                     msg += str(err) + "\n"
        #                 ProcessingLog.addToLog(ProcessingLog.LOG_ERROR, msg)
        #                 QMessageBox.critical(None, ("Failed to update Edge Table"),
        #                                      ("Failed to update Edge Table,Please check the processing.log for more details."))
        #                 return
        #     else:
        #         QMessageBox.information(None, ("Missing information"),
        #                              ("Please check parameter OUTPUT_FIELD_ZONE"))
        # else:
        #     #do nothing
        #     pass
        # ## write the results to a new layer--------------------
        # if self.m_CHECK_OUTPUT_AS_LAYER:
        #     #[TODO]write new output layer, only have attribute [id,bt,geom] according to zone layer
        #     pass
        # end: write results============================================================================================
        progress.setPercentage(int(100))
        # End Processing

    def edge_betweenness_centrality(self, G, k=None, normalized=True, weight=None,
                                    seed=None):
        r"""Compute betweenness centrality for edges.

        Betweenness centrality of an edge $e$ is the sum of the
        fraction of all-pairs shortest paths that pass through $e$

        .. math::

           c_B(e) =\sum_{s,t \in V} \frac{\sigma(s, t|e)}{\sigma(s, t)}

        where $V$ is the set of nodes, $\sigma(s, t)$ is the number of
        shortest $(s, t)$-paths, and $\sigma(s, t|e)$ is the number of
        those paths passing through edge $e$ [2]_.

        Parameters
        ----------
        G : graph
          A NetworkX graph.

        k : int, optional (default=None)
          If k is not None use k node samples to estimate betweenness.
          The value of k <= n where n is the number of nodes in the graph.
          Higher values give better approximation.

        normalized : bool, optional
          If True the betweenness values are normalized by $2/(n(n-1))$
          for graphs, and $1/(n(n-1))$ for directed graphs where $n$
          is the number of nodes in G.

        weight : None or string, optional (default=None)
          If None, all edge weights are considered equal.
          Otherwise holds the name of the edge attribute used as weight.

        Returns
        -------
        edges : dictionary
           Dictionary of edges with betweenness centrality as the value.

        See Also
        --------
        betweenness_centrality
        edge_load

        Notes
        -----
        The algorithm is from Ulrik Brandes [1]_.

        For weighted graphs the edge weights must be greater than zero.
        Zero edge weights can produce an infinite number of equal length
        paths between pairs of nodes.

        References
        ----------
        .. [1]  A Faster Algorithm for Betweenness Centrality. Ulrik Brandes,
           Journal of Mathematical Sociology 25(2):163-177, 2001.
           http://www.inf.uni-konstanz.de/algo/publications/b-fabc-01.pdf
        .. [2] Ulrik Brandes: On Variants of Shortest-Path Betweenness
           Centrality and their Generic Computation.
           Social Networks 30(2):136-145, 2008.
           http://www.inf.uni-konstanz.de/algo/publications/b-vspbc-08.pdf
        """
        betweenness = dict.fromkeys(G, 0.0)  # b[v]=0 for v in G
        # b[e]=0 for e in G.edges()
        betweenness.update(dict.fromkeys(G.edges(), 0.0))
        if k is None:
            nodes = G
        else:
            random.seed(seed)
            nodes = random.sample(G.nodes(), k)
        num_nodes = len(G.nodes)
        indx = 0.0
        # start_time = time.time()
        #progress bar from 10 -> 90
        for s in nodes:
            # single source shortest paths
            if weight is None:  # use BFS
                S, P, sigma = _single_source_shortest_path_basic(G, s)
            else:  # use Dijkstra's algorithm
                S, P, sigma = _single_source_dijkstra_path_basic(G, s, weight)
            # accumulation
            betweenness = _accumulate_edges(betweenness, S, P, sigma, s)
            indx+=1
            self.progress.setPercentage(int(10+indx*80.0/(num_nodes*1.0)))
            # end_time = time.time()
            # lap = end_time-start_time
            #print("Estimated time: "+str(int(lap))+"; percentage:"+str(indx/num_nodes)+"\n")
            #msg = "Elapse time: "+str(int(lap))+"; percentage:"+str(indx/num_nodes)+"\n"
            #ProcessingLog.addToLog(ProcessingLog.LOG_ERROR, msg)
        # rescaling
        for n in G:  # remove nodes to only return edges
            del betweenness[n]
        betweenness = _rescale_e(betweenness, len(G), normalized=normalized,
                                 directed=G.is_directed())
        return betweenness

def _single_source_shortest_path_basic(G, s):
    S = []
    P = {}
    for v in G:
        P[v] = []
    sigma = dict.fromkeys(G, 0.0)    # sigma[v]=0 for v in G
    D = {}
    sigma[s] = 1.0
    D[s] = 0
    Q = [s]
    while Q:   # use BFS to find shortest paths
        v = Q.pop(0)
        S.append(v)
        Dv = D[v]
        sigmav = sigma[v]
        for w in G[v]:
            if w not in D:
                Q.append(w)
                D[w] = Dv + 1
            if D[w] == Dv + 1:   # this is a shortest path, count paths
                sigma[w] += sigmav
                P[w].append(v)  # predecessors
    return S, P, sigma

def _single_source_dijkstra_path_basic(G, s, weight):
    # modified from Eppstein
    S = []
    P = {}
    for v in G:
        P[v] = []
    sigma = dict.fromkeys(G, 0.0)    # sigma[v]=0 for v in G
    D = {}
    sigma[s] = 1.0
    push = heappush
    pop = heappop
    seen = {s: 0}
    c = count()
    Q = []   # use Q as heap with (distance,node id) tuples
    push(Q, (0, next(c), s, s))
    while Q:
        (dist, _, pred, v) = pop(Q)
        if v in D:
            continue  # already searched this node.
        sigma[v] += sigma[pred]  # count paths
        S.append(v)
        D[v] = dist
        for w, edgedata in G[v].items():
            vw_dist = dist + edgedata.get(weight, 1)
            if w not in D and (w not in seen or vw_dist < seen[w]):
                seen[w] = vw_dist
                push(Q, (vw_dist, next(c), v, w))
                sigma[w] = 0.0
                P[w] = [v]
            elif vw_dist == seen[w]:  # handle equal paths
                sigma[w] += sigma[v]
                P[w].append(v)
    return S, P, sigma
def _accumulate_edges(betweenness, S, P, sigma, s):
    delta = dict.fromkeys(S, 0)
    while S:
        w = S.pop()
        coeff = (1.0 + delta[w]) / sigma[w]
        for v in P[w]:
            c = sigma[v] * coeff
            if (v, w) not in betweenness:
                betweenness[(w, v)] += c
            else:
                betweenness[(v, w)] += c
            delta[v] += c
        if w != s:
            betweenness[w] += delta[w]
    return betweenness

def _rescale_e(betweenness, n, normalized, directed=False, k=None):
    if normalized:
        if n <= 1:
            scale = None  # no normalization b=0 for all nodes
        else:
            scale = 1.0 / (n * (n - 1))
    else:  # rescale by 2 for undirected graphs
        if not directed:
            scale = 0.5
        else:
            scale = None
    if scale is not None:
        if k is not None:
            scale = scale * n / k
        for v in betweenness:
            betweenness[v] *= scale
    return betweenness