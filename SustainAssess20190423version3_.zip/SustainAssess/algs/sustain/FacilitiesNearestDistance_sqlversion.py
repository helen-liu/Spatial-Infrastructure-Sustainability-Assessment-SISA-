# -*- coding: utf-8 -*-

"""
***************************************************************************
    RandomPointsLayer.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Alexander Bruy
    Email                : alexander dot bruy at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
from qgis.PyQt.QtGui import QIcon
from qgis.core import (QgsDataSourceUri)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterBoolean_Group
from SustainAssess.core.parameters import ParameterTableField,ParameterCreateField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector
from SustainAssess.algs.cores.accesibility import update_accessibility_field
from SustainAssess.tools import postgis
from SustainAssess.tools.postgis import TableField

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class NearestDistance(GeoAlgorithm):

    SOURCE_LAYER = 'SOURCE_LAYER'

    TARGET_LAYER = 'TARGET_LAYER'
    TARGET_LAYER_ID = 'TARGET_LAYER_ID'

    RD_EDGE_LAYER = 'RD_EDGE_LAYER'
    RD_EDGE_LAYER_ID = 'RD_EDGE_LAYER_ID'
    RD_EDGE_LAYER_SOURCE_FIELD = 'RD_EDGE_LAYER_SOURCE_FIELD'
    RD_EDGE_LAYER_TARGET_FIELD = 'RD_EDGE_LAYER_TARGET_FIELD'
    RD_EDGE_LAYER_COST_FIELD = 'RD_EDGE_LAYER_COST_FIELD'
    RD_EDGE_LAYER_REVERSE_COST_FIELD = 'RD_EDGE_LAYER_REVERSE_COST_FIELD'

    RD_NODE_LAYER = 'RD_NODE_LAYER'
    # RD_NODE_LAYER_ID = 'RD_NODE_LAYER_ID'

    CHECK_OUTPUT_AS_FIELD = 'CHECK_OUTPUT_AS_FIELD'
    OUTPUT_FIELD = 'OUTPUT_FIELD'

    CHECK_OUTPUT_AS_LAYER = 'CHECK_OUTPUT_AS_LAYER'
    OUTPUT_LAYER = 'OUTPUT_LAYER'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Accessiblity/Nearest Distance"
        self.name, self.i18n_name = self.trAlgorithm('Nearest Distance')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')

        self.addParameter(ParameterVector_RDBMS(self.SOURCE_LAYER,
                                                self.tr('Source Layer (POINT)'), [ParameterVector_RDBMS.VECTOR_TYPE_POINT]))
        self.addParameter(ParameterVector_RDBMS(self.TARGET_LAYER,
                                                self.tr('Target Layer'),[ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.TARGET_LAYER_ID,
                                              self.tr('    Target Layer ID Field'), self.TARGET_LAYER))

        self.addParameter(ParameterVector_RDBMS(self.RD_EDGE_LAYER,
                                                self.tr('Roads\' Edge Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_LINE]))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_ID,
                                              self.tr('    Edge ID Field'), self.RD_EDGE_LAYER))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_SOURCE_FIELD,
                                              self.tr('    Edge Source Field'), self.RD_EDGE_LAYER))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_TARGET_FIELD,
                                              self.tr('    Edge Target Field'), self.RD_EDGE_LAYER))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_COST_FIELD,
                                              self.tr('    Edge Cost Field'), self.RD_EDGE_LAYER))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_REVERSE_COST_FIELD,
                                              self.tr('    Edge Reverse Cost Field'), self.RD_EDGE_LAYER))

        self.addParameter(ParameterVector_RDBMS(self.RD_NODE_LAYER,
                                                self.tr('Roads\' Node Layer'),[ParameterVector_RDBMS.VECTOR_TYPE_POINT]))
        # self.addParameter(ParameterTableField(self.RD_NODE_LAYER_ID,
        #                                       self.tr('    Road Node ID Field'), self.RD_NODE_LAYER))

        self.addParameter(ParameterBoolean_Group(self.CHECK_OUTPUT_AS_FIELD,
                                       self.tr('Create field in Source Layer:'),
                                                 [self.OUTPUT_FIELD],True))
        self.addParameter(ParameterCreateField(self.OUTPUT_FIELD,
                                          self.tr('Field Name'),self.SOURCE_LAYER))
        self.addParameter(ParameterBoolean_Group(self.CHECK_OUTPUT_AS_LAYER,
                                       self.tr('Create New Layer'),
                                                 [self.OUTPUT_LAYER],False))
        self.addOutput(OutputVector(self.OUTPUT_LAYER, self.tr('Nearest Distance to Facilities Layer')))

    def processAlgorithm(self, progress):
        source_param = self.getParameterFromName(self.SOURCE_LAYER)
        self.m_SOURCE_LAYER = source_param.getLayerObject()

        target_param = self.getParameterFromName(self.TARGET_LAYER)
        self.m_TARGET_LAYER = target_param.getLayerObject()
        self.m_TARGET_LAYER_ID = self.getParameterValue(self.TARGET_LAYER_ID)

        edge_param = self.getParameterFromName(self.RD_EDGE_LAYER)
        self.m_EDGE_LAYER = edge_param.getLayerObject()
        self.m_RD_EDGE_LAYER_ID = self.getParameterValue(self.RD_EDGE_LAYER_ID)
        self.m_RD_EDGE_LAYER_SOURCE_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_SOURCE_FIELD)
        self.m_RD_EDGE_LAYER_TARGET_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_TARGET_FIELD)
        self.m_RD_EDGE_LAYER_COST_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_COST_FIELD)
        self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_REVERSE_COST_FIELD)

        node_param = self.getParameterFromName(self.RD_NODE_LAYER)
        self.m_RD_NODE_LAYER = node_param.getLayerObject()
        # self.m_RD_NODE_LAYER_ID = self.getParameterValue(self.RD_NODE_LAYER_ID)

        self.m_CHECK_OUTPUT_AS_FIELD = self.getParameterValue(self.CHECK_OUTPUT_AS_FIELD)
        self.m_OUTPUT_FIELD = self.getParameterValue(self.OUTPUT_FIELD)

        self.m_CHECK_OUTPUT_AS_LAYER = self.getParameterValue(self.CHECK_OUTPUT_AS_LAYER)
        self.m_OUTPUT_LAYER = self.getOutputFromName(self.OUTPUT_LAYER)

        source_uri = QgsDataSourceUri(source_param.getURI())
        db = postgis.GeoDB(uri=source_uri)
        target_uri = QgsDataSourceUri(target_param.getURI())
        edge_uri = QgsDataSourceUri(edge_param.getURI())
        node_uri = QgsDataSourceUri(node_param.getURI())

        if not self.getParameterFromName(self.OUTPUT_FIELD).overwrite:
            t = TableField(self.m_OUTPUT_FIELD, "numeric", default='0')
            db.table_add_column(source_uri.table(), t, source_uri.schema())

            t = TableField(self.m_OUTPUT_FIELD+"_id", "numeric", default='0')
            db.table_add_column(source_uri.table(), t, source_uri.schema())

            t = TableField(self.m_OUTPUT_FIELD+"_area", "numeric", default='0')
            db.table_add_column(source_uri.table(), t, source_uri.schema())
        else:
            sql = 'Update "%s"."%s" set %s=0;' % (source_uri.schema(), source_uri.table(), self.m_OUTPUT_FIELD)
            sql += 'Update "%s"."%s" set %s=0;' % (source_uri.schema(), source_uri.table(), self.m_OUTPUT_FIELD+"_id")
            sql += 'Update "%s"."%s" set %s=0;' % (source_uri.schema(), source_uri.table(), self.m_OUTPUT_FIELD+"_area")
            db._exec_sql_and_commit(sql)

        para_dic = {"park": {"schema": target_uri.schema(), "name": target_uri.table(), "id":self.m_TARGET_LAYER_ID,
                             "geom": target_uri.geometryColumn(), "crs": int(target_uri.srid())},
                "road_edge": {"schema": edge_uri.schema(), "name": edge_uri.table(),
                                  "id":self.m_RD_EDGE_LAYER_ID,"geom": edge_uri.geometryColumn(),
                                  "crs": int(edge_uri.srid()),"source":self.m_RD_EDGE_LAYER_SOURCE_FIELD,
                                  "target":self.m_RD_EDGE_LAYER_TARGET_FIELD, "cost":self.m_RD_EDGE_LAYER_COST_FIELD,
                                  "rv_cost":self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD},
                "road_node": {"schema": node_uri.schema(), "name": node_uri.table(),
                            "geom": node_uri.geometryColumn(), "crs": int(node_uri.srid())},
                "random_point": {"schema": source_uri.schema(), "name": source_uri.table(),
                                          "geom": source_uri.geometryColumn(), "crs": int(source_uri.srid()),
                                          "accessibility":self.m_OUTPUT_FIELD, "parkID":"","area_sum":""},
                         "msg": ""
                         }
        cur = db.con.cursor()
        bool_c, msg1 = update_accessibility_field(para_dic,cur,db.con)
        db.con.close()

