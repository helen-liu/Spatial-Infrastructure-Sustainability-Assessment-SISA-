# -*- coding: utf-8 -*-

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,sys
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsGeometry, QgsField, QgsSpatialIndex,QgsFeature,QgsWkbTypes)
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterBoolean_Group
from SustainAssess.core.parameters import ParameterTableField,ParameterCreateField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.tools import vector
from SustainAssess.tools import postgis
from networkx import DiGraph,number_strongly_connected_components
from SustainAssess.core.ProcessingConfig import ProcessingConfig

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class E_V_P_Index(GeoAlgorithm):

    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_ID_FIELD = 'POLY_ID_FIELD' #
    EDGE_LAYER = 'EDGE_LAYER'
    EDGE_ID_FIELD = 'EDGE_ID_FIELD'
    EDGE_SOURCE_FIELD = 'EDGE_SOURCE_FIELD'
    EDGE_TARGET_FIELD = 'EDGE_TARGET_FIELD'
    #EDGE_DIRECTION_FIELD = 'EDGE_DIRECTION_FIELD'
    COST_FIELD = 'COST_FIELD'
    REVERSE_COST_FIELD = 'REVERSE_COST_FIELD'

    CHECK_OUTPUT_AS_FIELD = 'CHECK_OUTPUT_AS_FIELD'
    POLY_E_FIELD = 'POLY_E_FIELD'
    POLY_V_FIELD = 'POLY_V_FIELD'
    POLY_P_FIELD = 'POLY_P_FIELD'

    CHECK_OUTPUT_AS_LAYER = 'CHECK_OUTPUT_AS_LAYER'
    OUTPUT = 'OUTPUT'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Connectivity/Basic Network Index"
        self.name, self.i18n_name = self.trAlgorithm('Basic Network Index')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')
        self.precision = 0.0
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Zone Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterTableField(self.POLY_ID_FIELD,
                                          self.tr('ID Field'),self.POLY_VECTOR))
        self.addParameter(ParameterVector_RDBMS(self.EDGE_LAYER,
                                                self.tr('Roads Layer'), [ParameterVector_RDBMS.VECTOR_ROAD_NETWORK]))
        self.addParameter(ParameterTableField(self.EDGE_SOURCE_FIELD,
                                          self.tr('Source Field'),self.EDGE_LAYER,defalut="source"))
        self.addParameter(ParameterTableField(self.EDGE_TARGET_FIELD,
                                          self.tr('Target Field'),self.EDGE_LAYER,defalut="target"))
        self.addParameter(ParameterTableField(self.COST_FIELD,
                                          self.tr('Cost Field'),self.EDGE_LAYER,defalut="cost"))
        self.addParameter(ParameterTableField(self.REVERSE_COST_FIELD,
                                          self.tr('Reverse Cost Field'),self.EDGE_LAYER,defalut="reverse_cost"))

        # self.addParameter(ParameterBoolean_Group(self.CHECK_OUTPUT_AS_FIELD,
        #                                self.tr('Create Fields in Input Zone Layer'),
        #                                          [self.POLY_E_FIELD,self.POLY_V_FIELD,self.POLY_P_FIELD],True))
        self.addParameter(ParameterBoolean_Group(self.CHECK_OUTPUT_AS_LAYER,
                                       self.tr('Create New Output Layer'),
                                                 [self.OUTPUT],False))
        self.addParameter(ParameterCreateField(self.POLY_E_FIELD,
                                          self.tr("'E' Field:"),self.POLY_VECTOR,default = "e_net",optional=True))
        self.addParameter(ParameterCreateField(self.POLY_V_FIELD,
                                          self.tr("'V' Field:"),self.POLY_VECTOR,default = "v_net",optional=True))
        self.addParameter(ParameterCreateField(self.POLY_P_FIELD,
                                          self.tr("'P' Field:"),self.POLY_VECTOR,default = "p_net",optional=True))

        self.addOutput(OutputVector(self.OUTPUT, self.tr('Output Layer')))

    def checkParameterValuesBeforeExecuting(self):
        self.m_POLY_E_FIELD = self.getParameterValue(self.POLY_E_FIELD)
        self.m_POLY_V_FIELD = self.getParameterValue(self.POLY_V_FIELD)
        self.m_POLY_P_FIELD = self.getParameterValue(self.POLY_P_FIELD)
        if not self.m_POLY_E_FIELD and not self.m_POLY_P_FIELD and not self.m_POLY_V_FIELD:
            return "At Least Specify One of E, V, P Field to Calculate."
    def processAlgorithm(self, progress):
        # e = number of edges (links),
        # v = number of vertices (nodes),
        # p = number of graphs or subgraphs.

        # 1. get parameters
        paramInput = self.getParameterFromName(self.POLY_VECTOR)
        self.m_POLY_VECTOR = paramInput.getLayerObject()
        self.m_POLY_ID_FIELD = self.getParameterValue(self.POLY_ID_FIELD)

        paramInput2 = self.getParameterFromName(self.EDGE_LAYER)
        self.m_EDGE_LAYER = paramInput2.getLayerObject()
        #self.m_EDGE_ID_FIELD = self.getParameterValue(self.EDGE_ID_FIELD)
        self.m_EDGE_SOURCE_FIELD = self.getParameterValue(self.EDGE_SOURCE_FIELD)
        self.m_EDGE_TARGET_FIELD = self.getParameterValue(self.EDGE_TARGET_FIELD)
        self.m_COST_FIELD = self.getParameterValue(self.COST_FIELD)
        self.m_REVERSE_COST_FIELD = self.getParameterValue(self.REVERSE_COST_FIELD)

        self.m_CHECK_OUTPUT_AS_LAYER = self.getParameterValue(self.CHECK_OUTPUT_AS_LAYER)
        self.m_OUTPUT = self.getOutputFromName(self.OUTPUT)

        # 2. check whether m_POLY_VECTOR and m_EDGE_LAYER have the same SRID
        if self.m_POLY_VECTOR.crs().authid()!=self.m_EDGE_LAYER.crs().authid():
            raise GeoAlgorithmExecutionException("Input Zone layer and the Roads Layer should have the same SRID!")

        # poly_drivername = self.m_POLY_VECTOR.dataProvider().name()
        # edge_drivername = self.m_EDGE_LAYER.dataProvider().name()
        # if edge_drivername!=u"postgres":
        #     raise GeoAlgorithmExecutionException("Network layer must from PostGIS!")
        # if poly_drivername!=u'postgres':
        #     raise GeoAlgorithmExecutionException("Input Zone layer must from PostGIS!")

        # create spatial index for the edge table
        edge_data={}
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_EDGE_LAYER.selectedFeatureCount() > 0:
            idx = QgsSpatialIndex(self.m_EDGE_LAYER.getSelectedFeatures())
            feats = self.m_EDGE_LAYER.getSelectedFeatures()
            for ft in feats:
                edge_data[ft.id()]=[ft[self.m_EDGE_SOURCE_FIELD],ft[self.m_EDGE_TARGET_FIELD],
                                    ft[self.m_COST_FIELD],ft[self.m_REVERSE_COST_FIELD],QgsGeometry(ft.geometry())]
        else:
            idx = QgsSpatialIndex(self.m_EDGE_LAYER.getFeatures())
            feats = self.m_EDGE_LAYER.getFeatures()
            for ft in feats:
                edge_data[ft.id()]=[ft[self.m_EDGE_SOURCE_FIELD],ft[self.m_EDGE_TARGET_FIELD],
                                    ft[self.m_COST_FIELD],ft[self.m_REVERSE_COST_FIELD],QgsGeometry(ft.geometry())]

        field_names = [self.m_POLY_E_FIELD,self.m_POLY_V_FIELD,self.m_POLY_P_FIELD]
        field_name_index = {}
        # init----------------------------------------------------------------
        if not self.m_CHECK_OUTPUT_AS_LAYER:
            # create filed in the input zone layer
            # add field to the ROAD NETWORK LAYER====================================================
            if not self.m_POLY_VECTOR.isEditable():
                self.m_POLY_VECTOR.startEditing()
            # start: create new field =======================================================================================
            self.m_POLY_VECTOR.beginEditCommand("Added attribute")
            for field_name in field_names:
                if not field_name: continue
                # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
                field = QgsField(field_name, QVariant.LongLong, 'bigint')  # [TODO] rdedge_param.datasource, postgres, spatialite,file different command
                mAttributeId = -1
                if (not self.m_POLY_VECTOR.addAttribute(field)):
                    # failed to add new fields, may be already exists
                    # check whether exists
                    # try to get the index of the new field
                    fields = self.m_POLY_VECTOR.fields()
                    for indx in range(fields.count()):
                        # print fields[indx].name()
                        if fields[indx].name() == field_name:
                            mAttributeId = indx
                            break
                    if mAttributeId == -1:
                        # not exists, and add failed
                        self.m_POLY_VECTOR.destroyEditCommand()
                        QMessageBox.critical(None, ("Failed to add field"),
                                             ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                                 field.name(),
                                                 field.typeName())))
                        return
                else:
                    # add sucess, get index of the new field
                    fields = self.m_POLY_VECTOR.fields()
                    for indx in range(fields.count()):
                        # print fields[indx].name()
                        if fields[indx].name() == field_name:
                            mAttributeId = indx
                        if mAttributeId != -1:
                            break

                if mAttributeId == -1:
                    self.m_POLY_VECTOR.destroyEditCommand()
                    QMessageBox.critical(None, ("Failed to add field"),
                                         ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                             field.name(),
                                             field.typeName())))
                    return
                field_name_index[field_name] = mAttributeId
                # End: create new field ========================================================================================
        else:
            geometryType = self.m_POLY_VECTOR.wkbType()
            fields = []
            ufields = self.m_POLY_VECTOR.fields()
            if ufields.count() <= 0:
                raise Exception("Error: Attribute table must have at least one field")
            types = {}

            fields_needed = [self.m_POLY_ID_FIELD]
            for field in ufields:
                # initial read in has correct ordering...
                name = str(field.name())
                if name in fields_needed:
                    types[name] = int(field.type())
            ''' -5:BIGINT   QVariant::LongLong
                -3:VARBINARY QVariant::ByteArray
                1: CHAR QVariant::String
                12: VARCHAR QVariant::String
                4: INTEGER QVariant::Int
                3:     //NUMERIC and DECIMAL  QVariant::Double;
                7:     //REAL  QVariant::Double;
                8:     //DOUBLE QVariant::Double;
                9:    //DATE  QVariant::String; // don't know why it doesn't like QVariant::Date
                10:    //TIME  QVariant::Time;
                11:    //TIMESTAMP QVariant::String; // don't know why it doesn't like QVariant::DateTime
                // Everything else just dumped as a string.  QVariant::String;
            '''
            idTypes_map = {'10': "text", '2': "integer", '4': "bigint",
                           '3': "integer", '5' : "bigint"}

            fields.append(QgsField(self.m_POLY_ID_FIELD, types[self.m_POLY_ID_FIELD],
                                   idTypes_map[str(types[self.m_POLY_ID_FIELD])]))
            for field_name in field_names:
                if not field_name: continue
                fields.append(QgsField(field_name, QVariant.LongLong, 'bigint'))
            writer = self.m_OUTPUT.getVectorWriter(fields, geometryType, self.m_POLY_VECTOR.crs(),
                                                   {"pk":self.m_POLY_ID_FIELD})
            outFeat = QgsFeature()
        progress.setPercentage(int(10))

        # for each poly update e,v,p
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_POLY_VECTOR.selectedFeatureCount() > 0:
            polys = self.m_POLY_VECTOR.getSelectedFeatures()
            count = int(self.m_POLY_VECTOR.selectedFeatureCount())
        else:
            polys = self.m_POLY_VECTOR.getFeatures()
            count = int(self.m_POLY_VECTOR.featureCount())

        for current, poly in enumerate(polys):
            # get the intersect edge
            geom = vector.snapToPrecision(poly.geometry(), self.precision)
            bbox = vector.bufferedBoundingBox(geom.boundingBox(), 0.51 * self.precision)
            intersects = idx.intersects(bbox)
            # snap to presicion
            selection = []
            vertex = set()
            # request = QgsFeatureRequest().setFilterFids(intersects)
            # for rd_line in self.m_EDGE_LAYER.getFeatures(request):
            # for i in intersects:
            #     request = QgsFeatureRequest().setFilterFid(i)
            #     rd_line = next(self.m_EDGE_LAYER.getFeatures(request))

            for sel in intersects:
                rd_line = edge_data[sel]
                tmpGeom = rd_line[4]
                # tmpGeom = vector.snapToPrecision(rd_line.geometry(), self.precision)
                res = False
                res = geom.intersects(tmpGeom)
                if res == True:
                    selection.append(rd_line)
                    # vertex.add(rd_line[self.m_EDGE_SOURCE_FIELD])
                    # vertex.add(rd_line[self.m_EDGE_TARGET_FIELD])
                    vertex.add(rd_line[0])
                    vertex.add(rd_line[1])
            vals = {}
            # 3. calculate e
            if self.m_POLY_E_FIELD:
                n = len(selection)
                vals[self.m_POLY_E_FIELD] = n

            # 4. calculate v
            if self.m_POLY_V_FIELD:
                n = len(vertex)
                vals[self.m_POLY_V_FIELD] = n

            # 5. calculate p
            if self.m_POLY_P_FIELD:
                d_network = DiGraph()
                for e in selection:
                    # source = e[self.m_EDGE_SOURCE_FIELD]
                    # target = e[self.m_EDGE_TARGET_FIELD]
                    # cost = e[self.m_COST_FIELD]
                    # reverse_cost = e[self.m_REVERSE_COST_FIELD]
                    source = e[0]
                    target = e[1]
                    cost = e[2]
                    reverse_cost = e[3]
                    if (cost < 10000 and cost > 0):
                        d_network.add_edge(source, target)
                    if (reverse_cost < 10000 and reverse_cost > 0):
                        d_network.add_edge(target, source)
                # [TODO] correct??
                n = number_strongly_connected_components(d_network)
                vals[self.m_POLY_P_FIELD] = n

            if not self.m_CHECK_OUTPUT_AS_LAYER:
                for key in vals.keys():
                    self.m_POLY_VECTOR.changeAttributeValue(poly.id(), field_name_index[key],
                                                            vals[key])
            else:
                id_ = poly[self.m_POLY_ID_FIELD]
                attr = [id_]
                for field_name in field_names:
                    if not field_name: continue
                    attr.append(vals[field_name])
                outFeat.setAttributes(attr)
                outFeat.setGeometry(poly.geometry())
                writer.addFeature(outFeat)
            progress.setPercentage(int(10+current*1.0/count*85))
        if not self.m_CHECK_OUTPUT_AS_LAYER:
            # commit changes
            self.m_POLY_VECTOR.endEditCommand()
            modify = self.m_POLY_VECTOR.isModified()
            if modify:
                suc = self.m_POLY_VECTOR.commitChanges()
                if not suc:
                    errors = self.m_POLY_VECTOR.commitErrors()
                    msg = ''
                    for err in errors:
                        msg += str(err) + "\n"
                    ProcessingLog.addToLog(ProcessingLog.LOG_ERROR, msg)
                    QMessageBox.critical(None, ("Failed to update Zone Layer"),
                                         (
                                             "Failed to update Zone Layer,Please check the processingliu.log for more details."))
                    return
        else:
            del writer
        progress.setPercentage(int(100))

def update_e(arg1,output_con):
    cur = output_con.cursor()
    query1 = '''
        BEGIN;
        update %(polygon_table)s
        set %(update_field)s =0;

        update %(polygon_table)s
        set %(update_field)s = t3.total
        from (
            select t1.%(polygon_id_field)s as id, count(*) as total
            from %(polygon_table)s as t1 inner join %(edge_table)s as t2
            on st_intersects(t1.%(polygon_geom_field)s,t2.%(edge_geom_field)s)
            group by t1.%(polygon_id_field)s
        ) as t3
        where t3.id = %(polygon_table)s.%(polygon_id_field)s;
        END;
    ''' % arg1
    try:
        cur.execute(query1)
    except postgis.DbError as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, exc_obj, exc_tb.tb_lineno)
        msg = str(exc_type) + str(exc_obj) + str(exc_tb.tb_lineno)
        return 0, msg
    output_con.commit()
    msg = 'Update %(update_field)s Successfully!\n' % arg1
    return 1, msg

def update_v(arg1,output_con):
    # because some edge end is out of the polygon, so it will be less when count directly using node table.
    # so here I use the edge table
    # for each poly
    cur = output_con.cursor()
    query3 = '''
    
    
            select %(polygon_id_field)s from %(polygon_table)s
            ''' % arg1
    cur.execute(query3)
    rows = cur.fetchall()
    for row in rows:
        poly_id = row[0]
        arg1['poly_id'] = poly_id
        query1 = '''
                select t2.source as source,t2.target as target
                from 
                (select * from %(polygon_table)s where %(polygon_id_field)s=%(poly_id)s) as t1 inner join %(edge_table)s as t2
                on st_intersects(t1.%(polygon_geom_field)s,t2.%(edge_geom_field)s)
        ''' % arg1
        cur.execute(query1)
        nodes = cur.fetchall()
        unique_ = set()
        for node in nodes:
            unique_.add(node[0])
            unique_.add(node[1])

        num_ver = len(unique_)
        arg1['num_ver'] = str(num_ver)
        update_query = '''
                        Begin;
                        update %(polygon_table)s
                        set %(update_field)s = %(num_ver)s
                        where %(polygon_id_field)s = %(poly_id)s;
                        End;
                        ''' % arg1
        cur.execute(update_query)
        output_con.commit()
    msg = 'Update %(update_field)s Successfully!\n' % arg1
    return 1, msg

def update_p(arg1,output_con):
        # arg1 = {'polygon_table': polygon_table,
        #         'edge_table': edge_table,
        #         'polygon_geom_field': polygon_geom_field,
        #         'edge_geom_field': edge_geom_field,
        #         'polygon_id_field': polygon_id_field,
        #         'update_field': "p",
        #         'source': "source",
        #         'target': "target",
        #         'dir': "dir"
        #         }

    # get source_index, target_index, dir_index
    cur = output_con.cursor()
    source_index, target_index, cost_index,reverse_cost_index = -1, -1, -1,-1
    arg_temp = {"schema":arg1["edge_table"].split(".")[0],
                "name":arg1["edge_table"].split(".")[1]}
    query1 = '''
            SELECT *
            FROM information_schema.columns
            WHERE table_schema = '%(schema)s'
              AND table_name   = '%(name)s'
        ''' % (arg_temp)
    cur.execute(query1)
    rows = cur.fetchall()
    # get source_index
    index = -1
    for row in rows:
        index += 1
        if row[3] == arg1["source"]:
            source_index = index
        if row[3] == arg1["target"]:
            target_index = index
        if row[3] == arg1["cost_field"]:
            cost_index = index
        if row[3] == arg1["reverse_cost_field"]:
            reverse_cost_index = index
    # get all polygon id and store them in id_list
    query1 = '''
        update %(polygon_table)s
        set %(update_field)s = 0;
        select id
        from %(polygon_table)s; 
    ''' % arg1
    cur.execute(query1)
    rows = cur.fetchall()
    id_list = []
    for row in rows:
        id_list.append(row[0])

    # for each polygon calculate the p
    for mid in id_list:
        arg1['id'] = mid
        query2 = '''
                    drop table if exists temp_poly;

                    select * into temp_poly from %(polygon_table)s where %(polygon_id_field)s=%(id)s;

                    select t2.*
                    from temp_poly as t1 inner join %(edge_table)s as t2
                    on st_intersects(t1.%(polygon_geom_field)s,t2.%(edge_geom_field)s);

                ''' % arg1
        cur.execute(query2)
        edges = cur.fetchall()
        # d_network = nx.DiGraph()
        d_network = DiGraph()
        for e in edges:
            source = e[source_index]
            target = e[target_index]
            cost = e[cost_index]
            reverse_cost = e[reverse_cost_index]
            #if dir == 'B':
            #     d_network.add_edge(source, target)
            #     d_network.add_edge(target, source)
            # if dir == 'FT':
            #     d_network.add_edge(source, target)
            # if dir == 'TF':
            #     d_network.add_edge(target, source)
            if (cost < 10000 and cost > 0):
                d_network.add_edge(source, target)
            if (reverse_cost < 10000 and reverse_cost > 0):
                d_network.add_edge(target, source)
        # [TODO] correct??
        s_n = number_strongly_connected_components(d_network)
        arg1['p'] = s_n
        query_update = '''
                update %(polygon_table)s
                set %(update_field)s = %(p)s
                where %(polygon_id_field)s=%(id)s
                    ''' % arg1
        cur.execute(query_update)
        output_con.commit()
    msg = 'Update %(update_field)s Successfully!\n' % arg1
    return 1, msg
