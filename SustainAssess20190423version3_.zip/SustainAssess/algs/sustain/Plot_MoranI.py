# -*- coding: utf-8 -*-

"""
***************************************************************************
    Plot MoranI.py
    ---------------------
    Date                 : Sep. 7 2018
    Copyright            : (C) 2018 by Qingsong Liu and Mengmeng Liu
    Email                : qliu20 at kent dot edu
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import rpy2
import rpy2.robjects as robjects
import rpy2.rlike.container as rlc

from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsFeatureRequest
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm

from SustainAssess.core.parameters import ParameterBoolean,ParameterFile,ParameterString
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.parameters import ParameterSelection

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
# os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class Plot_MoranI(GeoAlgorithm):

    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_INPUT_FIELD = 'POLY_INPUT_FIELD'  #
    WEIGHT_OBJECT = "WEIGHT_OBJECT"
    # DISPLAY_INFLUENTAIL_VARIABLES = 'DISPLAY_INFLUENTAIL_VARIABLES'
    # DISPLAY_INFLUENTAIL_VARIABLES_OPTIONS = ['TRUE','FALSE']
    CHECK_SCALE = 'CHECK_SCALE'
    MIAN_TITLE = 'MIAN_TITLE' #DEFALUT Moran scatterplot
    SUB_TITLE = 'SUB_TITLE'
    X_LABLE = 'X Axis' #DEFAULT X Axis
    BOUNDING_BOX = 'BOUNDING_BOX'
    BOUNDING_BOX_OPTIONS = ['outline','l-shape','7-shape','c-shape','u-shape',']-shape','none']

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Data Explore/Moran Scatter Plot"
        self.name, self.i18n_name = self.trAlgorithm('Moran Scatter Plot')
        self.group, self.i18n_group = self.trAlgorithm('Plot')
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterTableField(self.POLY_INPUT_FIELD,
                                          self.tr('Input Field'),self.POLY_VECTOR))
        self.addParameter(ParameterFile(self.WEIGHT_OBJECT, self.tr('Weights File'),optional=False,ext='gal'))
        self.addParameter(ParameterBoolean(self.CHECK_SCALE,"Scale the Plot",default=True))
        # self.addParameter(ParameterSelection(self.DISPLAY_INFLUENTAIL_VARIABLES, self.tr('Display influential variables:'),
        #                                      self.DISPLAY_INFLUENTAIL_VARIABLES_OPTIONS, 1))
        self.addParameter(ParameterString(self.MIAN_TITLE,self.tr('Main Title'),default='Morans Scatter Plot'))
        self.addParameter(ParameterString(self.SUB_TITLE, self.tr('Sub Title'), default='',optional=True))
        self.addParameter(ParameterString(self.X_LABLE, self.tr('X Axis Label'), default='',optional=True))

        self.addParameter(ParameterSelection(self.BOUNDING_BOX, self.tr('Bounding Box:'),
                                             self.BOUNDING_BOX_OPTIONS, 0))

    def processAlgorithm(self, progress):
        paramInput = self.getParameterFromName(self.POLY_VECTOR)
        self.m_POLY_VECTOR = paramInput.getLayerObject()
        self.m_POLY_INPUT_FIELD = self.getParameterValue(self.POLY_INPUT_FIELD)

        self.m_WEIGHT_OBJECT = self.getParameterValue(self.WEIGHT_OBJECT)

        self.m_CHECK_SCALE = self.getParameterValue(self.CHECK_SCALE)
        # self.m_DISPLAY_INFLUENTAIL_VARIABLES = \
        #     self.DISPLAY_INFLUENTAIL_VARIABLES_OPTIONS[self.getParameterValue(self.DISPLAY_INFLUENTAIL_VARIABLES)]

        self.m_MIAN_TITLE = self.getParameterValue(self.MIAN_TITLE)
        self.m_SUB_TITLE = self.getParameterValue(self.SUB_TITLE)
        self.m_X_LABLE = self.getParameterValue(self.X_LABLE)
        self.m_BOUNDING_BOX = \
            self.BOUNDING_BOX_OPTIONS[self.getParameterValue(self.BOUNDING_BOX)]

        provider = self.m_POLY_VECTOR.dataProvider()
        sRs = provider.crs()
        projString = str(sRs.toProj4())
        # 2. get r function
        self.init_Rfunc()
        progress.setPercentage(int(25))
        # get id field from gal file
        r_command1 = '''con <- file("%s", open="r")
                        line <- unlist(strsplit(readLines(con, 1), " "))
                        x <- subset(line, nchar(line) > 0)
                        if (length(x) == 1L) {
                          n <- as.integer(x[1])
                          shpfile <- as.character(NA)
                          ind <- as.character(NA)
                        } else if (length(x) == 4L) {
                          n <- as.integer(x[2])
                          shpfile <- as.character(x[3])
                          ind <- as.character(x[4])
                        } else stop ("Invalid header line in GAL file")
                        ind
                        '''%(self.m_WEIGHT_OBJECT)
        res = robjects.r(r_command1)
        id_field = robjects.r("ind")
        id_field = id_field.rx(1)[0]

        req = QgsFeatureRequest()
        req.setFlags(QgsFeatureRequest.NoGeometry)

        feats = self.m_POLY_VECTOR.getFeatures(req)
        count = int(self.m_POLY_VECTOR.featureCount())

        fields = self.m_POLY_VECTOR.fields()
        if fields.count() <= 0:
            raise Exception("Error: Attribute table must have at least one field")
        df = {}
        types = {}
        order = []
        fid = {"fid": []}
        Coords = []
        fields_needed = [id_field,self.m_POLY_INPUT_FIELD]
        for field in fields:
            # initial read in has correct ordering...
            name = str(field.name())
            if name in fields_needed:
                df[name] = []
                types[name] = int(field.type())
                order.append(name)

        for current, feat in enumerate(feats):
            for f in fields_needed:
                val = feat[f]
                if val:
                    df[f].append(feat[f])
                else:
                    if types[f]==10:
                        df[f].append(robjects.NA_Character)
                    else:
                        df[f].append(robjects.NA_Real)
            fid["fid"].append(feat.id())

        progress.setPercentage(int(25))
        tmp = []
        for key in order:
            if types[key] == 10:
                tmp.append((str(key), self.as_character_(robjects.StrVector(df[key]))))
            else:
                tmp.append((str(key), robjects.FloatVector(df[key])))
        try:
            data_frame = rlc.OrdDict(tmp)
        except:
            data_frame = rlc.OrdDict(tmp)

        data_frame = robjects.DataFrame(data_frame)


        robjects.r.assign(str("r_input"), data_frame)
        # version 1
        if self.m_X_LABLE=="":
            self.m_X_LABLE = self.m_POLY_INPUT_FIELD

        arg1 = {"input": "r_input",
                "id_field":id_field,
                "weight_object": self.m_WEIGHT_OBJECT,
                "input_field": self.m_POLY_INPUT_FIELD,
                "main": self.m_MIAN_TITLE,
                "sub": self.m_SUB_TITLE,
                "xlab": self.m_X_LABLE,
                "bty": self.m_BOUNDING_BOX,
                "scale": 'TRUE' if self.m_CHECK_SCALE==True else 'FALSE'
                }
        # r_command = '''saveRDS(r_input,"C:/Users/qliu20/Kent/temp/r_input.rds")'''
        # robjects.r(r_command)
        r_command = '''            
                    require(spdep)
                    input <- %(input)s
                    
                    nb<- read.gal("%(weight_object)s",region.id=input$%(id_field)s,override.id = FALSE)
                    # deal with NA, need to remove corresponding vertex from neighborhood list
                    nalist <- which(is.na(input$%(input_field)s))
                    nb_new = nb
                    
                    n<-length(nb_new)
                    #remove vertex
                    for (ind in nalist) {
                      neighb = nb_new[[ind]]
                      nb_new[[ind]]= as.integer(c(0))
                      for (ind_n in neighb) {
                        nb_new[[ind_n]]<-nb_new[[ind_n]][!nb_new[[ind_n]] %%in%% c(ind)]  
                      }
                    }
                    #make sure that the no neighbor vertex is 0
                    for (i in 1:n) {
                      if(length(nb_new[[i]])==0){
                        nb_new[[i]]=as.integer(c(0))
                      }
                    }
                    
                    style <- 'W'
                    weight = nb2listw(nb_new, glist=NULL, style= style, zero.policy=TRUE)
                    
                    if (n<1) stop("non-positive number of entities")
                    cardnb <- card(weight$neighbours)
                    if (any(is.na(unlist(weight$weights))))
                      stop("NAs in general weights list")
                    
                    m_input<-as.matrix(input$%(input_field)s)
                    a1 = which(!is.na(m_input))
                    
                    local({
                    moran.plot_liu(input$%(input_field)s, weight, zero.policy=TRUE, spChk=FALSE, quiet=TRUE,
                        main='%(main)s', sub='%(sub)s', xlab='%(xlab)s', ylab=paste('Spatially lagged','%(input_field)s'), 
                        bty='%(bty)s', labels=FALSE, scale=%(scale)s)
                    })
 
                ''' % arg1
        
        res = robjects.r(r_command)
        progress.setPercentage(int(100))

    def createSpatialDataset(self, vectType, Coords, data, projString):
        if vectType == 0:
            # For points, coordinates must be input as a matrix, hense the extra bits below...
            # Not sure if this will work for multipoint features?
            spatialData = self.SpatialPoints_(self.matrix_(self.unlist_(Coords), \
                                                           nrow=len(Coords), byrow=True),
                                              proj4string=self.CRS_(projString))
            return self.SpatialPointsDataFrame_(spatialData, data)  # , match_ID = True )
            # kwargs = {'match.ID':"FALSE"}
            # return SpatialPointsDataFrame( spatialData, data, **kwargs )
        elif vectType == 1:
            spatialData = self.SpatialLines_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialLinesDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        elif vectType == 2:
            spatialData = self.SpatialPolygons_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialPolygonsDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        else:
            return ""

    # Helper function to get coordinates of input geometry
    # Does not require knowledge of input geometry type
    # Return: Appends R type geometry to input list
    def getNextGeometry(self, Coords, feat):
        geom = feat.geometry()
        if geom.type() == 0:
            Coords.append(self.getPointCoords(geom, feat.id()))
            return True
        elif geom.type() == 1:
            Coords.append(self.getLineCoords(geom, feat.id()))
            return True
        elif geom.type() == 2:
            Coords.append(self.getPolygonCoords(geom, feat.id()))
            return True
        else:
            return False

    # Function to retrieve QgsGeometry (point) coordinates
    # and convert to a format that can be used by R
    # Return: Item of class Matrix (R class)
    def getPointCoords(self, geom, fid):
        if geom.isMultipart():
            points = geom.asMultiPoint()  # multi_geom is a multipoint
            return [self.convertToXY(point) for point in points]
        else:
            point = geom.asPoint()  # multi_geom is a point
            return self.convertToXY(point)

        # Function to retrieve QgsGeometry (polygon) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Polygons (R class)

    def getPolygonCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            polygon = geom.asMultiPolygon()  # multi_geom is a multipolygon
            for lines in polygon:
                for line in lines:
                    keeps.append(self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                            nrow=len([self.convertToXY(point) for point in line]),
                                                            byrow=True)))
            return self.Polygons_(keeps, fid)
        else:
            lines = geom.asPolygon()  # multi_geom is a polygon
            Polygon = [self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                  nrow=len([self.convertToXY(point) for point in line]), byrow=True))
                       for line in lines]
            return self.Polygons_(Polygon, fid)

        # Function to retrieve QgsGeometry (line) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Lines (R class)

    def getLineCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            lines = geom.asMultiPolyline()  # multi_geom is a multipolyline
            for line in lines:
                for line in lines:
                    keeps.append(self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                         nrow=len([self.convertToXY(point) for point in line]),
                                                         byrow=True)))
            return self.Lines_(keeps, str(fid))
        else:
            line = geom.asPolyline()  # multi_geom is a line
            Line = self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                           nrow=len([self.convertToXY(point) for point in line]), byrow=True))
            return self.Lines_(Line, str(fid))

    def convertToXY(self, inPoint):
        return [inPoint.x(), inPoint.y()]

    def init_Rfunc(self):
        robjects.r("require(%s)" % ("sp"))[0]
        robjects.r("require(%s)" % ("spdep"))[0]
        self.CRS_ = robjects.r.get('CRS', mode='function')
        self.Polygon_ = robjects.r.get('Polygon', mode='function')
        self.Polygons_ = robjects.r.get('Polygons', mode='function')
        self.SpatialPolygons_ = robjects.r.get('SpatialPolygons', mode='function')
        self.Line_ = robjects.r.get('Line', mode='function')
        self.Lines_ = robjects.r.get('Lines', mode='function')
        self.SpatialLines_ = robjects.r.get('SpatialLines', mode='function')
        self.SpatialPoints_ = robjects.r.get('SpatialPoints', mode='function')
        self.SpatialPointsDataFrame_ = robjects.r.get('SpatialPointsDataFrame', mode='function')
        self.SpatialLinesDataFrame_ = robjects.r.get('SpatialLinesDataFrame', mode='function')
        self.SpatialPolygonsDataFrame_ = robjects.r.get('SpatialPolygonsDataFrame', mode='function')

        self.as_character_ = robjects.r.get('as.character', mode='function')
        self.data_frame_ = robjects.r.get('data.frame', mode='function')
        self.matrix_ = robjects.r.get('matrix', mode='function')
        self.unlist_ = robjects.r.get('unlist', mode='function')

        self.poly2nb_ = robjects.r.get('poly2nb', mode='function')
        self.nb2listw_ = robjects.r.get('nb2listw', mode='function')
        # moran.test(x, listw, randomisation=TRUE, zero.policy = NULL,alternative = "greater", rank = FALSE, na.action = na.fail, spChk = NULL, adjust.n = TRUE)
        self.moran_test_ = robjects.r.get('localmoran', mode='function')
        self.dim_ = robjects.r.get('dim',mode='function')
        self.any_ = robjects.r.get('any',mode='function')
        self.is_na_ = robjects.r.get('is.na', mode='function')
        r_fun='''moran.plot_liu <- function(x, listw, zero.policy=NULL, spChk=NULL,
                       labels=NULL, xlab=NULL, ylab=NULL, quiet=NULL, scale=TRUE,...)
                {
                  if (!inherits(listw, "listw")) stop(paste(deparse(substitute(listw)),
                                                            "is not a listw object"))
                  if (is.null(quiet)) quiet <- !get("verbose", envir = .spdepOptions)
                  stopifnot(is.vector(x))
                  stopifnot(is.logical(quiet))
                  if (is.null(zero.policy))
                    zero.policy <- get("zeroPolicy", envir = .spdepOptions)
                  stopifnot(is.logical(zero.policy))
                  xname <- deparse(substitute(x))
                  if (!is.numeric(x)) stop(paste(xname, "is not a numeric vector"))
                  x <- na.omit(x)
                  na.act <- attr(x, "na.action")
                  rn <- attr(listw, "region.id")
                  n_liu <- length(listw$neighbours)
                  if (!is.null(na.act)) {
                    subset <- !(1:length(listw$neighbours) %in% na.act)
                    listw <- subset(listw, subset, zero.policy=zero.policy)
                  }
                  
                   #if (any(is.na(x))) stop("NA in X")
                  n <- length(listw$neighbours)
                  
                  if (n != length(x)) stop("objects of different length")
                  if (is.null(spChk)) spChk <- get.spChkOption()
                  if (spChk && !chkIDs(x, listw))
                    stop("Check of data and weights ID integrity failed")
                  labs <- TRUE
                  if (is.logical(labels) && !labels) labs <- FALSE
                  if (is.null(labels) || length(labels) != n)
                    labels <- as.character(attr(listw, "region.id"))
                  wx <- lag.listw(listw, x, zero.policy=zero.policy,NAOK = TRUE)
                  if (is.null(xlab)) xlab <- xname
                  if (is.null(ylab)) ylab <- paste("spatially lagged", xname)
                  
                  if(scale){ 
                      meanx= mean(x)
                      meanwx = mean(wx)
                      x = x-meanx
                      wx = wx-meanwx
                      rx = range(x)
                      if(sum(rx)>=0){
                        x<- x * 10/rx[2]
                      }else{
                        x<- x * 10/abs(rx[1])
                      }
                      rwx = range(wx)
                      if(sum(rwx)>=0){
                        wx<- wx * 10/rwx[2]
                      }else{
                        wx<- wx * 10/abs(rwx[2])
                      }
                      plot(x, wx, xlab=xlab, ylab=ylab,xlim=c(-10,10),ylim=c(-10,10),...)
                  }else{
                    plot(x, wx, xlab=xlab, ylab=ylab, ...)
                  }
                  # if (zero.policy) {
                  #   n0 <- wx == 0.0
                  #   # bug found 100401 Paulo Grahl
                  #   if (any(n0)) {
                  #     symbols(x[n0], wx[n0], inches=FALSE, 
                  #             circles=rep(diff(range(x))/50, length(which(n0))),
                  #             bg="grey", add=TRUE)
                  #   }
                  # }
                  xwx.lm <- lm(wx ~ x)
                  abline(xwx.lm)
                  abline(h=mean(wx), lty=2)
                  abline(v=mean(x), lty=2)
                  # infl.xwx <- influence.measures(xwx.lm)
                  # is.inf <- which(apply(infl.xwx$is.inf, 1, any))
                  # points(x[is.inf], wx[is.inf], pch=9, cex=1.2)
                  # if (labs)
                  #   text(x[is.inf], wx[is.inf], labels=labels[is.inf], pos=2, cex=0.7)
                  # rownames(infl.xwx$infmat) <- labels
                  # if (!quiet) summary(infl.xwx)
                  # invisible(infl.xwx)
                }'''
        robjects.r(r_fun)