# -*- coding: utf-8 -*-

"""
***************************************************************************
    RandomPointsLayer.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Alexander Bruy
    Email                : alexander dot bruy at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

import rpy2
import rpy2.robjects as robjects
import rpy2.rlike.container as rlc

from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsFeatureRequest
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm

from SustainAssess.core.parameters import ParameterString,ParameterNumber
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.outputs import OutputFile

from SustainAssess.tools.postgis import TableField
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
#os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class Plot_Scatter(GeoAlgorithm):
    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_INPUT_X_FIELD = 'POLY_INPUT_X_FIELD'  #
    POLY_INPUT_Y_FIELD = 'POLY_INPUT_Y_FIELD'  #

    MIAN_TITLE = 'MIAN_TITLE'  # DEFALUT Histogram
    SUB_TITLE = 'SUB_TITLE'
    X_LABLE = 'X Axis'
    Y_LABLE = 'Y Axis'
    BOUNDING_BOX = 'BOUNDING_BOX'
    BOUNDING_BOX_OPTIONS = ['outline','l-shape','7-shape','c-shape','u-shape',']-shape','none']
    X_AXIS_TICKS = 'X_AXIS_TICKS'
    Y_AXIS_TICKS = 'Y_AXIS_TICKS'

    AXIS_LABLES = 'AXIS_LABLES'
    AXIS_LABLES_OPTIONS = ["1","2","3","0"]

    ADD_TRENDLINE = 'ADD_TRENDLINE'
    ADD_TRENDLINE_OPTIONS = ['FALSE','TRUE']

    TRENDLINE_STYLE = 'LINE_STYLE'
    TRENDLINE_STYLE_OPTIONS = ['solid','dashed','dotted','dotdash','longdash','twodash']



    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Data Explore/Scatter Plot"
        self.name, self.i18n_name = self.trAlgorithm('Scatter Plot')
        self.group, self.i18n_group = self.trAlgorithm('Plot')


        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.POLY_INPUT_X_FIELD,
                                          self.tr('Input X Field'),self.POLY_VECTOR))
        self.addParameter(ParameterTableField(self.POLY_INPUT_Y_FIELD,
                                              self.tr('Input Y Field'), self.POLY_VECTOR))
        self.addParameter(ParameterString(self.MIAN_TITLE,self.tr('Main Title'),default='Scatter Plot'))
        self.addParameter(ParameterString(self.SUB_TITLE, self.tr('Sub Title'), default='',optional=True))
        self.addParameter(ParameterString(self.X_LABLE, self.tr('X Axis Label'), default='Default'))
        self.addParameter(ParameterString(self.Y_LABLE, self.tr('Y Axis Label'), default='Default'))

        self.addParameter(ParameterSelection(self.BOUNDING_BOX, self.tr('Bounding Box'),
                                             self.BOUNDING_BOX_OPTIONS, 0))
        self.addParameter(ParameterNumber(self.X_AXIS_TICKS, self.tr('X Axis Ticks'), 1, 20, 5))
        self.addParameter(ParameterNumber(self.Y_AXIS_TICKS, self.tr('Y Axis Ticks'), 1, 20, 5))
        self.addParameter(ParameterSelection(self.AXIS_LABLES, self.tr('Style of Axis Labels'),
                                             self.AXIS_LABLES_OPTIONS, 0))
        self.addParameter(ParameterSelection(self.ADD_TRENDLINE, self.tr('Add Trend Line'),
                                             self.ADD_TRENDLINE_OPTIONS, 0))
        self.addParameter(ParameterSelection(self.TRENDLINE_STYLE, self.tr('Trend Line Style'),
                                             self.TRENDLINE_STYLE_OPTIONS, 0))

    def processAlgorithm(self, progress):
        paramInput = self.getParameterFromName(self.POLY_VECTOR)
        self.m_POLY_VECTOR = paramInput.getLayerObject()
        self.m_POLY_INPUT_X_FIELD = self.getParameterValue(self.POLY_INPUT_X_FIELD)
        self.m_POLY_INPUT_Y_FIELD = self.getParameterValue(self.POLY_INPUT_Y_FIELD)
        request_fields = [self.m_POLY_INPUT_X_FIELD,self.m_POLY_INPUT_Y_FIELD]
        self.m_MIAN_TITLE = self.getParameterValue(self.MIAN_TITLE)
        self.m_SUB_TITLE = self.getParameterValue(self.SUB_TITLE)
        self.m_X_LABLE = self.getParameterValue(self.X_LABLE)
        self.m_Y_LABLE = self.getParameterValue(self.Y_LABLE)

        self.m_BOUNDING_BOX = \
            self.BOUNDING_BOX_OPTIONS[self.getParameterValue(self.BOUNDING_BOX)]

        self.m_X_AXIS_TICKS = self.getParameterValue(self.X_AXIS_TICKS)
        self.m_Y_AXIS_TICKS = self.getParameterValue(self.Y_AXIS_TICKS)

        self.m_AXIS_LABLES = \
            self.AXIS_LABLES_OPTIONS[self.getParameterValue(self.AXIS_LABLES)]

        self.m_ADD_TRENDLINE = \
            self.ADD_TRENDLINE_OPTIONS[self.getParameterValue(self.ADD_TRENDLINE)]
        self.m_TRENDLINE_STYLE = \
            self.TRENDLINE_STYLE_OPTIONS[self.getParameterValue(self.TRENDLINE_STYLE)]

        provider = self.m_POLY_VECTOR.dataProvider()
        sRs = provider.crs()
        projString = str(sRs.toProj4())
        # 2. get r function
        robjects.r("require(%s)" % ("sp"))[0]
        self.CRS_ = robjects.r.get('CRS', mode='function')
        self.Polygon_ = robjects.r.get('Polygon', mode='function')
        self.Polygons_ = robjects.r.get('Polygons', mode='function')
        self.SpatialPolygons_ = robjects.r.get('SpatialPolygons', mode='function')
        self.Line_ = robjects.r.get('Line', mode='function')
        self.Lines_ = robjects.r.get('Lines', mode='function')
        self.SpatialLines_ = robjects.r.get('SpatialLines', mode='function')
        self.SpatialPoints_ = robjects.r.get('SpatialPoints', mode='function')
        self.SpatialPointsDataFrame_ = robjects.r.get('SpatialPointsDataFrame', mode='function')
        self.SpatialLinesDataFrame_ = robjects.r.get('SpatialLinesDataFrame', mode='function')
        self.SpatialPolygonsDataFrame_ = robjects.r.get('SpatialPolygonsDataFrame', mode='function')

        self.as_character_ = robjects.r.get('as.character', mode='function')
        self.data_frame_ = robjects.r.get('data.frame', mode='function')
        self.matrix_ = robjects.r.get('matrix', mode='function')
        self.unlist_ = robjects.r.get('unlist', mode='function')


        progress.setPercentage(int(25))
        req = QgsFeatureRequest()
        req.setFlags(QgsFeatureRequest.NoGeometry)
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_POLY_VECTOR.selectedFeatureCount() > 0:
            feats = self.m_POLY_VECTOR.getSelectedFeatures(req)
            count = int(self.m_POLY_VECTOR.selectedFeatureCount())
        else:
            feats = self.m_POLY_VECTOR.getFeatures(req)
            count = int(self.m_POLY_VECTOR.featureCount())

        fields = self.m_POLY_VECTOR.fields()
        if fields.count() <= 0:
            raise Exception("Error: Attribute table must have at least one field")
        df = {}
        types = {}
        order = []
        fid = {"fid": []}
        Coords = []
        for field in fields:
            # initial read in has correct ordering...
            name = str(field.name())
            if name in request_fields:
                df[name] = []
                types[name] = int(field.type())
                order.append(name)

        for current, feat in enumerate(feats):
            for f in request_fields:
                val = feat[f]
                if val:
                    df[f].append(feat[f])
                else:
                    if types[f] == 10:
                        df[f].append(robjects.NA_Character)
                    else:
                        df[f].append(robjects.NA_Real)
            fid["fid"].append(feat.id())

        progress.setPercentage(int(50))
        tmp = []
        for key in order:
            if types[key] == 10:
                tmp.append((str(key), self.as_character_(robjects.StrVector(df[key]))))
            else:
                tmp.append((str(key), robjects.FloatVector(df[key])))
        try:
            data_frame = rlc.OrdDict(tmp)
        except:
            data_frame = rlc.OrdDict(tmp)

        data_frame = robjects.DataFrame(data_frame)
        #spds = self.createSpatialDataset(feat.geometry().type(), Coords, data_frame, projString)

        robjects.r.assign(str("r_input"), data_frame)
        # r_command = '''saveRDS(r_input,"C:/Users/qliu20/Kent/temp/r_input.rds")'''
        # robjects.r(r_command)
        # version 1
        if self.m_X_LABLE=="Default":
            self.m_X_LABLE = self.m_POLY_VECTOR.name()+"$"+self.m_POLY_INPUT_X_FIELD
        if self.m_Y_LABLE == "Default":
            self.m_Y_LABLE = self.m_POLY_VECTOR.name() + "$" + self.m_POLY_INPUT_Y_FIELD

        arg1 = {"input": "r_input",
                "x":self.m_POLY_INPUT_X_FIELD,
                "y":self.m_POLY_INPUT_Y_FIELD,
                "main": self.m_MIAN_TITLE,
                "sub": self.m_SUB_TITLE,
                "xlab": self.m_X_LABLE,
                "ylab": self.m_Y_LABLE,
                "bty": self.m_BOUNDING_BOX,
                "xticks":str(self.m_X_AXIS_TICKS),
                "yticks": str(self.m_Y_AXIS_TICKS),
                "Axislabels":str(self.m_AXIS_LABLES),
                "addtrend": self.m_ADD_TRENDLINE,
                "trendline_style": self.m_TRENDLINE_STYLE
                }
        r_command = '''
                    input <- %(input)s
                    input <- input[complete.cases(input),]
                    local({
                    plot(x=input$%(x)s, y=input$%(y)s, type='p', main='%(main)s', sub='%(sub)s', xlab='%(xlab)s', 
                    ylab='%(ylab)s', bty='%(bty)s', lab=c(%(xticks)s,%(yticks)s,7), las=%(Axislabels)s)        
                    if (%(addtrend)s) {
                    tmp.fit <- lm(input$%(y)s ~ input$%(x)s)
                    abline(tmp.fit, lty='%(trendline_style)s')
                    }
                    })
                ''' % arg1

        
        res = robjects.r(r_command)
        progress.setPercentage(int(100))

    def createSpatialDataset(self, vectType, Coords, data, projString):
        if vectType == 0:
            # For points, coordinates must be input as a matrix, hense the extra bits below...
            # Not sure if this will work for multipoint features?
            spatialData = self.SpatialPoints_(self.matrix_(self.unlist_(Coords), \
                                                           nrow=len(Coords), byrow=True),
                                              proj4string=self.CRS_(projString))
            return self.SpatialPointsDataFrame_(spatialData, data)  # , match_ID = True )
            # kwargs = {'match.ID':"FALSE"}
            # return SpatialPointsDataFrame( spatialData, data, **kwargs )
        elif vectType == 1:
            spatialData = self.SpatialLines_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialLinesDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        elif vectType == 2:
            spatialData = self.SpatialPolygons_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialPolygonsDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        else:
            return ""

    # Helper function to get coordinates of input geometry
    # Does not require knowledge of input geometry type
    # Return: Appends R type geometry to input list
    def getNextGeometry(self, Coords, feat):
        geom = feat.geometry()
        if geom.type() == 0:
            Coords.append(self.getPointCoords(geom, feat.id()))
            return True
        elif geom.type() == 1:
            Coords.append(self.getLineCoords(geom, feat.id()))
            return True
        elif geom.type() == 2:
            Coords.append(self.getPolygonCoords(geom, feat.id()))
            return True
        else:
            return False

    # Function to retrieve QgsGeometry (point) coordinates
    # and convert to a format that can be used by R
    # Return: Item of class Matrix (R class)
    def getPointCoords(self, geom, fid):
        if geom.isMultipart():
            points = geom.asMultiPoint()  # multi_geom is a multipoint
            return [self.convertToXY(point) for point in points]
        else:
            point = geom.asPoint()  # multi_geom is a point
            return self.convertToXY(point)

        # Function to retrieve QgsGeometry (polygon) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Polygons (R class)

    def getPolygonCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            polygon = geom.asMultiPolygon()  # multi_geom is a multipolygon
            for lines in polygon:
                for line in lines:
                    keeps.append(self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                            nrow=len([self.convertToXY(point) for point in line]),
                                                            byrow=True)))
            return self.Polygons_(keeps, fid)
        else:
            lines = geom.asPolygon()  # multi_geom is a polygon
            Polygon = [self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                  nrow=len([self.convertToXY(point) for point in line]), byrow=True))
                       for line in lines]
            return self.Polygons_(Polygon, fid)

        # Function to retrieve QgsGeometry (line) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Lines (R class)

    def getLineCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            lines = geom.asMultiPolyline()  # multi_geom is a multipolyline
            for line in lines:
                for line in lines:
                    keeps.append(self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                         nrow=len([self.convertToXY(point) for point in line]),
                                                         byrow=True)))
            return self.Lines_(keeps, str(fid))
        else:
            line = geom.asPolyline()  # multi_geom is a line
            Line = self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                           nrow=len([self.convertToXY(point) for point in line]), byrow=True))
            return self.Lines_(Line, str(fid))

    def convertToXY(self, inPoint):
        return [inPoint.x(), inPoint.y()]

