# -*- coding: utf-8 -*-
__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsField, QgsSpatialIndex,QgsGeometry,QgsFeature,QgsFields,QgsDistanceArea,
                       QgsFeature, QgsFeatureRequest,QgsFeatureIterator,NULL)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterTableField,ParameterCreateField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from igraph import Graph
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
import time
pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

class PathCount(GeoAlgorithm):
    OD_PAIRS = 'OD_PAIRS'
    OD_WEIGHT = 'OD_WEIGHT'
    RD_EDGE_LAYER = 'RD_EDGE_LAYER'
    #RD_EDGE_LAYER_WEIGHT = 'RD_EDGE_LAYER_WEIGHT'

    RD_EDGE_LAYER_SOURCE_FIELD = 'RD_EDGE_LAYER_SOURCE_FIELD'
    RD_EDGE_LAYER_TARGET_FIELD = 'RD_EDGE_LAYER_TARGET_FIELD'

    RD_EDGE_LAYER_COST_FIELD = 'RD_EDGE_LAYER_COST_FIELD'
    RD_EDGE_LAYER_REVERSE_COST_FIELD = 'RD_EDGE_LAYER_REVERSE_COST_FIELD'
    RD_EDGE_LAYER_COST_UNIT_FIELD = 'RD_EDGE_LAYER_COST_UNIT_FIELD'
    # RD_EDGE_LAYER_COST_UNIT_FIELD_OPTIONS = ['HOUR','MINUTE',"SECOND"]

    OUTPUT_FIELD_RD_EDGE_FT = 'OUTPUT_FIELD_RD_EDGE_FT'

    OUTPUT_FIELD_OD_PAIRS_LEN = 'OUTPUT_FIELD_OD_PAIRS_LEN'
    OUTPUT_FIELD_OD_PAIRS_TIME = 'OUTPUT_FIELD_OD_PAIRS_TIME'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/PathCount"
        self.name, self.i18n_name = self.trAlgorithm('PathCount')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')
        self.precision = 20

        self.addParameter(ParameterVector_RDBMS(self.OD_PAIRS,
                                                self.tr('Origin-Destination(OD) Pairs Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_LINE]))
        self.addParameter(ParameterTableField(self.OD_WEIGHT,
                                          self.tr('Origin-Destination(OD) Pairs Weight'),self.OD_PAIRS,defalut="weight"))

        self.addParameter(ParameterVector_RDBMS(self.RD_EDGE_LAYER,
                                                self.tr('Road Layer'), [ParameterVector_RDBMS.VECTOR_ROAD_NETWORK]))

        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_SOURCE_FIELD,
                                          self.tr('Source Field in Road Layer'),self.RD_EDGE_LAYER,defalut="source"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_TARGET_FIELD,
                                          self.tr('Target Field in Road Layer'),self.RD_EDGE_LAYER,defalut="target"))

        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_COST_FIELD,
                                          self.tr('Cost Field in Road Layer'),self.RD_EDGE_LAYER,defalut="cost"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_REVERSE_COST_FIELD,
                                          self.tr('Reverse Cost Field in Road Layer'),self.RD_EDGE_LAYER,defalut="reverse_cost"))

        self.addParameter(ParameterCreateField(self.OUTPUT_FIELD_RD_EDGE_FT,self.tr('Outupt: PathCount Field Name in Road Layer'),
                                self.RD_EDGE_LAYER))

        self.addParameter(ParameterCreateField(self.OUTPUT_FIELD_OD_PAIRS_LEN,self.tr('Outupt: Accumulated Length Field Name in OD Layer'),
                                self.OD_PAIRS,optional=True))
        self.addParameter(ParameterCreateField(self.OUTPUT_FIELD_OD_PAIRS_TIME,self.tr('Outupt: Accumulated Cost Field Name in OD Layer'),
                                self.OD_PAIRS,optional=True))

        # self.addParameter(ParameterBoolean_Group(self.CHECK_OUTPUT_AS_LAYER,
        #                                self.tr('Create New Layer'),
        #                                          [self.OUTPUT_LAYER],False))
        # self.addOutput(OutputVector(self.OUTPUT_LAYER, self.tr('New Road Layer')))

    def processAlgorithm(self, progress):
        self.progress = progress
        odpair_param = self.getParameterFromName(self.OD_PAIRS)
        self.m_OD_PAIRS = odpair_param.getLayerObject()
        self.m_OD_WEIGHT = self.getParameterValue(self.OD_WEIGHT)

        # road network data
        rdedge_param = self.getParameterFromName(self.RD_EDGE_LAYER)
        self.m_RD_EDGE_LAYER = rdedge_param.getLayerObject()

        self.m_RD_EDGE_LAYER_SOURCE_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_SOURCE_FIELD)
        self.m_RD_EDGE_LAYER_TARGET_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_TARGET_FIELD)
        self.m_RD_EDGE_LAYER_COST_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_COST_FIELD)
        self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_REVERSE_COST_FIELD)
        # output fields information
        self.m_OUTPUT_FIELD_RD_EDGE_FT = self.getParameterValue(self.OUTPUT_FIELD_RD_EDGE_FT)
        self.m_OUTPUT_FIELD_OD_PAIRS_LEN = self.getParameterValue(self.OUTPUT_FIELD_OD_PAIRS_LEN)
        self.m_OUTPUT_FIELD_OD_PAIRS_TIME = self.getParameterValue(self.OUTPUT_FIELD_OD_PAIRS_TIME)

        #default_speed = {['HOUR':,'MINUTE':,"SECOND":}
        if (self.m_OUTPUT_FIELD_OD_PAIRS_LEN and not self.m_OUTPUT_FIELD_OD_PAIRS_TIME) or \
            (not self.m_OUTPUT_FIELD_OD_PAIRS_LEN and self.m_OUTPUT_FIELD_OD_PAIRS_TIME):
            # QMessageBox.critical(None, ("Fields Setting"),
            #                      ("Must set both Accumulation Length Field and Accumulation Time Field if one of them is specified!"))
            # return
            msg = "Must set both Accumulated Length Field and Accumulated Time Field if one of them is specified!"
            raise GeoAlgorithmExecutionException(msg)
        set_len_time = False
        if self.m_OUTPUT_FIELD_OD_PAIRS_LEN and self.m_OUTPUT_FIELD_OD_PAIRS_TIME:
            set_len_time = True

        # start: 1.read network into memory; 2.construct the diagraph; 3. count the pass number=========================
        #--------1.read network into memory;---------------------
        rd_feats = self.m_RD_EDGE_LAYER.getFeatures()
        count = int(self.m_RD_EDGE_LAYER.featureCount())
        #--------2.construct the diagraph;----------------
        start_time = time.time()
        bt = {} # results: {(node1,node2):count,.....}
        leng_dt = {}  # road network each edge length {(node1,node2):[length,time],(node3,node4):[length,time],......}

        od_pairs_expand_map = {} # 30,000 --> 850,000 {(source,target):[id1,id2,id3,...]}
        od_pairs_map = {}  # 850,000's length  {id1:[length,time],id2:[length,time],...}

        edges=[]
        g_points_index = QgsSpatialIndex()
        g_points_index_feats = {}     # id->point
        pointset = set()
        # feats_list = {} # feat_id-->node
        # fid = 0
        da = QgsDistanceArea()
        da.setSourceCrs(self.m_RD_EDGE_LAYER.crs().srsid())

        for current, feat in enumerate(rd_feats):
            node1 = feat[self.m_RD_EDGE_LAYER_SOURCE_FIELD]
            node2 = feat[self.m_RD_EDGE_LAYER_TARGET_FIELD]
            cost = feat[self.m_RD_EDGE_LAYER_COST_FIELD]
            re_cost = feat[self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD]
            fGeom = QgsGeometry(feat.geometry()).asPolyline()
            dis = da.measureLength(feat.geometry())
            if node1 not in pointset:
                fs = QgsFields()
                #fs.append(QgsField('id', QVariant.LongLong))
                pFeat = QgsFeature(fs,node1)
                #pFeat['id'] = node1
                pFeat.setGeometry(QgsGeometry.fromPointXY(fGeom[0]))
                g_points_index.insertFeature(pFeat)
                g_points_index_feats[node1] = fGeom[0]
                pointset.add(node1)
                # feats_list[fid] = node1
                # fid+=1
            if node2 not in pointset:
                fs = QgsFields()
                #fs.append(QgsField('id', QVariant.LongLong))
                pFeat = QgsFeature(fs,node2)
                #pFeat['id'] = node2
                pFeat.setGeometry(QgsGeometry.fromPointXY(fGeom[-1]))
                g_points_index.insertFeature(pFeat)
                g_points_index_feats[node2] = fGeom[-1]
                pointset.add(node2)
                # feats_list[fid] = node2
                # fid+=1

            # test whether node1 and node2 in the vertexs
            if cost !=NULL and (cost > 0 and cost < 9999):
                edges.append({"source":node1,"target":node2,"weight":cost})
                bt[(node1,node2)]=0
                leng_dt[(node1,node2)] = [dis,cost]
            if re_cost !=NULL and (re_cost > 0 and re_cost < 9999):
                edges.append({"source": node2, "target": node1, "weight": re_cost})
                bt[(node2, node1)] = 0
                leng_dt[(node2, node1)] = [dis,re_cost]
        progress.setPercentage(int(1))
        end_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "Create Road Network Spatial Index:%s\n" % (str(end_time - start_time)))

        start_time = time.time()

        g = Graph.DictList({}, edges,directed=True)
        p_dict = {} #Source ID(Target ID) --> graph_id(start from 0)
        for i in range(g.vcount()):
            v_t = g.vs[i]["name"]
            p_dict[v_t] = i

        ##============3. read OD pairs=======================
        # select_ids = None
        # od_feats = self.m_OD_PAIRS.getFeatures()
        # count_od = int(self.m_OD_PAIRS.featureCount())
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_OD_PAIRS.selectedFeatureCount() > 0:
            # select_ids = set(self.m_OD_PAIRS.selectedFeaturesIds())
            feats = self.m_OD_PAIRS.getSelectedFeatures()
            count_od = int(self.m_OD_PAIRS.selectedFeatureCount())
        else:
            feats = self.m_OD_PAIRS.getFeatures()
            count_od = int(self.m_OD_PAIRS.featureCount())
        start_time = time.time()
        s_t_dict = {} # reduced source,target pairs{source1:[target1,target2,target3,...],source2:[target1,target2,target3,...],....}
        s_t_w_dict = {} # reduced pairs weight     {source1:[weight1,weight2,weight3,...],source2:[weight1,weight2,weight3,...],....}
        pointset = set() # unique source
        for current, feat in enumerate(feats):
            od_id = feat.id()
            segments=[]
            t_geom = QgsGeometry(feat.geometry())
            if t_geom.isMultipart():
                multi = t_geom.asMultiPolyline()
                for polyline in multi:
                    segments.append(polyline)
            else:
                line = t_geom.asPolyline()
                segments.append(line)
            for fGeom in segments:
                od_w = feat[self.m_OD_WEIGHT]

                od_pairs_map[od_id]=[0.0,0.0]
                try:
                    nearestIds = g_points_index.nearestNeighbor(fGeom[0],1)
                    source_id = nearestIds[0]
                except:
                    ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "NULL geom:%s\n" % (str(feat["id"])))
                    continue

                if source_id not in pointset:
                    pointset.add(source_id)
                    s_t_dict[source_id]=[]
                    s_t_w_dict[source_id]=[]
                nearestIds = g_points_index.nearestNeighbor(fGeom[-1],1)
                target_id = nearestIds[0]

                if target_id not in s_t_dict[source_id]:
                    s_t_dict[source_id].append(target_id)
                    s_t_w_dict[source_id].append(od_w)
                    od_pairs_expand_map[(source_id,target_id)]=[od_id]
                else:
                    t_ind = s_t_dict[source_id].index(target_id)
                    s_t_w_dict[source_id][t_ind]+=od_w
                    od_pairs_expand_map[(source_id, target_id)].append(od_id)

        end_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "Aggregate OD pairs:%s\n" % (str(end_time - start_time)))
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "OD features:%s\n" % (str(count_od)))
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "pairs:%s\n" % (str(len(pointset))))

        start_time1000=time.time()
        timeind = 0
        count_pset = len(pointset)
        for s_ in pointset:
            source_gid = p_dict[s_]
            target_gids = [p_dict[t] for t in s_t_dict[s_]]
            od_ws = s_t_w_dict[s_]
            # start_time = time.time()
            res = g.get_shortest_paths(source_gid,target_gids,"weight","OUT","vpath")
            # end_time = time.time()
            # ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "1 shortest laps:%s\n" % (str(end_time - start_time)))
            # start_time = time.time()

            for res_ind in range(len(res)):
                t_dis = 0.0
                t_time = 0.0
                res_one = res[res_ind]
                res_ind_target = s_t_dict[s_][res_ind]
                od_w = od_ws[res_ind]
                for ind in range(len(res_one)-1):
                    #g.es.find(_between=((res_one[ind],), (res_one[ind+1],)))["count"]+=1*od_w # 1000 laps: 4948
                    ind_node1 = g.vs[res_one[ind]]["name"]
                    ind_node2 = g.vs[res_one[ind+1]]["name"]
                    bt[(ind_node1,ind_node2)]+=od_w # 1000 laps: 103
                    t_dis+=leng_dt[(ind_node1,ind_node2)][0]
                    t_time+=leng_dt[(ind_node1,ind_node2)][1]
                t_len = len(od_pairs_expand_map[(s_,res_ind_target)])
                for i_ in range(t_len):
                    t_id = od_pairs_expand_map[(s_,res_ind_target)][i_]
                    od_pairs_map[t_id][0] += t_dis
                    od_pairs_map[t_id][1] += t_time
            timeind+=1
            # end_time = time.time()
            # ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "1 agg laps:%s\n" % (str(end_time - start_time)))
            if timeind%1000==0:
                end_time1000 = time.time()
                ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "1000 laps:%s\n" % (str(end_time1000 - start_time1000)))
                start_time1000 = time.time()
                progress.setPercentage(int(1 + timeind * 49.0 / count_pset))
        progress.setPercentage(int(50))

        end_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "End Calculation laps:%s\n" % (str(end_time - start_time)))
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "Start to write results\n")
        # end: 1.read network into memory; 2.construct the diagraph; 3. compute betweenness index=======================
        ################################################################################################################
        #### Add fields in Road layer and populate the results
        ################################################################################################################
        # add field to the ROAD NETWORK LAYER
        if not self.m_RD_EDGE_LAYER.isEditable():
            self.m_RD_EDGE_LAYER.startEditing()
        # start: create new field =======================================================================================
        field_name = self.m_OUTPUT_FIELD_RD_EDGE_FT
        self.m_RD_EDGE_LAYER.beginEditCommand("Added attribute")
        # [TODO] if shapefile, the fieldname must less than 13 characters.
        # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
        field = QgsField(field_name, QVariant.Double, 'numeric(20,10)', 20,
                         10)  # [TODO] rdedge_param.datasource, postgres, spatialite,file different command
        field_reverse = QgsField(field_name + '_re', QVariant.Double, 'numeric(20,10)', 20, 10)
        mAttributeId = -1
        mAttributeId_re = -1
        if (not self.m_RD_EDGE_LAYER.addAttribute(field)):
            # failed to add new fields, may be already exists
            # check whether exists
            # try to get the index of the new field
            fields = self.m_RD_EDGE_LAYER.fields()
            for indx in range(fields.count()):
                #print fields[indx].name()
                if fields[indx].name() == field_name:
                    mAttributeId = indx
                    break
            if mAttributeId == -1:
                # not exists, and add failed
                self.m_RD_EDGE_LAYER.destroyEditCommand()
                QMessageBox.critical(None, ("Failed to add field"),
                                     ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                         field.name(),
                                         field.typeName())))
                return
        if (not self.m_RD_EDGE_LAYER.addAttribute(field_reverse)):
            # failed to add new fields, may be already exists
            # check whether exists
            # try to get the index of the new field
            fields = self.m_RD_EDGE_LAYER.fields()
            for indx in range(fields.count()):
                #print fields[indx].name()
                if fields[indx].name() == field_name:
                    mAttributeId_re = indx
                    break
            if mAttributeId_re == -1:
                # not exists, and add failed
                self.m_RD_EDGE_LAYER.destroyEditCommand()
                QMessageBox.critical(None, ("Failed to add field"),
                                     ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                         field.name(),
                                         field.typeName())))
                return
        if mAttributeId == -1 or mAttributeId_re == -1:
            # add sucess, get index of the new field
            fields = self.m_RD_EDGE_LAYER.fields()
            for indx in range(fields.count()):
                #print fields[indx].name()
                if fields[indx].name() == field_name:
                    mAttributeId = indx
                if fields[indx].name() == field_name + '_re':
                    mAttributeId_re = indx
                if mAttributeId != -1 and mAttributeId_re != -1:
                    break
        if mAttributeId == -1 or mAttributeId_re == -1:
            self.m_RD_EDGE_LAYER.destroyEditCommand()
            QMessageBox.critical(None, ("Failed to add field"),
                                 ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                     field.name(),
                                     field.typeName())))
            return

        #start: write results===========================================================================================
        ## write the results to the fields in RD_EDGE_LAYER------------
        # update value with new fields
        start_time = time.time()
        request = QgsFeatureRequest()
        request.setFlags(QgsFeatureRequest.NoGeometry)
        # is only update select features
        # request.setFilterFids( layer.selectedFeaturesIds() )
        fit = QgsFeatureIterator(self.m_RD_EDGE_LAYER.getFeatures(request))  # fit:QgsFeatureIterator
        feat = QgsFeature()
        rownum = 0
        while (fit.nextFeature(feat)):
            # self.m_RD_EDGE_LAYER.changeAttributeValue(feat.id(), mAttributeId, 0.0)
            # self.m_RD_EDGE_LAYER.changeAttributeValue(feat.id(), mAttributeId_re, 0.0)
            source = feat[self.m_RD_EDGE_LAYER_SOURCE_FIELD]
            target = feat[self.m_RD_EDGE_LAYER_TARGET_FIELD]
            cost = feat[self.m_RD_EDGE_LAYER_COST_FIELD]
            re_cost = feat[self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD]

            if cost !=NULL and (cost > 0 and cost < 9999):
                value = bt[(source,target)]
                field.convertCompatible(value)
                if value>0:
                    self.m_RD_EDGE_LAYER.changeAttributeValue(feat.id(), mAttributeId, value)
            if re_cost !=NULL and (re_cost > 0 and re_cost < 9999):
                value = bt[(target, source)]
                field_reverse.convertCompatible(value)
                if value>0:
                    self.m_RD_EDGE_LAYER.changeAttributeValue(feat.id(), mAttributeId_re, value)
            rownum += 1
            if rownum%1000==0:
                progress.setPercentage(int(50 + rownum * 5.0 / count))
        self.m_RD_EDGE_LAYER.endEditCommand()
        modify = self.m_RD_EDGE_LAYER.isModified()
        if modify:
            suc = self.m_RD_EDGE_LAYER.commitChanges()
            if not suc:
                errors = self.m_RD_EDGE_LAYER.commitErrors()
                msg = ''
                for err in errors:
                    msg+=str(err)+"\n"
                ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM,msg)
                QMessageBox.critical(None, ("Failed to update Edge Table"),
                                     ("Failed to update Edge Table,Please check the processing.log for more details." ))
                return
        progress.setPercentage(int(75))
        end_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "End Write Road Layer laps:%s\n" % (str(end_time - start_time)))
        ################################################################################################################
        #### Add fields in OD layer and populate the result
        ################################################################################################################

        if not set_len_time:
            progress.setPercentage(int(100))
            ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM,
                                   "End PathCount!" )
            return
        # add field to the ROAD NETWORK LAYER
        if not self.m_OD_PAIRS.isEditable():
            self.m_OD_PAIRS.startEditing()

        field_len_name = self.m_OUTPUT_FIELD_OD_PAIRS_LEN
        field_time_name = self.m_OUTPUT_FIELD_OD_PAIRS_TIME
        self.m_OD_PAIRS.beginEditCommand("Added attribute")
        # [TODO] if shapefile, the fieldname must less than 13 characters.
        # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
        field_len = QgsField(field_len_name, QVariant.Double, 'numeric(20,10)', 20,
                         10)  # [TODO] rdedge_param.datasource, postgres, spatialite,file different command
        field_time = QgsField(field_time_name, QVariant.Double, 'numeric(20,10)', 20, 10)
        mAtt_len_Id = -1
        mAttr_time_Id = -1
        if (not self.m_OD_PAIRS.addAttribute(field_len)):
            # failed to add new fields, may be already exists
            # check whether exists
            # try to get the index of the new field
            fields = self.m_OD_PAIRS.fields()
            for indx in range(fields.count()):
                #print fields[indx].name()
                if fields[indx].name() == field_len_name:
                    mAtt_len_Id = indx
                    break
            if mAtt_len_Id == -1:
                # not exists, and add failed
                self.m_OD_PAIRS.destroyEditCommand()
                QMessageBox.critical(None, ("Failed to add field"),
                                     ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                         field_len.name(),
                                         field_len.typeName())))
                return
        if (not self.m_OD_PAIRS.addAttribute(field_time)):
            # failed to add new fields, may be already exists
            # check whether exists
            # try to get the index of the new field
            fields = self.m_OD_PAIRS.fields()
            for indx in range(fields.count()):
                #print fields[indx].name()
                if fields[indx].name() == field_time_name:
                    mAttr_time_Id = indx
                    break
            if mAttr_time_Id == -1:
                # not exists, and add failed
                self.m_OD_PAIRS.destroyEditCommand()
                QMessageBox.critical(None, ("Failed to add field"),
                                     ("Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                                         field_time.name(),
                                         field_time.typeName())))
                return
        if mAtt_len_Id == -1 or mAttr_time_Id == -1:
            # add sucess, get index of the new field
            fields = self.m_OD_PAIRS.fields()
            for indx in range(fields.count()):
                #print fields[indx].name()
                if fields[indx].name() == field_len_name:
                    mAtt_len_Id = indx
                if fields[indx].name() == field_time_name:
                    mAttr_time_Id = indx
                if mAtt_len_Id != -1 and mAttr_time_Id != -1:
                    break
        if mAtt_len_Id == -1 or mAttr_time_Id == -1:
            self.m_OD_PAIRS.destroyEditCommand()
            QMessageBox.critical(None, ("Failed to add field"),
                                 ("Failed to add field in Layer %s" % (self.m_OD_PAIRS.name())))
            return

        # start: write results===========================================================================================
        ## write the results to the fields in RD_EDGE_LAYER------------
        # update value with new fields
        start_time = time.time()
        request = QgsFeatureRequest()
        request.setFlags(QgsFeatureRequest.NoGeometry)
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_OD_PAIRS.selectedFeatureCount(request) > 0:
            od_feats = self.m_OD_PAIRS.getSelectedFeatures()
            count_od = int(self.m_OD_PAIRS.selectedFeatureCount())
        else:
            od_feats = self.m_OD_PAIRS.getFeatures(request)
            count_od = int(self.m_OD_PAIRS.featureCount())
        rownum = 0
        for current, feat in enumerate(od_feats):
            od_id = feat.id()
            value = od_pairs_map[od_id][0]
            field_len.convertCompatible(value)
            self.m_OD_PAIRS.changeAttributeValue(od_id, mAtt_len_Id, value)
            value = od_pairs_map[od_id][1]
            field_time.convertCompatible(value)
            self.m_OD_PAIRS.changeAttributeValue(od_id, mAttr_time_Id, value)
            rownum += 1
            if rownum % 1000 == 0:
                progress.setPercentage(int(75 + rownum * 5.0 / count_od))
                ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM,
                                       "test value:%s\n" % (str(value)))
                ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM,
                                       "Iterater OD:%s\n" % (str(rownum)))
        self.m_OD_PAIRS.endEditCommand()
        modify = self.m_OD_PAIRS.isModified()
        if modify:
            suc = self.m_OD_PAIRS.commitChanges()
            if not suc:
                errors = self.m_OD_PAIRS.commitErrors()
                msg = ''
                for err in errors:
                    msg += str(err) + "\n"
                ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, msg)
                QMessageBox.critical(None, ("Failed to update OD Layer"),
                                     ("Failed to update OD Layere,Please check the processing.log for more details."))
                return


        end_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "End writing OD Layers laps:%s\n" % (str(end_time - start_time)))
        ## write the results to a new layer--------------------
        # if self.m_CHECK_OUTPUT_AS_LAYER:
        #     #[TODO]write new output layer, only have attribute [id,bt,geom] according to zone layer
        #     pass
        # end: write results============================================================================================
        progress.setPercentage(int(100))
        # End Processing