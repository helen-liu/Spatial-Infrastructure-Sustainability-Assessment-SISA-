# -*- coding: utf-8 -*-

"""
***************************************************************************
    Plot_Histogram.py
    ---------------------
    Date                 : Jan 2019
    Copyright            : Mengmeng Liu and Qingsong Liu'
    Email                : qliu20@kent.edu
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

import rpy2
import rpy2.robjects as robjects
import rpy2.rlike.container as rlc

from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsFeatureRequest
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm

from SustainAssess.core.parameters import ParameterString,ParameterFile
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.outputs import OutputFile

from SustainAssess.tools.postgis import TableField
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
# os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class Plot_Histogram(GeoAlgorithm):
    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_INPUT_FIELD = 'POLY_INPUT_FIELD'  #

    BREAK_CALCULATION = "BREAK_CALCULATION"
    BREAK_CALCULATION_OPTIONS = ["Sturges","Scott","Freedman-Diaconis"]

    PLOT_TYPE = 'PLOT_TYPE'
    PLOT_TYPE_OPTIONS = ["Frequency", "Density"]
    MIAN_TITLE = 'MIAN_TITLE' #DEFALUT Histogram
    SUB_TITLE = 'SUB_TITLE'
    X_LABLE = 'X Axis'
    # BOUNDING_BOX = 'BOUNDING_BOX'
    # BOUNDING_BOX_OPTIONS = ['outline','l-shape','7-shape','c-shape','u-shape',']-shape','none']

    ADD_PROBABILITY_DISTRIBUTION = 'ADD_PROBABILITY_DISTRIBUTION'
    ADD_PROBABILITY_DISTRIBUTION_OPTIONS = ['FALSE','TRUE']

    LINE_STYLE = 'LINE_STYLE'
    LINE_STYLE_OPTIONS = ['solid','dashed','dotted','dotdash','longdash','twodash']

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Data Explore/Histogram"
        self.name, self.i18n_name = self.trAlgorithm('Histogram')
        self.group, self.i18n_group = self.trAlgorithm('Plot')

        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.POLY_INPUT_FIELD,
                                          self.tr('Input Field'),self.POLY_VECTOR))
        self.addParameter(ParameterSelection(self.BREAK_CALCULATION, self.tr('Break Calculation:'),
                                             self.BREAK_CALCULATION_OPTIONS, 0))
        self.addParameter(ParameterSelection(self.PLOT_TYPE, self.tr('Plot Type'), self.PLOT_TYPE_OPTIONS, 0))
        self.addParameter(ParameterString(self.MIAN_TITLE,self.tr('Main Title'),default='Histogram'))
        self.addParameter(ParameterString(self.SUB_TITLE, self.tr('Sub Title'), default='',optional=True))
        self.addParameter(ParameterString(self.X_LABLE, self.tr('X Axis Label'), default='',optional=True))

        # self.addParameter(ParameterSelection(self.BOUNDING_BOX, self.tr('Bounding Box'),
        #                                      self.BOUNDING_BOX_OPTIONS, 0))
        self.addParameter(ParameterSelection(self.ADD_PROBABILITY_DISTRIBUTION, self.tr('Add Probability Distribution'),
                                             self.ADD_PROBABILITY_DISTRIBUTION_OPTIONS, 0))
        self.addParameter(ParameterSelection(self.LINE_STYLE, self.tr('Line Style'),
                                             self.LINE_STYLE_OPTIONS, 0))
        # self.addParameter(ParameterString(self.ADDITIONAL_PARAMETER, self.tr('Additional Parameter:'), default='',
        #                                   optional=True))

    def processAlgorithm(self, progress):

        paramInput = self.getParameterFromName(self.POLY_VECTOR)
        self.m_POLY_VECTOR = paramInput.getLayerObject()
        self.m_POLY_INPUT_FIELD = self.getParameterValue(self.POLY_INPUT_FIELD)
        self.m_BREAK_CALCULATION = \
            self.BREAK_CALCULATION_OPTIONS[self.getParameterValue(self.BREAK_CALCULATION)]
        self.m_PLOT_TYPE = self.PLOT_TYPE_OPTIONS[self.getParameterValue(self.PLOT_TYPE)]

        self.m_MIAN_TITLE = self.getParameterValue(self.MIAN_TITLE)
        self.m_SUB_TITLE = self.getParameterValue(self.SUB_TITLE)
        self.m_X_LABLE = self.getParameterValue(self.X_LABLE)
        # self.m_BOUNDING_BOX = \
        #     self.BOUNDING_BOX_OPTIONS[self.getParameterValue(self.BOUNDING_BOX)]
        self.m_ADD_PROBABILITY_DISTRIBUTION = \
            self.ADD_PROBABILITY_DISTRIBUTION_OPTIONS[self.getParameterValue(self.ADD_PROBABILITY_DISTRIBUTION)]
        self.m_LINE_STYLE = \
            self.LINE_STYLE_OPTIONS[self.getParameterValue(self.LINE_STYLE)]

        # self.m_ADDITIONAL_PARAMETER = self.getParameterValue(self.ADDITIONAL_PARAMETER)

        provider = self.m_POLY_VECTOR.dataProvider()
        sRs = provider.crs()
        projString = str(sRs.toProj4())
        # 2. get r function
        robjects.r("require(%s)" % ("sp"))[0]
        robjects.r("require(%s)" % ("spdep"))[0]
        self.CRS_ = robjects.r.get('CRS', mode='function')
        self.Polygon_ = robjects.r.get('Polygon', mode='function')
        self.Polygons_ = robjects.r.get('Polygons', mode='function')
        self.SpatialPolygons_ = robjects.r.get('SpatialPolygons', mode='function')
        self.Line_ = robjects.r.get('Line', mode='function')
        self.Lines_ = robjects.r.get('Lines', mode='function')
        self.SpatialLines_ = robjects.r.get('SpatialLines', mode='function')
        self.SpatialPoints_ = robjects.r.get('SpatialPoints', mode='function')
        self.SpatialPointsDataFrame_ = robjects.r.get('SpatialPointsDataFrame', mode='function')
        self.SpatialLinesDataFrame_ = robjects.r.get('SpatialLinesDataFrame', mode='function')
        self.SpatialPolygonsDataFrame_ = robjects.r.get('SpatialPolygonsDataFrame', mode='function')

        self.as_character_ = robjects.r.get('as.character', mode='function')
        self.data_frame_ = robjects.r.get('data.frame', mode='function')
        self.matrix_ = robjects.r.get('matrix', mode='function')
        self.unlist_ = robjects.r.get('unlist', mode='function')

        self.poly2nb_ = robjects.r.get('poly2nb', mode='function')
        self.nb2listw_ = robjects.r.get('nb2listw', mode='function')
        # moran.test(x, listw, randomisation=TRUE, zero.policy = NULL,alternative = "greater", rank = FALSE, na.action = na.fail, spChk = NULL, adjust.n = TRUE)
        self.moran_test_ = robjects.r.get('moran.test', mode='function')

        progress.setPercentage(int(25))
        req = QgsFeatureRequest()
        req.setFlags(QgsFeatureRequest.NoGeometry)
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_POLY_VECTOR.selectedFeatureCount() > 0:
            feats = self.m_POLY_VECTOR.getSelectedFeatures(req)
            count = int(self.m_POLY_VECTOR.selectedFeatureCount())
        else:
            feats = self.m_POLY_VECTOR.getFeatures(req)
            count = int(self.m_POLY_VECTOR.featureCount())

        fields = self.m_POLY_VECTOR.fields()
        if fields.count() <= 0:
            raise Exception("Error: Attribute table must have at least one field")
        df = {}
        types = {}
        order = []
        fid = {"fid": []}
        Coords = []
        for field in fields:
            # initial read in has correct ordering...
            name = str(field.name())
            if name==self.m_POLY_INPUT_FIELD:
                df[name] = []
                types[name] = int(field.type())
                order.append(name)

        for current, feat in enumerate(feats):
            val = feat[self.m_POLY_INPUT_FIELD]
            if val:
                df[self.m_POLY_INPUT_FIELD].append(feat[self.m_POLY_INPUT_FIELD])
            else:
                if types[self.m_POLY_INPUT_FIELD] == 10:
                    df[self.m_POLY_INPUT_FIELD].append(robjects.NA_Character)
                else:
                    df[self.m_POLY_INPUT_FIELD].append(robjects.NA_Real)
            fid["fid"].append(feat.id())

        progress.setPercentage(int(50))
        tmp = []
        for key in order:
            if types[key] == 10:
                tmp.append((str(key), self.as_character_(robjects.StrVector(df[key]))))
            else:
                tmp.append((str(key), robjects.FloatVector(df[key])))
        try:
            data_frame = rlc.OrdDict(tmp)
        except:
            data_frame = rlc.OrdDict(tmp)

        data_frame = robjects.DataFrame(data_frame)
        #spds = self.createSpatialDataset(feat.geometry().type(), Coords, data_frame, projString)

        robjects.r.assign(str("r_input"), data_frame)
        # version 1
        if self.m_X_LABLE=="":
            self.m_X_LABLE = self.m_POLY_INPUT_FIELD

        arg1 = {"input": "r_input$"+self.m_POLY_INPUT_FIELD,
                "breaks": self.m_BREAK_CALCULATION,
                "freq": self.m_PLOT_TYPE,
                "main": self.m_MIAN_TITLE,
                "sub": self.m_SUB_TITLE,
                "xlab": self.m_X_LABLE,
                "additional":"",#self.m_ADDITIONAL_PARAMETER,
                "add_probability":self.m_ADD_PROBABILITY_DISTRIBUTION,
                "line_style":self.m_LINE_STYLE
                }
        r_command = '''
                library("spdep")
                input <- %(input)s
                input <- input[complete.cases(input)]
                hs <- hist(input, breaks='%(breaks)s', main='%(main)s', sub='%(sub)s', xlab='%(xlab)s', 
                    freq=ifelse('%(freq)s'=='Frequency',TRUE,FALSE), %(additional)s);
                max_hs_y <- max(hs$counts)
                ds<- density(input)
                max_ds_y <- max(ds$y)
                rate <- max_hs_y/max_ds_y
                ds$y <- ds$y * rate
                if (%(add_probability)s) lines(ds, lty='%(line_style)s');
                ''' % arg1

        
        res = robjects.r(r_command)
        progress.setPercentage(int(100))

    def createSpatialDataset(self, vectType, Coords, data, projString):
        if vectType == 0:
            # For points, coordinates must be input as a matrix, hense the extra bits below...
            # Not sure if this will work for multipoint features?
            spatialData = self.SpatialPoints_(self.matrix_(self.unlist_(Coords), \
                                                           nrow=len(Coords), byrow=True),
                                              proj4string=self.CRS_(projString))
            return self.SpatialPointsDataFrame_(spatialData, data)  # , match_ID = True )
            # kwargs = {'match.ID':"FALSE"}
            # return SpatialPointsDataFrame( spatialData, data, **kwargs )
        elif vectType == 1:
            spatialData = self.SpatialLines_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialLinesDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        elif vectType == 2:
            spatialData = self.SpatialPolygons_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialPolygonsDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        else:
            return ""

    # Helper function to get coordinates of input geometry
    # Does not require knowledge of input geometry type
    # Return: Appends R type geometry to input list
    def getNextGeometry(self, Coords, feat):
        geom = feat.geometry()
        if geom.type() == 0:
            Coords.append(self.getPointCoords(geom, feat.id()))
            return True
        elif geom.type() == 1:
            Coords.append(self.getLineCoords(geom, feat.id()))
            return True
        elif geom.type() == 2:
            Coords.append(self.getPolygonCoords(geom, feat.id()))
            return True
        else:
            return False

    # Function to retrieve QgsGeometry (point) coordinates
    # and convert to a format that can be used by R
    # Return: Item of class Matrix (R class)
    def getPointCoords(self, geom, fid):
        if geom.isMultipart():
            points = geom.asMultiPoint()  # multi_geom is a multipoint
            return [self.convertToXY(point) for point in points]
        else:
            point = geom.asPoint()  # multi_geom is a point
            return self.convertToXY(point)

        # Function to retrieve QgsGeometry (polygon) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Polygons (R class)

    def getPolygonCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            polygon = geom.asMultiPolygon()  # multi_geom is a multipolygon
            for lines in polygon:
                for line in lines:
                    keeps.append(self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                            nrow=len([self.convertToXY(point) for point in line]),
                                                            byrow=True)))
            return self.Polygons_(keeps, fid)
        else:
            lines = geom.asPolygon()  # multi_geom is a polygon
            Polygon = [self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                  nrow=len([self.convertToXY(point) for point in line]), byrow=True))
                       for line in lines]
            return self.Polygons_(Polygon, fid)

        # Function to retrieve QgsGeometry (line) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Lines (R class)

    def getLineCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            lines = geom.asMultiPolyline()  # multi_geom is a multipolyline
            for line in lines:
                for line in lines:
                    keeps.append(self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                         nrow=len([self.convertToXY(point) for point in line]),
                                                         byrow=True)))
            return self.Lines_(keeps, str(fid))
        else:
            line = geom.asPolyline()  # multi_geom is a line
            Line = self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                           nrow=len([self.convertToXY(point) for point in line]), byrow=True))
            return self.Lines_(Line, str(fid))

    def convertToXY(self, inPoint):
        return [inPoint.x(), inPoint.y()]

