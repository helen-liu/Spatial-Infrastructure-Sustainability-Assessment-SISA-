# -*- coding: utf-8 -*-

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import time
from collections import defaultdict
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsGeometry, NULL, QgsField, QgsSpatialIndex,
                       QgsPointXY, QgsFeature,QgsDistanceArea,Qgis,QgsWkbTypes)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.parameters import ParameterTableField,ParameterString
from SustainAssess.core.parameters import ParameterVector_RDBMS,ParameterNumber
from SustainAssess.core.outputs import OutputVector
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from igraph import Graph
pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class NearestFacilities(GeoAlgorithm):

    SOURCE_LAYER = 'SOURCE_LAYER'
    SOURCE_LAYER_ID = 'SOURCE_LAYER_ID'
    TARGET_LAYER = 'TARGET_LAYER'
    TARGET_LAYER_ID = 'TARGET_LAYER_ID'
    TARGET_LAYER_INPUTFIELD = "TARGET_LAYER_INPUTFIELD"
    POWERGRAVITY = "POWERGRAVITY"

    RD_EDGE_LAYER = 'RD_EDGE_LAYER'
    RD_EDGE_LAYER_SOURCE_FIELD = 'RD_EDGE_LAYER_SOURCE_FIELD'
    RD_EDGE_LAYER_TARGET_FIELD = 'RD_EDGE_LAYER_TARGET_FIELD'
    RD_EDGE_LAYER_COST_FIELD = 'RD_EDGE_LAYER_COST_FIELD'
    RD_EDGE_LAYER_REVERSE_COST_FIELD = 'RD_EDGE_LAYER_REVERSE_COST_FIELD'
    HIGHWAY = 'HIGHWAY'

    OUTPUT_FIELD = 'OUTPUT_FIELD'
    OUTPUT_LAYER = 'OUTPUT_LAYER'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Accessiblity/Nearest Facility"
        self.name, self.i18n_name = self.trAlgorithm('Nearest Facility')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')

        self.addParameter(ParameterVector_RDBMS(self.SOURCE_LAYER,
                                                self.tr('Source Layer (POINT)'), [ParameterVector_RDBMS.VECTOR_TYPE_POINT]))
        self.addParameter(ParameterTableField(self.SOURCE_LAYER_ID,
                                              self.tr('Source Layer ID'), self.SOURCE_LAYER))
        self.addParameter(ParameterVector_RDBMS(self.TARGET_LAYER,
                                                self.tr('Target Layer'),[ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.TARGET_LAYER_ID,
                                              self.tr('Target Layer ID'), self.TARGET_LAYER,defalut="id"))
        self.addParameter(ParameterTableField(self.TARGET_LAYER_INPUTFIELD,
                                              self.tr('Target Layer Attractiveness Field'), self.TARGET_LAYER))
        self.addParameter(ParameterNumber(self.POWERGRAVITY,self.tr('Power of Gravity'), default=2.0))
        self.addParameter(ParameterVector_RDBMS(self.RD_EDGE_LAYER,
                                                self.tr('Roads\' Layer'), [ParameterVector_RDBMS.VECTOR_ROAD_NETWORK]))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_SOURCE_FIELD,
                                              self.tr('Roads\' Source Field'), self.RD_EDGE_LAYER, defalut="source"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_TARGET_FIELD,
                                              self.tr('Roads\' Target Field'), self.RD_EDGE_LAYER, defalut="target"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_COST_FIELD,
                                              self.tr('Roads\' Cost Field'), self.RD_EDGE_LAYER, defalut="cost"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_REVERSE_COST_FIELD,
                                              self.tr('Roads\' Reverse Cost Field'), self.RD_EDGE_LAYER, defalut="reverse_cost"))
        self.addParameter(ParameterTableField(self.HIGHWAY,
                                              self.tr('Highway Indicator(1 or 0)'), self.RD_EDGE_LAYER, optional=True))

        self.addParameter(ParameterString(self.OUTPUT_FIELD,
                                          self.tr('Field Name of Accessibility'),default="target"))

        self.addOutput(OutputVector(self.OUTPUT_LAYER, self.tr('Output Accessibility Layer')))

    def Geom2Points(self,fGeom, ftype):
        # if fGeom.isMultipart():
        #     raise GeoAlgorithmExecutionException("Features can not be Multiple part! Please convert it to single part.")
        if QgsWkbTypes.geometryType(ftype) == QgsWkbTypes.PointGeometry:
            point = fGeom.asPoint()  # multi_geom is a point
            return point
        elif QgsWkbTypes.geometryType(ftype) == QgsWkbTypes.PolygonGeometry:
            line = fGeom.asPolygon()
            if len(line) == 0:
                return []
            else:
                return line[0][0:-1]
        elif QgsWkbTypes.geometryType(ftype) == QgsWkbTypes.LineGeometry:
            line = fGeom.asPolyline()
            return line
        else:
            raise GeoAlgorithmExecutionException("Error in Geom2Points function: geometry type is %s."% str(ftype))
    # def isHighWay(self,a):
    #     if a is None: return None
    #     isHW = True
    #     if a<80:
    #         isHW = False
    #     return isHW
    def isHighWay(self,a):
        try:
            a_int = int(a)
        except:
            raise GeoAlgorithmExecutionException("Error: Highway field must be int type(1: is highway, 0: is not highway).")
        if a is None: return None
        if a!=1 and a!=0:
            raise GeoAlgorithmExecutionException("Error: Highway field must be (1: is highway, 0: is not highway).")
        isHW = True
        if a_int==0:
            ## if speed < 80km/h, then it is not highway
            isHW = False
        return isHW
    def check(self):
        if self.m_SOURCE_LAYER.crs().authid() != self.m_RD_EDGE_LAYER.crs().authid() or \
            self.m_SOURCE_LAYER.crs().authid() != self.m_TARGET_LAYER.crs().authid():
            raise GeoAlgorithmExecutionException("Projection inconsistency among input layers!")
        if QgsWkbTypes.isMultiType(self.m_SOURCE_LAYER.wkbType()) or \
                QgsWkbTypes.isMultiType(self.m_TARGET_LAYER.wkbType()) or \
                   QgsWkbTypes.isMultiType(self.m_RD_EDGE_LAYER.wkbType()):
            raise GeoAlgorithmExecutionException("Please convert the multipart geometry to singles of input layers!")

    def processAlgorithm(self, progress):

        source_param = self.getParameterFromName(self.SOURCE_LAYER)
        self.m_SOURCE_LAYER = source_param.getLayerObject()
        self.m_SOURCE_ID = self.getParameterValue(self.SOURCE_LAYER_ID)

        target_param = self.getParameterFromName(self.TARGET_LAYER)
        self.m_TARGET_LAYER = target_param.getLayerObject()
        self.m_TARGET_LAYER_ID = self.getParameterValue(self.TARGET_LAYER_ID)
        self.m_TARGET_LAYER_INPUTFIELD = self.getParameterValue(self.TARGET_LAYER_INPUTFIELD)
        self.m_POWERGRAVITY = self.getParameterValue(self.POWERGRAVITY)

        edge_param = self.getParameterFromName(self.RD_EDGE_LAYER)
        self.m_RD_EDGE_LAYER = edge_param.getLayerObject()
        self.m_RD_EDGE_LAYER_SOURCE_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_SOURCE_FIELD)
        self.m_RD_EDGE_LAYER_TARGET_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_TARGET_FIELD)
        self.m_RD_EDGE_LAYER_COST_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_COST_FIELD)
        self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_REVERSE_COST_FIELD)
        self.m_HIGHWAY = self.getParameterValue(self.HIGHWAY)
        self.check()
        self.straighLine = False

        self.m_OUTPUT_ID = "id"
        self.m_OUTPUT_SOURCEID = "s_id"
        self.m_OUTPUT_TARGETID = 't_id'
        self.m_OUTPUT_ATTRACT = "attract"
        self.m_OUTPUT_DIS = "length"
        self.m_OUTPUT_ASSECC = self.getParameterValue(self.OUTPUT_FIELD)
        self.m_OUTPUT_LAYER = self.getOutputFromName(self.OUTPUT_LAYER)
        field_names = [self.m_OUTPUT_ID,self.m_OUTPUT_SOURCEID,self.m_OUTPUT_TARGETID,
                       self.m_OUTPUT_ATTRACT,self.m_OUTPUT_DIS,self.m_OUTPUT_ASSECC]

        # create new Layer =============================================================================================
        s_t = time.time()
        geometryType = QgsWkbTypes.LineString
        outFields = []
        outFields.append(QgsField(self.m_OUTPUT_ID,QVariant.LongLong,"bigint")) # add id field "id"
        # add source_id field "s_id"
        idTypes_map = {'10': "text", '2': "int4", '4': "int8",
                       '3': "int4", '5': "int8",'6': "numeric(20,8)"}
        fields = self.m_SOURCE_LAYER.fields()
        indx_id = fields.indexFromName(self.m_SOURCE_ID)
        outFields.append(QgsField(self.m_OUTPUT_SOURCEID,fields[indx_id].type(),
                                  idTypes_map[str(fields[indx_id].type())]))
        # add target_id field "t_id"
        fields = self.m_TARGET_LAYER.fields()
        indx_id = fields.indexFromName(self.m_TARGET_LAYER_ID)
        outFields.append(QgsField(self.m_OUTPUT_TARGETID,fields[indx_id].type(),
                                  idTypes_map[str(fields[indx_id].type())]))
        # add "attract","length", self.OUTPUT_FIELD fields
        outFields.append(QgsField(self.m_OUTPUT_ATTRACT, QVariant.Double, "numeric(20,8)", 20, 8))
        outFields.append(QgsField(self.m_OUTPUT_DIS, QVariant.Double, "numeric(20,8)", 20, 8))
        outFields.append(QgsField(self.m_OUTPUT_ASSECC, QVariant.Double, "numeric(20,8)", 20, 8))

        writer = self.m_OUTPUT_LAYER.getVectorWriter(outFields, geometryType, self.m_RD_EDGE_LAYER.crs(),
                                                     {"pk":self.m_OUTPUT_ID})
        outFeat = QgsFeature()
        e_t = time.time()
        progress.setInfo("Init output layer: %0.5f seconds"%(e_t-s_t))
        progress.setPercentage(int(5))
        # init the Target spatial indexing==============================================================================
        # --------- Break the target feature(Polygon,Polyline) to points ---------
        # --------- create spatial index for points---------
        s_t = time.time()
        idx_target = QgsSpatialIndex()
        idxId2targetId = {} # {id1:[targetID1,QgsPointXY,area], id2:[targetID2,QgsPointXY,area]}
        feats = self.m_TARGET_LAYER.getFeatures()
        count = int(self.m_TARGET_LAYER.featureCount())
        targetGeometryType = self.m_TARGET_LAYER.wkbType()
        idx_id = 0

        for ft in feats:
            targetID = ft[self.m_TARGET_LAYER_ID]
            fGeom = QgsGeometry(ft.geometry())
            points = self.Geom2Points(fGeom, targetGeometryType)
            value = ft[self.m_TARGET_LAYER_INPUTFIELD]
            for pt in points:
                pnt = QgsPointXY(pt[0],pt[1])
                geom = QgsGeometry.fromPointXY(pnt)
                f = QgsFeature(idx_id)
                f.setGeometry(geom)
                idx_target.insertFeature(f)
                idxId2targetId[idx_id] = [targetID,pnt,value]
                idx_id+=1
        # end  the Target spatial indexing==============================================================================
        e_t = time.time()
        progress.setInfo("Create Target layer spatial indexing: %0.5f seconds"%(e_t-s_t))

        # create the road network and its vertices indexing=============================================================
        s_t = time.time()

        feats = self.m_RD_EDGE_LAYER.getFeatures()
        count = int(self.m_RD_EDGE_LAYER.featureCount())
        # init points spatial index---------------------------
        idx_network = QgsSpatialIndex()
        edge_data = {}
        reverse_edge_data = {}  # {(source,target):id,...} id is the id in Igraph

        # create spatial index for the edge ends without the highway ends
        idset = set()
        highwayPointSet = set()
        for i,ft in enumerate(feats):
            id = ft.id()
            edge_data[id] = [ft[self.m_RD_EDGE_LAYER_SOURCE_FIELD], ft[self.m_RD_EDGE_LAYER_TARGET_FIELD],
                                  ft[self.m_RD_EDGE_LAYER_COST_FIELD], ft[self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD],
                                  self.isHighWay(ft[self.m_HIGHWAY] if self.m_HIGHWAY else None),
                                  QgsGeometry(ft.geometry())]
            idset.add(id)
            # find the points set which on the highway
            if self.m_HIGHWAY:
                e = edge_data[id]
                if e[4]:
                    highwayPointSet.add(e[0])
                    highwayPointSet.add(e[1])

        indexPointSset = set()
        indPointsData = {}
        for id in idset:
            e = edge_data[id]
            sourceID, targetID = e[0], e[1]
            fGeom = e[5]
            vertices = fGeom.asPolyline()
            startP, endP = vertices[0], vertices[-1]

            if sourceID not in highwayPointSet and sourceID not in indexPointSset:
                indexPointSset.add(sourceID)
                pnt = QgsPointXY(startP.x(), startP.y())
                indPointsData[sourceID] = pnt
                geom = QgsGeometry.fromPointXY(pnt)
                f = QgsFeature(sourceID)
                f.setGeometry(geom)
                idx_network.insertFeature(f)
            if targetID not in highwayPointSet and targetID not in indexPointSset:
                indexPointSset.add(targetID)
                pnt = QgsPointXY(endP.x(), endP.y())
                indPointsData[targetID] = pnt
                geom = QgsGeometry.fromPointXY(pnt)
                f = QgsFeature(targetID)
                f.setGeometry(geom)
                idx_network.insertFeature(f)

        # create road network===========================================================================================
        edges = []
        for id in idset:
            e = edge_data[id]
            source, target, cost, reverse_cost, _, _ = e
            if (cost < 10000 and cost > 0):
                edges.append({"source": source, "target": target, "weight": cost})
                reverse_edge_data[(source, target)] = id
            if (reverse_cost < 10000 and reverse_cost > 0):
                edges.append({"source": target, "target": source, "weight": reverse_cost})
                reverse_edge_data[(target, source)] = id
        d_network = Graph.DictList({}, edges, directed=True)
        p_dict = {}  # Source ID(Target ID) --> graph_id(start from 0)
        for i in range(d_network.vcount()):
            v_t = d_network.vs[i]["name"]
            p_dict[v_t] = i
        e_t = time.time()
        progress.setInfo("Road Network Complete and its spatial indexing:%0.5f" % (e_t - s_t))
        progress.setPercentage(int(15))
        # end create the road network and its spatial indexing==========================================================
        # find neighbors increased by 50, only compare the first two polygons, each polygon only consider the first 10 points

        # for each point in points ( of polygon)
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_SOURCE_LAYER.selectedFeatureCount() > 0:
            sourceFeats = self.m_SOURCE_LAYER.getSelectedFeatures()
            count = int(self.m_SOURCE_LAYER.selectedFeatureCount())
        else:
            sourceFeats = self.m_SOURCE_LAYER.getFeatures()
            count = int(self.m_SOURCE_LAYER.featureCount())

        s_t = time.time()
        progress.setInfo("Find the Nearest Facility on Network...")
        for current,ft in enumerate(sourceFeats):
            fGeom = QgsGeometry(ft.geometry())
            s_point = fGeom.asPoint() # as source in road network
            sInd = idx_network.nearestNeighbor(s_point, 1)
            
            notfinish = True
            visited_points = set()
            visited_polyID = set()
            num_polyID = defaultdict(lambda:0) # record the number of poly visited, if visited more than 10, it will add to visited_polyID
            vals = {}
            iter_ = 1
            min_route_dis = 999999999.0
            min_routeid = None
            min_path = []
            while notfinish:
                # get the 100 nearest
                nearest_inds = idx_target.nearestNeighbor(s_point,iter_*50)
                for nind in nearest_inds:
                    if nind in visited_points:
                        continue
                    t_ID, t_point, t_value = idxId2targetId[nind] # as target in road network
                    if t_ID not in visited_polyID:
                        tInd = idx_network.nearestNeighbor(t_point,1)
                        # calculate the shortest distance
                        try:
                            newpaths = []
                            paths = \
                            d_network.get_shortest_paths(p_dict[sInd[0]], p_dict[tInd[0]], "weight", "OUT", "vpath")[0]
                            pathlen = 0.0
                            if paths is None or len(paths) == 0:
                                progress.setInfo(str("No path found for %s,%s" % (sInd[0], tInd[0])))
                                pathlen = NULL
                            else:
                                for res_ind in range(len(paths) - 1):
                                    note1, note2 = paths[res_ind], paths[res_ind + 1]
                                    note1 = d_network.vs[note1]["name"]
                                    note2 = d_network.vs[note2]["name"]
                                    newpaths.append(note1)
                                    e_id = reverse_edge_data[(note1, note2)]
                                    e_data = edge_data[e_id]
                                    s, t, c, r_c, _, _ = e_data
                                    if note1 == s:
                                        pathlen += c
                                    else:
                                        pathlen += r_c
                                newpaths.append(note2)
                                paths = newpaths
                        except Exception as e:
                            raise GeoAlgorithmExecutionException("%s" % (str(e)))

                        vals = {}
                        # total distance
                        if pathlen!=NULL:
                            dis_source = 0 # distance.measureLine(s_point,indPointsData[sInd[0]])
                            dis_target = 0 # distance.measureLine(indPointsData[tInd[0]],t_point)
                            route_dis = dis_source + pathlen + dis_target
                            if route_dis < min_route_dis:
                                min_route_dis = route_dis
                                min_routeid = nind
                                min_path = paths
                    else:
                        continue
                    num_polyID[t_ID] = num_polyID[t_ID] + 1
                    visited_points.add(nind)
                    if num_polyID[t_ID] >= 10:
                        visited_polyID.add(nind)
                        if len(visited_polyID)>1:
                            notfinish = False
                iter_+=1
            #field_names = ["id","s_id",'t_id',"attract","length",self.m_OUTPUT_ASSECC]
            t_ID, t_point, t_value = idxId2targetId[min_routeid]  # as target in road network
            vals[self.m_OUTPUT_ID] = current
            vals[self.m_OUTPUT_SOURCEID] = ft[self.m_SOURCE_ID]
            vals[self.m_OUTPUT_TARGETID] = t_ID
            vals[self.m_OUTPUT_ATTRACT] = t_value
            vals[self.m_OUTPUT_DIS] = min_route_dis
            vals[self.m_OUTPUT_ASSECC] = t_value / pow(min_route_dis, self.m_POWERGRAVITY)

            # update fields
            attr = []
            for field_name in field_names:
                attr.append(vals[field_name])
            outFeat.setAttributes(attr)
            # outFeat.setGeometry(ft.geometry())
            if self.straighLine:
                outFeat.setGeometry(QgsGeometry.fromPolylineXY([s_point, t_point]))
            else:
                polyline = []
                for i in range(len(min_path) - 1):
                    node1, node2 = min_path[i], min_path[i + 1]
                    e_id = reverse_edge_data[(node1, node2)]
                    e_data = edge_data[e_id]
                    s, t, c, r_c, _, fGeom = e_data
                    vertices = fGeom.asPolyline()
                    if node1 == s:
                        polyline.extend(vertices)
                    else:
                        polyline.extend(vertices[::-1])

                outFeat.setGeometry(QgsGeometry.fromPolylineXY(polyline))
            writer.addFeature(outFeat)
            progress.setPercentage(int(25+current*1.0/count*75))
        # save the update===============================================================================================
        del writer
        progress.setPercentage(int(100))

