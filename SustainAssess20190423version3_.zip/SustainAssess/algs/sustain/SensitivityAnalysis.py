# -*- coding: utf-8 -*-

"""
***************************************************************************
    RandomPointsLayer.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Alexander Bruy
    Email                : alexander dot bruy at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,sys
import numpy as np
from qgis.core import (QgsDataSourceUri,QgsMapLayer,QgsProject)
from qgis.PyQt.QtGui import QIcon,QCursor,QPalette,QColor
from qgis.PyQt.QtWidgets import QAbstractItemView,QApplication,QWidget,QVBoxLayout,QScrollArea,QFrame,QSpacerItem,QSizePolicy,\
            QLabel,QTableWidget,QTableWidgetItem,QComboBox,QMessageBox
from qgis.PyQt.QtCore import QVariant,QRect,Qt,QSize,QItemSelectionModel
from SustainAssess.algs.cores import sobol_analyze
from SustainAssess.algs.cores import saltelli
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterRaster,ParameterVector
from SustainAssess.core.parameters import ParameterFile
from SustainAssess.core.parameters import ParameterVector_RDBMS,ParameterNumber
from SustainAssess.core.outputs import OutputFile
from qgis.gui import QgsCollapsibleGroupBox
from SustainAssess.gui.NumberInputPanel import NumberInputPanel
from SustainAssess.gui.AlgorithmExecutor import runalg,runalgIterating
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.tools import dataobjects,postgis,spatialite
from SustainAssess.gui.InputLayerRDBMSelectorPanel import InputLayerRDBMSelectorPanel
from SustainAssess.gui.OutputSelectionPanel import OutputSelectionPanel
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.gui.FileSelectionPanel import FileSelectionPanel
from SustainAssess.gui.Postprocessing import handleAlgorithmResults

from SustainAssess.gui.AlgorithmDialogBase import AlgorithmDialogBase
pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class Sensitivity(GeoAlgorithm):

    POLY_RESULT_VECTOR = 'POLY_RESULT_VECTOR'
    WEIGHT_FILE = "WEIGHT_FILE"
    UNCERTAINTY_RANGE = 'UNCERTAINTY_RANGE'
    NUMBER_SAMPLES = 'NUMBER_SAMPLES'
    CONFIDENCE_INTERVAL = 'CONFIDENCE_INTERVAL'
    CONFIDENCE_INTERVAL_OPTIONS = ['90%','95%','98%']
    CONFIDENCE_INTERVAL_VALUES = [0.95,0.975,0.99]
    OUTPUT_AS_TEXT = 'OUTPUT_AS_TEXT'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Results Analysis/Sensitivity Analysis"
        self.name, self.i18n_name = self.trAlgorithm('Sensitivity Analysis')
        self.group, self.i18n_group = self.trAlgorithm('Indicator Analysis')

        # self.addParameter(ParameterVector_RDBMS(self.POLY_RESULT_VECTOR,
        #                                         self.tr('AHP Result Layer:'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))

        self.addParameter(ParameterFile(self.WEIGHT_FILE, self.tr('AHP Weight File'), optional=False, ext='weight'))
        # self.addParameter(ParameterNumber(self.UNCERTAINTY_RANGE, self.tr(u'Uncertainty Range(±%)'), default=10.0,minValue=0, maxValue=30))
        self.addParameter(ParameterNumber(self.NUMBER_SAMPLES, self.tr("Number of Samples:"), default=1000, minValue=100))
        # self.addParameter(ParameterSelection(self.CONFIDENCE_INTERVAL, self.tr('Confidence Interval:'), self.CONFIDENCE_INTERVAL_OPTIONS, 0))
        self.addOutput(OutputFile(self.OUTPUT_AS_TEXT, self.tr('Output Sensitivity Results File'), 'txt'))

    def getCustomParametersDialog(self):
        self.dlg = SensitivityDialog(self)
        return self.dlg
    def processAlgorithm(self, progress):
        self.progress = progress
        # Read setting from the table widget
        table = self.dlg.fields_widget
        n_rows = table.rowCount()

        names = []
        bounds = []
        for r_i in range(n_rows - 1):
            cell1 = table.item(r_i, 0)
            cell2 = table.item(r_i, 2)
            cell3 = table.item(r_i, 3)
            names.append(cell1.text())
            bounds.append([float(cell2.text()),float(cell3.text())]) #[TODO] check if the item is numeric

        sample_num = self.getParameterValue(self.NUMBER_SAMPLES)
        problem = {
            'num_vars': len(names),
            'names': names,
            'bounds': bounds
        }

        # Generate samples
        progress.setPercentage(10)
        try:
            # import rpdb2
            # rpdb2.start_embedded_debugger("liu")
            param_values = saltelli.sample(problem, sample_num, calc_second_order= False,progress=progress)
            Y1 = np.zeros([param_values.shape[0]])
        except Exception as e:
            raise GeoAlgorithmExecutionException(str(e))
        # for i, X in enumerate(param_values):
        progress.setPercentage(45)
        # for w in weights:
        Y1 = param_values.dot(self.dlg.weight.transpose())
        res1 = sobol_analyze.analyze(problem, Y1,calc_second_order=False)
        progress.setPercentage(90)
        # problem = {
        #     'num_vars': 3,
        #     'names': ['x1','x2','x3'],
        #     'bounds': [[0, 1],[3,10],[26,62]]
        # }
        # param_values2 = saltelli.sample(problem, 1000)
        # Y2 = np.zeros([param_values2.shape[0]])
        # for i, X in enumerate(param_values2):
        #     Y2[i] = X[0]+X[1]+X[2]
        # res2 = sobol_analyze.analyze(problem, Y2)
        self.m_OUTPUT_AS_TEXT = self.getOutputValue(self.OUTPUT_AS_TEXT)
        f = open(self.m_OUTPUT_AS_TEXT,"w")
        # 'S1', 'S1_conf', 'ST', and 'ST_conf'
        keys = ['S1', 'S1_conf', 'ST','ST_conf']
        f.write("Indicator,"+",".join(names)+"\n")
        for key in keys:
            f.write(key+",")
            f.write(",".join([str(i) for i in res1[key]])+"\n")
        f.close()
        progress.setPercentage(int(100))


class SensitivityDialog(AlgorithmDialogBase):
    def __init__(self,alg):
        AlgorithmDialogBase.__init__(self,alg)

        self.alg = alg
        self.iterateButtons = {}
        self.mainWidget = self.MainPanel()
        self.setMainWidget()

        self.cornerWidget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0,0,0,5) #void QLayout::setContentsMargins(int left, int top, int right, int bottom)
        self.tabWidget.setStyleSheet("QTabBar::tab { height: 30px; }")

        QgsProject.instance().layerWasAdded.connect(self.layerAdded_sen)
        QgsProject.instance().layersWillBeRemoved.connect(self.layersWillBeRemoved_sen)

    def MainPanel(self):
        myForm = QWidget()
        myForm.setObjectName("From")
        myForm.resize(400,200) #resize(int w, int h)
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 10, QSizePolicy.Minimum, QSizePolicy.Preferred)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}
        self.labels = {}
        # # add parameter[0] ParameterVector_RDBMS=========================================================
        # param = self.alg.parameters[0]
        # layers = dataobjects.getVectorLayers([2]) # 2 Polygon
        # items = []
        # for layer in layers:
        #     items.append((layer.name(), layer))
        # widget = InputLayerRDBMSelectorPanel(items, param)
        # widget.cmbText.name = param.name
        # widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)
        # self.widgets[param.name] = widget
        #
        # desc = param.description
        # label = QLabel(desc)
        # self.labels[param.name] = label
        #
        # self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        # self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)
        # self.widgets[param.name] = widget
        # add parameter[1]  ParameterFile(self.WEIGHT_FILE, self.tr('Weight file'), optional=False, ext='weight')
        param = self.alg.parameters[0]
        item = FileSelectionPanel(param.isFolder, param.ext)
        self.widgets[param.name] = item
        desc = param.description
        label = QLabel(desc)
        self.labels[param.name] = label
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        item.leText.textChanged.connect(self.pop_tableview)
        

        # add parameter ================================================================================================
        self.fields_widget = QTableWidget()
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        self.fields_widget.setSizePolicy(sizePolicy)
        self.init_tableview()
        self.fields_widget.setObjectName("selected_widget")
        self.fields_widget.setMinimumSize(QSize(100, 250))
        self.fields_widget.setAlternatingRowColors(True)
        self.fields_widget.setSortingEnabled(True)
        self.fields_widget.setDragEnabled(False)
        self.fields_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.fields_widget.setDragDropOverwriteMode(False)
        self.fields_widget.setDefaultDropAction(Qt.MoveAction)
        self.fields_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.fields_widget.setSelectionBehavior(QAbstractItemView.SelectItems)

        desc = "AHP Indicators"
        label = QLabel(desc)
        # label.setToolTip(tooltip)

        self.labels["selection"] = label
        self.widgets["selection"] = self.fields_widget
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, self.fields_widget)
        
        # add number panel =============================================================================================
        name = "NUMBER_SAMPLES"
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        item = NumberInputPanel(param.default, param.min, param.max,
                                param.isInteger)
        self.labels[name] = label
        self.widgets[name] = item
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        # add output ===================================================================================================
        output = self.alg.outputs[0]
        label = QLabel(output.description)
        widget_out = OutputSelectionPanel(output, self.alg)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, widget_out)

        self.widgets[output.name] = widget_out

        self.init_signals()
        # ind = widget.cmbText.currentIndex()
        # widget.cmbText.currentIndexChanged.emit(ind)
        return myForm

    def init_signals(self):
        # self.fields_widget.itemDoubleClicked.connect(self._deselect)
        pass

    def pop_tableview(self,path):
        sender = self.sender()
        table = self.fields_widget
        if path=="": return
        f_in = open(path,"r")
        # get top dimentions
        # top_dims = ["Economic','Environmental','Social']
        line = f_in.readline().rstrip("\r\n")
        top_dims  = line.split(",")[1:]  # [b'Eco', b'Env', b'Soc']
        n_top_dims = len(top_dims)

        line = f_in.readline().rstrip("\n\t")
        infos = line.split(",")[1:] #[b'Eco_1', b'Eco_2', b'Eco_3', b'Env_1', b'Env_2', b'Env_3', b'Soc_1', b'Soc_2', b'Soc_3', b'Soc_4']
        n_col = len(infos)

        # origin_weight = [0.1156237051214135,0.09293824481282241,0.036719040459988625,0.018637110997602832,0.1156237051214135,0.09293824481282241,0.036719040459988625,0.018637110997602832,0.17551395029424272,0.11056684929525253,0.046435138818353955,0.07371119552034461,0.046435138818353955,0.019501524469797707]
        line = f_in.readline().rstrip("\r\n")
        origin_weight = line.split(",")[1:]
        self.weight = np.array([float(i) for i in origin_weight])

        # top_dims_positions = [[1,1,1,1,1,1,1,1,0,0,0,0,0,0]
        #                       [0,0,0,0,0,0,0,0,1,1,1,0,0,0]
        #                       [0,0,0,0,0,0,0,0,0,0,0,1,1,1]]
        top_dims_positions = [[0.0] * n_col for i in range(n_top_dims)]
        TOPITEMS_ALIAS = []
        for tp in top_dims_positions:
            line = f_in.readline().rstrip("\r\n")
            TOPITEMS_ALIAS.append(line.split(",")[0].split(" ")[0])
            ws = [float(e) for e in line.split(",")[1:]] #0.5,0.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0
            for i in range(n_col):
                if ws[i]>0:
                    tp[i] = 1

        ind_dims = 0
        fieldinfo = []
        while  ind_dims<len(top_dims):
            while True:
                line = f_in.readline()
                if not line: break
                line = line.strip("\r\n")
                if line.lower()==TOPITEMS_ALIAS[ind_dims].lower():
                    break
            f_in.readline() # skip input line
            for i in range(int(sum(top_dims_positions[ind_dims]))):
                line = f_in.readline().rstrip("\n\t").split(",")
                fieldinfo.append(line)
            ind_dims+=1


        nrow = len(fieldinfo)
        table.setRowCount(0)
        for i in range(nrow):
            table.insertRow(i)
            info = fieldinfo[i]
            item_t = QTableWidgetItem(info[1])
            item_t.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable)
            table.setItem(i,0,item_t)
            item_t = QTableWidgetItem(info[0])
            item_t.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable)
            table.setItem(i,1,item_t)
            item_t = QTableWidgetItem(info[2])
            item_t.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable|Qt.ItemIsEditable)
            table.setItem(i,2,item_t)
            item_t = QTableWidgetItem(info[3])
            item_t.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable|Qt.ItemIsEditable)
            table.setItem(i,3,item_t)

    def init_tableview(self):
        table = self.fields_widget
        colnames = ["Fields","Original Name","Low Bound","Upper Bound"]
        ncol = len(colnames)
        data = [[""] for i in range(ncol)]

        for i in range(ncol):
            table.insertColumn(i)
            table.setHorizontalHeaderItem(i,QTableWidgetItem(colnames[i]))
        nrow = len(data[0])
        ncol = len(data)
        for i in range(nrow):
            table.insertRow(i)
        for j in range(ncol):
            for i in range(nrow):
                item_t = QTableWidgetItem(str(data[j][i]))
                item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                if j==1:
                    item_t.setFlags(Qt.ItemIsSelectable |  Qt.ItemIsEnabled | Qt.ItemIsEditable)
                table.setItem(i,j,item_t)

    def _select(self):
        self._do_move_f2t(self.unselected_widget, self.fields_widget)

    def _deselect(self):
        self._do_move_t2f(self.unselected_widget, self.fields_widget)

    def _do_move_t2f(self, fromList, toList):
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        if len(targets)==0:
            return
        target = targets[0]
        t_row = toList.row(target)
        t_col = toList.column(target)
        if t_col!=0:
            return
        try:
            ind = self.fieldslist.index(target.text())
        except:
            return

        prev_from_item = toList.item(t_row,t_col)
        fromList.setItem(ind,0,toList.takeItem(t_row, t_col))
        toList.removeRow(t_row)

        fromList.setCurrentCell(ind,0,QItemSelectionModel.Select)
        fromList.scrollToItem(prev_from_item)

    def _do_move_f2t(self, fromList, toList):
        recover = False
        temp = None
        add_to_last = True
        insert = False
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        nrows = toList.rowCount()
        # No selection
        if len(targets)==0:
            # find the first empty element
            for i in range(nrows):
                t_i = toList.item(i,0)
                if t_i.text()=="":
                    t_row = toList.row(t_i)
                    t_col = toList.column(t_i)
                    break
        else:
            # has selection
            target = targets[0]
            t_row = toList.row(target)
            t_col = toList.column(target)
            if t_col!=0:
                t_col = 0
                t_row = nrows - 1
            else:

                if target.text()!="":
                    recover=True
                    temp = target.text()
                    add_to_last = False
                    insert = True

        if t_row==-1:
            return
        if add_to_last:
            toList.insertRow(nrows)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(nrows,0,item_t)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            toList.setItem(nrows, 1, item_t)
        if insert:
            toList.insertRow(t_row+1)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(t_row+1,0,item_t)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            toList.setItem(t_row+1, 1, item_t)
            t_row = t_row + 1
        for item in fromList.selectedItems():
            f_row = fromList.row(item)
            f_col = fromList.column(item)
            prev_from_item = fromList.item(f_row,f_col)
            toList.setItem(t_row,t_col,fromList.takeItem(f_row,f_col))
            fromList.scrollToItem(prev_from_item)
        # if recover:
        #     ind = self.fieldslist.index(temp)
        #     fromList.setItem(ind, 0, QTableWidgetItem(temp))
        toList.clearSelection()
        toList.setCurrentCell(t_row, 0, QItemSelectionModel.Select)
        #toList.setCurrentCell(t_row, 1, QItemSelectionModel.Select)
    def runAsBatch(self):
        pass

    def setParamValues(self):
        params = self.alg.parameters
        outputs = self.alg.outputs

        for param in params:
            if param.hidden:
                continue
            if not self.setParamValue(
                    param, self.widgets[param.name]):
                raise AlgorithmDialogBase.InvalidParameterValue(
                    param, self.widgets[param.name])

        for output in outputs:
            if output.hidden:
                continue
            output.value = self.widgets[output.name].getValue()
        return True

    def setParamValue(self, param, widget, alg=None):
        if isinstance(param, ParameterRaster):
            return param.setValue(widget.getValue())
        elif isinstance(param,(ParameterVector_RDBMS)):
            return param.setValue(widget.getValue())
        elif isinstance(param, (ParameterVector)):
            try:
                return param.setValue(widget.itemData(widget.currentIndex()))
            except:
                return param.setValue(widget.getValue())
        elif isinstance(param, ParameterFile):
            return param.setValue(widget.getValue())
        elif isinstance(param,ParameterNumber):
            return param.setValue(widget.getValue())

    def accept(self):
        self.settings.setValue("/Processing/dialogBase", self.saveGeometry())

        checkCRS = ProcessingConfig.getSetting(ProcessingConfig.WARN_UNMATCHING_CRS)
        try:
            self.setParamValues()
            if checkCRS and not self.alg.checkInputCRS():
                reply = QMessageBox.question(self, self.tr("Unmatching CRS's"),
                                             self.tr('Layers do not all use the same CRS. This can '
                                                     'cause unexpected results.\nDo you want to '
                                                     'continue?'),
                                             QMessageBox.Yes | QMessageBox.No,
                                             QMessageBox.No)
                if reply == QMessageBox.No:
                    return

            msg = self.alg._checkParameterValuesBeforeExecuting()
            if msg:
                QMessageBox.warning(
                    self, self.tr('Unable to execute algorithm'), msg)
                return
            self.btnRun.setEnabled(False)
            self.btnClose.setEnabled(False)
            buttons = self.iterateButtons
            self.iterateParam = None

            for i in range(len(buttons.values())):
                button = buttons.values()[i]
                if button.isChecked():
                    self.iterateParam = buttons.keys()[i]
                    break

            self.progressBar.setMaximum(0)
            self.lblProgress.setText(self.tr('Processing algorithm...'))
            # Make sure the Log tab is visible before executing the algorithm
            try:
                self.tabWidget.setCurrentIndex(1)
                self.repaint()
            except:
                pass

            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))

            self.setInfo(
                self.tr('<b>Algorithm %s starting...</b>') % self.alg.name)

            if self.iterateParam:
                if runalgIterating(self.alg, self.iterateParam, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
            else:
                command = self.alg.getAsCommand()
                if command:
                    ProcessingLog.addToLog(
                        ProcessingLog.LOG_ALGORITHM, command)
                if runalg(self.alg, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
        except AlgorithmDialogBase.InvalidParameterValue as e:
            try:
                self.buttonBox.accepted.connect(lambda:
                                                e.widget.setPalette(QPalette()))
                palette = e.widget.palette()
                palette.setColor(QPalette.Base, QColor(255, 255, 0))
                e.widget.setPalette(palette)
                self.lblProgress.setText(
                    self.tr('<b>Missing parameter value: %s</b>') % e.parameter.description)
                return
            except:
                QMessageBox.critical(self,
                                     self.tr('Unable to execute algorithm'),
                                     self.tr('Wrong or missing parameter values'))

    def closeEvent(self, evt):
        QgsProject.instance().layerWasAdded.disconnect(self.layerAdded_sen)
        QgsProject.instance().layersWillBeRemoved.disconnect(self.layersWillBeRemoved_sen)
        super(SensitivityDialog, self).closeEvent(evt)

    def finish(self):
        keepOpen = ProcessingConfig.getSetting(ProcessingConfig.KEEP_DIALOG_OPEN)

        if self.iterateParam is None:
            if not handleAlgorithmResults(self.alg, self, not keepOpen):
                self.resetGUI()
                return

        self.executed = True
        self.setInfo('Algorithm %s finished' % self.alg.name)
        QApplication.restoreOverrideCursor()

        if not keepOpen:
            self.close()
        else:
            self.resetGUI()
            if self.alg.getHTMLOutputsCount() > 0:
                self.setInfo(
                    self.tr('HTML output has been generated by this algorithm.'
                            '\nOpen the results dialog to check it.'))
    def layerAdded_sen(self,layer):
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    if dataobjects.canUseVectorLayer(layer, param.shapetype):
                        widget = self.widgets[param.name]
                        if isinstance(widget, InputLayerRDBMSelectorPanel) and hasattr(widget.cmbText, 'addItem'):
                            widget = widget.cmbText
                        widget.addItem(layer.name(), layer)
        elif layer.type() == QgsMapLayer.RasterLayer and dataobjects.canUseRasterLayer(layer):
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText
                    widget.addItem(self.getExtendedLayerName(layer), layer)

    def layersWillBeRemoved_sen(self,layers):
        for layer in layers:
            self.layerRemoved(layer)
    def layerRemoved(self, layer):
        layer = QgsProject.instance().mapLayer(layer)
        widget = None
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    widget = self.widgets[param.name]
                    if isinstance(widget, InputLayerRDBMSelectorPanel):
                        widget = widget.cmbText

                        if widget is not None:
                            idx = widget.findData(layer)
                            if idx != -1:
                                widget.removeItem(idx)
                            widget = None

        elif layer.type() == QgsMapLayer.RasterLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText

                    if widget is not None:
                        idx = widget.findData(layer)
                        if idx != -1:
                            widget.removeItem(idx)
                        widget = None

    def updateDependentFields(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        layer = sender.itemData(sender.currentIndex())
        if not layer:
            return
        widget = self.fields_widget
        widget.clearContents()
        fieldTypes = []

        fieldTypes = [QVariant.Int, QVariant.Double, QVariant.LongLong,
                          QVariant.UInt, QVariant.ULongLong]

        fieldNames = set()
        # ============for ParameterVector_RDBMS
        if isinstance(layer, dict):
            if "uri" in layer.keys():
                uri = layer["uri"]
                if uri.startswith(u"spatialite:"):
                    uri = uri[len(u"spatialite:"):]
                    uri = QgsDataSourceUri(uri)
                    try:
                        db = spatialite.GeoDB(uri)
                    except postgis.DbError as e:
                        raise GeoAlgorithmExecutionException(
                            "Couldn't connect to database:\n%s" % e.message)
                        # return False
                    sql_fields = 'pragma table_info(%s)' % (uri.table())
                    c = db.con.cursor()
                    c.execute(sql_fields)
                    fields = c.fetchall()
                    for field in fields:
                        # [TODO] filter the spatialite field type
                        fieldNames.add(field[1])
                elif uri.startswith(u"postgis:"):
                    uri = uri[len(u"postgis:"):]
                    uri = QgsDataSourceUri(uri)
                    try:
                        db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                                           dbname=uri.database(), user=uri.username(), passwd=uri.password())
                    except postgis.DbError as e:
                        raise GeoAlgorithmExecutionException(
                            "Couldn't connect to database:\n%s" % e.message)
                        # return False
                    fields = db.get_table_fields(uri.table(), uri.schema())
                    for field in fields:
                        # [TODO] filter the PostgreSQL field type
                        fieldNames.add(field.name)
                else:
                    layer = dataobjects.getObjectFromUri(uri)
                    for field in layer.fields():
                        if not fieldTypes or field.type() in fieldTypes:
                            fieldNames.add(str(field.name()))
        else:
            for field in layer.fields():
                if not fieldTypes or field.type() in fieldTypes:
                    fieldNames.add(str(field.name()))
        nrow = len(fieldNames)
        self.fieldslist = list(fieldNames)

        for i in range(nrow):
            widget.insertRow(i)
            item_t = QTableWidgetItem(str(self.fieldslist[i]))
            item_t.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable)
            widget.setItem(i,0,item_t)
