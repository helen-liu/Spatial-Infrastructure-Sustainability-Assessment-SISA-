# -*- coding: utf-8 -*-
__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,math
import numpy as np
from scipy.stats.mstats import gmean
from collections import defaultdict
from qgis.PyQt.QtGui import QIcon, QFont, QCursor,QColor, QPalette,QDesktopServices
from qgis.PyQt.QtCore import QVariant,QRect,Qt,QSize,QItemSelectionModel
from qgis.PyQt.QtWidgets import QAbstractItemView,QApplication,QWidget,\
    QVBoxLayout,QPushButton,QScrollArea,QFrame,QSpacerItem,QSizePolicy,QLabel,QHBoxLayout,\
    QTableWidget,QTableWidgetItem,QComboBox,QMessageBox,QCheckBox
from SustainAssess.gui.OutputSelectionPanel import OutputSelectionPanel
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.gui.AlgorithmExecutor import runalg,runalgIterating
from SustainAssess.gui.InputLayerRDBMSelectorPanel import InputLayerRDBMSelectorPanel
from qgis.core import QgsMapLayer, QgsDataSourceUri, Qgis, QgsFeature, QgsGeometry, NULL,QgsProject,\
                QgsFeatureRequest,QgsSpatialIndex,QgsDistanceArea,QgsWkbTypes
from SustainAssess.gui.AlgorithmDialogBase import AlgorithmDialogBase
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterVector_RDBMS,Parameter
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.parameters import ParameterRaster
from SustainAssess.core.outputs import OutputVector
from SustainAssess.tools import dataobjects,postgis,spatialite
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.gui.Postprocessing import handleAlgorithmResults
from qgis.gui import QgsCollapsibleGroupBox
from SustainAssess.core.outputs import OutputVector,OutputRaster, OutputTable,OutputVector_liu

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

class AggregateAttributes(GeoAlgorithm):
    SOURCE = "SOURCE" # SELECT FEATURE FROM THIS LAYER
    METHODS = 'METHODS'
    METHODS_OPTIONS = ['ID','LOCATION']
    SOURCE_ID = 'SOURCE_ID' # WILL APPEAR WHEN SELECT BY ID

    REFERENCE = 'REFERENCE'
    REFERENCE_ID = 'REFERENCE_ID'

    MULTIFIELDS = 'MULTIFIELDS'
    METHODS_DISSOLVE = 'METHODS_DISSOLVE'
    METHODS_DISSOLVE_OPTIONS = ['Sum','Median','Min','Max','Arithmetic Mean','Geometric Mean','Interquartile Mean']
    OUTPUT = "OUTPUT"

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Geoprocess/Aggregate Attributes"
        self.name, self.i18n_name = self.trAlgorithm('Aggregate Attributes')
        self.group, self.i18n_group = self.trAlgorithm('Vector general tools')

        self.addParameter(ParameterVector_RDBMS(self.SOURCE,
                                          self.tr('Source Layer'),
                                          [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))

        self.addParameter(ParameterSelection(self.METHODS,
                                             self.tr('Aggregate By'), self.METHODS_OPTIONS,0))
        self.addParameter(ParameterTableField(self.SOURCE_ID, self.tr('ID Field of Source Layer'), self.SOURCE,
                                              FieldType.DATA_TYPE_ID))
        self.addParameter(ParameterVector_RDBMS(self.REFERENCE,
                                          self.tr('Reference Layer'),
                                          [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterTableField(self.REFERENCE_ID, self.tr('ID Field of Reference Layer'),
                                              self.REFERENCE,FieldType.DATA_TYPE_ID))

        self.addParameter(ParameterMultiFields(self.MULTIFIELDS,self.tr('Select Fields to Aggregate'),self.SOURCE,
                                               FieldType.DATA_TYPE_NUMERIC))

        self.addParameter(ParameterSelection(self.METHODS_DISSOLVE,
                                             self.tr('Aggregation Method'), self.METHODS_DISSOLVE_OPTIONS,0))
        self.addOutput(OutputVector(self.OUTPUT, self.tr('Output Aggregation Layer')))

    def getCustomParametersDialog(self):
        self.dlg = AggregationLDialog(self)
        return self.dlg
    # def check(self):

    def processAlgorithm(self, progress):
        source_param = self.getParameterFromName(self.SOURCE)
        sourceLayer = source_param.getLayerObject()   # will select features from source layer

        m_METHODS = self.METHODS_OPTIONS[self.getParameterValue(self.METHODS)]
        m_SOURCE_ID = None
        m_REFERENCE_layer = None

        m_MULTIFIELDS = self.getParameterValue(self.MULTIFIELDS)
        if m_MULTIFIELDS is None or len(m_MULTIFIELDS)==0:
            raise GeoAlgorithmExecutionException("Please select some fields to calculate!")

        m_METHODS_DISSOLVE = self.METHODS_DISSOLVE_OPTIONS[self.getParameterValue(self.METHODS_DISSOLVE)]
        METHODS_FUNS = {'Sum': self.sum,'Arithmetic Mean':self.mean,'Median':self.median,
                        "Min":self.min,'Max':self.max,"Geometric Mean":self.geomean,"Interquartile Mean":self.midmean}


        if m_METHODS=='ID':
            m_SOURCE_ID = self.getParameterValue(self.SOURCE_ID)
            id_idx = sourceLayer.fields().indexFromName(m_SOURCE_ID)

            # ensure the fields have the correct order, since user could select fields not in original ordere
            fields = sourceLayer.fields()
            neededFields_dic = {}
            m_MULTIFIELDS.insert(0,m_SOURCE_ID)
            for f in fields:
                if f.name() in m_MULTIFIELDS:
                    neededFields_dic[f.name()] = f
            neededFields = [neededFields_dic[n] for n in m_MULTIFIELDS]

            writer = self.getOutputFromName(self.OUTPUT).getVectorWriter(neededFields,
                                                                         QgsWkbTypes.multiType(sourceLayer.wkbType()),
                                                                         sourceLayer.crs(),{"pk":m_SOURCE_ID})
            outFeat = QgsFeature()

            field_indexes = [sourceLayer.fields().indexFromName(f) for f in m_MULTIFIELDS]
            request = QgsFeatureRequest().setSubsetOfAttributes(field_indexes)#.setFlags(QgsFeatureRequest.NoGeometry)

            field_indexes.remove(id_idx)

            if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                    and sourceLayer.selectedFeatureCount() > 0:

                feats = sourceLayer.getSelectedFeatures(request)
                count = int(sourceLayer.selectedFeatureCount())
            else:
                feats = sourceLayer.getFeatures(request)
                count = int(sourceLayer.featureCount())

            total = 100.0 / count if count > 0 else 1

            attribute_dict = defaultdict(lambda: [])
            geometry_dict = defaultdict(lambda: [])

            for inFeat in feats:
                attrs = inFeat.attributes()

                index_attrs = attrs[id_idx]

                tmpInGeom = QgsGeometry(inFeat.geometry())
                if tmpInGeom.isEmpty():
                    continue
                errors = tmpInGeom.validateGeometry()
                if len(errors) != 0:
                    for error in errors:
                        ProcessingLog.addToLog(ProcessingLog.LOG_ERROR,
                                               self.tr('ValidateGeometry() '
                                                       'error: One or more input'
                                                       'features have invalid '
                                                       'geometry: ')
                                               + error.what())
                temp_attrs = []
                for fi in field_indexes:
                    temp_attrs.append(attrs[fi])
                attribute_dict[index_attrs].append(temp_attrs)
                geometry_dict[index_attrs].append(tmpInGeom)

            nFeat = len(attribute_dict) if len(attribute_dict) > 0 else 1

            nElement = 0
            for key, value in geometry_dict.items():
                # outFeat = QgsFeature()
                nElement += 1
                progress.setPercentage(int(nElement * 100 / nFeat))
                try:
                    tmpOutGeom = QgsGeometry.unaryUnion(value)  #
                except:
                    raise GeoAlgorithmExecutionException(
                        self.tr('Geometry exception while dissolving'))
                outFeat.setGeometry(tmpOutGeom)
                temp_attrs = METHODS_FUNS[m_METHODS_DISSOLVE](attribute_dict[key],field_indexes)
                temp_attrs.insert(0,key)
                outFeat.setAttributes(temp_attrs)
                writer.addFeature(outFeat)

            del writer

        elif m_METHODS=='LOCATION':
            REFERENCE_param = self.getParameterFromName(self.REFERENCE)
            m_REFERENCE_layer = REFERENCE_param.getLayerObject()  # will use this to select features from source layer
            m_REFERENCE_ID = self.getParameterValue(self.REFERENCE_ID)

            fields = m_REFERENCE_layer.fields()
            referenceField = None
            referenceField_idx = -1
            for i,f in enumerate(fields):
                if f.name()==m_REFERENCE_ID:
                    referenceField = f
                    referenceField_idx = i
                    break
            # ensure the fields have the correct order, since user could select fields not in original ordere
            fields = sourceLayer.fields()
            neededFields_dic = {}
            for f in fields:
                if f.name() in m_MULTIFIELDS:
                    neededFields_dic[f.name()] = f
            neededFields = [neededFields_dic[n] for n in m_MULTIFIELDS]
            neededFields.insert(0,referenceField)
            writer = self.getOutputFromName(self.OUTPUT).getVectorWriter(neededFields,
                                                                         QgsWkbTypes.multiType(m_REFERENCE_layer.wkbType()),
                                                                         m_REFERENCE_layer.crs(),{"pk":m_REFERENCE_ID})
            outFeat = QgsFeature()

            # first build up a list of clip geometries
            clip_ids = []
            clip_geoms = []

            request = QgsFeatureRequest().setSubsetOfAttributes([referenceField_idx])
            if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                    and m_REFERENCE_layer.selectedFeatureCount() > 0:
                feats = m_REFERENCE_layer.getSelectedFeatures(request)
                clip_count = int(m_REFERENCE_layer.selectedFeatureCount())
            else:
                feats = m_REFERENCE_layer.getFeatures(request)
                clip_count = int(m_REFERENCE_layer.featureCount())
            for maskFeat in feats:
                clip_ids.append(maskFeat[referenceField_idx])
                clip_geoms.append(QgsGeometry(maskFeat.geometry()))

            field_indexes = [sourceLayer.fields().indexFromName(f) for f in m_MULTIFIELDS]
            request = QgsFeatureRequest().setSubsetOfAttributes(field_indexes)#.setFlags(QgsFeatureRequest.NoGeometry)
            if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                    and sourceLayer.selectedFeatureCount() > 0:
                feats = sourceLayer.getSelectedFeatures(request)
                source_count = int(sourceLayer.selectedFeatureCount())
            else:
                feats = sourceLayer.getFeatures(request)
                source_count = int(sourceLayer.featureCount())
            source_data = {}
            index = QgsSpatialIndex()
            for ft in feats:
                index.insertFeature(ft)
                source_data[ft.id()] = ft
            da = QgsDistanceArea()
            da.setSourceCrs(m_REFERENCE_layer.crs().srsid())
            for i, clip_geom in enumerate(clip_geoms):
                attribute_dict = defaultdict(lambda: [])
                # get boundingbox of clip_geom
                bbox = clip_geom.boundingBox() # TODO point and line situation
                # get the spatial index set of intersection
                joinList = index.intersects(bbox)
                # for each intersection id
                if len(joinList) > 0:
                    for ind_j in joinList:
                        inFeatS = source_data[ind_j]
                        inGeomS = QgsGeometry(inFeatS.geometry())

                        # check whether intersect is true
                        res = clip_geom.intersects(inGeomS)
                        if res == True:
                            # if
                            # check if contains
                            if not sourceLayer.geometryType()==QgsWkbTypes.PointGeometry:
                                # polygons or lines
                                if not clip_geom.contains(inGeomS):
                                    if not clip_geom.touches(inGeomS):
                                        # calculate the area propotion
                                        cur_geom = QgsGeometry(inFeatS.geometry())
                                        new_geom = clip_geom.intersection(cur_geom)
                                        # int_com = in_feat.constGeometry().combine(new_geom)
                                        int_sym = cur_geom.symDifference(new_geom)
                                        if sourceLayer.geometryType()==QgsWkbTypes.LineGeometry:
                                            new_geom_a = da.measureLength(new_geom)
                                            int_sym_a = da.measureLength(int_sym)
                                        elif sourceLayer.geometryType()==QgsWkbTypes.PolygonGeometry:
                                            new_geom_a = da.measureArea(new_geom)
                                            int_sym_a = da.measureArea(int_sym)
                                        else:
                                            raise GeoAlgorithmExecutionException("Unexpected Geometry!")
                                        # cur_geom_a = da.measureArea(cur_geom)
                                        # a = cur_geom_a - new_geom_a - int_sym_a
                                        ratio = new_geom_a/(new_geom_a+int_sym_a)
                                        if ratio > 10e-6:
                                            temp_attrs = []
                                            for fi in field_indexes:
                                                if inFeatS[fi]==NULL:
                                                    temp_attrs.append(NULL)
                                                else:
                                                    temp_attrs.append(inFeatS[fi]*ratio)
                                            attribute_dict[clip_ids[i]].append(temp_attrs)
                                else:
                                    # save the attributes to dict
                                    temp_attrs = []
                                    for fi in field_indexes:
                                        temp_attrs.append(inFeatS[fi])
                                    attribute_dict[clip_ids[i]].append(temp_attrs)
                            else:
                                # save the attributes to dict
                                temp_attrs = []
                                for fi in field_indexes:
                                    temp_attrs.append(inFeatS[fi])
                                attribute_dict[clip_ids[i]].append(temp_attrs)
                # calculate the final results
                # write to output file

                temp_attrs = METHODS_FUNS[m_METHODS_DISSOLVE](attribute_dict[clip_ids[i]],field_indexes)
                temp_attrs.insert(0,clip_ids[i])
                outFeat.setAttributes(temp_attrs)
                outFeat.setGeometry(clip_geom)
                writer.addFeature(outFeat)

            del writer

    def sum(self,attrs,fields_list):
        rows = len(attrs)
        cols = len(fields_list)
        res_list = [NULL]*cols
        if attrs:
            data_ = np.matrix(attrs)
            for col in range(cols):
                a = data_[:,col]
                b = a != NULL
                cur_r = sum(b)[0,0]
                if cur_r>0:
                    sum_factor = np.matrix([1] * cur_r)
                    res = sum_factor.dot(a[b].T)
                    res_list[col]= res.tolist()[0][0]
                else:
                    res_list[col] = NULL
        return res_list
    def geomean(self,attrs,fields_list):
        res_list = [NULL]*len(fields_list)
        cols = len(fields_list)
        if attrs:
            data_ = np.matrix(attrs)
            for col in range(cols):
                a = data_[:,col]
                b = a != NULL
                cur_r = sum(b)[0,0]
                if cur_r>0:
                    res = gmean(a[b].T, axis=0,dtype=float)
                    res_list[col] = res.tolist()[0]
                else:
                    res_list[col] = NULL
        return res_list

    def midmean(self,attrs,fields_list):
        res_list = [NULL]*len(fields_list)
        cols = len(fields_list)
        if attrs:
            data_ = np.matrix(attrs)
            for col in range(cols):
                a = data_[:,col]
                b = a != NULL
                cur_r = sum(b)[0,0]
                c = a[b].tolist()[0]
                if cur_r>2:
                    n = float(len(c))
                    upperIdx = int(math.floor(3.0*n/4.0))-1
                    lowerIdx = int(math.ceil(n / 4.0))-1
                    x_iqm = 2.0/n*(sum(c[(lowerIdx + 1):(upperIdx)])
                                   +(c[lowerIdx] + c[upperIdx+1])/2*(n/2.0-(upperIdx - lowerIdx)))
                    res_list[col] = x_iqm
                elif cur_r>0:
                    n = float(len(c))
                    res_list[col] = sum(c)/n
                else:
                    res_list[col] = NULL
        return res_list

    def mean(self,attrs,fields_list):
        rows = len(attrs)
        cols = len(fields_list)
        res_list = [NULL]*cols
        if attrs:
            data_ = np.matrix(attrs)
            for col in range(cols):
                a = data_[:,col]
                b = a != NULL
                cur_r = sum(b)[0,0]
                if cur_r>0:
                    sum_factor = np.matrix([1.0/cur_r]*cur_r)
                    res = sum_factor.dot(a[b].T)
                    res_list[col] = res.tolist()[0][0]
                else:
                    res_list[col] = NULL
        return res_list
    def median(self,attrs,fields_list):
        res_list = [NULL]*len(fields_list)
        cols = len(fields_list)
        if attrs:
            data_ = np.matrix(attrs)
            for col in range(cols):
                a = data_[:,col]
                b = a != NULL
                cur_r = sum(b)[0,0]
                if cur_r>0:
                    res = np.median(a[b].T, axis=0)
                    res_list[col] = res.tolist()[0][0]
                else:
                    res_list[col] = NULL
        return res_list
    def min(self,attrs,fields_list):
        res_list = [NULL]*len(fields_list)
        cols = len(fields_list)
        if attrs:
            data_ = np.matrix(attrs)
            for col in range(cols):
                a = data_[:,col]
                b = a != NULL
                cur_r = sum(b)[0,0]
                if cur_r>0:
                    res = (a[b].T).min(0)
                    res_list[col] = res.tolist()[0][0]
                else:
                    res_list[col] = NULL
        return res_list

    def max(self,attrs,fields_list):
        res_list = [NULL]*len(fields_list)
        cols = len(fields_list)
        if attrs:
            data_ = np.matrix(attrs)
            for col in range(cols):
                a = data_[:,col]
                b = a != NULL
                cur_r = sum(b)[0,0]
                if cur_r>0:
                    res = (a[b].T).max(0)
                    res_list[col] = res.tolist()[0][0]
                else:
                    res_list[col] = NULL
        return res_list

class ParameterMultiFields(Parameter):
    DATA_TYPE_NUMBER = 0
    DATA_TYPE_STRING = 1
    DATA_TYPE_ANY = -1

    def __init__(self, name='', description='', parent=None, datatype=-1,
                 optional=False,default = None):
        Parameter.__init__(self, name, description, None, optional)
        self.parent = parent
        self.datatype = int(datatype)
        self.default = default

    def setValue(self, obj):
        if obj is None:
            if self.optional:
                self.value = None
                return True
            return False

        if isinstance(obj, list):
            if len(obj) == 0:
                if self.optional:
                    self.value = None
                    return True
                return False
            self.value = obj
            return True
        else:
            self.value = str(obj)
            return True

    def __str__(self):
        return self.name + ' <' + self.__module__.split('.')[-1] + ' from ' \
            + self.parent + '>'

    def dataType(self):
        if self.datatype == self.DATA_TYPE_NUMBER:
            return 'numeric'
        elif self.datatype == self.DATA_TYPE_STRING:
            return 'string'
        else:
            return 'any'
class multifieldsSelectionPanel(QWidget):
    def __init__(self,param):
        QWidget.__init__(self)
        self.param = param
        self.setObjectName("widget_2")
        self.horizontalLayout = QHBoxLayout(self)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setMargin(0)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.label = QLabel(self)
        font = QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.verticalLayout_6.addWidget(self.label)
        self.unselected_widget = QTableWidget(self)
        self.unselected_widget.setObjectName("unselected_widget")
        # self.unselected_widget.resize(100,550)
        self.verticalLayout_6.addWidget(self.unselected_widget)
        self.horizontalLayout.addLayout(self.verticalLayout_6)
        self.unselected_widget.insertColumn(0)
        self.unselected_widget.setHorizontalHeaderItem(0, QTableWidgetItem("Fields"))
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        self.unselected_widget.setSizePolicy(sizePolicy)
        self.unselected_widget.setMinimumSize(QSize(50, 250))

        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.select_btn = QPushButton(self)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.select_btn.sizePolicy().hasHeightForWidth())
        self.select_btn.setSizePolicy(sizePolicy)
        self.select_btn.setMaximumSize(QSize(30, 30))
        self.select_btn.setObjectName("select_btn")
        self.verticalLayout_5.addWidget(self.select_btn)
        self.deselect_btn = QPushButton(self)

        self.deselect_btn.setSizePolicy(sizePolicy)
        self.deselect_btn.setMaximumSize(QSize(30, 30))
        self.deselect_btn.setObjectName("deselect_btn")
        self.verticalLayout_5.addWidget(self.deselect_btn)

        self.horizontalLayout.addLayout(self.verticalLayout_5)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.label_2 = QLabel(self)
        font = QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_4.addWidget(self.label_2)
        self.selected_widget = QTableWidget(self)
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(1)
        self.selected_widget.setSizePolicy(sizePolicy)

        self.selected_widget.setObjectName("selected_widget")
        self.verticalLayout_4.addWidget(self.selected_widget)
        self.horizontalLayout.addLayout(self.verticalLayout_4)

        self.selected_widget.setAlternatingRowColors(True)
        self.selected_widget.setSortingEnabled(True)
        self.selected_widget.setDragEnabled(False)
        self.selected_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.selected_widget.setDragDropOverwriteMode(False)
        self.selected_widget.setDefaultDropAction(Qt.MoveAction)
        self.selected_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.selected_widget.setSelectionBehavior(QAbstractItemView.SelectItems)
        # self.selected_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.unselected_widget.setAlternatingRowColors(True)
        self.unselected_widget.setSortingEnabled(True)
        self.unselected_widget.setDragEnabled(False)
        self.unselected_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.unselected_widget.setDragDropOverwriteMode(False)
        self.unselected_widget.setDefaultDropAction(Qt.MoveAction)
        self.unselected_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.unselected_widget.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.unselected_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.label_2.setText("Selected Fields")
        self.select_btn.setText(">")
        self.deselect_btn.setText("<")
        self.label.setText("Available Fields")

        self.pop_tableview(self.selected_widget)

        self.init_signals()
    def getLabel(self):
        desc = self.param.description
        label = QLabel(desc)
        return label
    def init_signals(self):
        self.select_btn.clicked.connect(self._select)
        self.deselect_btn.clicked.connect(self._deselect)

        self.unselected_widget.itemDoubleClicked.connect(self._select)
        self.selected_widget.itemDoubleClicked.connect(self._deselect)

        #self.selected_widget.keyPressEvent.connect(self.keypress)
    def pop_tableview(self,table):
        #table = QTableWidget(table)
        colnames = ["Fields"]
        ncol = len(colnames)
        data = [[""]]

        for i in range(ncol):
            table.insertColumn(i)
            table.setHorizontalHeaderItem(i,QTableWidgetItem(colnames[i]))
        nrow = len(data[0])
        ncol = len(data)
        for i in range(nrow):
            table.insertRow(i)
        for j in range(ncol):
            for i in range(nrow):
                item_t = QTableWidgetItem(str(data[j][i]))
                item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                # if j==1:
                #     item_t.setFlags(Qt.ItemIsSelectable |  Qt.ItemIsEnabled | Qt.ItemIsEditable)
                table.setItem(i,j,item_t)

    def _select(self):
        self._do_move_f2t(self.unselected_widget, self.selected_widget)

    def _deselect(self):
        self._do_move_t2f(self.unselected_widget, self.selected_widget)

    def _do_move_t2f(self, fromList, toList):
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        if len(targets)==0:
            return
        target = targets[0]
        t_row = toList.row(target)
        t_col = toList.column(target)
        if t_col!=0:
            return
        try:
            ind = self.fieldslist.index(target.text())
        except:
            return

        prev_from_item = toList.item(t_row,t_col)
        fromList.setItem(ind,0,toList.takeItem(t_row, t_col))
        toList.removeRow(t_row)

        fromList.setCurrentCell(ind,0,QItemSelectionModel.Select)
        fromList.scrollToItem(prev_from_item)

    def _do_move_f2t(self, fromList, toList):
        recover = False
        temp = None
        add_to_last = True
        insert = False
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        nrows = toList.rowCount()
        # No selection
        if len(targets)==0:
            # find the first empty element
            for i in range(nrows):
                t_i = toList.item(i,0)
                if t_i.text()=="":
                    t_row = toList.row(t_i)
                    t_col = toList.column(t_i)
                    break
        else:
            # has selection
            target = targets[0]
            t_row = toList.row(target)
            t_col = toList.column(target)
            if t_col!=0:
                t_col = 0
                t_row = nrows - 1
            else:

                if target.text()!="":
                    recover=True
                    temp = target.text()
                    add_to_last = False
                    insert = True

        if t_row==-1:
            return
        if add_to_last:
            toList.insertRow(nrows)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(nrows,0,item_t)
            # item_t = QTableWidgetItem("")
            # item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            # toList.setItem(nrows, 1, item_t)

        if insert:
            toList.insertRow(t_row+1)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(t_row+1,0,item_t)
            # item_t = QTableWidgetItem("")
            # item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            # toList.setItem(t_row+1, 1, item_t)
            # combo_box_options = ["Positive", "Negative"]
            # combo = QComboBox()
            # for t in combo_box_options:
            #     combo.addItem(t)
            # toList.setCellWidget(t_row+1,2,combo)
            t_row = t_row + 1
        for item in fromList.selectedItems():
            f_row = fromList.row(item)
            f_col = fromList.column(item)
            prev_from_item = fromList.item(f_row,f_col)
            toList.setItem(t_row,t_col,fromList.takeItem(f_row,f_col))
            # combo_box_options = ["Positive", "Negative"]
            # combo = QComboBox()
            # for t in combo_box_options:
            #     combo.addItem(t)
            # toList.setCellWidget(t_row,2,combo)
            fromList.scrollToItem(prev_from_item)

        # if recover:
        #     ind = self.fieldslist.index(temp)
        #     fromList.setItem(ind, 0, QTableWidgetItem(temp))
        toList.clearSelection()
        toList.setCurrentCell(t_row, 0, QItemSelectionModel.Select)
        #toList.setCurrentCell(t_row, 1, QItemSelectionModel.Select)
    def get_selected_items(self):
        """
        :return list with all the selected items text
        """
        return self._get_items(self.selected_widget)
    def _get_items(self, widget):
        for i in range(widget.rowCount()-1):
            yield widget.item(i,0).text()
    def clear(self):
        widget = self.unselected_widget
        widget_sele = self.selected_widget
        widget.setRowCount(0)
        widget_sele.setRowCount(0)
        widget_sele.insertRow(0)
        widget_sele.setItem(0, 0, QTableWidgetItem(""))
    def addItem(self,item):
        widget = self.unselected_widget
        i = widget.rowCount()
        widget.insertRow(i)
        item_t = QTableWidgetItem(str(item))
        item_t.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        widget.setItem(i, 0, item_t)
    def addItems(self,items):
        for item in items:
            self.addItem(item)
        self.fieldslist = items
    def findText(self,item):
        widget = self.unselected_widget
        rows = widget.rowCount()
        for i in range(rows):
            item_t = widget.item(i,0)
            if item_t.text()==str(item):
                return i
    def setCurrentIndex(self,ind):
        widget = self.unselected_widget
        rows = widget.rowCount()
        if ind<rows:
            widget.selectRow(ind)
class FieldType(object):
    DATA_TYPE_ID = 0
    DATA_TYPE_NUMERIC = 1
    DATA_TYPE_ALL = -1
class AggregationLDialog(AlgorithmDialogBase):
    def __init__(self,alg):
        AlgorithmDialogBase.__init__(self,alg)

        self.alg = alg
        self.checkBoxes = {}
        self.dependentItems = {}
        self.iterateButtons = {}
        self.mainWidget = self.MainPanel()
        self.setMainWidget()

        self.cornerWidget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0,0,0,5) #void QLayout::setContentsMargins(int left, int top, int right, int bottom)
        self.tabWidget.setStyleSheet("QTabBar::tab { height: 30px; }")
        #self.runAsBatchButton = QPushButton(self.tr("Run as batch process..."))
        #self.runAsBatchButton.clicked.connect(self.runAsBatch)
        #layout.addWidget(self.runAsBatchButton)
        # self.cornerWidget.setLayout(layout)
        # self.tabWidget.setCornerWidget(self.cornerWidget)

        QgsProject.instance().layerWasAdded.connect(self.layerAdded_aggre)
        QgsProject.instance().layersWillBeRemoved.connect(self.layersWillBeRemoved_aggre)
    def MainPanel(self):
        myForm = QWidget()
        #         myForm.setObjectName("From")
        #         # myForm.resize(400,200) #resize(int w, int h)
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 100, QSizePolicy.Minimum, QSizePolicy.Preferred)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}
        self.widgets = {}
        self.labels = {}

        # add 1 parameter ParameterVector_RDBMS======(self.alg.SOURCE)==================================================
        param = self.alg.getParameterFromName(self.alg.SOURCE)
        layers = dataobjects.getVectorLayers(param.shapetype) # 2 Polygon
        items = []
        for layer in layers:
            items.append((layer.name(), layer))

        widget = InputLayerRDBMSelectorPanel(items, param)
        widget.cmbText.name = param.name
        widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)

        desc = param.description
        label = QLabel(desc)

        self.labels[param.name] = label
        self.widgets[param.name] = widget
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)

        # add 2 parameter ParameterSelection======(self.alg.METHODS)====================================================
        # METHODS_OPTIONS = ['ID', 'LOCATION']
        param = self.alg.getParameterFromName(self.alg.METHODS)
        desc = param.description
        label = QLabel(desc)
        self.labels[param.name] = label
        item = QComboBox()
        item.addItems(param.options)
        if param.default:
            item.setCurrentIndex(param.default)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        self.widgets[param.name] = item
        def indchanged(ind):
            paramSourceID = self.alg.getParameterFromName(self.alg.SOURCE_ID)
            paramREFERENCE = self.alg.getParameterFromName(self.alg.REFERENCE)
            paramREFERENCE_ID = self.alg.getParameterFromName(self.alg.REFERENCE_ID)
            if ind == 0:
                self.widgets["SOURCE_ID"].show()
                self.labels["SOURCE_ID"].show()
                paramSourceID.hidden = False
                self.widgets["REFERENCE"].hide()
                self.labels["REFERENCE"].hide()
                paramREFERENCE.hidden = True
                self.widgets["REFERENCE_ID"].hide()
                self.labels["REFERENCE_ID"].hide()
                paramREFERENCE_ID.hidden = True
            elif ind==1:
                self.widgets["SOURCE_ID"].hide()
                self.labels["SOURCE_ID"].hide()
                paramSourceID.hidden = True
                self.widgets["REFERENCE"].show()
                self.labels["REFERENCE"].show()
                paramREFERENCE.hidden = False
                self.widgets["REFERENCE_ID"].show()
                self.labels["REFERENCE_ID"].show()
                paramREFERENCE_ID.hidden = False
        item.currentIndexChanged.connect(indchanged)

        # add 3 parameter ParameterTableField======(self.alg.SOURCE_ID)=================================================
        param = self.alg.getParameterFromName(self.alg.SOURCE_ID)
        item = QComboBox()
        desc = param.description
        label = QLabel(desc)
        if param.parent in self.dependentItems:
            items = self.dependentItems[param.parent]
        else:
            items = []
            self.dependentItems[param.parent] = items
        items.append(param)
        parent = self.alg.getParameterFromName(param.parent)

        self.labels[param.name] = label
        self.widgets[param.name] = item
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        # add 4 parameter ParameterVector_RDBMS======(self.alg.REFERENCE)===============================================
        param = self.alg.getParameterFromName(self.alg.REFERENCE)
        layers = dataobjects.getVectorLayers(param.shapetype) # 2 Polygon
        items = []
        for layer in layers:
            items.append((layer.name(), layer))

        widget = InputLayerRDBMSelectorPanel(items, param)
        widget.cmbText.name = param.name
        widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)

        desc = param.description
        label = QLabel(desc)

        self.labels[param.name] = label
        self.widgets[param.name] = widget
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)

        # add 5 parameter ParameterTableField======(self.alg.REFERENCE_ID)=================================================
        param = self.alg.getParameterFromName(self.alg.REFERENCE_ID)
        item = QComboBox()
        desc = param.description
        label = QLabel(desc)
        if param.parent in self.dependentItems:
            items = self.dependentItems[param.parent]
        else:
            items = []
            self.dependentItems[param.parent] = items
        items.append(param)
        self.labels[param.name] = label
        self.widgets[param.name] = item
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        # # add 6 parameter ParameterMultiFields======(self.alg.MULTIFIELDS)=================================================
        param = self.alg.getParameterFromName(self.alg.MULTIFIELDS)
        widget = multifieldsSelectionPanel(param)
        label = widget.getLabel()

        if param.parent in self.dependentItems:
            items = self.dependentItems[param.parent]
        else:
            items = []
            self.dependentItems[param.parent] = items
        items.append(param)
        self.labels[param.name] = label
        self.widgets[param.name] = widget
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)

        # add 7 parameter ParameterSelection======(self.alg.METHODS_DISSOLVE)=================================================
        param = self.alg.getParameterFromName(self.alg.METHODS_DISSOLVE)
        desc = param.description
        label = QLabel(desc)
        self.labels[param.name] = label
        item = QComboBox()
        item.addItems(param.options)
        if param.default:
            item.setCurrentIndex(param.default)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        self.labels[param.name] = label
        self.widgets[param.name] = item

        # self.addOutput(OutputVector(self.OUTPUT, self.tr('Output Aggregation Layer')))
        output = self.alg.outputs[0]
        label = QLabel(output.description)
        widget_out = OutputSelectionPanel(output, self.alg)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, widget_out)
        self.labels[param.name] = label
        self.widgets[output.name] = widget_out

        check = QCheckBox()
        check.setText(self.tr('Open output file after running algorithm'))
        check.setChecked(False)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, check)
        self.checkBoxes[output.name] = check

        widget = self.widgets[self.alg.METHODS]
        ind = widget.currentIndex()
        widget.currentIndexChanged.emit(ind)

        widget = self.widgets[self.alg.SOURCE]
        ind = widget.cmbText.currentIndex()
        widget.cmbText.currentIndexChanged.emit(ind)

        widget = self.widgets[self.alg.REFERENCE]
        ind = widget.cmbText.currentIndex()
        widget.cmbText.currentIndexChanged.emit(ind)
        return myForm

    def runAsBatch(self):
        pass

    def setParamValues(self):
        params = self.alg.parameters
        outputs = self.alg.outputs

        for param in params:
            if param.hidden:
                continue
            if not self.setParamValue(
                    param, self.widgets[param.name]):
                raise AlgorithmDialogBase.InvalidParameterValue(
                    param, self.widgets[param.name])

        for output in outputs:
            if output.hidden:
                continue
            output.value = self.widgets[output.name].getValue()
            if isinstance(output, (OutputRaster, OutputVector, OutputTable,OutputVector_liu)):
                output.open = self.checkBoxes[output.name].isChecked()
        return True

    def setParamValue(self, param, widget, alg=None):
        if isinstance(param, ParameterRaster):
            return param.setValue(widget.getValue())
        elif isinstance(param,(ParameterVector_RDBMS)):
            return param.setValue(widget.getValue())
        elif isinstance(param, (ParameterVector)):
            try:
                return param.setValue(widget.itemData(widget.currentIndex()))
            except:
                return param.setValue(widget.getValue())
        elif isinstance(param, ParameterSelection):
            return param.setValue(widget.currentIndex())
        elif isinstance(param, ParameterTableField):
            if param.optional and widget.currentIndex() == 0:
                return param.setValue(None)
            return param.setValue(widget.currentText())
        elif isinstance(param,ParameterMultiFields):
            if param.optional and len(list(widget.get_selected_items())) == 0:
                return param.setValue(None)
            return param.setValue(list(widget.get_selected_items()))

    def accept(self):
        self.settings.setValue("/Processing/dialogBase", self.saveGeometry())

        checkCRS = ProcessingConfig.getSetting(ProcessingConfig.WARN_UNMATCHING_CRS)
        try:
            self.setParamValues()
            if checkCRS and not self.alg.checkInputCRS():
                reply = QMessageBox.question(self, self.tr("Unmatching CRS's"),
                                             self.tr('Layers do not all use the same CRS. This can '
                                                     'cause unexpected results.\nDo you want to '
                                                     'continue?'),
                                             QMessageBox.Yes | QMessageBox.No,
                                             QMessageBox.No)
                if reply == QMessageBox.No:
                    return

            msg = self.alg._checkParameterValuesBeforeExecuting()
            if msg:
                QMessageBox.warning(
                    self, self.tr('Unable to execute algorithm'), msg)
                return
            self.btnRun.setEnabled(False)
            self.btnClose.setEnabled(False)
            buttons = self.iterateButtons
            self.iterateParam = None

            for i in range(len(buttons.values())):
                button = buttons.values()[i]
                if button.isChecked():
                    self.iterateParam = buttons.keys()[i]
                    break

            self.progressBar.setMaximum(0)
            self.lblProgress.setText(self.tr('Processing algorithm...'))
            # Make sure the Log tab is visible before executing the algorithm
            try:
                self.tabWidget.setCurrentIndex(1)
                self.repaint()
            except:
                pass

            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))

            self.setInfo(
                self.tr('<b>Algorithm %s starting...</b>') % self.alg.name)

            if self.iterateParam:
                if runalgIterating(self.alg, self.iterateParam, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
            else:
                command = self.alg.getAsCommand()
                if command:
                    ProcessingLog.addToLog(
                        ProcessingLog.LOG_ALGORITHM, command)
                if runalg(self.alg, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
        except AlgorithmDialogBase.InvalidParameterValue as e:
            try:
                self.buttonBox.accepted.connect(lambda:
                                                e.widget.setPalette(QPalette()))
                palette = e.widget.palette()
                palette.setColor(QPalette.Base, QColor(255, 255, 0))
                e.widget.setPalette(palette)
                self.lblProgress.setText(
                    self.tr('<b>Missing parameter value: %s</b>') % e.parameter.description)
                return
            except:
                QMessageBox.critical(self,
                                     self.tr('Unable to execute algorithm'),
                                     self.tr('Wrong or missing parameter values'))
    def reject(self):
        self.done(0)
    def finish(self):
        keepOpen = ProcessingConfig.getSetting(ProcessingConfig.KEEP_DIALOG_OPEN)

        if self.iterateParam is None:
            if not handleAlgorithmResults(self.alg, self, not keepOpen):
                self.resetGUI()
                return

        self.executed = True
        self.setInfo('Algorithm %s finished' % self.alg.name)
        QApplication.restoreOverrideCursor()

        if not keepOpen:
            self.close()
        else:
            self.resetGUI()
            if self.alg.getHTMLOutputsCount() > 0:
                self.setInfo(
                    self.tr('HTML output has been generated by this algorithm.'
                            '\nOpen the results dialog to check it.'))
    def closeEvent(self, evt):
        # ProcessingLog.addToLog(ProcessingLog.LOG_INFO, "AggregationDLG Close")
        QgsProject.instance().layerWasAdded.disconnect(self.layerAdded_aggre)
        QgsProject.instance().layersWillBeRemoved.disconnect(self.layersWillBeRemoved_aggre)
        super(AggregationLDialog, self).closeEvent(evt)

    def layerAdded_aggre(self,layer):
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    if dataobjects.canUseVectorLayer(layer, param.shapetype):
                        widget = self.widgets[param.name]
                        if isinstance(widget, InputLayerRDBMSelectorPanel) and hasattr(widget.cmbText, 'addItem'):
                            widget = widget.cmbText
                        widget.addItem(layer.name(), layer)
        elif layer.type() == QgsMapLayer.RasterLayer and dataobjects.canUseRasterLayer(layer):
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText
                    widget.addItem(self.getExtendedLayerName(layer), layer)

    def layersWillBeRemoved_aggre(self,layers):
        for layer in layers:
            self.layerRemoved(layer)
    def layerRemoved(self, layer):
        layer = QgsProject.instance().mapLayer(layer)
        widget = None
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    widget = self.widgets[param.name]
                    if isinstance(widget, InputLayerRDBMSelectorPanel):
                        widget = widget.cmbText

                        if widget is not None:
                            idx = widget.findData(layer)
                            if idx != -1:
                                widget.removeItem(idx)
                            widget = None

        elif layer.type() == QgsMapLayer.RasterLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText

                    if widget is not None:
                        idx = widget.findData(layer)
                        if idx != -1:
                            widget.removeItem(idx)
                        widget = None

    def updateDependentFields(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        if sender.name not in self.dependentItems:
            return
        layer = sender.itemData(sender.currentIndex())
        if not layer:
            return

        children = self.dependentItems[sender.name]
        for child in children:
            if (isinstance(child, ParameterTableField) or isinstance(
                    child, ParameterMultiFields)):
                widget = self.widgets[child.name]
                widget.clear()
                child_param = self.alg.getParameterFromName(child.name)
                datatype = child_param.datatype
                fieldTypes = []
                if datatype == FieldType.DATA_TYPE_ID:
                    fieldTypes = [QVariant.String, QVariant.Int, QVariant.LongLong,
                               QVariant.UInt, QVariant.ULongLong]
                elif datatype == FieldType.DATA_TYPE_NUMERIC:
                    fieldTypes = [QVariant.Int, QVariant.Double, QVariant.LongLong,
                                  QVariant.UInt, QVariant.ULongLong]

                def Spatialite2qgis(type):
                    typeTrans = {"INT": QVariant.Int, "INTEGER": QVariant.Int, "TINYINT": QVariant.Int,
                                 "SMALLINT": QVariant.Int, "MEDIUMINT": QVariant.LongLong, "BIGINT": QVariant.LongLong,
                                 "UNSIGNED BIG INT": QVariant.LongLong, "INT2": QVariant.Int, "INT8": QVariant.LongLong,
                                 "INTEGER": QVariant.LongLong, "CHARACTER": QVariant.String, "VARCHAR": QVariant.String,
                                 "VARYING CHARACTER": QVariant.String, "NCHAR": QVariant.String,
                                 "NATIVE CHARACTER": QVariant.String,
                                 "NVARCHAR": QVariant.String, "TEXT": QVariant.String, "REAL": QVariant.Double,
                                 "DOUBLE": QVariant.Double, "DOUBLE PRECISION": QVariant.Double, "FLOAT": QVariant.Double,
                                 "REAL": QVariant.Double, "NUMERIC": QVariant.Double, "DECIMAL": QVariant.Double,
                                 "BOOLEAN": QVariant.Int, "DATE": QVariant.String, "DATETIME": QVariant.String}
                    ind = type.find("(")
                    if ind > 0:
                        type = type[0:ind]
                    if type in typeTrans.keys():
                        return typeTrans[type]
                    else:
                        return None
                def Postg2qgis(type):
                    Postg2qgis = {"bigint": QVariant.LongLong, "varbinary": QVariant.ByteArray,
                                  "char": QVariant.String, "varchar": QVariant.String, "integer": QVariant.Int,
                                  "numeric": QVariant.Double, "decimal": QVariant.Double, "real": QVariant.Double,
                                  "double": QVariant.Double, "date": QVariant.String, "time": QVariant.Time,
                                  "timestamp": QVariant.String, "int": QVariant.Int, "int2": QVariant.Int,
                                  "int4": QVariant.Int, "int8": QVariant.LongLong, "text": QVariant.String,
                                  "float4": QVariant.Double, "float8": QVariant.Double, "float64": QVariant.Double}

                    ind = type.find("(")
                    if ind > 0:
                        type = type[0:ind]
                    if type in Postg2qgis.keys():
                        return Postg2qgis[type]
                    else:
                        return None

                fieldNames = []
                idfieldNames = []
                idfieldTypes = []
                # ============for ParameterVector_RDBMS
                if isinstance(layer, dict):
                    if "uri" in layer.keys():
                        uri = layer["uri"]
                        if uri.startswith(u"spatialite:"):
                            uri = uri[len(u"spatialite:"):]
                            uri = QgsDataSourceUri(uri)
                            try:
                                db = spatialite.GeoDB(uri)
                            except postgis.DbError as e:
                                raise GeoAlgorithmExecutionException(
                                    "Couldn't connect to database:\n%s" % e.message)
                                # return False
                            sql_fields = 'pragma table_info(%s)' % (uri.table())
                            c = db.con.cursor()
                            c.execute(sql_fields)
                            fields = c.fetchall()
                            for field in fields:
                                type = field[2]
                                if not fieldTypes or (Spatialite2qgis(type) is not None and Spatialite2qgis(type) in fieldTypes):
                                    fieldNames.append(field[1])
                        elif uri.startswith(u"postgis:"):
                            uri = uri[len(u"postgis:"):]
                            uri = QgsDataSourceUri(uri)
                            try:
                                db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                                                   dbname=uri.database(), user=uri.username(), passwd=uri.password())
                            except postgis.DbError as e:
                                raise GeoAlgorithmExecutionException(
                                    "Couldn't connect to database:\n%s" % e.message)
                                # return False
                            fields = db.get_table_fields(uri.table(), uri.schema())
                            for field in fields:
                                type = field.data_type
                                if not fieldTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in fieldTypes):
                                    fieldNames.append(field.name)
                        else:
                            layer = dataobjects.getObjectFromUri(uri)
                            for field in layer.fields():
                                if not fieldTypes or field.type() in fieldTypes:
                                    fieldNames.append(str(field.name()))
                else:
                    for field in layer.fields():
                        if not fieldTypes or field.type() in fieldTypes:
                            fieldNames.append(str(field.name()))
                nrow = len(fieldNames)
                widget.addItems(fieldNames)


