# -*- coding: utf-8 -*-

"""
***************************************************************************
    RandomPointsLayer.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Alexander Bruy
    Email                : alexander dot bruy at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,time
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QVariant,NULL
from qgis.core import (QgsField, QgsFeature, QgsFeatureRequest,QgsFeatureIterator)
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterNumber
from SustainAssess.core.parameters import ParameterTableField,ParameterSelection,ParameterCreateField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from networkx import DiGraph,katz_centrality

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class Katz(GeoAlgorithm):

    POLY_ZONE_VECTOR = 'POLY_ZONE_VECTOR' #poly_layer REGION_BY_WAYS_LAYER
    POLY_ZONE_ID_FIELD = 'POLY_ZONE_ID_FIELD'

    RD_EDGE_LAYER = 'RD_EDGE_LAYER'
    RD_EDGE_LAYER_ID = 'RD_EDGE_LAYER_ID'

    RD_NODE_LAYER = "RD_NODE_LAYER"
    RD_NODE_LAYER_ID = 'RD_NODE_LAYER_ID'

    RD_EDGE_LAYER_SOURCE_FIELD = 'RD_EDGE_LAYER_SOURCE_FIELD'
    RD_EDGE_LAYER_TARGET_FIELD = 'RD_EDGE_LAYER_TARGET_FIELD'

    RD_EDGE_LAYER_WEIGHT_FIELD = 'RD_EDGE_LAYER_WEIGHT_FIELD'
    RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD = 'RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD'

    ALPHA = "ALPHA"
    BETA = "BETA"
    MAX_ITER = "MAX_ITER"

    CUTOFF = "CUTOFF"
    BETWEENNESS_K = 'BETWEENNESS_K'

    PACKAGE = 'PACKAGE'
    PACKAGE_OPTIONS = ['IGRAPH','NETWORKX']

    OUTPUT_FIELD_RD_NODE = 'OUTPUT_FIELD_RD_NODE'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Centrality/Katz"
        self.name, self.i18n_name = self.trAlgorithm('Katz')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')

        self.addParameter(ParameterVector_RDBMS(self.RD_NODE_LAYER,
                                                self.tr('Roads Node Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POINT]))
        self.addParameter(ParameterTableField(self.RD_NODE_LAYER_ID,
                                          self.tr('Node ID Field'),self.RD_NODE_LAYER,defalut="id"))

        self.addParameter(ParameterVector_RDBMS(self.RD_EDGE_LAYER,
                                                self.tr('Roads Edge Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_LINE]))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_ID,
                                          self.tr('Edge ID Field'),self.RD_EDGE_LAYER,defalut="id"))

        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_SOURCE_FIELD,
                                          self.tr('Edge Source Field'),self.RD_EDGE_LAYER,defalut="source"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_TARGET_FIELD,
                                          self.tr('Edge Target Field'),self.RD_EDGE_LAYER,defalut="target"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_WEIGHT_FIELD,
                                          self.tr('Edge Weight Field'),self.RD_EDGE_LAYER,defalut="cost"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD,
                                          self.tr('Edge Reverse Weight Field'),self.RD_EDGE_LAYER,defalut="reverse_cost"))

        self.addParameter(ParameterNumber(self.ALPHA, self.tr('Alpha'), default=0.1))
        self.addParameter(ParameterNumber(self.BETA, self.tr('Beta'), default=1.0))
        self.addParameter(ParameterNumber(self.MAX_ITER, self.tr('Maximum Number of Iterations'), default=1000))
        self.addParameter(ParameterCreateField(self.OUTPUT_FIELD_RD_NODE,self.tr('Katz Result\'s Field in Node Layer'),
                                self.RD_NODE_LAYER))

    def processAlgorithm(self, progress):
        self.progress = progress
        rdedge_param = self.getParameterFromName(self.RD_EDGE_LAYER)
        self.m_RD_EDGE_LAYER = rdedge_param.getLayerObject()
        self.m_RD_EDGE_LAYER_ID = self.getParameterValue(self.RD_EDGE_LAYER_ID)
        rdnode_param = self.getParameterFromName(self.RD_NODE_LAYER)
        self.m_RD_NODE_LAYER = rdnode_param.getLayerObject()
        self.m_RD_NODE_LAYER_ID = self.getParameterValue(self.RD_NODE_LAYER_ID)

        self.m_RD_EDGE_LAYER_SOURCE_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_SOURCE_FIELD)
        self.m_RD_EDGE_LAYER_TARGET_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_TARGET_FIELD)
        self.m_RD_EDGE_LAYER_WEIGHT_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_WEIGHT_FIELD)
        self.m_RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD)

        self.m_ALPHA = self.getParameterValue(self.ALPHA)
        self.m_BETA = self.getParameterValue(self.BETA)
        self.m_MAX_ITER = self.getParameterValue(self.MAX_ITER)

        self.m_BETWEENNESS_K = 0
        # self.m_CUTOFF = self.getParameterValue(self.CUTOFF)
        self.m_PACKAGE = "NETWORKX"
        # self.m_PACKAGE = self.PACKAGE_OPTIONS[self.getParameterValue(self.PACKAGE)]
        self.m_OUTPUT_FIELD_RD_NODE = self.getParameterValue(self.OUTPUT_FIELD_RD_NODE)

        # add field to the NODE LAYER
        if not self.m_RD_NODE_LAYER.isEditable():
            self.m_RD_NODE_LAYER.startEditing()
        try:
            # start: create new field =======================================================================================
            field_name = self.m_OUTPUT_FIELD_RD_NODE
            self.m_RD_NODE_LAYER.beginEditCommand("Added attribute")
            # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
            field = QgsField(field_name, QVariant.Double, 'numeric(20,10)', 20, 10)
            mAttributeId = -1
            if (not self.m_RD_NODE_LAYER.addAttribute(field)):
                # failed to add new fields, may be already exists
                # check whether exists
                # try to get the index of the new field
                fields = self.m_RD_NODE_LAYER.fields()
                for indx in range(fields.count()):
                    if fields[indx].name() == field_name:
                        mAttributeId = indx
                        break
                if mAttributeId == -1:
                    # not exists, and add failed
                    self.m_RD_NODE_LAYER.destroyEditCommand()
                    raise GeoAlgorithmExecutionException(
                        "Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                            field.name(),
                            field.typeName()))
            else:
                # add sucess, get index of the new field
                fields = self.m_RD_NODE_LAYER.fields()
                for indx in range(fields.count()):
                    if fields[indx].name() == field_name:
                        mAttributeId = indx
                    if mAttributeId != -1:
                        break

            if mAttributeId == -1:
                self.m_RD_NODE_LAYER.destroyEditCommand()
                raise GeoAlgorithmExecutionException(
                    "Failed to add field '%s' of type '%s'. Is the field name unique?" % (
                        field.name(),
                        field.typeName()))

            # end: create new field ========================================================================================
            # start: 1.read network into memory; 2.construct the diagraph; 3. compute betweenness index=====================
            # --------1.read network into memory;---------------------
            if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                    and self.m_RD_EDGE_LAYER.selectedFeatureCount() > 0:
                feats = self.m_RD_EDGE_LAYER.getSelectedFeatures()
                count = int(self.m_RD_EDGE_LAYER.selectedFeatureCount())
            else:
                feats = self.m_RD_EDGE_LAYER.getFeatures()
                count = int(self.m_RD_EDGE_LAYER.featureCount())
            # --------2.construct the diagraph;----------------
            bt = {}
            start_time = time.time()
            ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "Start time:%s\n" % (str(start_time)))
            if self.m_PACKAGE == "NETWORKX":
                d_network = DiGraph()
                for current, feat in enumerate(feats):
                    id = feat[self.m_RD_EDGE_LAYER_ID]
                    source = feat[self.m_RD_EDGE_LAYER_SOURCE_FIELD]
                    target = feat[self.m_RD_EDGE_LAYER_TARGET_FIELD]
                    weight = feat[self.m_RD_EDGE_LAYER_WEIGHT_FIELD]
                    re_weight = feat[self.m_RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD]
                    if (weight !=NULL and weight > 0):
                        d_network.add_edge(source, target,weight=weight)
                    if (weight !=NULL and re_weight > 0):
                        d_network.add_edge(target, source,weight = re_weight)

                progress.setPercentage(int(10))
                #--------3. compute betweenness index---------------------
                bt = katz_centrality(d_network,alpha=self.m_ALPHA,beta=self.m_BETA,max_iter=self.m_MAX_ITER,weight='weight')
                progress.setPercentage(int(60))
                end_time = time.time()
                ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "NetworkX laps:%s\n" % (str(end_time - start_time)))
                # end: 1.read network into memory; 2.construct the diagraph; 3. compute betweenness index=======================
            elif self.m_PACKAGE == 'IGRAPH':
                edges = []
                # idn = 0
                # for current, feat in enumerate(feats):
                #     id = feat[self.m_RD_EDGE_LAYER_ID]
                #     source = feat[self.m_RD_EDGE_LAYER_SOURCE_FIELD]
                #     target = feat[self.m_RD_EDGE_LAYER_TARGET_FIELD]
                #     weight = feat[self.m_RD_EDGE_LAYER_WEIGHT_FIELD]
                #     re_weight = feat[self.m_RD_EDGE_LAYER_REVERSE_WEIGHT_FIELD]
                #
                #     if (weight != NULL and weight > 0):
                #         edges.append({"source": source, "target": target, "weight": weight})
                #     if (weight != NULL and re_weight > 0):
                #         edges.append({"source": target, "target": source, "weight": re_weight})
                #     progress.setPercentage(int(0 + idn * 1.0 * 10 / count))
                #     idn += 1
                #
                # g = Graph.DictList({}, edges, directed=True)
                # coff = None
                # if self.m_CUTOFF > 0:
                #     coff = self.m_CUTOFF
                # res = g.closeness(mode="ALL", cutoff=coff, weights="weight")
                # progress.setPercentage(int(55))
                # for i in range(g.vcount()):
                #     s = g.vs[i]["name"]
                #     bt[s] = res[i]
                # end_time = time.time()
                # ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "Igraph laps:%s\n" % (str(end_time - start_time)))
                # progress.setPercentage(int(60))
            # start: write results===========================================================================================
            ## write the results to the fields in RD_EDGE_LAYER------------
            # update value with new fields
            request = QgsFeatureRequest()
            request.setFlags(QgsFeatureRequest.NoGeometry)
            # is only update select features
            # request.setFilterFids( layer.selectedFeaturesIds() )
            fit = QgsFeatureIterator(self.m_RD_NODE_LAYER.getFeatures(request))  # fit:QgsFeatureIterator
            feat = QgsFeature()
            rownum = 0
            idn = 0
            while (fit.nextFeature(feat)):
                self.m_RD_NODE_LAYER.changeAttributeValue(feat.id(), mAttributeId, NULL)
                id = feat[self.m_RD_NODE_LAYER_ID]
                value = bt.get(id, None)
                if value:
                    field.convertCompatible(value)
                    self.m_RD_NODE_LAYER.changeAttributeValue(feat.id(), mAttributeId, value)
                    rownum += 1
                    progress.setPercentage(int(60 + idn * 1.0 * 40 / count))
                    idn += 1
            self.m_RD_NODE_LAYER.endEditCommand()
            modify = self.m_RD_NODE_LAYER.isModified()
            if modify:
                suc = self.m_RD_NODE_LAYER.commitChanges()
                if not suc:
                    errors = self.m_RD_NODE_LAYER.commitErrors()
                    msg = ''
                    for err in errors:
                        msg += str(err) + "\n"
                    ProcessingLog.addToLog(ProcessingLog.LOG_ERROR, msg)
                    QMessageBox.critical(None, ("Failed to update Edge Table"),
                                         (
                                             "Failed to update Edge Table,Please check the processing.log for more details."))
                    return
            progress.setPercentage(int(100))
        except Exception as e:
            raise GeoAlgorithmExecutionException(str(e))
        finally:
            self.m_RD_NODE_LAYER.rollBack()

