# -*- coding: utf-8 -*-

"""
***************************************************************************
    RandomPointsLayer.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Alexander Bruy
    Email                : alexander dot bruy at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import rpy2
import rpy2.robjects as robjects
import rpy2.rlike.container as rlc

from qgis.PyQt.QtGui import QIcon

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm

from SustainAssess.core.parameters import ParameterNumber
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.outputs import OutputFile

from SustainAssess.core.ProcessingConfig import ProcessingConfig

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
# os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class CreateSpatialWeight(GeoAlgorithm):

    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_ID_FIELD = 'POLY_ID_FIELD' #

    SPATIAL_NEIGHBOURHOOD_TYPE = "SPATIAL_NEIGHBOURHOOD_TYPE"
    SPATIAL_NEIGHBOURHOOD_TYPE_OPTIONS = ['CONTIGUITY(QUEEN)','CONTIGUITY(ROOK)', 'FIXED DISTANCE', 'KNESTEST']

    DISTANCE_KNEAREST_KLAGS = 'DISTANCE_KNEAREST_KLAGS'

    WEIGHTING_SCHEMA = 'WEIGHTING_SCHEMA'
    WEIGHTING_SCHEMA_OPTIONS = ['BINARY','INVERSE.DISTANCE']

    DISTANCE_DECAY = 'DISTANCE_DECAY'

    WEIGHTING_STYLE = "WEIGHTING_STYLE"
    WEIGHTING_STYLE_OPTIONS = ["Basic Binary Coding(B)","Row Standardised(W)","Globally Standardised(C)",
                               "C divided by the number of neighbours(U)","variance-stabilizing coding(S)"]
    WEIGHTING_STYLE_OPTIONS_CHAR =["B","W","C","U","S"]

    OUTPUTNAME = 'OUTPUTNAME'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Spatial Statistics/Create Spatial Weight"
        self.name, self.i18n_name = self.trAlgorithm('Create Spatial Weight')
        self.group, self.i18n_group = self.trAlgorithm('Spatial Statistics')
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))

        self.addParameter(ParameterTableField(self.POLY_ID_FIELD,
                                          self.tr('ID Field'),self.POLY_VECTOR))

        self.addParameter(ParameterSelection(self.SPATIAL_NEIGHBOURHOOD_TYPE,
                                             self.tr('Spatial Neighborhood Type'), self.SPATIAL_NEIGHBOURHOOD_TYPE_OPTIONS,0))

        self.addParameter(ParameterNumber(self.DISTANCE_KNEAREST_KLAGS,
                                      self.tr('Distance(Km) or K Neighbors or K lags'), 1, 100, 1.0))

        self.addParameter(ParameterSelection(self.WEIGHTING_SCHEMA,
                                             self.tr('Weighting Schema'), self.WEIGHTING_SCHEMA_OPTIONS, 0))

        self.addParameter(ParameterNumber(self.DISTANCE_DECAY, self.tr('Distance Decay'),1,10,1.0))

        # self.addParameter(ParameterSelection(self.WEIGHTING_STYLE,
        #                                      self.tr('Weighting Style'),self.WEIGHTING_STYLE_OPTIONS,1))

        self.addOutput(OutputFile(self.OUTPUTNAME, self.tr('Output Weights File'), 'gal'))


    def processAlgorithm(self, progress):

        paramInput = self.getParameterFromName(self.POLY_VECTOR)
        self.m_POLY_VECTOR = paramInput.getLayerObject()
        self.m_POLY_ID_FIELD = self.getParameterValue(self.POLY_ID_FIELD)
        self.m_SPATIAL_NEIGHBOURHOOD_TYPE = \
            self.SPATIAL_NEIGHBOURHOOD_TYPE_OPTIONS[self.getParameterValue(self.SPATIAL_NEIGHBOURHOOD_TYPE)]
        self.m_DISTANCE_KNEAREST_KLAGS = \
            self.getParameterValue(self.DISTANCE_KNEAREST_KLAGS)
        self.m_WEIGHTING_SCHEMA =\
            self.WEIGHTING_SCHEMA_OPTIONS[self.getParameterValue(self.WEIGHTING_SCHEMA)]
        self.m_DISTANCE_DECAY = self.getParameterValue(self.DISTANCE_DECAY)
        # self.m_WEIGHTING_STYLE = \
        #         self.WEIGHTING_STYLE_OPTIONS_CHAR[self.getParameterValue(self.WEIGHTING_STYLE)]
        self.m_OUTPUTNAME = self.getOutputValue(self.OUTPUTNAME)

        provider = self.m_POLY_VECTOR.dataProvider()
        sRs = provider.crs()
        projString = str(sRs.toProj4())
        # 2. get r function
        robjects.r("require(%s)" % ("sp"))[0]
        robjects.r("require(%s)" % ("spdep"))[0]
        # a = robjects.r("R.version.string")
        # robjects.r("library(%s)" % ("sp"))[0]
        # robjects.r("library(%s)" % ("spdep"))[0]
        self.CRS_ = robjects.r.get('CRS', mode='function')
        self.Polygon_ = robjects.r.get('Polygon', mode='function')
        self.Polygons_ = robjects.r.get('Polygons', mode='function')
        self.SpatialPolygons_ = robjects.r.get('SpatialPolygons', mode='function')
        self.Line_ = robjects.r.get('Line', mode='function')
        self.Lines_ = robjects.r.get('Lines', mode='function')
        self.SpatialLines_ = robjects.r.get('SpatialLines', mode='function')
        self.SpatialPoints_ = robjects.r.get('SpatialPoints', mode='function')
        self.SpatialPointsDataFrame_ = robjects.r.get('SpatialPointsDataFrame', mode='function')
        self.SpatialLinesDataFrame_ = robjects.r.get('SpatialLinesDataFrame', mode='function')
        self.SpatialPolygonsDataFrame_ = robjects.r.get('SpatialPolygonsDataFrame', mode='function')

        self.as_character_ = robjects.r.get('as.character', mode='function')
        self.data_frame_ = robjects.r.get('data.frame', mode='function')
        self.matrix_ = robjects.r.get('matrix', mode='function')
        self.unlist_ = robjects.r.get('unlist', mode='function')

        self.poly2nb_ = robjects.r.get('poly2nb', mode='function')
        self.nb2listw_ = robjects.r.get('nb2listw', mode='function')
        # moran.test(x, listw, randomisation=TRUE, zero.policy = NULL,alternative = "greater", rank = FALSE, na.action = na.fail, spChk = NULL, adjust.n = TRUE)
        self.moran_test_ = robjects.r.get('moran.test', mode='function')

        progress.setPercentage(int(25))
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_POLY_VECTOR.selectedFeatureCount() > 0:
            feats = self.m_POLY_VECTOR.getSelectedFeatures()
            count = int(self.m_POLY_VECTOR.selectedFeatureCount())
        else:
            feats = self.m_POLY_VECTOR.getFeatures()
            count = int(self.m_POLY_VECTOR.featureCount())

        fields = self.m_POLY_VECTOR.fields()
        if fields.count() <= 0:
            raise Exception("Error: Attribute table must have at least one field")
        df = {}
        types = {}
        order = []
        fid = {"fid": []}
        Coords = []
        for field in fields:
            # initial read in has correct ordering...
            name = str(field.name())
            if name==self.m_POLY_ID_FIELD:
                df[name] = []
                types[name] = int(field.type())
                order.append(name)
        for current, feat in enumerate(feats):
            geom = feat.geometry()
            attrs = feat.attributes()
            for (key, value) in df.items():
                # df[key].append(feat.attributes()[provider.fields().indexFromName(key)])
                val = attrs[provider.fields().indexFromName(key)]
                if val:
                    df[key].append(feat[key])
                else:
                    raise Exception("Error: ID Field %s contains NULL value!"%self.m_POLY_ID_FIELD)
                    return
            fid["fid"].append(feat.id())
            if not self.getNextGeometry(Coords, feat):
                raise Exception("Error: Unable to convert layer geometry")

        progress.setPercentage(int(50))
        tmp = []
        for key in order:
            if types[key] == 10:
                tmp.append((str(key), self.as_character_(robjects.StrVector(df[key]))))
            else:
                tmp.append((str(key), robjects.FloatVector(df[key])))
        try:
            data_frame = rlc.OrdDict(tmp)
        except:
            data_frame = rlc.OrdDict(tmp)

        data_frame = robjects.DataFrame(data_frame)
        spds = self.createSpatialDataset(feat.geometry().type(), Coords, data_frame, projString)

        robjects.r.assign(str("r_inputPoly"), spds)
        # version 1
        arg1 = {"input":"r_inputPoly",
                "layer_name":self.m_POLY_VECTOR.name(),
                "input_id":self.m_POLY_ID_FIELD,
                "type":self.m_SPATIAL_NEIGHBOURHOOD_TYPE,
                "value": str(self.m_DISTANCE_KNEAREST_KLAGS),
                "style":'W',
                "w_schema":self.m_WEIGHTING_SCHEMA.lower(),
                "distance_decay":str(self.m_DISTANCE_DECAY),
                "outputfile": self.m_OUTPUTNAME.replace("\\",'/')
                }
        # r_command='saveRDS(r_inputPoly,"C:/Users/qliu20/Kent/temp/input_weight.rds")'
        # robjects.r(r_command)
        r_command = '''
                input <- %(input)s
                type <- '%(type)s'
                value <- %(value)s
                style <- '%(style)s'
                w_schema = '%(w_schema)s'
                distance_decay = %(distance_decay)s

                # if (w_schema=='binary'){decay <- 1 
                # } else {decay <- %(distance_decay)s}
                
                v <- c('CONTIGUITY(QUEEN)','CONTIGUITY(ROOK)')
                if (type %%in%% v) {
                  if(type=='CONTIGUITY(QUEEN)') {queen=TRUE
                  } else { queen = FALSE}
                  weights0 <- poly2nb(pl=input,row.names=input$%(input_id)s ,snap=0.0005, queen=queen) #Better parameter for snap?
                  if (value >= 2) {
                    nblags <- nblag(neighbours=weights0, maxlag=value)
                    weights0 <- nblag.cumul(nblags=nblags)
                  }
                  weights = nb2listw(weights0, glist=NULL, style= style, zero.policy=TRUE)
                } else {
                  # ids <- seq(1,dim(input@data)[1])
                  ids <- as.vector(input$%(input_id)s)
                  proj4 <- proj4string(input)
                  coords <- coordinates(obj=input)
                  points <- SpatialPoints(coords=coords, proj4string=CRS(proj4))
                  if (type=='FIXED DISTANCE') {
                    dist <- dnearneigh(x=points, d1=0, d2=value*1000, row.names=ids)
                  } else { # 'knearest'
                    knear <- knearneigh(x=points, k=value)
                    dist <- knn2nb(knn=knear, row.names=ids, sym=FALSE)
                  }
                  dlist <- nbdists(nb=dist, coords=points)
                  decayfun <- function(x) 1/(x^distance_decay)
                  idlist <- lapply(X=dlist, FUN=decayfun)
                  if (w_schema=='binary'){ 
                     weights <- nb2listw(neighbours=dist, glist=NULL, style=style, zero.policy=TRUE)
                } else {
                     weights <- nb2listw(neighbours=dist, glist=idlist, style=style, zero.policy=TRUE)
                }
                  
                }
                # write gal(gal only contain the relationship, but no weight)
                write.nb.gal(weights$neighbours,'%(outputfile)s',oldstyle = FALSE,shpfile = '%(layer_name)s',ind = '%(input_id)s')
                # saveRDS(weights, '%(outputfile)s')
                
                #write weight
                wfile <- file('%(outputfile)s.wgt',open="w")
                galwgh <- weights$weights
                n <- length(weights$neighbours)
                cn <- card(weights$neighbours)
                rn <- attr(weights$neighbours,"region.id")
                writeLines(paste("0",n,'%(layer_name)s','%(input_id)s',sep=" "),wfile)
                for (i in 1:n){
                    writeLines(paste(rn[i],cn[i],collapse=" "),wfile)
                    writeLines(ifelse(cn[i]>0,paste(galwgh[[i]],collapse=" "),""),wfile)
                }
                close(wfile)
                ''' % arg1


        robjects.r(r_command)
        progress.setPercentage(int(100))
        #list_queen = self.poly2nb_(spds,queen=True) #queen 策略
        #W = self.nb2listw_(list_queen, style="W") # row 标准化

    def createSpatialDataset(self, vectType, Coords, data, projString):
        if vectType == 0:
            # For points, coordinates must be input as a matrix, hense the extra bits below...
            # Not sure if this will work for multipoint features?
            spatialData = self.SpatialPoints_(self.matrix_(self.unlist_(Coords), \
                                                           nrow=len(Coords), byrow=True),
                                              proj4string=self.CRS_(projString))
            return self.SpatialPointsDataFrame_(spatialData, data)  # , match_ID = True )
            # kwargs = {'match.ID':"FALSE"}
            # return SpatialPointsDataFrame( spatialData, data, **kwargs )
        elif vectType == 1:
            spatialData = self.SpatialLines_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialLinesDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        elif vectType == 2:
            spatialData = self.SpatialPolygons_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialPolygonsDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        else:
            return ""

    # Helper function to get coordinates of input geometry
    # Does not require knowledge of input geometry type
    # Return: Appends R type geometry to input list
    def getNextGeometry(self, Coords, feat):
        geom = feat.geometry()
        if geom.type() == 0:
            Coords.append(self.getPointCoords(geom, feat.id()))
            return True
        elif geom.type() == 1:
            Coords.append(self.getLineCoords(geom, feat.id()))
            return True
        elif geom.type() == 2:
            Coords.append(self.getPolygonCoords(geom, feat.id()))
            return True
        else:
            return False

    # Function to retrieve QgsGeometry (point) coordinates
    # and convert to a format that can be used by R
    # Return: Item of class Matrix (R class)
    def getPointCoords(self, geom, fid):
        if geom.isMultipart():
            points = geom.asMultiPoint()  # multi_geom is a multipoint
            return [self.convertToXY(point) for point in points]
        else:
            point = geom.asPoint()  # multi_geom is a point
            return self.convertToXY(point)

        # Function to retrieve QgsGeometry (polygon) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Polygons (R class)

    def getPolygonCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            polygon = geom.asMultiPolygon()  # multi_geom is a multipolygon
            for lines in polygon:
                for line in lines:
                    keeps.append(self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                            nrow=len([self.convertToXY(point) for point in line]),
                                                            byrow=True)))
            return self.Polygons_(keeps, fid)
        else:
            lines = geom.asPolygon()  # multi_geom is a polygon
            Polygon = [self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                  nrow=len([self.convertToXY(point) for point in line]), byrow=True))
                       for line in lines]
            return self.Polygons_(Polygon, fid)

        # Function to retrieve QgsGeometry (line) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Lines (R class)

    def getLineCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            lines = geom.asMultiPolyline()  # multi_geom is a multipolyline
            for line in lines:
                for line in lines:
                    keeps.append(self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                         nrow=len([self.convertToXY(point) for point in line]),
                                                         byrow=True)))
            return self.Lines_(keeps, str(fid))
        else:
            line = geom.asPolyline()  # multi_geom is a line
            Line = self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                           nrow=len([self.convertToXY(point) for point in line]), byrow=True))
            return self.Lines_(Line, str(fid))

    def convertToXY(self, inPoint):
        return [inPoint.x(), inPoint.y()]