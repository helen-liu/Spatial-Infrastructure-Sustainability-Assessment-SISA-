# -*- coding: utf-8 -*-

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,sys,math
import random
from random import shuffle
import numpy
from scipy.stats import t as tdis
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsField,QgsFeature,NULL)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.parameters import ParameterNumber,ParameterFile
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class Uncertainty(GeoAlgorithm):

    POLY_RESULT_VECTOR = 'POLY_RESULT_VECTOR'
    WEIGHT_FILE = "WEIGHT_FILE"
    UNCERTAINTY_RANGE = 'UNCERTAINTY_RANGE'
    NUMBER_SAMPLES = 'NUMBER_SAMPLES'
    CONFIDENCE_INTERVAL = 'CONFIDENCE_INTERVAL'
    CONFIDENCE_INTERVAL_OPTIONS = ['90%','95%','98%']
    CONFIDENCE_INTERVAL_VALUES = [0.95,0.975,0.99]
    OUTPUT_LAYER = 'OUTPUT_LAYER'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Results Analysis/Uncertainty Analysis"
        self.name, self.i18n_name = self.trAlgorithm('Uncertainty Analysis')
        self.group, self.i18n_group = self.trAlgorithm('Indicator Analysis')

        self.addParameter(ParameterVector_RDBMS(self.POLY_RESULT_VECTOR,
                                                self.tr('AHP Result Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))

        self.addParameter(ParameterFile(self.WEIGHT_FILE, self.tr('AHP Weight File'),optional=False,ext='weight'))
        self.addParameter(ParameterNumber(self.UNCERTAINTY_RANGE, self.tr(u'Uncertainty Range(±%)'), default=10.0,minValue=0, maxValue=30))
        self.addParameter(ParameterNumber(self.NUMBER_SAMPLES, self.tr("Number of Samples"), default=1000, minValue=100))
        self.addParameter(ParameterSelection(self.CONFIDENCE_INTERVAL, self.tr('Confidence Level'), self.CONFIDENCE_INTERVAL_OPTIONS, 0))
        self.addOutput(OutputVector(self.OUTPUT_LAYER, self.tr('Uncertainty Results Layer')))
    def check(self):
        f_weight = open(self.m_WEIGHT_FILE,"r")
        f_weight.readline().rstrip("\r\n") # skip the first line
        line = f_weight.readline().rstrip("\r\n")
        # fields_names = [Eco1_1,Eco1_2,Eco1_3,Eco1_4,Eco1_5,Eco1_6,Eco1_7,Eco1_8,Env2_1,Env2_2,Env2_3,Soc3_1,Soc3_2,Soc3_3]
        ahp_fields_names = line.split(",")[1:]
        f_weight.close()

        fieldsnames = self.m_POLY_ZONE_VECTOR.fields().names()
        for name in ahp_fields_names:
            if name not in fieldsnames:
                raise GeoAlgorithmExecutionException('''Field(%s) inconsistency between AHP Result Layer and AHP Weight File.\n
                                                     "They must be produced by AHP tool!'''%(name))
    def processAlgorithm(self, progress):
        self.progress = progress
        zoneparam = self.getParameterFromName(self.POLY_RESULT_VECTOR)
        self.m_POLY_ZONE_VECTOR = zoneparam.getLayerObject()
        self.m_WEIGHT_FILE = self.getParameterValue(self.WEIGHT_FILE)
        self.m_UNCERTAINTY_RANGE = self.getParameterValue(self.UNCERTAINTY_RANGE)
        self.m_NUMBER_SAMPLES = self.getParameterValue(self.NUMBER_SAMPLES)
        self.m_CONFIDENCE_INTERVAL = self.CONFIDENCE_INTERVAL_VALUES[self.getParameterValue(self.CONFIDENCE_INTERVAL)]
        self.m_OUTPUT_LAYER = self.getOutputFromName(self.OUTPUT_LAYER)
        self.check()
        # get the weight data
        f_weight = open(self.m_WEIGHT_FILE,"r")
        # get top dimentions
        # top_dims = ["Economic','Environmental','Social']
        line = f_weight.readline().rstrip("\r\n")
        top_dims  = line.split(",")[1:]
        n_d = len(top_dims)

        # fields_names = [Eco1_1,Eco1_2,Eco1_3,Eco1_4,Eco1_5,Eco1_6,Eco1_7,Eco1_8,Env2_1,Env2_2,Env2_3,Soc3_1,Soc3_2,Soc3_3]
        line = f_weight.readline().rstrip("\r\n")
        fields_names = line.split(",")[1:]
        n_col = len(fields_names)

        # origin_weight = [0.1156237051214135,0.09293824481282241,0.036719040459988625,0.018637110997602832,0.1156237051214135,0.09293824481282241,0.036719040459988625,0.018637110997602832,0.17551395029424272,0.11056684929525253,0.046435138818353955,0.07371119552034461,0.046435138818353955,0.019501524469797707]
        line = f_weight.readline().rstrip("\r\n")
        origin_weight = line.split(",")[1:]
        origin_weight = [float(i) for i in origin_weight]

        # top_dims_positions = [[1,1,1,1,1,1,1,1,0,0,0,0,0,0]
        #                       [0,0,0,0,0,0,0,0,1,1,1,0,0,0]
        #                       [0,0,0,0,0,0,0,0,0,0,0,1,1,1]]
        top_dims_positions = [[0.0] * n_col for i in range(n_d)]
        for tp in top_dims_positions:
            line = f_weight.readline().rstrip("\r\n")
            ws = [float(e) for e in line.split(",")[1:]] #0.5,0.5,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0
            for i in range(n_col):
                if ws[i]>0:
                    tp[i] = 1

        f_weight.close()
        # read the raw data into matrix
        feats = self.m_POLY_ZONE_VECTOR.getFeatures()
        n_row = int(self.m_POLY_ZONE_VECTOR.featureCount())
        raw_data = numpy.zeros(shape=(n_row,n_col))


        for current, feat in enumerate(feats):
            for col in range(n_col):
                raw_data[current][col] = numpy.NaN if feat[fields_names[col]]==NULL else feat[fields_names[col]]

        # variance_y,CV_y,mean_y,CI_y = 0.0,1.0,2.0,[0.0,1.0]
        weight_sampling_ranges = [[0 if r-(self.m_UNCERTAINTY_RANGE/100.0)*r<0 else r-(self.m_UNCERTAINTY_RANGE/100.0)*r,
                                  r + (self.m_UNCERTAINTY_RANGE/100.0) * r]
                                 for r in origin_weight]
        weight_sampling_lhs = [Latin_Hypercube_Sampling(r[0],r[1],self.m_NUMBER_SAMPLES) for r in weight_sampling_ranges]
        # lhs = Latin_Hypercube_Sampling(1,10,10)
        res = []
        while True:
            weights = []
            # generate random weights
            weights_lhs = [lhs.next() for lhs in weight_sampling_lhs]
            if weights_lhs[0]==None:
                break
            s = sum(weights_lhs)
            weights.append([t/s for t in weights_lhs])
            # calculate new results
            for i in range(n_d):
                temp = [weights_lhs[j]*top_dims_positions[i][j] for j in range(len(top_dims_positions[i]))]
                s = sum(temp)
                temp = [t/s for t in temp]
                weights.append(temp)
            weights = numpy.matrix(weights)

            temp_res = numpy.asmatrix(numpy.zeros(shape=(n_row,len(top_dims)+1)))
            temp_res[:,0] = raw_data.dot(weights[0,:].transpose())
            for i in range(n_d):
                #temp_weight = weights[i+1,:]
                indxs = list(numpy.where(numpy.array(top_dims_positions[i]) == 1)[0])
                temp_res[:, i+1] = raw_data[:,indxs].dot(weights[i+1,indxs].transpose())
            res.append(temp_res)
        # calculate new indicator
        # sum and mean value
        N_y = len(res)
        sum_y, mean_y = numpy.zeros(shape=(n_row,len(top_dims)+1)),None
        for r in res:
            sum_y = sum_y + r
        mean_y = sum_y / N_y

        # variance
        sum_square_y = numpy.zeros(shape=(n_row,len(top_dims)+1))
        for r in res:
            sum_mean_y = sum_square_y + numpy.multiply((r - mean_y),(r - mean_y))
        variance_y = numpy.sqrt(sum_square_y)
        CV_y = variance_y / mean_y
        df = N_y - 1
        t_critical = tdis.ppf((self.m_CONFIDENCE_INTERVAL),df)
        CI_y = [mean_y - variance_y * t_critical / math.sqrt(N_y),mean_y + variance_y * t_critical / math.sqrt(N_y)]

        # add fields for variance, CV, mean, CI_l, CI_h
        outFields = self.m_POLY_ZONE_VECTOR.fields()
        outFields.append(QgsField('e0_var', QVariant.Double, 'numeric(20,10)', 20, 10))
        outFields.append(QgsField('e0_cv', QVariant.Double, 'numeric(20,10)', 20, 10))
        outFields.append(QgsField('e0_mean', QVariant.Double, 'numeric(20,10)', 20, 10))
        outFields.append(QgsField('e0_cil', QVariant.Double, 'numeric(20,10)', 20, 10))
        outFields.append(QgsField('e0_cih', QVariant.Double, 'numeric(20,10)', 20, 10))
        for top_ in top_dims:
            top = top_[0:3]
            outFields.append(QgsField(top.lower()+'_var', QVariant.Double, 'numeric(20,10)', 20, 10))
            outFields.append(QgsField(top.lower()+'_cv', QVariant.Double, 'numeric(20,10)', 20, 10))
            outFields.append(QgsField(top.lower()+'_mean', QVariant.Double, 'numeric(20,10)', 20, 10))
            outFields.append(QgsField(top.lower()+'_cil', QVariant.Double, 'numeric(20,10)', 20, 10))
            outFields.append(QgsField(top.lower()+'_cih', QVariant.Double, 'numeric(20,10)', 20, 10))
        outFields.append(QgsField('conflel', QVariant.Double, 'numeric(20,10)', 20, 10))
        writer = self.m_OUTPUT_LAYER.getVectorWriter(outFields, self.m_POLY_ZONE_VECTOR.wkbType(),
                                                     self.m_POLY_ZONE_VECTOR.crs())
        total = 100.0 / n_row if n_row > 0 else 1
        feats = self.m_POLY_ZONE_VECTOR.getFeatures()
        outFeat = QgsFeature()
        for current, feat in enumerate(feats):
            progress.setPercentage(int(current * total))
            atMap = feat.attributes()
            atMap.extend([float(variance_y[current,0]),float(CV_y[current,0]),float(mean_y[current,0]),float(CI_y[0][current,0]),float(CI_y[1][current,0])])
            for i in range(len(top_dims)):
                atMap.extend([float(variance_y[current,i+1]), float(CV_y[current,i+1]), float(mean_y[current,i+1]),
                              float(CI_y[0][current,i+1]), float(CI_y[1][current,i+1])])
            atMap.append(1.0 - 2.0*(1.0 - self.m_CONFIDENCE_INTERVAL))
            outFeat.setAttributes(atMap)
            geom = feat.geometry()
            outFeat.setGeometry(geom)
            writer.addFeature(outFeat)
        del writer

class Latin_Hypercube_Sampling:
    def __init__(self,xmin, xmax,n):
        self.xmin = xmin
        self.xmax = xmax
        self.n = n
        self.ranges = list(range(n))
        shuffle(self.ranges)
        self.one_sample_range = float(xmax-xmin)/n
    def next(self):
        if len(self.ranges)>0:
            cur = self.ranges.pop()
            low_b = self.xmin+cur*self.one_sample_range
            r = random.random()
            #print("random:"+str(r))
            return low_b+r*self.one_sample_range
        else:
            return None


