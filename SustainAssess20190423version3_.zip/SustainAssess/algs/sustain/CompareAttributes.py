# -*- coding: utf-8 -*-

"""
***************************************************************************
    ComparisonAttribute.py
    ---------------------
    __author__ = 'MM & QS'
    __date__ = 'Des 2018'
    __copyright__ = '(C) 2018, Mengmeng Liu'
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'MM & QS'
__date__ = 'Des 2018'
__copyright__ = '(C) 2018, Mengmeng Liu'
__revision__ = '$Format:%H$'

import os
import csv
from qgis.utils import iface
from qgis.PyQt.QtGui import QIcon,QCursor,QColor, QPalette,QPixmap
from qgis.PyQt.QtCore import QVariant,QRect,Qt,QSize,QSettings
from qgis.PyQt.QtWidgets import QAbstractItemView,QApplication,QWidget,QVBoxLayout,QPushButton,\
        QScrollArea,QFrame,QSpacerItem,QSizePolicy,QLabel,QHBoxLayout,QFileDialog,QTableWidget,\
        QTableWidgetItem,QComboBox,QAction,QMessageBox,QGridLayout,QCheckBox,QMenu
from SustainAssess.gui.OutputSelectionPanel import OutputSelectionPanel
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.gui.AlgorithmExecutor import runalg,runalgIterating
from SustainAssess.gui.InputLayerRDBMSelectorPanel import InputLayerRDBMSelectorPanel
from qgis.core import QgsMapLayer, QgsDataSourceUri, QgsFeature, QgsField, NULL,QgsProject
from SustainAssess.gui.AlgorithmDialogBase import AlgorithmDialogBase
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterVector_RDBMS,Parameter
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.parameters import ParameterRaster
from SustainAssess.tools import dataobjects,postgis,spatialite,vector
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.gui.Postprocessing import handleAlgorithmResults
from qgis.gui import QgsCollapsibleGroupBox
from SustainAssess.core.outputs import OutputVector,OutputRaster, OutputTable,OutputVector_liu

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class CompareAttributes(GeoAlgorithm):


    INPUT_LAYER = 'INPUT_LAYER'
    INPUT_LAYER_KEY = 'INPUT_LAYER_KEY'
    INPUT_LAYER_2 = 'INPUT_LAYER_2'
    INPUT_LAYER_2_KEY = 'INPUT_LAYER_2_KEY'

    TABLE_SELECTION = 'TABLE_SELECTION'
    TABLE_FIELD = 'TABLE_FIELD'
    TABLE_FIELD_2 = 'TABLE_FIELD_2'

    OUTPUT_LAYER = 'OUTPUT_LAYER'

    def defineCharacteristics(self):
        self.name, self.i18n_name = self.trAlgorithm('Compare Attributes')
        self.group, self.i18n_group = self.trAlgorithm('Vector general tools')
        self.menu_path = "Sustainability/Geoprocess/Compare Attributes"
        self.METHOD = {"-":self.minus,"+":self.add,"*":self.multiply,"/":self.divide}

        self.allowOnlyOpenedLayers = False
        self.addParameter(ParameterVector_RDBMS(self.INPUT_LAYER,
                                          self.tr('Input Layer 1'), [ParameterVector_RDBMS.VECTOR_TYPE_ANY], False))
        self.addParameter(ParameterVector_RDBMS(self.INPUT_LAYER_2,
                                         self.tr('Input Layer 2'),[ParameterVector_RDBMS.VECTOR_TYPE_ANY], False))
        self.addParameter(ParameterTableField(self.INPUT_LAYER_KEY, self.tr('Input Layer 1\'s Key Field'),
                                              self.INPUT_LAYER,datatype=FieldType.DATA_TYPE_ID))
        self.addParameter(ParameterTableField(self.INPUT_LAYER_2_KEY,self.tr('Input Layer 2\'s Key Field'),
                                              self.INPUT_LAYER_2,datatype=FieldType.DATA_TYPE_ID))

        self.addParameter(ParameterTableField(self.TABLE_FIELD,self.tr('Input Layer 1\'s Field'),
                                              self.INPUT_LAYER,datatype=FieldType.DATA_TYPE_NUMERIC))
        self.addParameter(ParameterTableField(self.TABLE_FIELD_2,self.tr('Input Layer 2\'s Field'),
                                              self.INPUT_LAYER_2,datatype=FieldType.DATA_TYPE_NUMERIC))
        param1 = self.getParameterFromName(self.TABLE_FIELD)
        param2 = self.getParameterFromName(self.TABLE_FIELD_2)
        self.addParameter(ParameterCompareSelection(self.TABLE_SELECTION,param1,param2))

        self.addOutput(OutputVector(self.OUTPUT_LAYER, self.tr('Output Layer')))
    def getCustomParametersDialog(self):
        self.dlg = ComparisonDialog(self)
        return self.dlg
    def minus(self,v1,v2):
        if v1 == NULL or v2 == NULL: return NULL
        return v1 - v2
    def add(self,v1,v2):
        if v1 == NULL or v2 == NULL: return NULL
        return v1 + v2
    def multiply(self,v1,v2):
        if v1 == NULL or v2 == NULL: return NULL
        return v1 * v2
    def divide(self,v1,v2):
        if v1 == NULL or v2 == NULL or v2 == 0: return NULL
        return v1/v2
    def processAlgorithm(self, progress):
        paraminput = self.getParameterFromName(self.INPUT_LAYER)
        paraminput2 = self.getParameterFromName(self.INPUT_LAYER_2)
        inputLayer = paraminput.getLayerObject()
        inputLayer_2 = paraminput2.getLayerObject()

        input_key = self.getParameterValue(self.INPUT_LAYER_KEY)
        input2_key = self.getParameterValue(self.INPUT_LAYER_2_KEY)

        field_pairs = self.getParameterValue(self.TABLE_SELECTION)

        idx_key1 = inputLayer.fields().indexFromName(input_key)
        idx_key2 = inputLayer_2.fields().indexFromName(input2_key)

        alias_name = []
        idxes_layer1 = []
        idxes_layer2 = []
        Operators = []
        # ["Field1","Operator","Field2"]
        for pair in field_pairs:
            alias_name.append(pair["OutputName"])
            idxes_layer1.append(inputLayer.fields().indexFromName(pair["Field1"]))
            idxes_layer2.append(inputLayer_2.fields().indexFromName(pair["Field2"]))
            Operators.append(pair["Operator"])

        # get the fields we need
        idxes_layer1.insert(0,idx_key1)
        alias_name.insert(0,input_key)
        fields = inputLayer.fields()
        outFields = []
        idTypes_map = {'10': "text", '2': "integer", '4': "bigint",
                       '3': "integer", '5': "bigint",'6': "numeric(20,8)"}


        for i,ind in enumerate(idxes_layer1):
            fi = fields[ind]
            type = fi.type()
            len_,prec_ = 0,0
            if idTypes_map[str(type)]=="real":
                len_ = -1
                prec_ = -1
            elif idTypes_map[str(type)]=="numeric(20,8)":
                len_ = 20
                prec_ = 8
            field = QgsField(alias_name[i], type, idTypes_map[str(type)],len_,prec_)
            outFields.append(field)

        idxes_layer1.remove(idx_key1)
        output = self.getOutputFromName(self.OUTPUT_LAYER)
        writer = output.getVectorWriter(outFields, inputLayer.wkbType(),inputLayer.crs(),{"pk":input_key})
        # Cache attributes of Layer 2
        cache = {}
        features = vector.features(inputLayer_2)
        total = 50.0 / len(features) if len(features) > 0 else 1
        for current, feat in enumerate(features):
            attrs = feat.attributes()
            id2 = attrs[idx_key2]
            values2 = [attrs[ind] for ind in idxes_layer2]
            if id2 not in cache:
                cache[id2] = values2
            else:
                raise GeoAlgorithmExecutionException("Input Layer 1 Key field values are not unique!")
            progress.setPercentage(int(current * total))

        # Create output vector layer with additional attribute
        outFeat = QgsFeature()
        features = vector.features(inputLayer)
        total = 50.0 / len(features) if len(features) > 0 else 1
        for current, feat in enumerate(features):
            outFeat.setGeometry(feat.geometry())
            attrs = feat.attributes()
            id1 = attrs[idx_key1]
            values1 = [attrs[ind] for ind in idxes_layer1]
            res = [self.METHOD[op](values1[i],cache[id1][i]) for i,op in enumerate(Operators)]
            res.insert(0,id1)
            outFeat.setAttributes(res)
            writer.addFeature(outFeat)
            progress.setPercentage(50+int(current * total))
        del writer
class FieldType(object):
    DATA_TYPE_ID = 0
    DATA_TYPE_NUMERIC = 1
    DATA_TYPE_ALL = -1
class ParameterCompareSelection(Parameter):
    def __init__(self, name = "", param1 = None, param2=None):
        Parameter.__init__(self, name, "ParameterSelection", None, False)
        self.param1 = param1
        self.param2 = param2
        self.parent = [param1.parent,param2.parent]
    def setValue(self, obj):
        # expected value is list [{"Field1":"...","Field2":"...","operation":"+"},{...},...]
        if obj is None:
            if self.optional:
                self.value = None
                return True
            return False

        if isinstance(obj, list):
            if len(obj) == 0:
                if self.optional:
                    self.value = None
                    return True
                return False
            self.value = obj
            return True
        else:
            self.value = None
            return False

    def __str__(self):
        return self.name + ' <' + self.__module__.split('.')[-1] + ' from ' \
            + self.parent + '>'
class QlTableWidget(QTableWidget):
    def __int__(self,parent):
        QTableWidget.__init__(self,parent)

    # def resizeEvent(self,evt):
    #     twidth = self.width()
    #     self.setColumnWidth(2,55)
    #     self.setColumnWidth(0, (twidth-55)/3.0)
    #     self.setColumnWidth(1, (twidth-55)/3.0)
    #     self.setColumnWidth(3, (twidth-55)/3.0)

class CompareSelectionPanel(QWidget):
    def __init__(self,param):
        QWidget.__init__(self)
        self.param = param
        self.titles = ["Field1","Operator","Field2","OutputName"]
        operaters = ["-", "+", "/", "*"]
        self.widgets = {}
        # [{"Field1":"...","Field2":"...","operater":"+"},{...},...]
        self.table_data = []
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.userSetWidth = False
        vLayout = QVBoxLayout(self)
        vLayout.setSpacing(2)
        vLayout.setMargin(0)
        # add tow horizonal combox and add button ======================================================================
        # input layer 1's field combox
        gridLayout_2 = QGridLayout()
        label = QLabel(param.param1.description)
        self.cbx_input1 = QComboBox()
        gridLayout_2.addWidget(label, 0, 0, 1, 1)
        gridLayout_2.addWidget(self.cbx_input1, 1, 0, 1, 1)

        label = QLabel(param.param2.description)
        self.cbx_input2 = QComboBox()
        labelOp = QLabel("")
        self.Operator_cmbox = QComboBox()
        # font = self.Operator_cmbox.font()
        # font.setPointSize(50)
        # self.Operator_cmbox.setFont(font)
        self.Operator_cmbox.addItems(operaters)
        self.Operator_cmbox.setMaximumWidth(50)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.btn_add = QPushButton(self)
        self.btn_add.setSizePolicy(sizePolicy)
        self.btn_add.setMaximumSize(QSize(20, 20))
        self.btn_add.setText("")
        pixmap = QPixmap(os.path.join(pluginPath, "icons", "plus.png"))
        curIcon = QIcon(pixmap)
        self.btn_add.setIcon(curIcon)
        self.btn_add.setIconSize(QSize(20, 20))
        gridLayout_2.addWidget(labelOp, 0, 1, 1, 1)
        gridLayout_2.addWidget(self.Operator_cmbox,1,1,1,1)
        gridLayout_2.addWidget(label, 0, 2, 1, 1)
        gridLayout_2.addWidget(self.cbx_input2, 1, 2, 1, 1)
        gridLayout_2.addWidget(self.btn_add, 1, 3, 1, 1)

        vLayout.addLayout(gridLayout_2)

        # add table and add delete,up, down ============================================================================
        label = QLabel("Comparison Table")
        vLayout.addWidget(label)
        hlayout2 = QHBoxLayout()
        self.tableWidget = QlTableWidget(self)
        # self.tableWidget = QTableWidget(self)
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(len(self.titles))
        self.tableWidget.setHorizontalHeaderLabels(self.titles)

        self.tableWidget.setShowGrid(True)
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # disable edit
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setSelectionMode(QAbstractItemView.MultiSelection)
        self.tableWidget.setMinimumHeight(250)
        self.tableWidget.horizontalHeader().setStretchLastSection(True)
        self.tableWidget.verticalHeader().hide()
        hlayout2.addWidget(self.tableWidget)

        vlayout_2 = QVBoxLayout()
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        self.btn_minus = QPushButton(self)
        self.btn_minus.setText("")
        self.btn_minus.setSizePolicy(sizePolicy)
        self.btn_minus.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath, "icons", "minus.png"))
        curIcon = QIcon(pixmap)
        self.btn_minus.setIcon(curIcon)
        self.btn_minus.setIconSize(QSize(20, 20))
        self.btn_minus.setObjectName("btn_minus")
        vlayout_2.addWidget(self.btn_minus)

        self.btn_up = QPushButton(self)
        self.btn_up.setText("")
        self.btn_up.setSizePolicy(sizePolicy)
        self.btn_up.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath, "icons", "uparrow.png"))
        curIcon = QIcon(pixmap)
        self.btn_up.setIcon(curIcon)
        self.btn_up.setIconSize(QSize(20, 20))
        self.btn_up.setObjectName("btn_up")
        vlayout_2.addWidget(self.btn_up)

        self.btn_down = QPushButton(self)
        self.btn_down.setText("")
        self.btn_down.setSizePolicy(sizePolicy)
        self.btn_down.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath, "icons", "downarrow.png"))
        curIcon = QIcon(pixmap)
        self.btn_down.setIcon(curIcon)
        self.btn_down.setIconSize(QSize(20, 20))
        self.btn_down.setObjectName("btn_down")
        vlayout_2.addWidget(self.btn_down)

        self.btn_more = QPushButton(self)
        self.btn_more.setText("...")
        self.btn_more.setSizePolicy(sizePolicy)
        self.btn_more.setMaximumSize(QSize(20, 20))
        self.btn_more.setObjectName("btn_more")
        vlayout_2.addWidget(self.btn_more)

        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        vlayout_2.addItem(spacerItem)
        hlayout2.addLayout(vlayout_2)

        vLayout.addLayout(hlayout2)

        self.widgets[param.param1.name] = self.cbx_input1
        self.widgets[param.param2.name] = self.cbx_input2
        self.init_signals()


    def updateTableWidget(self):
        keys = self.titles # ["OutputName","Field1","Operator","Field2"]
        operaters = ["-", "+", "/", "*"]
        self.tableWidget.setRowCount(0)

        if len(self.table_data):
            if not self.userSetWidth:
                self.tableWidget.setColumnWidth(1, 55)
                twidth = self.tableWidget.width()
                self.tableWidget.setColumnWidth(0, (twidth - 55) / 3.0)
                self.tableWidget.setColumnWidth(2, (twidth - 55) / 3.0)
                self.tableWidget.setColumnWidth(3, (twidth - 55) / 3.0)
                self.userSetWidth = True
            for drow in self.table_data:
                self.tableWidget.insertRow(self.tableWidget.rowCount())
                i = self.tableWidget.rowCount() - 1

                cur_string = str(drow[keys[0]]) # Field1
                item = QTableWidgetItem(cur_string)
                item.setToolTip(cur_string)
                self.tableWidget.setItem(i, 0, item)

                cur_string = str(drow[keys[1]]) # "Operator"
                item = QComboBox()
                item.addItems(operaters)
                item.setCurrentIndex(operaters.index(cur_string))
                item.position = [i,1]
                def idchanged(ind):
                    sender = self.sender()
                    if not isinstance(sender, QComboBox):
                        return
                    tempText = sender.currentText()
                    row,col = sender.position
                    self.table_data[row][keys[1]] = tempText
                item.currentIndexChanged.connect(idchanged)
                self.tableWidget.setCellWidget(i, 1, item)

                cur_string = str(drow[keys[2]]) # "Field2"
                item = QTableWidgetItem(cur_string)
                item.setToolTip(cur_string)
                self.tableWidget.setItem(i, 2, item)

                cur_string = str(drow[keys[3]]) # fieldname
                item = QTableWidgetItem(cur_string)
                item.setToolTip(cur_string)
                self.tableWidget.setItem(i, 3, item)

    def init_signals(self):
        self.btn_add.clicked.connect(self.btn_add_clicked)
        self.btn_minus.clicked.connect(self.btn_minus_clicked)
        self.btn_up.clicked.connect(self.btn_up_clicked)
        self.btn_down.clicked.connect(self.btn_down_clicked)
        self.btn_more.clicked.connect(self.btn_more_clicked)
        # self.tableWidget.doubleClicked.connect(self.table_doubleclicked)
    def getUniqueFieldName(self,name):
        basename = name
        suffix = 1
        end = False
        while not end:
            bb = [False] * len(self.table_data)
            for i,d in enumerate(self.table_data):
                if d["OutputName"] == name:
                    name = basename + "_" + str(suffix)
                    suffix += 1
                    bb[i] = True
                    break
            if sum(bb)==0:
                end = True
        return name
    def btn_add_clicked(self):
        # [{"Field1": "...", "Field2": "...", "operation": "+"}, {...}, ...]
        # keys = ["Field1", "Field2", "Operator"]
        # get Field1 and Field2

        item = {"OutputName":self.getUniqueFieldName(self.cbx_input1.currentText()),
                "Field1":self.cbx_input1.currentText(), "Field2": self.cbx_input2.currentText(),
                "Operator": self.Operator_cmbox.currentText()}
        # check uniqueness
        bool_unique = True
        for d in self.table_data:
            itemid = (item["Field1"],item["Field2"],item["Operator"])
            did = (d["Field1"], d["Field2"],d["Operator"])
            if itemid==did:
                bool_unique = False
                break
        if bool_unique:
            self.table_data.append(item)
            self.updateTableWidget()
        else:
            QMessageBox.warning(self, "Existing pair of fields!", "Existing pair of fields!")
    def btn_minus_clicked(self):
        # adjust the rows of the self.selectedData and tableWidget
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            for sel in sels:
                temp = self.table_data.pop(sel.row())
            self.updateTableWidget()
    def btn_up_clicked(self):
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            if len(sels)>1:
                QMessageBox.warning(self, "Only support One selection", "Please move one entry at a time!")
            sel = sels[0].row()
            if sel>0:
                temp = self.table_data.pop(sel)
                self.table_data.insert(sel-1,temp)
                self.updateTableWidget()
                self.tableWidget.selectRow(sel-1)
    def btn_down_clicked(self):
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            if len(sels)>1:
                QMessageBox.warning(self, "Only support One selection", "Only support One selection!")
            sel = sels[0].row()
            if sel<len(self.table_data)-1:
                temp = self.table_data.pop(sel)
                self.table_data.insert(sel+1,temp)
                self.updateTableWidget()
                self.tableWidget.selectRow(sel+1)
    def btn_more_clicked(self):
        popupmenu = QMenu()
        newAction = QAction(self.tr('Export...'), self)
        popupmenu.addAction(newAction)
        newAction.triggered.connect(self.on_click_Export)
        popupmenu.exec_(QCursor.pos())
    def on_click_Export(self):
        keys = self.titles
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        if settings.contains('/SustainAssess/LastOutputPath'):
            lastDir = str(settings.value('/SustainAssess/LastOutputPath'))
        else:
            lastDir = ''
        filename = QFileDialog.getSaveFileName(self, self.tr('Save to CSV file'),
                                               lastDir, self.tr('csv files (*.csv);;'))
        data_ = self.table_data
        if filename:
            with open(filename, 'wb') as csvfile:
                spamwriter = csv.writer(csvfile, delimiter=',',
                                        quotechar='"', quoting=csv.QUOTE_MINIMAL)
                spamwriter.writerow(keys)
                for d in data_:
                    spamwriter.writerow([d[t] for t in keys])
        # if settings.contains('/SustainAssess/LastOutputPath'):
        settings.setValue('/SustainAssess/LastOutputPath',os.path.dirname(filename))

    def getTableData(self):
        return self.table_data
    def clear(self):
        self.tableWidget.setRowCount(0)
        self.table_data = []
        self.updateTableWidget()

class ComparisonDialog(AlgorithmDialogBase):
    def __init__(self,alg):
        AlgorithmDialogBase.__init__(self,alg)

        self.alg = alg
        self.checkBoxes = {}
        self.dependentItems = {}
        self.iterateButtons = {}
        self.mainWidget = self.MainPanel()
        self.setMainWidget()

        self.cornerWidget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(0,0,0,5) #void QLayout::setContentsMargins(int left, int top, int right, int bottom)
        self.tabWidget.setStyleSheet("QTabBar::tab { height: 30px; }")
        self.btnClose.clicked.connect(self.close)
        #self.runAsBatchButton = QPushButton(self.tr("Run as batch process..."))
        #self.runAsBatchButton.clicked.connect(self.runAsBatch)
        #layout.addWidget(self.runAsBatchButton)
        # self.cornerWidget.setLayout(layout)
        # self.tabWidget.setCornerWidget(self.cornerWidget)

        QgsProject.instance().layerWasAdded.connect(self.layerAdded_aggre)
        QgsProject.instance().layersWillBeRemoved.connect(self.layersWillBeRemoved_aggre)
    def MainPanel(self):
        myForm = QWidget()
        myForm.setObjectName("From")
        # myForm.resize(400,200) #resize(int w, int h)
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Preferred)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}
        self.widgets = {}
        self.labels = {}

        # add 1 parameter ParameterVector_RDBMS======(self.alg.INPUT_LAYER)==================================================
        param = self.alg.getParameterFromName(self.alg.INPUT_LAYER)
        layers = dataobjects.getVectorLayers(param.shapetype) # 2 Polygon
        items = []
        for layer in layers:
            items.append((layer.name(), layer))

        widget = InputLayerRDBMSelectorPanel(items, param)
        widget.cmbText.name = param.name
        widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)

        desc = param.description
        label = QLabel(desc)

        self.labels[param.name] = label
        self.widgets[param.name] = widget
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)

        # add 2 parameter ParameterVector_RDBMS======(self.alg.INPUT_LAYER_2)==================================================
        param = self.alg.getParameterFromName(self.alg.INPUT_LAYER_2)
        layers = dataobjects.getVectorLayers(param.shapetype) # 2 Polygon
        items = []
        for layer in layers:
            items.append((layer.name(), layer))

        widget = InputLayerRDBMSelectorPanel(items, param)
        widget.cmbText.name = param.name
        widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)

        desc = param.description
        label = QLabel(desc)

        self.labels[param.name] = label
        self.widgets[param.name] = widget
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)

        # add 3,4 parameters two ParameterTableField======(self.alg.INPUT_LAYER_KEY, INPUT_LAYER_2_KEY)=================================================

        hlayout_ids = QHBoxLayout(widget)
        id1_vlayerout = QVBoxLayout()
        param = self.alg.getParameterFromName(self.alg.INPUT_LAYER_KEY)
        item = QComboBox()
        desc = param.description
        label = QLabel(desc)
        self.addDependParam(param)

        self.labels[param.name] = label
        self.widgets[param.name] = item
        id1_vlayerout.addWidget(label)
        id1_vlayerout.addWidget(item)
        hlayout_ids.addLayout(id1_vlayerout)

        id2_vlayerout = QVBoxLayout()
        param = self.alg.getParameterFromName(self.alg.INPUT_LAYER_2_KEY)
        item = QComboBox()
        desc = param.description
        label = QLabel(desc)
        self.addDependParam(param)

        self.labels[param.name] = label
        self.widgets[param.name] = item
        id2_vlayerout.addWidget(label)
        id2_vlayerout.addWidget(item)

        hlayout_ids.addLayout(id2_vlayerout)
        spacerItem1 = QSpacerItem(20, 0, QSizePolicy.Preferred, QSizePolicy.Minimum)
        hlayout_ids.addItem(spacerItem1)
        self.layoutMain.insertLayout(self.layoutMain.count() - 2,hlayout_ids)

        # add 5 parameters ParameterCompareSelection========================
        param = self.alg.getParameterFromName(self.alg.TABLE_SELECTION)
        widget = CompareSelectionPanel(param)
        self.widgets[param.param1.name] = widget.widgets[param.param1.name]
        self.widgets[param.param2.name] = widget.widgets[param.param2.name]
        self.widgets[param.name] = widget
        self.addDependParam(param.param1)
        self.addDependParam(param.param2)
        self.addDependParam(param)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)

        # self.addOutput(OutputVector(self.OUTPUT, self.tr('Output Aggregation Layer')))
        output = self.alg.outputs[0]
        label = QLabel(output.description)
        widget_out = OutputSelectionPanel(output, self.alg)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, widget_out)
        self.labels[param.name] = label
        self.widgets[output.name] = widget_out

        check = QCheckBox()
        check.setText(self.tr('Open output file after running algorithm'))
        check.setChecked(False)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, check)
        self.checkBoxes[output.name] = check


        widget = self.widgets[self.alg.INPUT_LAYER]
        ind = widget.cmbText.currentIndex()
        widget.cmbText.currentIndexChanged.emit(ind)

        widget = self.widgets[self.alg.INPUT_LAYER_2]
        ind = widget.cmbText.currentIndex()
        widget.cmbText.currentIndexChanged.emit(ind)
        return myForm

    def addDependParam(self,param):
        if isinstance(param.parent,list):
            for parent in param.parent:
                if parent in self.dependentItems:
                    items = self.dependentItems[parent]
                else:
                    items = []
                    self.dependentItems[parent] = items
                items.append(param)
        else:
            if param.parent in self.dependentItems:
                items = self.dependentItems[param.parent]
            else:
                items = []
                self.dependentItems[param.parent] = items
            items.append(param)

    def runAsBatch(self):
        pass

    def setParamValues(self):
        params = self.alg.parameters
        outputs = self.alg.outputs

        for param in params:
            if param.hidden:
                continue
            if not self.setParamValue(
                    param, self.widgets[param.name]):
                raise AlgorithmDialogBase.InvalidParameterValue(
                    param, self.widgets[param.name])

        for output in outputs:
            if output.hidden:
                continue
            output.value = self.widgets[output.name].getValue()
            if isinstance(output, (OutputRaster, OutputVector, OutputTable,OutputVector_liu)):
                output.open = self.checkBoxes[output.name].isChecked()
        return True

    def setParamValue(self, param, widget, alg=None):
        if isinstance(param, ParameterRaster):
            return param.setValue(widget.getValue())
        elif isinstance(param,(ParameterVector_RDBMS)):
            return param.setValue(widget.getValue())
        elif isinstance(param, (ParameterVector)):
            try:
                return param.setValue(widget.itemData(widget.currentIndex()))
            except:
                return param.setValue(widget.getValue())
        elif isinstance(param, ParameterSelection):
            return param.setValue(widget.currentIndex())
        elif isinstance(param, ParameterTableField):
            if param.optional and widget.currentIndex() == 0:
                return param.setValue(None)
            return param.setValue(widget.currentText())
        elif isinstance(param,ParameterCompareSelection):
            if param.optional and len(list(widget.getTableData())) == 0:
                return param.setValue(None)
            return param.setValue(list(widget.getTableData()))

    def accept(self):
        self.settings.setValue("/Processing/dialogBase", self.saveGeometry())

        checkCRS = ProcessingConfig.getSetting(ProcessingConfig.WARN_UNMATCHING_CRS)
        try:
            self.setParamValues()
            if checkCRS and not self.alg.checkInputCRS():
                reply = QMessageBox.question(self, self.tr("Unmatching CRS's"),
                                             self.tr('Layers do not all use the same CRS. This can '
                                                     'cause unexpected results.\nDo you want to '
                                                     'continue?'),
                                             QMessageBox.Yes | QMessageBox.No,
                                             QMessageBox.No)
                if reply == QMessageBox.No:
                    return

            msg = self.alg._checkParameterValuesBeforeExecuting()
            if msg:
                QMessageBox.warning(
                    self, self.tr('Unable to execute algorithm'), msg)
                return
            self.btnRun.setEnabled(False)
            self.btnClose.setEnabled(False)
            buttons = self.iterateButtons
            self.iterateParam = None

            for i in range(len(buttons.values())):
                button = buttons.values()[i]
                if button.isChecked():
                    self.iterateParam = buttons.keys()[i]
                    break

            self.progressBar.setMaximum(0)
            self.lblProgress.setText(self.tr('Processing algorithm...'))
            # Make sure the Log tab is visible before executing the algorithm
            try:
                self.tabWidget.setCurrentIndex(1)
                self.repaint()
            except:
                pass

            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))

            self.setInfo(
                self.tr('<b>Algorithm %s starting...</b>') % self.alg.name)

            if self.iterateParam:
                if runalgIterating(self.alg, self.iterateParam, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
            else:
                command = self.alg.getAsCommand()
                if command:
                    ProcessingLog.addToLog(
                        ProcessingLog.LOG_ALGORITHM, command)
                if runalg(self.alg, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
        except AlgorithmDialogBase.InvalidParameterValue as e:
            try:
                self.buttonBox.accepted.connect(lambda:
                                                e.widget.setPalette(QPalette()))
                palette = e.widget.palette()
                palette.setColor(QPalette.Base, QColor(255, 255, 0))
                e.widget.setPalette(palette)
                self.lblProgress.setText(
                    self.tr('<b>Missing parameter value: %s</b>') % e.parameter.description)
                return
            except:
                QMessageBox.critical(self,
                                     self.tr('Unable to execute algorithm'),
                                     self.tr('Wrong or missing parameter values'))
    def reject(self):
        self.done(0)
    def close(self):
        # QgsMessageLog.logMessage("DLG: releasing added event")
        QgsProject.instance().layerWasAdded.disconnect(self.layerAdded_aggre)
        QgsProject.instance().layersWillBeRemoved.disconnect(self.layersWillBeRemoved_aggre)
        self.done(0)
    def finish(self):
        keepOpen = ProcessingConfig.getSetting(ProcessingConfig.KEEP_DIALOG_OPEN)

        if self.iterateParam is None:
            if not handleAlgorithmResults(self.alg, self, not keepOpen):
                self.resetGUI()
                return

        self.executed = True
        self.setInfo('Algorithm %s finished' % self.alg.name)
        QApplication.restoreOverrideCursor()

        if not keepOpen:
            self.close()
        else:
            self.resetGUI()
            if self.alg.getHTMLOutputsCount() > 0:
                self.setInfo(
                    self.tr('HTML output has been generated by this algorithm.'
                            '\nOpen the results dialog to check it.'))
    def closeEvent(self, evt):
        # ProcessingLog.addToLog(ProcessingLog.LOG_INFO, "AggregationDLG Close")
        QgsProject.instance().layerWasAdded.disconnect(self.layerAdded_aggre)
        QgsProject.instance().layersWillBeRemoved.disconnect(self.layersWillBeRemoved_aggre)
        super(ComparisonDialog, self).closeEvent(evt)

    def layerAdded_aggre(self,layer):
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    if dataobjects.canUseVectorLayer(layer, param.shapetype):
                        widget = self.widgets[param.name]
                        if isinstance(widget, InputLayerRDBMSelectorPanel) and hasattr(widget.cmbText, 'addItem'):
                            widget = widget.cmbText
                        widget.addItem(layer.name(), layer)
        elif layer.type() == QgsMapLayer.RasterLayer and dataobjects.canUseRasterLayer(layer):
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText
                    widget.addItem(self.getExtendedLayerName(layer), layer)

    def layersWillBeRemoved_aggre(self,layers):
        for layer in layers:
            self.layerRemoved(layer)
    def layerRemoved(self, layer):
        layer = QgsProject.instance().mapLayer(layer)
        widget = None
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    widget = self.widgets[param.name]
                    if isinstance(widget, InputLayerRDBMSelectorPanel):
                        widget = widget.cmbText

                        if widget is not None:
                            idx = widget.findData(layer)
                            if idx != -1:
                                widget.removeItem(idx)
                            widget = None

        elif layer.type() == QgsMapLayer.RasterLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText

                    if widget is not None:
                        idx = widget.findData(layer)
                        if idx != -1:
                            widget.removeItem(idx)
                        widget = None

    def updateDependentFields(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        if sender.name not in self.dependentItems:
            return
        layer = sender.itemData(sender.currentIndex())
        if not layer:
            return

        children = self.dependentItems[sender.name]
        for child in children:
            if (isinstance(child, ParameterTableField)):
                widget = self.widgets[child.name]
                widget.clear()
                child_param = self.alg.getParameterFromName(child.name)
                datatype = child_param.datatype
                fieldTypes = []
                if datatype == FieldType.DATA_TYPE_ID:
                    fieldTypes = [QVariant.String, QVariant.Int, QVariant.LongLong,
                               QVariant.UInt, QVariant.ULongLong]
                elif datatype == FieldType.DATA_TYPE_NUMERIC:
                    fieldTypes = [QVariant.Int, QVariant.Double, QVariant.LongLong,
                                  QVariant.UInt, QVariant.ULongLong]

                def Spatialite2qgis(type):
                    typeTrans = {"INT": QVariant.Int, "INTEGER": QVariant.Int, "TINYINT": QVariant.Int,
                                 "SMALLINT": QVariant.Int, "MEDIUMINT": QVariant.LongLong, "BIGINT": QVariant.LongLong,
                                 "UNSIGNED BIG INT": QVariant.LongLong, "INT2": QVariant.Int, "INT8": QVariant.LongLong,
                                 "INTEGER": QVariant.LongLong, "CHARACTER": QVariant.String, "VARCHAR": QVariant.String,
                                 "VARYING CHARACTER": QVariant.String, "NCHAR": QVariant.String,
                                 "NATIVE CHARACTER": QVariant.String,
                                 "NVARCHAR": QVariant.String, "TEXT": QVariant.String, "REAL": QVariant.Double,
                                 "DOUBLE": QVariant.Double, "DOUBLE PRECISION": QVariant.Double, "FLOAT": QVariant.Double,
                                 "REAL": QVariant.Double, "NUMERIC": QVariant.Double, "DECIMAL": QVariant.Double,
                                 "BOOLEAN": QVariant.Int, "DATE": QVariant.String, "DATETIME": QVariant.String}
                    ind = type.find("(")
                    if ind > 0:
                        type = type[0:ind]
                    if type in typeTrans.keys():
                        return typeTrans[type]
                    else:
                        return None
                def Postg2qgis(type):
                    Postg2qgis = {"bigint": QVariant.LongLong, "varbinary": QVariant.ByteArray,
                                  "char": QVariant.String, "varchar": QVariant.String, "integer": QVariant.Int,
                                  "numeric": QVariant.Double, "decimal": QVariant.Double, "real": QVariant.Double,
                                  "double": QVariant.Double, "date": QVariant.String, "time": QVariant.Time,
                                  "timestamp": QVariant.String, "int": QVariant.Int, "int2": QVariant.Int,
                                  "int4": QVariant.Int, "int8": QVariant.LongLong, "text": QVariant.String,
                                  "float4": QVariant.Double, "float8": QVariant.Double, "float64": QVariant.Double}

                    ind = type.find("(")
                    if ind > 0:
                        type = type[0:ind]
                    if type in Postg2qgis.keys():
                        return Postg2qgis[type]
                    else:
                        return None

                fieldNames = []
                idfieldNames = []
                idfieldTypes = []
                # ============for ParameterVector_RDBMS
                if isinstance(layer, dict):
                    if "uri" in layer.keys():
                        uri = layer["uri"]
                        if uri.startswith(u"spatialite:"):
                            uri = uri[len(u"spatialite:"):]
                            uri = QgsDataSourceUri(uri)
                            try:
                                db = spatialite.GeoDB(uri)
                            except postgis.DbError as e:
                                raise GeoAlgorithmExecutionException(
                                    "Couldn't connect to database:\n%s" % e.message)
                                # return False
                            sql_fields = 'pragma table_info(%s)' % (uri.table())
                            c = db.con.cursor()
                            c.execute(sql_fields)
                            fields = c.fetchall()
                            for field in fields:
                                type = field[2]
                                if not fieldTypes or (Spatialite2qgis(type) is not None and Spatialite2qgis(type) in fieldTypes):
                                    fieldNames.append(field[1])
                        elif uri.startswith(u"postgis:"):
                            uri = uri[len(u"postgis:"):]
                            uri = QgsDataSourceUri(uri)
                            try:
                                db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                                                   dbname=uri.database(), user=uri.username(), passwd=uri.password())
                            except postgis.DbError as e:
                                raise GeoAlgorithmExecutionException(
                                    "Couldn't connect to database:\n%s" % e.message)
                                # return False
                            fields = db.get_table_fields(uri.table(), uri.schema())
                            for field in fields:
                                type = field.data_type
                                if not fieldTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in fieldTypes):
                                    fieldNames.append(field.name)
                        else:
                            layer = dataobjects.getObjectFromUri(uri)
                            for field in layer.fields():
                                if not fieldTypes or field.type() in fieldTypes:
                                    fieldNames.append(str(field.name()))
                else:
                    for field in layer.fields():
                        if not fieldTypes or field.type() in fieldTypes:
                            fieldNames.append(str(field.name()))
                nrow = len(fieldNames)
                widget.addItems(fieldNames)
            elif (isinstance(child, ParameterCompareSelection)):
                widget = self.widgets[child.name]
                widget.clear()