# -*- coding: utf-8 -*-
__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant

from qgis.core import Qgis,QgsWkbTypes, QgsFields, QgsField, QgsFeature, QgsGeometry, NULL

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.parameters import ParameterGeometryPredicate
from SustainAssess.core.parameters import ParameterNumber
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.parameters import ParameterString
from SustainAssess.core.outputs import OutputVector
from SustainAssess.tools import dataobjects, vector

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]



class SelectbyLocation(GeoAlgorithm):
    TARGET = "TARGET"
    JOIN = "JOIN"
    PREDICATE = "PREDICATE"
    PRECISION = 'PRECISION'
    OUTPUT = "OUTPUT"

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Geoprocess/Select by Location"
        self.name, self.i18n_name = self.trAlgorithm('Select by Location')
        self.group, self.i18n_group = self.trAlgorithm('Vector general tools')

        self.addParameter(ParameterVector_RDBMS(self.TARGET,
                                          self.tr('Select Feature From Layer'),
                                          [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterVector_RDBMS(self.JOIN,
                                          self.tr('Based on Layer'),
                                          [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        predicates = list(ParameterGeometryPredicate.predicates)
        predicates.remove('disjoint')
        self.addParameter(ParameterGeometryPredicate(self.PREDICATE,
                                                     self.tr('Spatial Relations'),
                                                     left=self.TARGET, right=self.JOIN,
                                                     enabledPredicates=predicates))

        self.addParameter(ParameterNumber(self.PRECISION,
                                          self.tr('Precision'),
                                          0.0, None, 0.0))

        self.addOutput(OutputVector(self.OUTPUT, self.tr('Output Selected Layer')))

    def processAlgorithm(self, progress):
        target_param = self.getParameterFromName(self.TARGET)
        target = target_param.getLayerObject()

        join_param = self.getParameterFromName(self.JOIN)
        join = join_param.getLayerObject()

        predicates = self.getParameterValue(self.PREDICATE)
        precision = self.getParameterValue(self.PRECISION)

        targetFields = target.fields()

        fields = QgsFields()
        for f in targetFields:
            fields.append(f)

        writer = self.getOutputFromName(self.OUTPUT).getVectorWriter(
            fields, target.wkbType(), target.crs())

        outFeat = QgsFeature()

        index = vector.spatialindex(join)

        mapP2 = dict()
        features = vector.features(join)
        for f in features:
            mapP2[f.id()] = QgsFeature(f)

        features = vector.features(target)
        total = 100.0 / len(features) if len(features) > 0 else 1
        for c, f in enumerate(features):
            atMap1 = f.attributes()

            inGeom = vector.snapToPrecision(f.geometry(), precision)
            b_output = False
            if inGeom.type() == QgsWkbTypes.Point:
                bbox = inGeom.buffer(10, 2).boundingBox()
            else:
                bbox = inGeom.boundingBox()
            bufferedBox = vector.bufferedBoundingBox(bbox, 0.51 * precision)
            joinList = index.intersects(bufferedBox)
            if len(joinList) > 0:
                for i in joinList:
                    inFeatB = mapP2[i]
                    inGeomB = vector.snapToPrecision(inFeatB.geometry(), precision)

                    res = False
                    for predicate in predicates:
                        if predicate == 'intersects':
                            res = inGeom.intersects(inGeomB)
                        elif predicate == 'contains':
                            res = inGeom.contains(inGeomB)
                        elif predicate == 'equals':
                            res = inGeom.equals(inGeomB)
                        elif predicate == 'touches':
                            res = inGeom.touches(inGeomB)
                        elif predicate == 'overlaps':
                            res = inGeom.overlaps(inGeomB)
                        elif predicate == 'within':
                            res = inGeom.within(inGeomB)
                        elif predicate == 'crosses':
                            res = inGeom.crosses(inGeomB)
                        if res:
                            b_output = True
                            break
            else:
                for predicate in predicates:
                    if predicate == 'disjoint':
                        b_output = True
                        break
            if b_output:
                outFeat.setGeometry(f.geometry())
                outFeat.setAttributes(atMap1)
                writer.addFeature(outFeat)

            progress.setPercentage(int(c * total))
        name = "_".join([str(predicate) for predicate in predicates])
        self.getOutputFromName(self.OUTPUT).description = name
        del writer

