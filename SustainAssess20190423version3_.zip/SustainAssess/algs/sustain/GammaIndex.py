# -*- coding: utf-8 -*-

"""
***************************************************************************
    GammaIndex.py
    ---------------------
    Date                 : Jan 2019
    Copyright            : Mengmeng Liu and Qingsong Liu'
    Email                : qliu20@kent.edu
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import re

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.PyQt.QtCore import QVariant
from qgis.core import ( QgsGeometry, QgsField, QgsSpatialIndex,QgsFeature)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog

from SustainAssess.core.parameters import ParameterString
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector_liu
from SustainAssess.tools import vector
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.core.ProcessingLog import ProcessingConfig

from networkx import DiGraph,number_strongly_connected_components

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class GammaIndex(GeoAlgorithm):

    POLY_VECTOR = 'POLY_VECTOR'
    POLY_ID_FIELD = 'POLY_ID_FIELD'

    EDGE_LAYER = 'EDGE_LAYER'
    EDGE_SOURCE_FIELD = 'EDGE_SOURCE_FIELD'
    EDGE_TARGET_FIELD = 'EDGE_TARGET_FIELD'
    COST_FIELD = 'COST_FIELD'
    REVERSE_COST_FIELD = 'REVERSE_COST_FIELD'

    POLY_E_FIELD = 'POLY_E_FIELD'
    POLY_V_FIELD = 'POLY_V_FIELD'

    OUTPUT_FIELD = 'OUTPUT_FIELD'
    OUTPUT = 'OUTPUT'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Connectivity/Gamma Index"
        self.name, self.i18n_name = self.trAlgorithm('Gamma Index')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')
        self.precision = 0.0
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Zone Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterTableField(self.POLY_ID_FIELD,
                                          self.tr('ID Field'),self.POLY_VECTOR))
        self.addParameter(ParameterVector_RDBMS(self.EDGE_LAYER,
                                                self.tr('Roads Layer'), [ParameterVector_RDBMS.VECTOR_ROAD_NETWORK]))
        self.addParameter(ParameterTableField(self.EDGE_SOURCE_FIELD,
                                              self.tr('Source Field'), self.EDGE_LAYER, defalut="source"))
        self.addParameter(ParameterTableField(self.EDGE_TARGET_FIELD,
                                              self.tr('Target Field'), self.EDGE_LAYER, defalut="target"))
        self.addParameter(ParameterTableField(self.COST_FIELD,
                                              self.tr('Cost Field'), self.EDGE_LAYER, defalut="cost"))
        self.addParameter(ParameterTableField(self.REVERSE_COST_FIELD,
                                              self.tr('Reverse Cost Field'), self.EDGE_LAYER, defalut="reverse_cost"))

        self.addParameter(ParameterTableField(self.POLY_E_FIELD,
                                          self.tr("'E' Field:"),self.POLY_VECTOR,defalut="e_net",optional=True))
        self.addParameter(ParameterTableField(self.POLY_V_FIELD,
                                          self.tr("'V' Field:"),self.POLY_VECTOR,defalut="v_net",optional=True))

        self.addParameter(ParameterString(self.OUTPUT_FIELD,
                                          self.tr('Field Name'), "gamma_net"))
        self.addOutput(OutputVector_liu(self.OUTPUT, self.tr('Output Layer')))

    def check(self,progress):
        self.m_POLY_E_FIELD = self.getParameterValue(self.POLY_E_FIELD)
        self.m_POLY_V_FIELD = self.getParameterValue(self.POLY_V_FIELD)
        msg = ""
        b_continue = True
        if not self.m_POLY_E_FIELD:
            msg+= "E Field,"
        if not self.m_POLY_V_FIELD:
            msg += "V Feield"
        if msg:
            msg+= " not provided. All of E,V,P Field will be calculated. This will cause extra computational work. " \
                  "Do you want to continue?"
            dlg = QMessageBox(progress)
            dlg.setText(msg)
            dlg.setStandardButtons(
                QMessageBox.StandardButtons(QMessageBox.Yes | QMessageBox.No))
            dlg.setDefaultButton(QMessageBox.Yes)
            if dlg.exec_() == QMessageBox.No:
                b_continue=False
        if b_continue:
            # check Output Field Name
            self.m_OUTPUT_FIELD = self.getParameterValue(self.OUTPUT_FIELD)
            len_ = len(self.m_OUTPUT_FIELD)
            msg= ""
            if len_>=13:
                msg+= "Output Field Name must less than 13 characters.\n"
            if not re.match("^[A-Za-z0-9_]*$", self.m_OUTPUT_FIELD):
                msg+= "Output Field Name can only be a-z,A-Z,1-9,_"
            if msg:
                b_continue = False
                raise GeoAlgorithmExecutionException(msg)
        else:
            raise GeoAlgorithmExecutionException("Please reset the E,V,P fields.")
        return b_continue

    def processAlgorithm(self, progress):
        # Here Gamma
        # gamma = float(e) / float((3 * (v - 2)))
        self.check(progress)
        paramInput = self.getParameterFromName(self.POLY_VECTOR)
        self.m_POLY_VECTOR = paramInput.getLayerObject()
        self.m_POLY_ID_FIELD = self.getParameterValue(self.POLY_ID_FIELD)

        paramInput2 = self.getParameterFromName(self.EDGE_LAYER)
        self.m_EDGE_LAYER = paramInput2.getLayerObject()

        self.m_EDGE_SOURCE_FIELD = self.getParameterValue(self.EDGE_SOURCE_FIELD)
        self.m_EDGE_TARGET_FIELD = self.getParameterValue(self.EDGE_TARGET_FIELD)
        self.m_COST_FIELD = self.getParameterValue(self.COST_FIELD)
        self.m_REVERSE_COST_FIELD = self.getParameterValue(self.REVERSE_COST_FIELD)

        self.m_OUTPUT_FIELD = self.getParameterValue(self.OUTPUT_FIELD)
        self.m_OUTPUT = self.getOutputFromName(self.OUTPUT)

        use_existing_evp = True
        save2input = self.m_OUTPUT.value == "save2input:"

        if not self.m_POLY_E_FIELD or not self.m_POLY_V_FIELD:
            use_existing_evp = False
        if use_existing_evp == True:
            field_names = [self.m_OUTPUT_FIELD]
            field_names_type = [QVariant.Double]
        else:
            self.m_POLY_E_FIELD = "e_net"
            self.m_POLY_V_FIELD = "v_net"
            self.m_POLY_P_FIELD = "p_net"
            field_names = ["e_net", "v_net", "p_net", self.m_OUTPUT_FIELD]
            field_names_type = [QVariant.LongLong, QVariant.LongLong, QVariant.LongLong, QVariant.Double]
        field_name_index = {}
        idTypes_map = {'10': "text", '2': "integer", '4': "bigint",
                       '3': "integer", '5': "bigint",'6': "numeric(20,8)"}
        ''' -5:BIGINT   QVariant::LongLong
            -3:VARBINARY QVariant::ByteArray
            1: CHAR QVariant::String
            12: VARCHAR QVariant::String
            4: INTEGER QVariant::Int
            3:     //NUMERIC and DECIMAL  QVariant::Double;
            7:     //REAL  QVariant::Double;
            8:     //DOUBLE QVariant::Double;
            9:    //DATE  QVariant::String; // don't know why it doesn't like QVariant::Date
            10:    //TIME  QVariant::Time;
            11:    //TIMESTAMP QVariant::String; // don't know why it doesn't like QVariant::DateTime
            // Everything else just dumped as a string.  QVariant::String;
        '''
        # init writer===================================================================================================
        outFeat = None
        writer = None
        if save2input == True:
            # create filed in the input zone layer
            # add field to the Input Zone LAYER====================================================
            if not self.m_POLY_VECTOR.isEditable():
                self.m_POLY_VECTOR.startEditing()
            # Start: create new field =======================================================================================
            self.m_POLY_VECTOR.beginEditCommand("Added attribute")
            for i, field_name in enumerate(field_names):
                # IMPORTANT, when working with postgres, "numeric(20,8)" must specified
                type = field_names_type[i]
                len_,prec_ = None,None
                if idTypes_map[str(type)]=="real":
                    len_ = -1
                    prec_ = -1
                elif idTypes_map[str(type)]=="numeric(20,8)":
                    len_ = 20
                    prec_ = 8
                if len_ and prec_:
                    field = QgsField(field_name, type, idTypes_map[str(type)],len_,prec_)  # [TODO] rdedge_param.datasource, postgres, spatialite,file different command
                else:
                    field = QgsField(field_name, type, idTypes_map[str(type)])
                mAttributeId = -1
                if (not self.m_POLY_VECTOR.addAttribute(field)):
                    # failed to add new fields, may be already exists
                    # check whether exists
                    # try to get the index of the new field
                    fields = self.m_POLY_VECTOR.fields()
                    for indx in range(fields.count()):
                        if fields[indx].name() == field_name:
                            mAttributeId = indx
                            break
                    if mAttributeId == -1:
                        # not exists, and add failed
                        self.m_POLY_VECTOR.destroyEditCommand()
                        QMessageBox.critical(None, ("Failed to add field"),
                                             ("Failed to add field '%1' of type '%2'. Is the field name unique?" % (
                                                 field.name(),
                                                 field.typeName())))
                        return
                else:
                    # add sucess, get index of the new field
                    fields = self.m_POLY_VECTOR.fields()
                    for indx in range(fields.count()):
                        if fields[indx].name() == field_name:
                            mAttributeId = indx
                        if mAttributeId != -1:
                            break

                if mAttributeId == -1:
                    self.m_POLY_VECTOR.destroyEditCommand()
                    QMessageBox.critical(None, ("Failed to add field"),
                                         ("Failed to add field '%1' of type '%2'. Is the field name unique?" % (
                                             field.name(),
                                             field.typeName())))
                    return
                field_name_index[field_name] = mAttributeId
            # End: create new field ========================================================================================
        else:
            # create new Layer
            geometryType = self.m_POLY_VECTOR.wkbType()
            fields = []
            ufields = self.m_POLY_VECTOR.fields()
            if ufields.count() <= 0:
                raise Exception("Error: Attribute table must have at least one field")
            types = {}

            fields_needed = [self.m_POLY_ID_FIELD]
            for field in ufields:
                # initial read in has correct ordering...
                name = str(field.name())
                if name in fields_needed:
                    types[name] = int(field.type())

            fields.append(QgsField(self.m_POLY_ID_FIELD, types[self.m_POLY_ID_FIELD],
                                   idTypes_map[str(types[self.m_POLY_ID_FIELD])]))
            for i, field_name in enumerate(field_names):
                type = field_names_type[i]
                len_, prec_ = None, None
                if idTypes_map[str(type)] == "real":
                    len_ = -1
                    prec_ = -1
                elif idTypes_map[str(type)] == "numeric(20,8)":
                    len_ = 20
                    prec_ = 8
                if len_ and prec_:
                    fields.append(QgsField(field_name, type, idTypes_map[str(type)], len_, prec_))
                else:
                    fields.append(QgsField(field_name, type, idTypes_map[str(type)]))
            writer = self.m_OUTPUT.getVectorWriter(fields, geometryType, self.m_POLY_VECTOR.crs())
            outFeat = QgsFeature()
        progress.setPercentage(int(10))

        # init road spatial index if not using existing e,v,p, since we need to recalculate=============================
        idx = None
        edge_data = {}
        if use_existing_evp == False:
            # create spatial index for the edge table
            if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                    and self.m_EDGE_LAYER.selectedFeatureCount() > 0:
                idx = QgsSpatialIndex(self.m_EDGE_LAYER.getSelectedFeatures())
                feats = self.m_EDGE_LAYER.getSelectedFeatures()
                for ft in feats:
                    edge_data[ft.id()] = [ft[self.m_EDGE_SOURCE_FIELD], ft[self.m_EDGE_TARGET_FIELD],
                                          ft[self.m_COST_FIELD], ft[self.m_REVERSE_COST_FIELD],
                                          QgsGeometry(ft.geometry())]
            else:
                idx = QgsSpatialIndex(self.m_EDGE_LAYER.getFeatures())
                feats = self.m_EDGE_LAYER.getFeatures()
                for ft in feats:
                    edge_data[ft.id()] = [ft[self.m_EDGE_SOURCE_FIELD], ft[self.m_EDGE_TARGET_FIELD],
                                          ft[self.m_COST_FIELD], ft[self.m_REVERSE_COST_FIELD],
                                          QgsGeometry(ft.geometry())]

        # for each poly in Input Zone Layer update e,v,p================================================================
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_POLY_VECTOR.selectedFeatureCount() > 0:
            polys = self.m_POLY_VECTOR.getSelectedFeatures()
            count = int(self.m_POLY_VECTOR.selectedFeatureCount())
        else:
            polys = self.m_POLY_VECTOR.getFeatures()
            count = int(self.m_POLY_VECTOR.featureCount())
        for current, poly in enumerate(polys):
            vals = {}
            # calculate or get the value of e,v,p
            if use_existing_evp == False:
                # get the intersect edge
                geom = vector.snapToPrecision(poly.geometry(), self.precision)
                bbox = vector.bufferedBoundingBox(geom.boundingBox(), 0.51 * self.precision)
                intersects = idx.intersects(bbox)
                # snap to presicion
                selection = []
                vertex = set()

                for sel in intersects:
                    rd_line = edge_data[sel]
                    tmpGeom = rd_line[4]
                    res = False
                    res = geom.intersects(tmpGeom)
                    if res == True:
                        selection.append(rd_line)
                        vertex.add(rd_line[0])
                        vertex.add(rd_line[1])
                # 3. calculate e
                n = len(selection)
                vals[self.m_POLY_E_FIELD] = n

                # 4. calculate v
                n = len(vertex)
                vals[self.m_POLY_V_FIELD] = n

                # 5. calculate p
                d_network = DiGraph()
                for e in selection:
                    source = e[0]
                    target = e[1]
                    cost = e[2]
                    reverse_cost = e[3]
                    if (cost < 10000 and cost > 0):
                        d_network.add_edge(source, target)
                    if (reverse_cost < 10000 and reverse_cost > 0):
                        d_network.add_edge(target, source)
                # [TODO] correct??
                n = number_strongly_connected_components(d_network)
                vals[self.m_POLY_P_FIELD] = n
            else:
                # get value from poly
                vals = {self.m_POLY_E_FIELD: poly[self.m_POLY_E_FIELD],
                        self.m_POLY_V_FIELD: poly[self.m_POLY_V_FIELD]}
            # calculate alpha
            e = vals[self.m_POLY_E_FIELD]
            v = vals[self.m_POLY_V_FIELD]
            gamma = float(e) / float((3 * (v - 2)))
            vals[self.m_OUTPUT_FIELD] = gamma
            # update fields
            if save2input == True:
                for key in field_names:
                    self.m_POLY_VECTOR.changeAttributeValue(poly.id(), field_name_index[key],
                                                            vals[key])
            else:
                id_ = poly[self.m_POLY_ID_FIELD]
                attr = [id_]
                for field_name in field_names:
                    attr.append(vals[field_name])
                outFeat.setAttributes(attr)
                outFeat.setGeometry(poly.geometry())
                writer.addFeature(outFeat)
            progress.setPercentage(int(10 + current * 1.0 / count * 85))
        # save the update===============================================================================================
        if save2input == True:
            # commit changes
            self.m_POLY_VECTOR.endEditCommand()
            modify = self.m_POLY_VECTOR.isModified()
            if modify:
                suc = self.m_POLY_VECTOR.commitChanges()
                if not suc:
                    errors = self.m_POLY_VECTOR.commitErrors()
                    msg = ''
                    for err in errors:
                        msg += str(err) + "\n"
                    ProcessingLog.addToLog(ProcessingLog.LOG_ERROR, msg)
                    QMessageBox.critical(None, ("Failed to update Zone Layer"),
                                         (
                                             "Failed to update Zone Layer,Please check the processingliu.log for more details."))
                    return
            self.m_OUTPUT.layer = self.m_POLY_VECTOR
            self.m_OUTPUT_FIELD.description = self.m_POLY_VECTOR.name()
        else:
            del writer
        progress.setPercentage(int(100))