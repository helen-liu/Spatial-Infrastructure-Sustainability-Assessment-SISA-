# -*- coding: utf-8 -*-
__author__ = 'QS'
__date__ = '07/11/2018'
__copyright__ = '(C) 2018, QS'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

from qgis.PyQt.QtGui import QIcon

from SustainAssess.core.AlgorithmProvider import AlgorithmProvider
from .RandomPointsLayer import RandomPointsLayer
from .Grid import Grid
from .JoinAttributes import JoinAttributes
from .SelectbyLocation import SelectbyLocation
from .RandomVectorLayer import RandomVectorsLayer
from .FixedDistanceBuffer import FixedDistanceBuffer
from .AlphaIndex import AlphaIndex
from .BetaIndex import BetaIndex
from .DetourIndex import DetourIndex
from .GammaIndex import GammaIndex
from .FacilitiesNearestDistance import NearestFacilities
from .FacilitieswithinDistance import FacilitieswithinDistance
from .Betweenness import Betweenness
from .Closeness import Closeness
from .CrossClique import CrossClique
from .Eigenvector import Eigenvector
from .Freeman import Freeman
from .Katz import Katz
from .PageRank import PageRank
from .Percolation import Percolation
from .BasicNetworkIndex import E_V_P_Index
from .MoranI import MoranI
from .CreateSpatialWeight import CreateSpatialWeight
from .Plot_Histogram import Plot_Histogram
from .Plot_MoranI import Plot_MoranI
from .MoranI_Local import MoranI_Local
from .Correlation import Correlation
from .Plot_Scatter import Plot_Scatter
from .PathCount import PathCount
from .AHP import AHP
from .Uncertainty import Uncertainty
from .SensitivityAnalysis import Sensitivity
from .Normalization import Normalization
from .VariableDistanceBuffer import VariableDistanceBuffer
from .CompareAttributes import CompareAttributes
from .Plot_Radar import Plot_Radar
from .AggregateAttributes import AggregateAttributes
from .Plot_Sunburst import Plot_Sunburst
from .Plot_BarChart import Plot_BarChart
from .Plot_LineChart import Plot_LineChart
from .Plot_Check import Plot_Check
from .PCA import PCAAlgorithm
pluginPath = os.path.normpath(os.path.join(
    os.path.split(os.path.dirname(__file__))[0], os.pardir))


class SustainAlgorithmProvider(AlgorithmProvider):

    def __init__(self):
        AlgorithmProvider.__init__(self)
        self._icon = QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

        self.alglist = [#Geoprocess
                        Grid(),RandomPointsLayer(),RandomVectorsLayer(),
                        FixedDistanceBuffer(),VariableDistanceBuffer(),
                        JoinAttributes(),CompareAttributes(), AggregateAttributes(),SelectbyLocation(),
                        # Network Analysis/ Connectivity
                        E_V_P_Index(),AlphaIndex(),BetaIndex(),GammaIndex(),DetourIndex(),
                        # Network Analysis/ Accessibility
                        NearestFacilities(),FacilitieswithinDistance(),
                        # Network Analysis/ Centrality
                        Betweenness(),Closeness(),PageRank(),Eigenvector(),Katz(),#Freeman(),Percolation(),CrossClique(),
                        PathCount(),
                        # Spatial Statitics
                        CreateSpatialWeight(),MoranI(),MoranI_Local(),
                        # Indicator Analysis
                        Normalization(),Correlation(),PCAAlgorithm(),AHP(),
                        # Results Analysis
                        Uncertainty(),Sensitivity(),
                        # Wizard
                        # Wizard()
                        # Plot
                        Plot_Histogram(), Plot_Scatter(), Plot_MoranI(),
                        # Results Visulization
                        Plot_Radar(),Plot_Sunburst(),Plot_BarChart(),Plot_LineChart(),Plot_Check()
            ]
        for alg in self.alglist:
            alg._icon = self._icon
            alg.provider=self

    def initializeSettings(self):
        AlgorithmProvider.initializeSettings(self)

    def unload(self):
        AlgorithmProvider.unload(self)

    def getName(self):
        return 'qgis'

    def getDescription(self):
        return self.tr('QGIS geoalgorithms')

    def getIcon(self):
        return self._icon

    def _loadAlgorithms(self):
        self.algs = list(self.alglist)

    def supportsNonFileBasedOutput(self):
        return True
