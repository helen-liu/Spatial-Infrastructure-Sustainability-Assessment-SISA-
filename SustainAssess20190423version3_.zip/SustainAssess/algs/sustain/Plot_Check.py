# -*- coding: utf-8 -*-

"""
***************************************************************************
    Plot_Histogram.py
    ---------------------
    Date                 : Jan 2019
    Copyright            : Mengmeng Liu and Qingsong Liu'
    Email                : qliu20@kent.edu
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import tempfile
import webbrowser
from collections import defaultdict
from qgis.PyQt.QtGui import QIcon,QCursor,QColor, QPalette,QPixmap
from qgis.PyQt.QtCore import QVariant,QRect,Qt,QSize,QSettings,pyqtSignal
from qgis.PyQt.QtWidgets import QAbstractItemView,QApplication,QWidget,QVBoxLayout,QPushButton,\
                QScrollArea,QFrame,QSpacerItem,QSizePolicy, QLabel,QHBoxLayout,QTableWidget,\
                QTableWidgetItem,QComboBox,QMessageBox,QDialog,QFileDialog,QTextBrowser,QMenu,QAction
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.gui.AlgorithmExecutor import runalg,runalgIterating
from SustainAssess.gui.InputLayerRDBMSelectorPanel import InputLayerRDBMSelectorPanel
from qgis.core import QgsMapLayer, QgsDataSourceUri,QgsProject
from SustainAssess.gui.AlgorithmDialogBase import AlgorithmDialogBase
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterVector_RDBMS,Parameter
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.parameters import ParameterRaster
from SustainAssess.tools import dataobjects,postgis,spatialite
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from SustainAssess.gui.Postprocessing import handleAlgorithmResults
from qgis.gui import QgsCollapsibleGroupBox,QgsMapToolIdentify
from SustainAssess.core.outputs import OutputVector,OutputRaster, OutputTable,OutputVector_liu
from qgis.utils import iface

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
# os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class FieldType(object):
    DATA_TYPE_ID = 0
    DATA_TYPE_NUMERIC = 1
    DATA_TYPE_ALL = -1
class Plot_Check(GeoAlgorithm):
    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_VECTOR_KEY = "POLY_VECTOR_KEY"
    FOLDERSETTING = "FOLDERSETTING"
    HTML_DLG = 'HTML_DLG'  #

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Results Visualization/Check Results"
        self.name, self.i18n_name = self.trAlgorithm('Check Results')
        self.group, self.i18n_group = self.trAlgorithm('Results Visualization')
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.POLY_VECTOR_KEY, self.tr('Input Layer\'s Key Field'),
                                              self.POLY_VECTOR,datatype=FieldType.DATA_TYPE_ID))
        self.addParameter(ParameterFolderSetting(self.FOLDERSETTING, self.tr(''), optional=False))
        self.addParameter(ParameterHtmlBuilder(self.HTML_DLG, self.tr(''), optional=False))
    def getCustomParametersDialog(self):
        self.dlg = PlotCheckDialog(self,parent=iface.mainWindow())
        return self.dlg
    def processAlgorithm(self, progress):
        source_param = self.getParameterFromName(self.POLY_VECTOR)
        sourceLayer = source_param.getLayerObject()


class ParameterFolderSetting(Parameter):
    def __init__(self, name='', description='', parent=None, datatype=-1,
                 optional=False,default = None):
        Parameter.__init__(self, name, description, None, optional)
        self.parent = parent
        self.datatype = int(datatype)
        self.default = default

    def setValue(self, obj):
        if obj is None:
            if self.optional:
                self.value = None
                return True
            return False

        if isinstance(obj, list):
            if len(obj) == 0:
                if self.optional:
                    self.value = None
                    return True
                return False
            self.value = obj
            return True
        else:
            self.value = str(obj)
            return True

    def __str__(self):
        return self.name + ' <' + self.__module__.split('.')[-1] + ' from ' \
            + self.parent + '>'
class ParameterHtmlBuilder(Parameter):
    def __init__(self, name='', description='', parent=None, datatype=-1,
                 optional=False,default = None):
        Parameter.__init__(self, name, description, None, optional)
        self.parent = parent
        self.datatype = int(datatype)
        self.default = default

    def setValue(self, obj):
        if obj is None:
            if self.optional:
                self.value = None
                return True
            return False

        if isinstance(obj, list):
            if len(obj) == 0:
                if self.optional:
                    self.value = None
                    return True
                return False
            self.value = obj
            return True
        else:
            self.value = str(obj)
            return True

    def __str__(self):
        return self.name + ' <' + self.__module__.split('.')[-1] + ' from ' \
            + self.parent + '>'
class FolderSettingDlg(QDialog):
    def __init__(self,titles,data,parent=None):
        self.titles = titles #list ["Path"]
        self.data_ = data[:] # data(1D list)["C:\path\line","C:\path\radar"]
        QDialog.__init__(self,parent)
        self.setWindowTitle("Select Result Directory")
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.setupPanel()
        self.updateTableWidget()
        self.selection = [] # store the row index of selections
    def setupPanel(self):
        self.resize(591, 409)
        t0_vlayout = QVBoxLayout(self)
        t0_1_hlayout = QHBoxLayout()

        self.tableWidget = QTableWidget()
        self.tableWidget.setColumnCount(1)
        w = self.width()
        self.tableWidget.setColumnWidth(0,w)
        self.tableWidget.setRowCount(0)
        t0_1_hlayout.addWidget(self.tableWidget)

        t0_1_2_hlayout = QVBoxLayout()
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        btn_add = QPushButton()
        btn_add.setSizePolicy(sizePolicy)
        btn_add.setMaximumSize(QSize(20, 20))
        btn_add.setText("")
        pixmap = QPixmap(os.path.join(pluginPath,"icons","plus.png"))
        curIcon = QIcon(pixmap)
        btn_add.setIcon(curIcon)
        btn_add.setIconSize(QSize(20,20))
        btn_add.setObjectName("btn_add")
        t0_1_2_hlayout.addWidget(btn_add)
        
        btn_minus = QPushButton()
        btn_minus.setText("")
        btn_minus.setSizePolicy(sizePolicy)
        btn_minus.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","minus.png"))
        curIcon = QIcon(pixmap)
        btn_minus.setIcon(curIcon)
        btn_minus.setIconSize(QSize(20, 20))
        btn_minus.setObjectName("btn_minus")
        t0_1_2_hlayout.addWidget(btn_minus)

        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        t0_1_2_hlayout.addItem(spacerItem)
        t0_1_hlayout.addLayout(t0_1_2_hlayout)
        t0_vlayout.addLayout(t0_1_hlayout)
        
        btn_add.clicked.connect(self.add)
        btn_minus.clicked.connect(self.minus)

        t0_2_hlayout = QHBoxLayout()
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        t0_2_hlayout.addItem(spacerItem)
        btn_OK = QPushButton()
        btn_OK.setText("OK")
        btn_Cancel = QPushButton()
        btn_Cancel.setText("Cancel")
        t0_2_hlayout.addWidget(btn_OK)
        t0_2_hlayout.addWidget(btn_Cancel)
        btn_OK.clicked.connect(self.accept)
        btn_Cancel.clicked.connect(self.reject)
        t0_vlayout.addLayout(t0_2_hlayout)

    def updateTableWidget(self):
        rows = len(self.data_)
        cols = len(self.titles)
        # update the tableWidget (https://wiki.qt.io/How_to_Use_QTableWidget)
        self.tableWidget.setRowCount(rows)
        self.tableWidget.setColumnCount(cols)
        self.tableWidget.setHorizontalHeaderLabels(self.titles)  # set header
        self.tableWidget.verticalHeader().setVisible(False)  # no row name
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # disable edit
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setSelectionMode(QAbstractItemView.MultiSelection)
        # insert data
        for i, dt in enumerate(self.data_):
            self.tableWidget.setItem(i, 0, QTableWidgetItem(str(dt)))
    def add(self):
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        if settings.contains('/SustainAssess/LastOutputPath'):
            lastDir = str(settings.value('/SustainAssess/LastOutputPath'))
        else:
            lastDir = ''
        dir = QFileDialog.getExistingDirectory(self, "Open Directory",lastDir,
                                                QFileDialog.ShowDirsOnly | QFileDialog.DontResolveSymlinks)
        settings.setValue('/SustainAssess/LastOutputPath', dir)
        self.data_.append(dir)
        self.updateTableWidget()

    def minus(self):
        # adjust the rows of the self.selectedData and tableWidget
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            for sel in sels:
                temp = self.data_.pop(sel.row())
            self.updateTableWidget()

    def accept(self):
        self.done(1)
    def reject(self):
        self.done(0)


class MapClick(QgsMapToolIdentify):
    afterLeftClick = pyqtSignal()
    afterRightClick = pyqtSignal()
    def __init__(self, alg):
        QgsMapToolIdentify.__init__(self, iface.mapCanvas())
        self.alg = alg
    """
    def canvasPressEvent(self, event):
        x = event.pos().x()
        y = event.pos().y()
        transform = self.iface.mapCanvas().getCoordinateTransform()
        startPt = transform.toMapCoordinates(x, y)
        print("start", startPt)
    """

    def canvasReleaseEvent(self, event):
        alg = self.alg
        # get x, y coordinate which is integer; you can also use x = event.x()
        self.x = event.pos().x()  # print x
        self.y = event.pos().y()
        if (event.button() == Qt.LeftButton):
            self.afterLeftClick.emit()
        if (event.button() == Qt.RightButton):
            self.afterRightClick.emit()

class PlotCheckDialog(QDialog):
    def __init__(self,alg,parent=None):
        QDialog.__init__(self,parent)
        self.setWindowTitle("Check Results")
        self.executed = False
        self.alg = alg
        self.checkBoxes = {}
        self.dependentItems = {}
        self.iterateButtons = {}
        self.resFolders = []
        self.mainWidget = self.MainPanel()
        topVLayout = QVBoxLayout(self)
        topVLayout.addWidget(self.mainWidget)
        # setup QgsMapTool
        self.mapTool = MapClick(alg)
        self.mapTool.afterLeftClick.connect(self.afterLeftClick)
        self.mapTool.afterRightClick.connect(self.afterRightClick)
        iface.mapCanvas().setMapTool(self.mapTool)

        QgsProject.instance().layerWasAdded.connect(self.layerAdded_plotcheck)
        QgsProject.instance().layersWillBeRemoved.connect(self.layersWillBeRemoved_plotcheck)
    def MainPanel(self):
        myForm = QWidget()
        myForm.setObjectName("From")
        # myForm.resize(400,200) #resize(int w, int h)
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 20, QSizePolicy.Minimum, QSizePolicy.Preferred)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}
        self.widgets = {}
        self.labels = {}

        # add 1 parameter ParameterVector_RDBMS======(self.alg.POLY_VECTOR)==================================================
        param = self.alg.getParameterFromName(self.alg.POLY_VECTOR)
        layers = dataobjects.getVectorLayers(param.shapetype) # 2 Polygon
        item = QComboBox()
        if param.optional:
            item.addItem(self.NOT_SELECTED, None)
        for layer in layers:
            item.addItem(layer.name(), layer)
        item.currentIndexChanged.connect(self.updateDependentFields)
        item.name = param.name
        desc = param.description
        label = QLabel(desc)
        self.labels[param.name] = label
        self.widgets[param.name] = item
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        # add 2 parameter Select ID Field======(self.alg.POLY_VECTOR_KEY)====================================================
        param = self.alg.getParameterFromName(self.alg.POLY_VECTOR_KEY)
        item = QComboBox()
        desc = param.description
        label = QLabel(desc)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)
        self.widgets[param.name] = item
        self.addDependParam(param)

        # add 3 parameter Select folder======(self.alg.FOLDERSETTING)====================================================
        param = self.alg.getParameterFromName(self.alg.FOLDERSETTING)
        h_sflayout = QHBoxLayout()
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        h_sflayout.addItem(spacerItem)
        item = QPushButton()
        item.setText("Select Reults Folders")
        item.clicked.connect(self.selectFolders)
        h_sflayout.addWidget(item)
        self.layoutMain.insertLayout(self.layoutMain.count() - 2, h_sflayout)
        self.widgets[param.name] = item

        # add 4 parameter QTextBrowser ==========(self.alg.HTML_DLG)====================================================
        param = self.alg.getParameterFromName(self.alg.HTML_DLG)
        item = QTextBrowser()
        item.setMaximumHeight(999999999)
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        item.setSizePolicy(sizePolicy)
        item.setOpenLinks(False)
        def linkClicked(url):
            webbrowser.open(url.toString())
        item.anchorClicked.connect(linkClicked)
        self.widgets[param.name] = item
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        # add two buttons ==========(Open in Browser, Close)====================================================
        h_btn_layout = QHBoxLayout()
        btn_spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        h_btn_layout.addItem(btn_spacerItem)
        self.btn_OK = QPushButton()
        self.btn_OK.setText("Open in Browser")
        self.btn_Close = QPushButton()
        self.btn_Close.setText("Close")
        h_btn_layout.addWidget(self.btn_OK)
        h_btn_layout.addWidget(self.btn_Close)
        self.btn_OK.clicked.connect(self.OpenInHTML)
        self.btn_Close.clicked.connect(self.Close)
        self.layoutMain.insertLayout(self.layoutMain.count(), h_btn_layout)

        self.widgets[self.alg.POLY_VECTOR].currentIndexChanged.emit(0)
        return myForm
    def OpenInHTML(self):
        # open it in Browser
        temp = self.tempfile
        webbrowser.open("file:///"+temp)
    def Close(self):
        self.done(0)
    def afterLeftClick(self):
        # QMessageBox.information(None, 'TEST', 'afterLeftClick_')
        layer = self.activeLayer
        if layer is None:
            return
        # Identify the feature near the point and send feature id to share's variable
        idf = self.mapTool
        found_features = idf.identify(self.mapTool.x, self.mapTool.y, [layer], QgsMapToolIdentify.ActiveLayer)
        if len(found_features) > 0:
            layer = found_features[0].mLayer
            feature = found_features[0].mFeature
        # get ID
        id_f = self.widgets[self.alg.POLY_VECTOR_KEY].currentText()
        idx = layer.fields().indexFromName(id_f)
        id = feature[idx]

        # find images files
        img_list = []
        for folder in self.resFolders:
            for root,dirs,files in os.walk(folder):
                for file in files:
                    if file.endswith(".png"):
                        t1 = file.split(".")[0]
                        if len(t1.split("_"))<2:
                            continue
                        t_id = t1.split("_")[-1]
                        if str(id) == t_id:
                            img_list.append(os.path.join(folder,file))
        dir = tempfile.gettempdir()
        # delete temporay file if exists
        self.tempfile = os.path.join(dir,"%s_%s.html"%(layer.name(),str(id)))
        ftemp = open(self.tempfile,"w")
        # creat HTML in the tempory directory
        htmlstring = '''
            <!DOCTYPE html>
            <html>
            <head>
            <style>
            img { 
              width: 100%; 
            }
            </style>
            </head>
            <body>
            '''
        for i,img in enumerate(img_list):
            htmlstring+= '<img src="%s" alt="image%s" width="500">\n'%(img,str(i))
        htmlstring+='''
            </body>
            </html>
        '''
        ftemp.write(htmlstring)
        ftemp.close()
        # show in QTextBrowser
        self.widgets[self.alg.HTML_DLG].setHtml(htmlstring)

    def afterRightClick(self):
        self.afterLeftClick()
        popupmenu = QMenu()
        newAction = QAction(self.tr('Open in Browser...'), self)
        popupmenu.addAction(newAction)
        newAction.triggered.connect(self.OpenInHTML)
        popupmenu.exec_(QCursor.pos())
    def selectFolders(self):
        selectDlg = FolderSettingDlg(["Path"],self.resFolders,parent=self)
        flag = selectDlg.exec_()
        if flag == QDialog.Accepted:
            self.resFolders = selectDlg.data_[:]

    def runAsBatch(self):
        pass

    def setParamValues(self):
        params = self.alg.parameters
        outputs = self.alg.outputs

        for param in params:
            if param.hidden:
                continue
            if not self.setParamValue(
                    param, self.widgets[param.name]):
                raise AlgorithmDialogBase.InvalidParameterValue(
                    param, self.widgets[param.name])

        for output in outputs:
            if output.hidden:
                continue
            output.value = self.widgets[output.name].getValue()
            if isinstance(output, (OutputRaster, OutputVector, OutputTable,OutputVector_liu)):
                output.open = self.checkBoxes[output.name].isChecked()
        return True

    def setParamValue(self, param, widget, alg=None):
        if isinstance(param, ParameterRaster):
            return param.setValue(widget.getValue())
        elif isinstance(param,(ParameterVector_RDBMS)):
            return param.setValue(widget.getValue())
        elif isinstance(param, (ParameterVector)):
            try:
                return param.setValue(widget.itemData(widget.currentIndex()))
            except:
                return param.setValue(widget.getValue())
        elif isinstance(param, ParameterSelection):
            return param.setValue(widget.currentIndex())
        elif isinstance(param, ParameterTableField):
            if param.optional and widget.currentIndex() == 0:
                return param.setValue(None)
            return param.setValue(widget.currentText())

    def accept(self):
        self.settings.setValue("/Processing/dialogBase", self.saveGeometry())

        checkCRS = ProcessingConfig.getSetting(ProcessingConfig.WARN_UNMATCHING_CRS)
        try:
            self.setParamValues()
            if checkCRS and not self.alg.checkInputCRS():
                reply = QMessageBox.question(self, self.tr("Unmatching CRS's"),
                                             self.tr('Layers do not all use the same CRS. This can '
                                                     'cause unexpected results.\nDo you want to '
                                                     'continue?'),
                                             QMessageBox.Yes | QMessageBox.No,
                                             QMessageBox.No)
                if reply == QMessageBox.No:
                    return

            msg = self.alg._checkParameterValuesBeforeExecuting()
            if msg:
                QMessageBox.warning(
                    self, self.tr('Unable to execute algorithm'), msg)
                return
            self.btnRun.setEnabled(False)
            self.btnClose.setEnabled(False)
            buttons = self.iterateButtons
            self.iterateParam = None

            for i in range(len(buttons.values())):
                button = buttons.values()[i]
                if button.isChecked():
                    self.iterateParam = buttons.keys()[i]
                    break

            self.progressBar.setMaximum(0)
            self.lblProgress.setText(self.tr('Processing algorithm...'))
            # Make sure the Log tab is visible before executing the algorithm
            try:
                # self.tabWidget.setCurrentIndex(1)
                self.repaint()
            except:
                pass

            QApplication.setOverrideCursor(QCursor(Qt.WaitCursor))

            self.setInfo(
                self.tr('<b>Algorithm %s starting...</b>') % self.alg.name)

            if self.iterateParam:
                if runalgIterating(self.alg, self.iterateParam, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
            else:
                command = self.alg.getAsCommand()
                if command:
                    ProcessingLog.addToLog(
                        ProcessingLog.LOG_ALGORITHM, command)
                if runalg(self.alg, self):
                    self.finish()
                else:
                    QApplication.restoreOverrideCursor()
                    self.resetGUI()
        except AlgorithmDialogBase.InvalidParameterValue as e:
            try:
                self.buttonBox.accepted.connect(lambda:
                                                e.widget.setPalette(QPalette()))
                palette = e.widget.palette()
                palette.setColor(QPalette.Base, QColor(255, 255, 0))
                e.widget.setPalette(palette)
                self.lblProgress.setText(
                    self.tr('<b>Missing parameter value: %s</b>') % e.parameter.description)
                return
            except:
                QMessageBox.critical(self,
                                     self.tr('Unable to execute algorithm'),
                                     self.tr('Wrong or missing parameter values'))
    def reject(self):
        self.done(0)
    def finish(self):
        keepOpen = ProcessingConfig.getSetting(ProcessingConfig.KEEP_DIALOG_OPEN)

        if self.iterateParam is None:
            if not handleAlgorithmResults(self.alg, self, not keepOpen):
                self.resetGUI()
                return

        self.executed = True
        self.setInfo('Algorithm %s finished' % self.alg.name)
        QApplication.restoreOverrideCursor()

        if not keepOpen:
            self.close()
        else:
            self.resetGUI()
            if self.alg.getHTMLOutputsCount() > 0:
                self.setInfo(
                    self.tr('HTML output has been generated by this algorithm.'
                            '\nOpen the results dialog to check it.'))
    def closeEvent(self, evt):
        # ProcessingLog.addToLog(ProcessingLog.LOG_INFO, "AggregationDLG Close")
        QgsProject.instance().layerWasAdded.disconnect(self.layerAdded_plotcheck)
        QgsProject.instance().layersWillBeRemoved.disconnect(self.layersWillBeRemoved_plotcheck)
        super(PlotCheckDialog, self).closeEvent(evt)

    def layerAdded_plotcheck(self,layer):
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    if dataobjects.canUseVectorLayer(layer, param.shapetype):
                        widget = self.widgets[param.name]
                        if isinstance(widget, InputLayerRDBMSelectorPanel) and hasattr(widget.cmbText, 'addItem'):
                            widget = widget.cmbText
                        widget.addItem(layer.name(), layer)
        elif layer.type() == QgsMapLayer.RasterLayer and dataobjects.canUseRasterLayer(layer):
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText
                    widget.addItem(self.getExtendedLayerName(layer), layer)

    def layersWillBeRemoved_plotcheck(self,layers):
        for layer in layers:
            self.layerRemoved(layer)
    def layerRemoved(self, layer):
        layer = QgsProject.instance().mapLayer(layer)
        widget = None
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    widget = self.widgets[param.name]
                    if isinstance(widget, InputLayerRDBMSelectorPanel):
                        widget = widget.cmbText

                        if widget is not None:
                            idx = widget.findData(layer)
                            if idx != -1:
                                widget.removeItem(idx)
                            widget = None

        elif layer.type() == QgsMapLayer.RasterLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText

                    if widget is not None:
                        idx = widget.findData(layer)
                        if idx != -1:
                            widget.removeItem(idx)
                        widget = None
    def addDependParam(self,param):
        if isinstance(param.parent,list):
            for parent in param.parent:
                if parent in self.dependentItems:
                    items = self.dependentItems[parent]
                else:
                    items = []
                    self.dependentItems[parent] = items
                items.append(param)
        else:
            if param.parent in self.dependentItems:
                items = self.dependentItems[param.parent]
            else:
                items = []
                self.dependentItems[param.parent] = items
            items.append(param)
    def updateDependentFields(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        if sender.name not in self.dependentItems:
            return
        layer = sender.itemData(sender.currentIndex())
        if not layer:
            return
        self.activeLayer = layer
        children = self.dependentItems[sender.name]
        for child in children:
            if (isinstance(child, ParameterTableField)):
                widget = self.widgets[child.name]
                widget.clear()
                child_param = self.alg.getParameterFromName(child.name)
                datatype = child_param.datatype
                fieldTypes = []
                if datatype == FieldType.DATA_TYPE_ID:
                    fieldTypes = [QVariant.String, QVariant.Int, QVariant.LongLong,
                                  QVariant.UInt, QVariant.ULongLong]
                elif datatype == FieldType.DATA_TYPE_NUMERIC:
                    fieldTypes = [QVariant.Int, QVariant.Double, QVariant.LongLong,
                                  QVariant.UInt, QVariant.ULongLong]

                def Spatialite2qgis(type):
                    typeTrans = {"INT": QVariant.Int, "INTEGER": QVariant.Int, "TINYINT": QVariant.Int,
                                 "SMALLINT": QVariant.Int, "MEDIUMINT": QVariant.LongLong, "BIGINT": QVariant.LongLong,
                                 "UNSIGNED BIG INT": QVariant.LongLong, "INT2": QVariant.Int, "INT8": QVariant.LongLong,
                                 "INTEGER": QVariant.LongLong, "CHARACTER": QVariant.String, "VARCHAR": QVariant.String,
                                 "VARYING CHARACTER": QVariant.String, "NCHAR": QVariant.String,
                                 "NATIVE CHARACTER": QVariant.String,
                                 "NVARCHAR": QVariant.String, "TEXT": QVariant.String, "REAL": QVariant.Double,
                                 "DOUBLE": QVariant.Double, "DOUBLE PRECISION": QVariant.Double,
                                 "FLOAT": QVariant.Double,
                                 "REAL": QVariant.Double, "NUMERIC": QVariant.Double, "DECIMAL": QVariant.Double,
                                 "BOOLEAN": QVariant.Int, "DATE": QVariant.String, "DATETIME": QVariant.String}
                    ind = type.find("(")
                    if ind > 0:
                        type = type[0:ind]
                    if type in typeTrans.keys():
                        return typeTrans[type]
                    else:
                        return None

                def Postg2qgis(type):
                    Postg2qgis = {"bigint": QVariant.LongLong, "varbinary": QVariant.ByteArray,
                                  "char": QVariant.String, "varchar": QVariant.String, "integer": QVariant.Int,
                                  "numeric": QVariant.Double, "decimal": QVariant.Double, "real": QVariant.Double,
                                  "double": QVariant.Double, "date": QVariant.String, "time": QVariant.Time,
                                  "timestamp": QVariant.String, "int": QVariant.Int, "int2": QVariant.Int,
                                  "int4": QVariant.Int, "int8": QVariant.LongLong, "text": QVariant.String,
                                  "float4": QVariant.Double, "float8": QVariant.Double, "float64": QVariant.Double}

                    ind = type.find("(")
                    if ind > 0:
                        type = type[0:ind]
                    if type in Postg2qgis.keys():
                        return Postg2qgis[type]
                    else:
                        return None

                fieldNames = []
                idfieldNames = []
                idfieldTypes = []
                # ============for ParameterVector_RDBMS
                if isinstance(layer, dict):
                    if "uri" in layer.keys():
                        uri = layer["uri"]
                        if uri.startswith(u"spatialite:"):
                            uri = uri[len(u"spatialite:"):]
                            uri = QgsDataSourceUri(uri)
                            try:
                                db = spatialite.GeoDB(uri)
                            except postgis.DbError as e:
                                raise GeoAlgorithmExecutionException(
                                    "Couldn't connect to database:\n%s" % e.message)
                                # return False
                            sql_fields = 'pragma table_info(%s)' % (uri.table())
                            c = db.con.cursor()
                            c.execute(sql_fields)
                            fields = c.fetchall()
                            for field in fields:
                                type = field[2]
                                if not fieldTypes or (
                                        Spatialite2qgis(type) is not None and Spatialite2qgis(type) in fieldTypes):
                                    fieldNames.append(field[1])
                        elif uri.startswith(u"postgis:"):
                            uri = uri[len(u"postgis:"):]
                            uri = QgsDataSourceUri(uri)
                            try:
                                db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                                                   dbname=uri.database(), user=uri.username(), passwd=uri.password())
                            except postgis.DbError as e:
                                raise GeoAlgorithmExecutionException(
                                    "Couldn't connect to database:\n%s" % e.message)
                                # return False
                            fields = db.get_table_fields(uri.table(), uri.schema())
                            for field in fields:
                                type = field.data_type
                                if not fieldTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in fieldTypes):
                                    fieldNames.append(field.name)
                        else:
                            layer = dataobjects.getObjectFromUri(uri)
                            for field in layer.fields():
                                if not fieldTypes or field.type() in fieldTypes:
                                    fieldNames.append(str(field.name()))
                else:
                    for field in layer.fields():
                        if not fieldTypes or field.type() in fieldTypes:
                            fieldNames.append(str(field.name()))
                nrow = len(fieldNames)
                widget.addItems(fieldNames)