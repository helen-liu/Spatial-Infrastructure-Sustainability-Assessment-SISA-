# -*- coding: utf-8 -*-

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,math
from qgis.PyQt import uic,QtCore
import webbrowser
from qgis.PyQt.QtGui import QTextDocument,QBrush,QColor,QIcon,QFont
from qgis.PyQt.QtWidgets import QDialog,QTreeWidgetItem,QMessageBox,QWidget,QVBoxLayout,QPushButton,QScrollArea,QFrame,QSpacerItem,QSizePolicy,\
            QLabel,QHBoxLayout,QTableWidget,QTableWidgetItem,QComboBox
from qgis.PyQt.QtWidgets import QAbstractItemView,QFileDialog
from qgis.PyQt.QtCore import QVariant,QRect,QSize,NULL,QItemSelectionModel,Qt
from qgis.core import (QgsProject,QgsVectorLayer,QgsField,QgsFields,QgsFeature,\
                       QgsDataSourceUri,QgsMapLayer)
from SustainAssess.gui.OutputSelectionPanel import OutputSelectionPanel
from SustainAssess.gui.InputLayerRDBMSelectorPanel import InputLayerRDBMSelectorPanel
from qgis.gui import QgsCollapsibleGroupBox
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.gui.AlgorithmDialogBase import AlgorithmDialogBase
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterSelection,ParameterRaster
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector,OutputFile
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.tools import dataobjects,postgis,spatialite
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from qgis.utils import iface

import numpy as np

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]
WIDGET, BASE = uic.loadUiType(os.path.join(pluginPath,'ui','DlgAhpBase.ui'))

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s
class AHP(GeoAlgorithm):

    POLY_ZONE_VECTOR = 'POLY_ZONE_VECTOR' #poly_layer REGION_BY_WAYS_LAYER
    METHOD = 'METHOD'
    METHOD_TYPES = ['Linear Additive','Geometric Mean']
    OUTPUT_AS_LAYER = 'OUTPUT_AS_LAYER'
    OUTPUT_WEIGHT = "OUTPUT_WEIGHT"
    TOPITEMS = ["Economic","Environmental","Social","Resilient","Composite"]
    TOPITEMS_ALIAS = {"Economic":"Eco", "Environmental":"Env", "Social":"Soc", "Resilient":"Res", "Composite":"Comp"}
    SELECTED_ITEMS = []
    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Indicator Analysis/AHP"
        self.name, self.i18n_name = self.trAlgorithm('AHP')
        self.group, self.i18n_group = self.trAlgorithm('Indicator Analysis')
        self.addParameter(ParameterVector_RDBMS(self.POLY_ZONE_VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))#[TODO]
        self.addParameter(ParameterSelection(self.METHOD, self.tr('Select Aggregation Method'), self.METHOD_TYPES))
        self.addOutput(OutputVector(self.OUTPUT_AS_LAYER, self.tr('Output Result Layer')))
        self.addOutput(OutputFile(self.OUTPUT_WEIGHT, self.tr('Output Weights File'),"weight"))

    def getCustomParametersDialog(self):
        self.dlg = AHPDialog(self)
        return self.dlg
    def processAlgorithm(self, progress):
        data_dic = {"p":[],"d":None,"w":1.0,"n":"root","path":None}
        w_temp = self.dlg.Widgets_list[0]
        top_col = []
        top_col_weight = []
        if isinstance(w_temp,MatrixPanel):
            top_col.extend(w_temp.col_list)
            top_col_weight.extend(w_temp.col_weight)
        else:
            #[TODO] pop error
            return
        for i in range(len(top_col)):
            data_dic["p"].append({"p":[],"w":top_col_weight[i],"d":None,"n":top_col[i],"path":None})
        #create fields according to the top level matrix
        for wid in self.dlg.Widgets_list:
            if isinstance(wid,MainPanelLevel1):
                # polyBase = wid.widgets[self.POLY_ZONE_VECTOR].getValue()
                paramInput = self.getParameterFromName(self.POLY_ZONE_VECTOR)
                polyBase = paramInput.getLayerObject()
                polyID = wid.widgets["IDfield"].currentText()
                polyIDtype = wid.widgets["IDfield"].itemData(wid.widgets["IDfield"].currentIndex())
                break
        idTypes_map = {'10': "text",'2':"integer",'4':"bigint",
                          '3':"integer", '5':"bigint"}

        fields = QgsFields()
        fields.append(QgsField('id', int(polyIDtype), idTypes_map[polyIDtype], 10, 0))
        fields.append(QgsField('E0', QVariant.Double, 'numeric(20,10)', 20, 10))
        for col in top_col:
            fields.append(QgsField(col, QVariant.Double, 'numeric(20,10)', 20, 10))


        raw_data_col_list = []
        top_tree = self.dlg.treeWidget.topLevelItem(0)
        ch_cnt = top_tree.childCount()

        for i in range(ch_cnt):
            tree_child = top_tree.child(i)
            ch_ch_cnt = tree_child.childCount()
            mainPanel = self.dlg.Widgets_list[self.dlg.TreeItems_list.index(tree_child)]
            # inputPath = mainPanel.widgets[self.parameters[0].name].getValue()
            paramInput = self.getParameterFromName(self.parameters[0].name)
            inputPath = paramInput.getLayerObject()
            idField = mainPanel.widgets["IDfield"].currentText()
            url = inputPath.dataProvider().dataSourceUri()
            data_dic["p"][i]["path"] = url
            for j in range(ch_ch_cnt):
                data_dic["p"][i]["p"].append({"p": [], "w": 1.0 / ch_ch_cnt, "d": None,"n":j})
                matrix_ch = tree_child.child(j)
                matrix_panel = self.dlg.Widgets_list[self.dlg.TreeItems_list.index(matrix_ch)]
                col_list = matrix_panel.col_list
                col_alias = matrix_panel.col_alias
                col_weight = matrix_panel.col_weight

                data_temp = self.getData(inputPath,col_list,idField)
                for k in range(len(col_alias)):
                    data_dic["p"][i]["p"][j]["p"].append({"p":None,"d":data_temp[k],"w":col_weight[k],"n":col_alias[k]})
                    raw_data_col_list.append(col_alias[k])
                    fields.append(QgsField(col_alias[k], QVariant.Double, 'numeric(20,10)', 20, 10))
        # aggreage the data to the matrix
        def aggregateDic(data_t):
            sum_data = {}
            if data_t["d"] is not None:
                sum_data = data_t["d"]
            else:
                for i in range(len(data_t["p"])):
                    if data_t["p"][i]["d"]==None:
                        data_t["p"][i]["d"] = aggregateDic(data_t["p"][i])
                    temp_data = {}
                    for idkey in data_t["p"][i]["d"].keys():#i: Feature ID
                        if data_t["p"][i]["d"][idkey]==NULL:
                            temp_data[idkey] = NULL
                        else:
                            temp_data[idkey] = data_t["p"][i]["d"][idkey] * data_t["p"][i]["w"]
                    if len(sum_data.keys())==0:
                        sum_data = temp_data
                    else:
                        temp2_data = {}
                        for idkey in temp_data.keys():
                            s1 = sum_data.get(idkey,NULL)
                            s2 = temp_data[idkey]
                            if (s1 == NULL) or (s2 == NULL):
                                temp2_data[idkey] = NULL
                            else:
                                temp2_data[idkey] = s1 + s2
                        sum_data = temp2_data
            return sum_data
        def aggregateWeight(data_t,keyword):
            p = data_t
            queue = [p]
            weight_queue = [p["w"]]
            weight_indicator = [1*(0 if p["n"]==keyword else 1)]
            res_weight = []
            res_name = []
            res_indicator = []
            while True:
                if len(queue)==0:
                    break
                cur = queue.pop(0)
                cur_weight = weight_queue.pop(0)
                cur_indicator = weight_indicator.pop(0)
                # add cur's children
                if cur["p"] is not None:
                    for ele in cur["p"]:
                        queue.append(ele)
                        weight_queue.append(ele["w"]*cur_weight)
                        weight_indicator.append(cur_indicator * (0 if ele["n"] == keyword else 1))
                        if ele["n"] == keyword:
                            weight_queue[-1] = 1.0
                else:
                    # leaf node
                    res_weight.append(cur_weight)
                    res_name.append(cur["n"])
                    res_indicator.append(cur_indicator)
            res_indicator  = [0 if i==1 else 1 for i in res_indicator]
            for i in range(len(res_indicator)):
                res_weight[i] = res_weight[i] *res_indicator[i]
            return res_weight,res_name


        data_dic["d"] = aggregateDic(data_dic)
        # write the data to the output
        writer = self.getOutputFromName(self.OUTPUT_AS_LAYER).getVectorWriter(
            fields,polyBase.wkbType(),polyBase.crs(),{"pk":"id"})
        # write weights
        out = self.getOutputFromName(self.OUTPUT_WEIGHT)
        weightfile = out.value
        f_out = open(weightfile,"w")
        f_out.write("Dimension,%s\n"%(",".join(top_col)))
        f_out.write("Indicator,"+",".join(raw_data_col_list)+"\n")
        weights,titles = aggregateWeight(data_dic,"root")
        f_out.write("E0 Overall Weight, "+",".join([str(w) for w in weights])+"\n")
        for col in top_col:
            weights, titles = aggregateWeight(data_dic, col)
            f_out.write(col+" Weight,")
            f_out.write(",".join([str(w) for w in weights])+"\n")
        f_out.write("\n")

        for i in range(ch_cnt):
            tree_child = top_tree.child(i)
            ch_ch_cnt = tree_child.childCount()
            mainPanel = self.dlg.Widgets_list[self.dlg.TreeItems_list.index(tree_child)]
            # inputPath = mainPanel.widgets[self.parameters[0].name].getValue()
            paramInput = self.getParameterFromName(self.parameters[0].name)
            inputPath = paramInput.getLayerObject()
            f_out.write(mainPanel.param["title"]+"\n")
            if isinstance(inputPath, QgsVectorLayer):
                url = inputPath.dataProvider().dataSourceUri()
                f_out.write("INPUT=" + str(url) + "\n")
            else:
                f_out.write("INPUT=" + str("") + "\n")
            for j in range(ch_ch_cnt):
                matrix_ch = tree_child.child(j)
                matrix_panel = self.dlg.Widgets_list[self.dlg.TreeItems_list.index(matrix_ch)]
                col_list = matrix_panel.col_list
                col_alias = matrix_panel.col_alias
                for k in range(len(col_list)):
                    data_ = (data_dic["p"][i]["p"][j]["p"][k]["d"]).values()
                    data_2 = []
                    for xi in data_:
                        if xi!=NULL:
                            data_2.append(float(xi))
                    data_ = data_2
                    mean_ = sum(data_)/len(data_)
                    varRes = sum([(xi - mean_) ** 2 for xi in data_]) / (len(data_) - 1)
                    max_,min_= max(data_),min(data_)
                    f_out.write(col_list[k]+","+col_alias[k]+","+str(min_)+","+str(max_)+","+str(math.sqrt(varRes))+"\n")

        f_out.close()

        polys = polyBase.getFeatures()
        count = int(polyBase.featureCount())
        ft = QgsFeature()
        ind = 0
        for poly in polys:
            id_ = poly[polyID]
            attr = [id_]
            attr.append(data_dic["d"][id_])
            for i in range(len(top_col)):
                attr.append(data_dic["p"][i]["d"][id_])

            for i in range(ch_cnt):
                tree_child = top_tree.child(i)
                ch_ch_cnt = tree_child.childCount()
                for j in range(ch_ch_cnt):
                    matrix_ch = tree_child.child(j)
                    matrix_panel = self.dlg.Widgets_list[self.dlg.TreeItems_list.index(matrix_ch)]
                    col_list = matrix_panel.col_alias
                    for k in range(len(col_list)):
                        attr.append(data_dic["p"][i]["p"][j]["p"][k]['d'][id_])

            attr = [NULL if i==NULL else float(i) for i in attr]
            ft.setAttributes(attr)
            ft.setGeometry(poly.geometry())
            writer.addFeature(ft)
            ind+=1
        del writer
        QMessageBox.information(None, 'AHP', 'AHP Process Complete!')

    def getData(self,inputPath,col_list,id):
        polys = inputPath.getFeatures()
        count = int(inputPath.featureCount())
        data_ = [{} for col in col_list]
        for current, poly in enumerate(polys):
            for i in range(len(col_list)):
                data_[i][poly[id]] = poly[col_list[i]]
        return data_

class AHPDialog(BASE,WIDGET):
    def __init__(self, alg):
        super(AHPDialog, self).__init__(iface.mainWindow())
        self.setupUi(self)
        self.alg = alg
        self.setWindowTitle(self.alg.displayName())
        self.executed = False
        self.widget_seq = []
        self.Widgets_list = []
        self.TreeItems_list = []
        algHelp = self.alg.shortHelp()
        if algHelp is None:
            self.textShortHelp.setVisible(False)
        else:
            localpath = os.path.dirname(__file__).replace("\\", "/")
            self.textShortHelp.document().setMetaInformation(QTextDocument.DocumentUrl,
                                                             os.path.join(pluginPath,'algs','help'))
            self.textShortHelp.setHtml(algHelp)

        self.textShortHelp.setOpenLinks(False)

        def linkClicked(url):
            webbrowser.open(url.toString())

        self.textShortHelp.anchorClicked.connect(linkClicked)

        if len(self.alg.SELECTED_ITEMS)<=3:
            t_titles=["Dimensions"]
            t_data = []
            for ele in self.alg.TOPITEMS:
                t_data.append([ele])
            dlg = TopWizard(t_titles,t_data)
            if dlg.exec_() == QDialog.Accepted:
                inds = dlg.selection
                self.alg.SELECTED_ITEMS=[]
                for ind in inds:
                    self.alg.SELECTED_ITEMS.append(t_data[ind][0])

        selected_fs = self.alg.SELECTED_ITEMS
        # selected_alias = [""]*len(selected_fs)
        # for i in range(len(selected_fs)):
        #     if selected_alias[i]=="":
        #         selected_alias[i] = selected_fs[i]
        selected_alias = [self.alg.TOPITEMS_ALIAS[ele] for ele in selected_fs]
        self.secondItems_title = selected_fs
        self.secondItems_title_alias = selected_alias

        self.init_tree()

    def init_tree(self):
        # self.secondItems_title = ["E1","E2","E3"]#["E1","E2","E3","E4","E5"]

        self.treeWidget.clear()
        item = TopItem({"title":"Top Level","level":0,"col_list":self.secondItems_title})
        w = MatrixPanel({"title":"Top Level","level":0,"col_list":self.secondItems_title,"col_alias":self.secondItems_title_alias,"input":"","id":""},self.alg)
        self.Widgets_list.append(w)
        self.TreeItems_list.append(item)
        self.widget_seq.append(self.Widgets_list.index(w))
        self.stackedWidget.addWidget(w)
        self.treeWidget.addTopLevelItem(item)


        for i,i_t in enumerate(self.secondItems_title):
            item_t = SecondLevelItem({"title":i_t,"level":1})
            w = MainPanelLevel1({"title":i_t,"alias":self.secondItems_title_alias[i],"level":1},self.alg)
            self.Widgets_list.append(w)
            self.TreeItems_list.append(item_t)
            self.widget_seq.append(self.Widgets_list.index(w))
            self.stackedWidget.addWidget(w)
            item.addChild(item_t)

        item1 = TopItem({"title": "Output", "level": 0, "col_list": []})
        self.treeWidget.addTopLevelItem(item1)
        self.TreeItems_list.append(item1)
        w_temp = OutputPanel({},self.alg)
        self.Widgets_list.append(w_temp)
        self.widget_seq.append(self.Widgets_list.index(w_temp))
        self.stackedWidget.addWidget(w_temp)
        # self.btnNext = self.buttonBox.button(QDialogButtonBox.Ok)
        self.btn1.setText('LoadTable')
        self.btn1.clicked.connect(self.loadtable)
        self.btn2.setText('SaveTable')
        self.btn2.clicked.connect(self.savetable)
        self.btn3.setText('Next')
        self.btn3.clicked.connect(self.accept)
        self.btn4.setText('Cancel')
        self.btn4.clicked.connect(self.reject)
        self.btn5.setText('SaveWeight')
        self.btn5.clicked.connect(self.saveWeight)
        # self.btnClose = self.buttonBox.button(QDialogButtonBox.Cancel)
        # self.btnClose.setText('Cancel')

        self.treeWidget.clicked.connect(self.on_click_tree)
    def loadtable(self):
        #Loading the pairwise table.

        loadDlg,ext = QFileDialog.getOpenFileName(None, 'Load Table', '.', 'AHP file (*.ahp)')
        toptree = self.treeWidget.topLevelItem(0)
        ch_cnt = toptree.childCount()
        for i in range(ch_cnt):
            tree_child = toptree.child(i)
            for chi in tree_child.takeChildren():
                ch_tree_ind = self.TreeItems_list.index(chi)
                w = self.stackedWidget.removeWidget(self.Widgets_list[ch_tree_ind])
                del w
                self.widget_seq.remove(ch_tree_ind)
                self.TreeItems_list.remove(chi)
                del chi

        if loadDlg:
            fin = open(loadDlg, "r")
            treeStack = []
            treeStack.append(self.treeWidget.topLevelItem(0))
            ch_cnt = self.treeWidget.topLevelItem(0).childCount()
            for i in range(ch_cnt):
                ind_i = ch_cnt - i - 1
                tree_child = self.treeWidget.topLevelItem(0).child(ind_i)
                treeStack.append(tree_child)

            treeStack_ind = 0
            while treeStack_ind<=len(treeStack)-1:
                line = fin.readline()
                t1,t2 = line.split(" ")
                assert t1 == "TREEITEM","FAILED TO READ FILE!"
                t2 = int(t2)
                level = -1
                for i in range(t2):
                    line = fin.readline()
                    line_list = line.strip().split("=")
                    if line_list[0].strip()=="level":
                        level = line_list[1].strip()
                    if line_list[0].strip()=="col_list":
                        col_list = line_list[1].strip()
                    if line_list[0].strip()=="title":
                        title = line_list[1].strip()
                if level==2:
                    treeStack_ind -=1
                treeItem = treeStack[treeStack_ind]
                tree_ind = self.TreeItems_list.index(treeItem)

                line = fin.readline()
                if level=="0":
                    assert line=="MatrixPanel", "SHOULD BE MatrixPanel"
                if level=="2":
                    assert line == "MatrixPanel", "SHOULD BE MatrixPanel"
                if level=="1":
                    assert line == "MainPanelLevel1", "SHOULD BE MatrixPanel"
                if line=="MatrixPanel":
                    if level=="2":
                        #need to creat and add
                        ind_inseq = self.TreeItems_list.index(treeItem)
                        item = LeafLevelItem({"title": title, "level": 2, "col_list": col_list})
                        w = MatrixPanel({"title": title, "level": 2, "col_list": col_list}, self.alg) #[TODO]
                        self.Widgets_list.append(w)
                        tree_ind = self.Widgets_list.index(w)
                        self.TreeItems_list.append(item)
                        self.widget_seq.insert(ind_inseq+1, self.Widgets_list.index(w))
                        self.stackedWidget.addWidget(w)
                        treeItem.addChild(item)
                    w_widget = self.Widgets_list[tree_ind]
                    w_widget.tableWidget.blockSignals(True)
                    row,col,lambdas,ci,cr = 0,0,0,0,0
                    row = int(fin.readline())
                    col = int(fin.readline())
                    lambdas = float(fin.readline())
                    ci = float(fin.readline())
                    cr = float(fin.readline())
                    csvList = list()
                    for i_t in range(row):
                        les = fin.readline().split(",")
                        for j in range(col):
                            cellItem = w_widget.tableWidget.item(i_t,j)
                            cellItem.setText(les[j])
                            w_widget.tableWidget.setItem(i_t, j, cellItem)
                    w_widget.lb_lamda.setText(u"λ = %0.6f"%(lambdas))
                    w_widget.lb_ci.setText("CI = %0.6f" % (ci))
                    w_widget.lb_cr.setText("CR = %0.6f" % (cr))
                    w_widget.tableWidget.blockSignals(False)

                if line =="MainPanelLevel1":
                    # INPUT
                    line = fin.readline()
                    indl = line.find("=")
                    value = line[indl+1:]
                    ind_inseq = self.TreeItems_list.index(treeItem)
                    mainpanel = self.Widgets_list[ind_inseq]
                    cnt_cmb = mainpanel.widgets[self.alg.parameters[0]].cmbText.count()
                    cmb_datas = []
                    cmb_datas_url = []
                    for i_line in range(cnt_cmb):
                        cmb_datas.append(mainpanel.widgets[self.alg.parameters[0]].cmbText.itemData(i_line))
                    for v in cmb_datas:
                        if isinstance(v, QgsVectorLayer):
                            url = value.dataProvider().dataSourceUri()
                            cmb_datas_url.append(url)
                        else:
                            cmb_datas_url.append("None")
                    com_ind = cmb_datas_url.index(value)
                    if com_ind!=-1:
                        mainpanel.widgets[self.alg.parameters[0]].cmbText.setCurrentIndex(com_ind)
                    # SELECTED FIELDS
                    line = fin.readline()
                    selected_fields = line.split("=")[1].split(",")
                    # SELECTED FIELDS ALIAS=
                    line = fin.readline()
                    selected_fields_alias = line.split("=")[1].split(",")
                    row_unselected = mainpanel.unselected_widget.rowCount()
                    for i in range(row_unselected):
                        pass#[TODO]
            treeStack_ind+=1

    def savetable(self):
        #Saving the pairwise table.
        saveDlg = QFileDialog.getSaveFileName(None, 'Save Table', '.', 'AHP file (*.ahp)')

        if saveDlg:
            if not os.path.splitext(saveDlg)[1]:
                saveDlg += '.ahp'
            fout = open(saveDlg,"w")
            treeStack = []
            treeStack.append(self.treeWidget.topLevelItem(0))
            while len(treeStack)>0:
                treeItem = treeStack.pop()
                #output the tree
                fout.write("TREEITEM %s\n"%(str(len(treeItem.param.keys()))))
                for par_key in treeItem.param.keys():
                    if par_key=="col_list":
                        fout.write(par_key + "=" + ",".join(treeItem.param[par_key]) + "\n")
                    else:
                        fout.write(par_key + "=" + str(treeItem.param[par_key]) + "\n")

                ch_cnt = treeItem.childCount()
                for i in range(ch_cnt):
                    ind_i = ch_cnt-i-1
                    tree_child = treeItem.child(ind_i)
                    treeStack.append(tree_child)


                tree_ind = self.TreeItems_list.index(treeItem)
                w_widget = self.Widgets_list[tree_ind]

                if isinstance(w_widget,MainPanelLevel1):
                    # MainPanelLevel1
                    fout.write("MainPanelLevel1"+"\n")
                    #save layer source
                    input_widget = w_widget.widgets[self.alg.parameters[0].name]
                    value = input_widget.getValue()
                    if isinstance(value,QgsVectorLayer):
                        url = value.dataProvider().dataSourceUri()
                        fout.write("INPUT="+str(url)+"\n")
                    else:
                        fout.write("INPUT=" + str("") + "\n")
                    #save selected fields
                    row_cnt = w_widget.selected_widget.rowCount()
                    selected_fs = []
                    selected_alias = []
                    for r_i in range(row_cnt-1):
                        cell1 = w_widget.selected_widget.item(r_i, 0)
                        cell2 = w_widget.selected_widget.item(r_i, 1)
                        selected_fs.append(cell1.text())
                        selected_alias.append(cell2.text())

                    fout.write("SELECTED FIELDS="+",".join(selected_fs)+"\n")
                    fout.write("SELECTED FIELDS ALIAS=" + ",".join(selected_alias)+"\n")


                if isinstance(w_widget,MatrixPanel):
                    # MatrixPanel
                    fout.write("MatrixPanel"+"\n")
                    tableSize = w_widget.tableWidget.columnCount()
                    fout.write("ROW = "+ str(tableSize)+"\n")
                    fout.write("COLUMN = " + str(tableSize)+"\n")
                    lamdas = w_widget.lb_lamda.text().strip().split("=")[1].strip()
                    fout.write("LAMDA = " + str(lamdas) + "\n")
                    CI = w_widget.lb_ci.text().strip().split("=")[1].strip()
                    fout.write("CI = " + str(CI) + "\n")
                    CR = w_widget.lb_cr.text().strip().split("=")[1].strip()
                    fout.write("CR = " + str(CR) + "\n")

                    try:
                        for i in range(int(tableSize)):
                            tempList = list()
                            for j in range(int(tableSize)):
                                tempList.append(w_widget.tableWidget.item(i,j).text())
                            fout.write(",".join(tempList)+"\n")

                    except Exception as saveError:
                        QMessageBox.critical(None, 'EasyAHP', str(saveError))
            fout.close()
    def saveWeight(self):
        saveDlg = QFileDialog.getSaveFileName(None, 'Save Weight', '.', 'AHP Weight file (*.ahpw)')

        if saveDlg:
            if not os.path.splitext(saveDlg)[1]:
                saveDlg += '.ahpw'
            fout = open(saveDlg,"w")
            treeStack = []
            top_item = self.treeWidget.topLevelItem(0)
            tree_ind = self.TreeItems_list.index(top_item)
            w_widget = self.Widgets_list[tree_ind]
            fout.write("col_list" + "=" + ",".join(w_widget.param["col_list"]) + "\n")
            fout.write("col_weight" + "=" + ",".join([str(i) for i in w_widget.col_weight]) + "\n")

            ch_cnt = top_item.childCount()
            for i in range(ch_cnt):
                tree_child = top_item.child(i)
                treeStack.append(tree_child)

            for child_tree in treeStack:
                #output the tree
                fout.write("TREEITEM %s\n"%(child_tree.param["title"]))
                # fout.write("col_list" + "=" + ",".join(treeItem.param["col_list"]) + "\n")
                # fout.write("col_weight" + "=" + ",".join(treeItem.param["col_weight"]) + "\n")
                children_ = []
                ch_cnt = child_tree.childCount()
                for i in range(ch_cnt):
                    tree_child = child_tree.child(i)
                    children_.append(tree_child)
                if ch_cnt>0:
                    tree_ind = self.TreeItems_list.index(child_tree)
                    w_widget = self.Widgets_list[tree_ind]
                    input_widget = w_widget.widgets[self.alg.parameters[0].name]
                    value = input_widget.getValue()
                    if isinstance(value, QgsVectorLayer):
                        url = value.dataProvider().dataSourceUri()
                        fout.write("INPUT=" + str(url) + "\n")
                    else:
                        fout.write("INPUT=" + str("") + "\n")
                    # MainPanelLevel1
                    for mat_child in children_:
                        ind_m = self.TreeItems_list.index(mat_child)
                        matrix_widget = self.Widgets_list[ind_m]
                        fout.write("col_list" + "=" + ",".join(matrix_widget.param["col_list"]) + "\n")
                        fout.write("col_weight" + "=" + ",".join([str(i) for i in matrix_widget.col_weight]) + "\n")

    def reject(self):
        self.done(0)
    def closeEvent(self, evt):
        for wid in self.Widgets_list:
            if isinstance(wid,MainPanelLevel1):
                QgsProject.instance().layerWasAdded.disconnect(wid.layerAdded_ahp)
                QgsProject.instance().layersWillBeRemoved.disconnect(wid.layersWillBeRemoved_ahp)
        super(AHPDialog, self).closeEvent(evt)

    def setupWidgets(self,w,param):
        w.setObjectName("Form")
        label = QLabel(w)
        label.setText(param["title"])

    def on_click_tree(self):
        self.currentItem = self.treeWidget.currentItem()

        #变换界面
        ind_list = self.TreeItems_list.index(self.currentItem)
        self.btn3.setText('Next')
        self.btn1.show()
        self.btn2.show()
        if isinstance(self.Widgets_list[ind_list], OutputPanel):
            self.btn3.setText('OK')
            self.btn1.hide()
            self.btn2.hide()
        self.stackedWidget.setCurrentIndex(ind_list)

    def accept(self):
        w_cur = self.stackedWidget.currentWidget()
        if isinstance(w_cur,MainPanelLevel1):
            self.alg.parameters[0].setValue(w_cur.widgets[self.alg.parameters[0].name].getValue())
        if isinstance(w_cur,OutputPanel):
            #check if E1, E2, E3, E4, E5's panels are completed
            self.btn3.setEnabled(False)

            all_finish = True
            # num_mainPanel = 0
            # num_matrixPanel = 0
            for wid in self.Widgets_list:
                if isinstance(wid,MatrixPanel):
                    # num_matrixPanel+=1
                    if not wid.finish_bool:
                        all_finish=False
                # if isinstance(wid,MainPanelLevel1):
                #     num_mainPanel+=1

            if (not all_finish):# and num_mainPanel+1>num_matrixPanel:
                QMessageBox.critical(None, ("All Matrix tables must be set"),
                                     ("Please Check Uncompleted Matrix Tables!"))
                self.btn3.setEnabled(True)
                return
            #set parameter

            param = self.alg.parameters[1]
            param.setValue(w_cur.widgets[param.name].currentIndex())
            self.alg.outputs[0].value = w_cur.widgets[self.alg.outputs[0].name].getValue()
            self.alg.outputs[1].value = w_cur.widgets[self.alg.outputs[1].name].getValue()
            # write the data to the place where user selected
            try:
                self.alg.processAlgorithm(None)
            except Exception as e:
                QMessageBox.information(self, "Error",
                                        "Error-%s" % str(e))
            finally:
                self.btn3.setEnabled(True)
            return

        if isinstance(w_cur,QWidget):
            ind_inlist = self.Widgets_list.index(w_cur)
            ind_inseq = self.widget_seq.index(ind_inlist)
            tree_cur = self.TreeItems_list[ind_inlist]
            if ind_inseq<len(self.Widgets_list):
                # if this item is the secondlevel item, it should be add leaf items group1, group2...
                need2update = False
                if isinstance(self.TreeItems_list[ind_inlist],SecondLevelItem):
                    select_fields = []
                    select_fields_alias = []
                    rows = w_cur.selected_widget.rowCount()
                    for i in range(rows-1):
                        cell1 = w_cur.selected_widget.item(i,0)
                        cell2 = w_cur.selected_widget.item(i,1)
                        select_fields.append(cell1.text())
                        if cell2.text():
                            select_fields_alias.append(cell2.text())
                        else:
                            select_fields_alias.append(cell1.text())
                    if len(select_fields)!=len(w_cur.select_fields):
                        need2update = True
                    for s_i in select_fields:
                        if need2update:
                            break
                        if s_i not in w_cur.select_fields:
                            need2update = True
                # if need update
                if need2update:
                    w_cur.select_fields = []
                    w_cur.select_fields.extend(select_fields)
                    w_cur.select_fields_alias = []
                    w_cur.select_fields_alias.extend(select_fields_alias)
                    inputPath = None#= w_cur.inputPath#w_cur.widgets[self.alg.parameters[0].name].getValue()
                    idField = None#w_cur.idfiled#.widgets["IDfield"].currentText()
                    #remove all the children of current tree item
                    for ch in tree_cur.takeChildren():
                        ch_tree_ind = self.TreeItems_list.index(ch)
                        self.stackedWidget.removeWidget(self.Widgets_list[ch_tree_ind])
                        del self.Widgets_list[ch_tree_ind]
                        self.widget_seq.remove(ch_tree_ind)
                        self.TreeItems_list.remove(ch)
                        del ch
                    # create new group1,group2,...
                    #[TODO] every 7 to form on group
                    g_ind = 1
                    g_num = 1
                    total_fields = len(select_fields)
                    g_group_list = []
                    if total_fields>7:
                        g_num = math.ceil(total_fields*1.0/7.0)
                        g_group_num = total_fields / g_num
                        for i in range(g_num-1):
                            g_group_list.append(g_group_num)
                            total_fields -= g_group_num
                        g_group_list.append(total_fields)
                    else:
                        g_group_list.append(total_fields)
                    start_ind = ind_inseq
                    for g_group_num in g_group_list:
                        g =  select_fields[0:g_group_num]
                        g_alias = select_fields_alias[0:g_group_num]
                        item = LeafLevelItem({"title": "group"+str(g_ind), "level": 2, "col_list": g,"col_alias":g_alias})
                        w = MatrixPanel({"title": "group"+str(g_ind), "level": 2, "col_list": g,"col_alias":g_alias, "input":inputPath,
                                         "id":idField}, self.alg)
                        self.Widgets_list.append(w)
                        self.TreeItems_list.append(item)
                        self.widget_seq.insert(start_ind+1, self.Widgets_list.index(w))
                        self.stackedWidget.addWidget(w)
                        tree_cur.addChild(item)
                        select_fields = select_fields[g_group_num:]
                        select_fields_alias = select_fields_alias[g_group_num:]
                        g_ind+=1
                        start_ind+=1

                if isinstance(self.Widgets_list[self.widget_seq[ind_inseq+1]],OutputPanel):
                    self.btn3.setText('OK')
                    self.btn1.hide()
                    self.btn2.hide()
                self.stackedWidget.setCurrentIndex(self.widget_seq[ind_inseq+1])
                self.treeWidget.setCurrentItem(self.TreeItems_list[self.widget_seq[ind_inseq+1]])
                self.treeWidget.setSelectionBehavior(QAbstractItemView.SelectItems)
            else:
                self.finish()

    def finish(self):
        keepOpen = ProcessingConfig.getSetting(ProcessingConfig.KEEP_DIALOG_OPEN)

        self.executed = True

        if not keepOpen:
            self.close()


class TopWizard(QDialog):
    def __init__(self,titles,data):
        self.titles = titles #list [id,..]
        self.data_ = data # data(2D list)[[1,...],[2,...]]
        QDialog.__init__(self)
        self.setWindowTitle("Select Dimensions...")
        self.setupPanel()
        self.updataTableWidget()
        self.selection = [] # store the row index of selections
    def setupPanel(self):
        self.resize(591, 409)
        self.horizontalLayout = QHBoxLayout(self)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.tableWidget = QTableWidget(self)
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setColumnCount(len(self.titles))
        # self.tableWidget.setColumnWidth(0,150)
        self.tableWidget.setRowCount(0)
        self.horizontalLayout.addWidget(self.tableWidget)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.btn_addselection = QPushButton(self)
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.btn_addselection.sizePolicy().hasHeightForWidth())
        self.btn_addselection.setSizePolicy(sizePolicy)
        self.btn_addselection.setObjectName(_fromUtf8("btn_addselection"))
        self.verticalLayout.addWidget(self.btn_addselection)
        self.btn_cancel = QPushButton(self)
        self.btn_cancel.setObjectName(_fromUtf8("btn_cancel"))
        self.verticalLayout.addWidget(self.btn_cancel)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout.addLayout(self.verticalLayout)

        self.btn_addselection.setText("OK")
        self.btn_cancel.setText("Cancel")

        self.btn_addselection.clicked.connect(self.accept)
        self.btn_cancel.clicked.connect(self.reject)
    def updataTableWidget(self):
        rows = len(self.data_)
        cols = len(self.titles)
        # update the tableWidget (https://wiki.qt.io/How_to_Use_QTableWidget)
        self.tableWidget.setRowCount(rows)

        self.tableWidget.setColumnCount(cols)
        self.tableWidget.setHorizontalHeaderLabels(self.titles)  # set header
        self.tableWidget.verticalHeader().setVisible(False)  # no row name
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # disable edit
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setSelectionMode(QAbstractItemView.MultiSelection)
        # insert data
        for i, dt in enumerate(self.data_):
            for j, d in enumerate(dt):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(d)))
    def accept(self):
        # indj = self.titles.index("id")
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            self.selection = [sel.row() for sel in sels]
        # if len(self.selection)<3:
        #     QMessageBox.warning(self, "Dimensions", "Too less dimensions. Need at least 3 dimensions to continue...")
        #     return
        # self.done(QDialog.Accepted)
        super(TopWizard,self).accept()

class MainPanelLevel1(QWidget):
    def __init__(self,param,alg):
        self.param = param # {"title":i_t,"alias":self.secondItems_title_alias[i],"level":1}
        self.alg = alg
        QWidget.__init__(self)
        self.select_fields = []
        self.select_fields_alias = []
        self.setupPanel()
        # self.inputPath = None
        # self.idfiled = None
        # self.need2updated = False
        QgsProject.instance().layerWasAdded.connect(self.layerAdded_ahp)
        QgsProject.instance().layersWillBeRemoved.connect(self.layersWillBeRemoved_ahp)

    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")
        # myForm.resize(400, 200)  # resize(int w, int h)
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20,10, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}
        self.labels = {}
        # add 1 parameter ParameterVector_RDBMS=========================================================
        layers = dataobjects.getVectorLayers(self.alg.parameters[0].shapetype)  # 2 Polygon
        items = []
        for layer in layers:
            items.append((layer.name(), layer))
        param = self.alg.parameters[0]
        widget = InputLayerRDBMSelectorPanel(items, param)
        widget.cmbText.name = param.name
        widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)
        self.widgets[param.name] = widget

        desc = param.description + " for " + self.param["title"]
        label = QLabel(desc)
        # label.setToolTip(tooltip)
        self.labels[param.name] = label

        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)
        # self.widgets[param.name] = widget
        # add 2 related fields used for select ID field
        label = QLabel("ID Filed:")
        item = QComboBox()
        item.currentIndexChanged.connect(self.idchanged)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        self.widgets["IDfield"] = item
        # add 2 parameter ParameterVector_RDBMS=========================================================
        widget_2 = QWidget()
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(2)
        widget_2.setSizePolicy(sizePolicy)

        widget_2.setObjectName("widget_2")
        # widget_2.resize(400, 550)
        self.horizontalLayout = QHBoxLayout(widget_2)
        self.horizontalLayout.setObjectName("horizontalLayout")
        self.horizontalLayout.setSpacing(2)
        self.horizontalLayout.setMargin(0)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName("verticalLayout_6")
        self.label = QLabel(widget_2)
        font = QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.verticalLayout_6.addWidget(self.label)
        self.unselected_widget = QTableWidget(widget_2)
        self.unselected_widget.setObjectName("unselected_widget")
        # self.unselected_widget.resize(100, 550)
        self.verticalLayout_6.addWidget(self.unselected_widget)
        self.horizontalLayout.addLayout(self.verticalLayout_6)
        self.unselected_widget.insertColumn(0)
        self.unselected_widget.setHorizontalHeaderItem(0, QTableWidgetItem("Fields"))
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(2)
        self.unselected_widget.setSizePolicy(sizePolicy)
        self.unselected_widget.setMinimumSize(QSize(100, 250))

        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName("verticalLayout_5")
        self.select_btn = QPushButton(widget_2)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.select_btn.sizePolicy().hasHeightForWidth())
        self.select_btn.setSizePolicy(sizePolicy)
        self.select_btn.setMaximumSize(QSize(30, 30))
        self.select_btn.setObjectName("select_btn")
        self.verticalLayout_5.addWidget(self.select_btn)
        self.deselect_btn = QPushButton(widget_2)
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.deselect_btn.sizePolicy().hasHeightForWidth())
        self.deselect_btn.setSizePolicy(sizePolicy)
        self.deselect_btn.setMaximumSize(QSize(30, 30))
        self.deselect_btn.setObjectName("deselect_btn")
        self.verticalLayout_5.addWidget(self.deselect_btn)

        self.horizontalLayout.addLayout(self.verticalLayout_5)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName("verticalLayout_4")
        self.label_2 = QLabel(widget_2)
        font = QFont()
        font.setFamily("Times New Roman")
        font.setPointSize(10)
        self.label_2.setFont(font)
        self.label_2.setObjectName("label_2")
        self.verticalLayout_4.addWidget(self.label_2)
        self.selected_widget = QTableWidget(widget_2)
        self.pop_tableview(self.selected_widget)
        self.selected_widget.setObjectName("selected_widget")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(2)
        self.selected_widget.setSizePolicy(sizePolicy)
        self.selected_widget.setMinimumSize(QSize(100, 250))

        self.verticalLayout_4.addWidget(self.selected_widget)
        self.horizontalLayout.addLayout(self.verticalLayout_4)

        self.selected_widget.setAlternatingRowColors(True)
        self.selected_widget.setSortingEnabled(True)
        self.selected_widget.setDragEnabled(False)
        self.selected_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.selected_widget.setDragDropOverwriteMode(False)
        self.selected_widget.setDefaultDropAction(Qt.MoveAction)
        self.selected_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.selected_widget.setSelectionBehavior(QAbstractItemView.SelectItems)

        self.unselected_widget.setAlternatingRowColors(True)
        self.unselected_widget.setSortingEnabled(True)
        self.unselected_widget.setDragEnabled(False)
        self.unselected_widget.setDragDropMode(QAbstractItemView.NoDragDrop)
        self.unselected_widget.setDragDropOverwriteMode(False)
        self.unselected_widget.setDefaultDropAction(Qt.MoveAction)
        self.unselected_widget.setSelectionMode(QAbstractItemView.SingleSelection)
        self.unselected_widget.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.unselected_widget.setEditTriggers(QAbstractItemView.NoEditTriggers)

        self.label_2.setText("Selected Fields")
        self.select_btn.setText(">")
        self.deselect_btn.setText("<")

        self.label.setText("Available Fields")

        self.widgets["selection"] = widget_2

        desc = "Select Fields:"
        label = QLabel(desc)
        # label.setToolTip(tooltip)
        self.labels["selection"] = label

        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget_2)
        self.widgets["selection"] = widget_2

        self.init_signals()
        ind = widget.cmbText.currentIndex()
        widget.cmbText.currentIndexChanged.emit(ind)

    def init_signals(self):
        self.select_btn.clicked.connect(self._select)
        self.deselect_btn.clicked.connect(self._deselect)

        self.unselected_widget.itemDoubleClicked.connect(self._select)
        self.selected_widget.itemDoubleClicked.connect(self._deselect)

        #self.selected_widget.keyPressEvent.connect(self.keypress)
    def idchanged(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        self.idfiled = sender.currentText()
    def pop_tableview(self,table):
        #table = QTableWidget(table)
        colnames = ["Fields","Alias"]
        ncol = len(colnames)
        data = [[""],[""]]

        for i in range(ncol):
            table.insertColumn(i)
            table.setHorizontalHeaderItem(i,QTableWidgetItem(colnames[i]))
        nrow = len(data[0])
        ncol = len(data)
        for i in range(nrow):
            table.insertRow(i)
        for j in range(ncol):
            for i in range(nrow):
                item_t = QTableWidgetItem(str(data[j][i]))
                item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                if j==1:
                    item_t.setFlags(Qt.ItemIsSelectable |  Qt.ItemIsEnabled | Qt.ItemIsEditable)
                table.setItem(i,j,item_t)

    def _select(self):
        self._do_move_f2t(self.unselected_widget, self.selected_widget)
        # self.need2updated = True
    def _deselect(self):
        self._do_move_t2f(self.unselected_widget, self.selected_widget)
        # self.need2updated = True
    def _do_move_t2f(self, fromList, toList):
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        if len(targets)==0:
            return
        target = targets[0]
        t_row = toList.row(target)
        t_col = toList.column(target)
        if t_col!=0:
            return
        try:
            ind = self.fieldslist.index(target.text())
        except:
            return

        prev_from_item = toList.item(t_row,t_col)
        fromList.setItem(ind,0,toList.takeItem(t_row, t_col))
        toList.removeRow(t_row)

        fromList.setCurrentCell(ind,0,QItemSelectionModel.Select)
        fromList.scrollToItem(prev_from_item)
        nrows = toList.rowCount()
        for i in range(nrows-1):
            temp = toList.item(i, 1)
            temp.setText(self.param["alias"]+"_"+str(i+1))

    def _do_move_f2t(self, fromList, toList):
        recover = False
        temp = None
        add_to_last = True
        insert = False
        targets = toList.selectedItems()
        t_row, t_col = -1, -1
        nrows = toList.rowCount()
        # No selection
        if len(targets)==0:
            # find the first empty element
            for i in range(nrows):
                t_i = toList.item(i,0)
                if t_i.text()=="":
                    t_row = toList.row(t_i)
                    t_col = toList.column(t_i)
                    break
        else:
            # has selection
            target = targets[0]
            t_row = toList.row(target)
            t_col = toList.column(target)
            if t_col!=0:
                t_col = 0
                t_row = nrows - 1
            else:

                if target.text()!="":
                    recover=True
                    temp = target.text()
                    add_to_last = False
                    insert = True

        if t_row==-1:
            return
        if add_to_last:
            toList.insertRow(nrows)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(nrows,0,item_t)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            toList.setItem(nrows, 1, item_t)
        if insert:
            toList.insertRow(t_row+1)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            toList.setItem(t_row+1,0,item_t)
            item_t = QTableWidgetItem("")
            item_t.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
            toList.setItem(t_row+1, 1, item_t)
            t_row = t_row + 1
        for item in fromList.selectedItems():
            f_row = fromList.row(item)
            f_col = fromList.column(item)
            prev_from_item = fromList.item(f_row,f_col)
            toList.setItem(t_row,t_col,fromList.takeItem(f_row,f_col))
            fromList.scrollToItem(prev_from_item)
        # if recover:
        #     ind = self.fieldslist.index(temp)
        #     fromList.setItem(ind, 0, QTableWidgetItem(temp))
        toList.clearSelection()
        toList.setCurrentCell(t_row, 0, QItemSelectionModel.Select)
        nrows = toList.rowCount()
        for i in range(nrows-1):
            temp = toList.item(i, 1)
            temp.setText(self.param["alias"]+"_"+str(i+1))
        #toList.setCurrentCell(t_row, 1, QItemSelectionModel.Select)

    def setParamValues(self):
        params = self.alg.parameters
        outputs = self.alg.outputs

        for param in params:
            if param.hidden:
                continue
            if not self.setParamValue(
                    param, self.widgets[param.name]):
                raise AlgorithmDialogBase.InvalidParameterValue(
                    param, self.widgets[param.name])

        for output in outputs:
            if output.hidden:
                continue
            output.value = self.widgets[output.name].getValue()
        return True

    def setParamValue(self, param, widget, alg=None):
        if isinstance(param, ParameterRaster):
            return param.setValue(widget.getValue())
        elif isinstance(param,(ParameterVector_RDBMS)):
            return param.setValue(widget.getValue())
        elif isinstance(param, (ParameterVector)):
            try:
                return param.setValue(widget.itemData(widget.currentIndex()))
            except:
                return param.setValue(widget.getValue())

    def layerAdded_ahp(self,layer):
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    if dataobjects.canUseVectorLayer(layer, param.shapetype):
                        widget = self.widgets[param.name]
                        if isinstance(widget, InputLayerRDBMSelectorPanel) and hasattr(widget.cmbText, 'addItem'):
                            widget = widget.cmbText
                        widget.addItem(layer.name(), layer)
        elif layer.type() == QgsMapLayer.RasterLayer and dataobjects.canUseRasterLayer(layer):
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText
                    widget.addItem(self.getExtendedLayerName(layer), layer)

    def layersWillBeRemoved_ahp(self,layers):
        for layer in layers:
            self.layerRemoved(layer)
    def layerRemoved(self, layer):
        layer = QgsProject.instance().mapLayer(layer)
        widget = None
        if layer.type() == QgsMapLayer.VectorLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, (ParameterVector,ParameterVector_RDBMS)):
                    widget = self.widgets[param.name]
                    if isinstance(widget, InputLayerRDBMSelectorPanel):
                        widget = widget.cmbText

                        if widget is not None:
                            idx = widget.findData(layer)
                            if idx != -1:
                                widget.removeItem(idx)
                            widget = None

        elif layer.type() == QgsMapLayer.RasterLayer:
            for param in self.alg.parameters:
                if param.hidden:
                    continue
                if isinstance(param, ParameterRaster):
                    widget = self.widgets[param.name].cmbText

                    if widget is not None:
                        idx = widget.findData(layer)
                        if idx != -1:
                            widget.removeItem(idx)
                        widget = None

    def updateDependentFields(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        layer = sender.itemData(sender.currentIndex())
        # self.inputPath = layer
        if not layer:
            return
        widget = self.unselected_widget
        widget_sele = self.selected_widget
        widget.setRowCount(0)
        widget_sele.setRowCount(0)
        wid_ID = self.widgets["IDfield"]
        wid_ID.clear()

        fieldTypes = [QVariant.Int, QVariant.Double, QVariant.LongLong,
                          QVariant.UInt, QVariant.ULongLong]
        idTypes = [QVariant.String,QVariant.Int,QVariant.LongLong,
                          QVariant.UInt, QVariant.ULongLong]

        def Spatialite2qgis(type):
            typeTrans={"INT":QVariant.Int,"INTEGER":QVariant.Int,"TINYINT":QVariant.Int,
                        "SMALLINT":QVariant.Int,"MEDIUMINT":QVariant.LongLong,"BIGINT":QVariant.LongLong,
                        "UNSIGNED BIG INT":QVariant.LongLong,"INT2":QVariant.Int,"INT8":QVariant.LongLong,
                        "INTEGER":QVariant.LongLong,"CHARACTER":QVariant.String,"VARCHAR":QVariant.String,
                        "VARYING CHARACTER":QVariant.String,"NCHAR":QVariant.String,"NATIVE CHARACTER":QVariant.String,
                        "NVARCHAR":QVariant.String,"TEXT":QVariant.String,"REAL":QVariant.Double,
                        "DOUBLE":QVariant.Double,"DOUBLE PRECISION":QVariant.Double,"FLOAT":QVariant.Double,
                        "REAL":QVariant.Double,"NUMERIC":QVariant.Double,"DECIMAL":QVariant.Double,
                        "BOOLEAN":QVariant.Int,"DATE":QVariant.String,"DATETIME":QVariant.String}
            ind = type.find("(")
            if ind > 0:
                type = type[0:ind]
            if type in typeTrans.keys():
                return typeTrans[type]
            else:
                return None
        def Postg2qgis(type):
            Postg2qgis = {"bigint":QVariant.LongLong,"varbinary":QVariant.ByteArray,
                        "char":QVariant.String,"varchar":QVariant.String,"integer":QVariant.Int,
                        "numeric":QVariant.Double, "decimal":QVariant.Double,"real":QVariant.Double,
                        "double":QVariant.Double,"date":QVariant.String,"time":QVariant.Time,
                        "timestamp":QVariant.String,"int":QVariant.Int,"int2":QVariant.Int,
                        "int4":QVariant.Int,"int8":QVariant.LongLong,"text":QVariant.String,
                        "float4":QVariant.Double,"float8":QVariant.Double,"float64":QVariant.Double}

            ind = type.find("(")
            if ind > 0:
                type = type[0:ind]
            if type in Postg2qgis.keys():
                return Postg2qgis[type]
            else:
                return None

        fieldNames = set()
        idfieldNames = []
        idfieldTypes = []
        # ============for ParameterVector_RDBMS
        if isinstance(layer, dict):
            if "uri" in layer.keys():
                uri = layer["uri"]
                if uri.startswith(u"spatialite:"):
                    uri = uri[len(u"spatialite:"):]
                    uri = QgsDataSourceUri(uri)
                    try:
                        db = spatialite.GeoDB(uri)
                    except postgis.DbError as e:
                        raise GeoAlgorithmExecutionException(
                            "Couldn't connect to database:\n%s" % e.message)
                        # return False
                    sql_fields = 'pragma table_info(%s)' % (uri.table())
                    c = db.con.cursor()
                    c.execute(sql_fields)
                    fields = c.fetchall()
                    for field in fields:
                        type = field[2]
                        if not fieldTypes or (Spatialite2qgis(type) is not None and Spatialite2qgis(type) in fieldTypes):
                            fieldNames.add(field[1])
                        if not idTypes or (Spatialite2qgis(type) is not None and Spatialite2qgis(type) in idTypes):
                            idfieldNames.append(str(field[1]))
                            idfieldTypes.append(str(Spatialite2qgis(type)))
                elif uri.startswith(u"postgis:"):
                    uri = uri[len(u"postgis:"):]
                    uri = QgsDataSourceUri(uri)
                    try:
                        db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                                           dbname=uri.database(), user=uri.username(), passwd=uri.password())
                    except postgis.DbError as e:
                        raise GeoAlgorithmExecutionException(
                            "Couldn't connect to database:\n%s" % e.message)
                        # return False
                    fields = db.get_table_fields(uri.table(), uri.schema())
                    for field in fields:
                        type = field.data_type
                        if not fieldTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in fieldTypes):
                            fieldNames.add(field.name)
                        if not idTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in idTypes):
                            idfieldNames.append(str(field.name))
                            idfieldTypes.append(str(Postg2qgis(type)))
                else:
                    layer = dataobjects.getObjectFromUri(uri)
                    for field in layer.fields():
                        if not fieldTypes or field.type() in fieldTypes:
                            fieldNames.add(str(field.name()))
                        if not idTypes or field.type() in idTypes:
                            idfieldNames.append(str(field.name()))
                            idfieldTypes.append(str(field.type()))
        else:
            for field in layer.fields():
                if not fieldTypes or field.type() in fieldTypes:
                    fieldNames.add(str(field.name()))
                if not idTypes or field.type() in idTypes:
                    idfieldNames.append(str(field.name()))
                    idfieldTypes.append(str(field.type()))
        nrow = len(fieldNames)
        self.fieldslist = list(fieldNames)

        for i in range(len(idfieldNames)):
            wid_ID.addItem(str(idfieldNames[i]),idfieldTypes[i])
        self.idfiled = wid_ID.currentText()
        for i in range(nrow):
            widget.insertRow(i)
            item_t = QTableWidgetItem(str(self.fieldslist[i]))
            item_t.setFlags(Qt.ItemIsEnabled|Qt.ItemIsSelectable)
            widget.setItem(i,0,item_t)
        widget_sele.insertRow(0)
        widget_sele.setItem(0,0,QTableWidgetItem(""))
        widget_sele.setItem(0,1,QTableWidgetItem(""))

class OutputPanel(QWidget):
    def __init__(self,param,alg):
        self.param = param
        self.alg = alg
        QWidget.__init__(self)
        self.setupPanel()

    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")
        # myForm.resize(400, 200)  # resize(int w, int h)
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}

        label_temp = QLabel("Select Combination Method:")
        widget_temp = QComboBox()
        widget_temp.addItems(self.alg.parameters[1].options)
        self.widgets[self.alg.parameters[1].name] = widget_temp
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label_temp)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget_temp)

        for output in self.alg.outputs:
            if output.hidden:
                continue
            label = QLabel(output.description)
            widget = OutputSelectionPanel(output, self.alg)
            self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
            self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)
            self.widgets[output.name] = widget

class MatrixPanel(QWidget):
    CRI = {3:0.52,4:0.89,5:1.11,6:1.25,7:1.35,8:1.40,9:1.45,10:1.49,11:1.52,12:1.54,13:1.56,14:1.58,15:1.59}
    def __init__(self,param,alg):
        self.param = param
        self.inputPath = param["input"]
        self.idField = param["id"]
        self.col_list = param["col_list"]
        self.col_alias = param["col_alias"]
        self.col_weight = []
        self.alg = alg
        QWidget.__init__(self)

        self.setupPanel()
        self.tableMaker()
        self.label_8.hide()
        self.tableWidget.itemChanged.connect(self.itemchanged)
        self.calcBtn.clicked.connect(self.Calculate_button_click)
        self.finish_bool = False
    def setupPanel(self):
        Form = self

        self.verticalLayout = QVBoxLayout(Form)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        label = QLabel("Pairwise Comparison Matrix A:")
        self.verticalLayout.addWidget(label)
        self.tableWidget = QTableWidget(Form)
        self.tableWidget.setMinimumSize(QtCore.QSize(0, 400))
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)
        self.verticalLayout.addWidget(self.tableWidget)

        label = QLabel("AHP Consistency Indicators")
        self.verticalLayout.addWidget(label)

        hLayout = QHBoxLayout()
        self.lb_titles = QLabel()
        self.lb_titles.setContentsMargins(0, 0, 0, 0)
        # self.lb_titles.setGeometry(QtCore.QRect(40, 40, 91, 31))
        font = QFont()
        font.setPointSize(12)
        self.lb_titles.setFont(font)
        self.lb_titles.setObjectName(_fromUtf8("lb_titles"))
        hLayout.addWidget(self.lb_titles)
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        hLayout.addItem(spacerItem)
        self.verticalLayout.addLayout(hLayout)


        hLayout = QHBoxLayout()
        self.lb_weights = QLabel()
        self.lb_weights.setContentsMargins(0, 0, 0, 0)
        # self.lb_weights.setGeometry(QtCore.QRect(40, 40, 91, 31))
        font = QFont()
        font.setPointSize(12)
        self.lb_weights.setFont(font)
        self.lb_weights.setObjectName(_fromUtf8("lb_weights"))
        hLayout.addWidget(self.lb_weights)
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        hLayout.addItem(spacerItem)
        self.verticalLayout.addLayout(hLayout)

        hLayout = QHBoxLayout()
        self.lb_cr = QLabel()
        font = QFont()
        font.setPointSize(12)
        self.lb_cr.setFont(font)
        self.lb_cr.setObjectName(_fromUtf8("lb_cr"))
        self.lb_cr_value = QLabel()
        self.lb_cr_value.setContentsMargins(0, 0, 0, 0)
        hLayout.addWidget(self.lb_cr)
        hLayout.addWidget(self.lb_cr_value)
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        hLayout.addItem(spacerItem)
        self.verticalLayout.addLayout(hLayout)

        self.label_8 = QLabel()
        # self.label_8.setGeometry(QtCore.QRect(20, 170, 121, 101))
        self.label_8.setAlignment(QtCore.Qt.AlignCenter)
        self.label_8.setObjectName(_fromUtf8("label_8"))
        self.verticalLayout.addWidget(self.label_8)

        hLayout = QHBoxLayout()
        self.calcBtn = QPushButton()
        self.calcBtn.setObjectName(_fromUtf8("calcBtn"))
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        hLayout.addWidget(self.calcBtn)
        hLayout.addItem(spacerItem)
        self.verticalLayout.addLayout(hLayout)

        self.retranslateUi(Form)
    def retranslateUi(self, Form):
        Form.setWindowTitle("Form")
        # self.groupBox.setTitle("AHP Consistency Indicators")
        self.calcBtn.setText("Calculate")
        # self.lb_lamda.setText(u"max λ =")
        self.lb_titles.setText(u",".join(self.col_alias))
        self.lb_weights.setText("Waiting to calculate...")
        # self.lb_ci.setText("CI =")
        self.lb_cr.setText("CR =")
        self.label_8.setText(
            u"<html><head/><body><p><span style=\" color:#ff0000;\">CR ≥ 0.1 You should revise the table.</span></p></body></html>")

    def getMatrix(self):
        row = self.tableWidget.rowCount()
        col = self.tableWidget.columnCount()
        mat_list = []
        for i in range(row):
            list_i = []
            for j in range(col):
                cellitem = self.tableWidget.item(i,j).text()
                list_i.append(float(cellitem))
            mat_list.append(list_i)
        return np.matrix(mat_list)
    def tableMaker(self):
        #preparing the pairwise table.
        row = col = len(self.col_list)
        self.tableWidget.setRowCount(row)
        self.tableWidget.setColumnCount(col)
        self.tableWidget.setHorizontalHeaderLabels(self.col_alias)
        self.tableWidget.setVerticalHeaderLabels(self.col_alias)

        # height = self.tableWidget.rowHeight(0)
        height = 60
        for i in range(col):
            self.tableWidget.setColumnWidth(i,height)
        for i in range(row):
            self.tableWidget.setRowHeight(i,height)

        for i in range(row):
            for j in range(col):
                if i == j:
                    cellItem = QTableWidgetItem()
                    #cellItem = self.tableWidget.item(i,j)
                    brush = QBrush(QColor(209, 209, 209))
                    brush.setStyle(Qt.SolidPattern)
                    cellItem.setBackground(brush)
                    cellItem.setText('1')
                    cellItem.setFlags(Qt.ItemIsEnabled)
                    cellItem.setTextAlignment(Qt.AlignCenter)
                    self.tableWidget.setItem(i,j,cellItem)
                if i>j:
                    #cellItem = self.tableWidget.item(i, j)
                    cellItem = QTableWidgetItem()
                    # brush = QBrush(QColor(209, 209, 209))
                    # brush.setStyle(Qt.SolidPattern)
                    # cellItem.setBackground(brush)
                    cellItem.setFlags(cellItem.flags() & Qt.ItemIsEditable)
                    # cellItem.setTextAlignment(Qt.AlignCenter)
                    self.tableWidget.setItem(i, j, cellItem)
                if i<j:
                    cellItem = QTableWidgetItem()
                    #cellItem.setFlags(cellItem.flags() & Qt.ItemIsEditable)
                    self.tableWidget.setItem(i, j, cellItem)
    def itemchanged(self,item):
        row = item.row()
        col = item.column()
        if row<col:
            text = item.text()
            if text:
                try:
                    num = float(text)
                except:
                    QMessageBox.critical(None, ("Input must be number"),
                                         ("The input must be number"))
                    cellItem = QTableWidgetItem()
                    self.tableWidget.setItem(row, col, cellItem)
                    return
                if num<=1.0/9:
                    QMessageBox.critical(None, ("Input must be larger than 0"),
                                         ("The input must be larger than 0"))
                    item.setText("0.111111")
                    self.tableWidget.setItem(row, col, item)
                    return
                if num>9:
                    QMessageBox.critical(None, ("Input must be smaller than 9"),
                                         ("The input must be smaller than 9"))
                    item.setText("9")
                    self.tableWidget.setItem(row, col, item)
                    return
                cellItem = QTableWidgetItem()
                cellItem.setText("%.6f" % (1.0/num))
                self.tableWidget.setItem(col, row, cellItem)
                self.resetStatus()

    def Calculate_button_click(self):
        if self.isTableCompleted():
            #self.LAYER_WEIGHT_LIST = self.weightCalculator(self.matrixNormalizer(self.columnAddition()))
            t_matrix = self.getMatrix()
            if t_matrix.shape[0]==1:
                self.col_weight = [1.0]
                self.finish_bool = True
            elif t_matrix.shape[0]==2:
                # do not need eigvector to calculate weights
                val = t_matrix[0,1]
                self.col_weight = [val/(val+1.0),1.0/(val+1.0)]
                self.finish_bool = True
            else:
                ones_ = np.ones(t_matrix.shape)
                c = t_matrix==ones_
                if not c.all():
                    # t_matrix is not ones matrix
                    row,col = t_matrix.shape
                    LAMBDA_PARAMETER,EigVectors= np.linalg.eig(t_matrix)
                    vs = []
                    for i in range(EigVectors.shape[0]):
                        vs.append(EigVectors[i,0].real)
                    # vs = [i.real for i in EigVectors[0].tolist()[0]] #[TODO] vs has negative number
                    vs_sum = sum(vs)
                    self.col_weight = [e/vs_sum for e in vs]
                    CONSISTENCY_INDEX = (max(LAMBDA_PARAMETER).real-row)*1.0/(row - 1)
                    CONSISTENCY_RATIO = CONSISTENCY_INDEX/self.CRI[row]
                    # self.lb_lamda_value.setText(u"%0.6f"%(max(LAMBDA_PARAMETER).real))

                    # self.lb_ci_value.setText("%0.6f"%(CONSISTENCY_INDEX))

                    self.lb_cr_value.setText("%0.3f"%(CONSISTENCY_RATIO))
                    if CONSISTENCY_RATIO>=0.1:
                        self.label_8.show()
                    else:
                        self.finish_bool = True
                        self.label_8.hide()
                else:
                    # t_matrix is ones matrix
                    #val = t_matrix[0, 1]
                    self.col_weight = [1.0/t_matrix.shape[0]]*t_matrix.shape[0]
                    self.finish_bool = True
            self.lb_weights.setText(",".join(["%0.3f"%val for val in self.col_weight]))
        else:
            QMessageBox.information(None, 'AHP Error','You must fill all the cells in the pairwise table.')
    def isTableCompleted(self):
        #checking the table for containing any blank cell.
        row = col = 0
        control = 0
        tableSize = self.tableWidget.columnCount()
        while row < tableSize:
            while col < tableSize:
                try:
                    if not self.tableWidget.item(row,col).text():
                        control+=1
                except:
                    control+=1
                col+=1
            row+=1
            col=0

        if control > 0:
            return False
        else:
            return True
    def resetStatus(self):
        self.finish_bool=False
        # self.lb_lamda_value.setText("")
        # self.lb_ci_value.setText("")
        self.lb_weights.setText("Waiting to calculate...")
        self.lb_cr_value.setText("")

class TopItem(QTreeWidgetItem):
    def __init__(self, param):
        # param = {"title":"","level":,"des":""}
        self.connIcon = QIcon(os.path.join(pluginPath,'images','postgis.png'))
        self.param = param
        QTreeWidgetItem.__init__(self)
        self.setChildIndicatorPolicy(QTreeWidgetItem.DontShowIndicatorWhenChildless)
        self.setExpanded(True)
        self.setText(0, param["title"])
        self.setIcon(0, self.connIcon)
class SecondLevelItem(QTreeWidgetItem):
    def __init__(self, param):
        # param = {"title":"","level":,"des":""}
        self.connIcon = QIcon(os.path.join(pluginPath,'images','postgis.png'))
        self.param = param
        QTreeWidgetItem.__init__(self)
        self.setChildIndicatorPolicy(QTreeWidgetItem.DontShowIndicatorWhenChildless)
        self.setExpanded(True)
        self.setText(0, param["title"])
        self.setIcon(0, self.connIcon)
class LeafLevelItem(QTreeWidgetItem):
    def __init__(self, param):
        # param = {"title":"","level":,"des":""}
        self.connIcon = QIcon(os.path.join(pluginPath,'images','postgis.png'))
        self.param = param
        QTreeWidgetItem.__init__(self)
        self.setChildIndicatorPolicy(QTreeWidgetItem.DontShowIndicatorWhenChildless)
        self.setExpanded(True)
        self.setText(0, param["title"])
        self.setIcon(0, self.connIcon)
