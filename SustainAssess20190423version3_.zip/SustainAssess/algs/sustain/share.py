
TOPITEMS = ["Economic","Environmental","Social","Resilient","Composite"]
TOPITEMS_ALIAS = {"Economic":"Eco", "Environmental":"Env", "Social":"Soc", "Resilient":"Res", "Composite":"Comp"}
algList = {}
algNameList=[]
standalone=False