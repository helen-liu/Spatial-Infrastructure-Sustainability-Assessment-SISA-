# -*- coding: utf-8 -*-

"""
***************************************************************************
    RandomPointsLayer.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Alexander Bruy
    Email                : alexander dot bruy at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import random

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsGeometry, QgsFields, QgsField, QgsSpatialIndex,
                        QgsFeature, QgsFeatureRequest)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterNumber
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector
from SustainAssess.tools import dataobjects, vector

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class Freeman(GeoAlgorithm):

    SOURCE_VECTOR = 'SOURCE_VECTOR'
    SOURCE_ID_FIELD = 'SOURCE_ID_FIELD'
    ROADNETWORK_EDGE_LAYER = 'ROADNETWORK_EDGE_LAYER'
    RD_EDGE_ID_FIELD = 'ROADNETWORK_EDGE_ID_FIELD'
    RD_EDGE_SOURCE_FIELD = 'ROADNETWORK_EDGE_SOURCE_FIELD'
    RD_EDGE_TARGET_FIELD = 'ROADNETWORK_EDGE_TARGET_FIELD'
    RD_EDGE_COST_FIELD = 'ROADNETWORK_EDGE_COST_FIELD'
    RD_EDGE_REVERSE_COST_FIELD = 'ROADNETWORK_EDGE_COST_FIELD'
    ROADNETWORK_NODE_LAYER = 'ROADNETWORK_NODE_LAYER'

    RANDOM_POINT_LAYER = 'RANDOM_POINT_LAYER'

    OUTPUT = 'OUTPUT'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Centrality/Freeman"
        self.name, self.i18n_name = self.trAlgorithm('Freeman')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')

        self.addParameter(ParameterVector_RDBMS(self.SOURCE_VECTOR,
                                                self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.SOURCE_ID_FIELD,
                                              self.tr('ID Field'), self.SOURCE_VECTOR))
        self.addParameter(ParameterVector_RDBMS(self.ROADNETWORK_EDGE_LAYER,
                                                self.tr('Roads Edge Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_LINE]))
        self.addParameter(ParameterTableField(self.RD_EDGE_ID_FIELD,
                                              self.tr('Edge ID Field'), self.ROADNETWORK_EDGE_LAYER))
        self.addParameter(ParameterTableField(self.RD_EDGE_SOURCE_FIELD,
                                              self.tr('Edge Source Field'), self.ROADNETWORK_EDGE_LAYER))
        self.addParameter(ParameterTableField(self.RD_EDGE_TARGET_FIELD,
                                              self.tr('Edge Target Field'), self.ROADNETWORK_EDGE_LAYER))
        self.addParameter(ParameterTableField(self.RD_EDGE_COST_FIELD,
                                              self.tr('Edge Cost Field'), self.ROADNETWORK_EDGE_LAYER))
        self.addParameter(ParameterTableField(self.RD_EDGE_REVERSE_COST_FIELD,
                                              self.tr('Edge Cost Field'), self.ROADNETWORK_EDGE_LAYER))
        self.addParameter(ParameterVector_RDBMS(self.ROADNETWORK_NODE_LAYER,
                                                self.tr('Input Network Node Layer'),
                                                [ParameterVector_RDBMS.VECTOR_TYPE_POINT]))
        self.addParameter(ParameterVector_RDBMS(self.RANDOM_POINT_LAYER,
                                                self.tr('Input Random Point Layer'),
                                                [ParameterVector_RDBMS.VECTOR_TYPE_POINT]))

        self.addOutput(OutputVector(self.OUTPUT, self.tr('Freeman Layer')))

    def processAlgorithm(self, progress):
        #[TODO] write the Freeman Layer Alogrithm
        pass
        # paramInput = self.getParameterValue(self.VECTOR)
        # if paramInput["p"] in [ParameterVector_RDBMS.INPUT_TYPE_LAYERS]:
        #     layer = dataobjects.getObjectFromUri(
        #         paramInput["data"])
        # elif paramInput["p"]==ParameterVector_RDBMS.INPUT_TYPE_DATABASE:
        #     uri_text = paramInput["data"]["uri"]
        #     if uri_text.startswith(u"spatialite:"):
        #         uri_text = uri_text[len(u"spatialite:"):]
        #         layer = dataobjects.getObjectFromUri(uri_text)
        #     elif uri_text.startswith(u"postgis:"):
        #         uri_text = uri_text[len(u"postgis:"):]
        #         layer = dataobjects.getObjectFromUri(uri_text)
        #     else:
        #         layer = dataobjects.getObjectFromUri(uri_text)

