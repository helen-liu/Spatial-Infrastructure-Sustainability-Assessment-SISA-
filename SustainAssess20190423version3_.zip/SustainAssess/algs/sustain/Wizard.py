# -*- coding: utf-8 -*-

"""
***************************************************************************
    RandomPointsLayer.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Alexander Bruy
    Email                : alexander dot bruy at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os,csv,datetime
from io import BytesIO
import traceback
from qgis.PyQt import uic,QtCore
from qgis.core import QgsDataSourceUri,QgsVectorLayer,QgsWkbTypes
import webbrowser
from qgis.PyQt.QtGui import QTextDocument,QCursor,QIcon,QPixmap
from qgis.PyQt.QtWidgets import QAbstractItemView,QFileDialog,QMenu,QAction,QTextEdit,QLineEdit,QCheckBox,\
                QProgressBar,QMessageBox,QWidget,QVBoxLayout,QScrollArea,QFrame,QLabel,QComboBox,\
                QSpacerItem,QSizePolicy,QHBoxLayout,QTableWidget,QPushButton,QTableWidgetItem,\
                QDialog,QTreeWidgetItem,QTreeWidget
from qgis.PyQt.QtCore import QVariant,QRect,QSize,QCoreApplication
from SustainAssess.core.parameters import Parameter
from SustainAssess.gui.NumberInputPanel import NumberInputPanel
from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtCore import Qt
from SustainAssess.tools import dataobjects,spatialite
from qgis.gui import QgsCollapsibleGroupBox
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.gui.FileSelectionPanel import FileSelectionPanel
from SustainAssess.core.parameters import ParameterSelection,ParameterString,ParameterTableField
from SustainAssess.core.parameters import ParameterNumber,ParameterFile,ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputFile,OutputDirectory
from SustainAssess.gui.OutputSelectionPanel import OutputSelectionPanel
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from qgis.utils import iface
from SustainAssess.tools import postgis
from SustainAssess.gui.InputLayerRDBMSelectorPanel import InputLayerRDBMSelectorPanel
import rpy2
import rpy2.robjects as robjects
import rpy2.rlike.container as rlc
from SustainAssess.algs.sustain.share import algList

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]
WIDGET, BASE = uic.loadUiType(os.path.join(pluginPath,'ui','DlgWizard.ui'))

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s
class Wizard(GeoAlgorithm):

    OBJECT_DES = 'OBJECT_DES'
    SPATIALSCALE = 'SPATIALSCALE'
    # Set Up Available Values in ComboBox, which are all the spatial scales provided by system
    # reference the document: https://www2.census.gov/geo/pdfs/reference/GARM/Ch2GARM.pdf
    # Bounary Definitions: https://www.census.gov/geo/reference/garm.html
    SPATIALSCALE_OPTIONS = ["Global","Nation","Regions","Divisions",
        "States/Provinces","Counties","Census Tracts","Census Block Groups",
        "Census Blocks","Traffic Analysis Zones","Metropolitan Areas",
        "User Defined/Others"]    # all other spatial scales not listed here]
    USERDEFINED_SPATIALSCALE = 'USERDEFINED_SPATIALSCALE'

    TEMPORALSCALE = 'TEMPORALSCALE'
    TEMPORALSCALE_OPTIONS = ["Not Considered","User Defined"]
    USERDEFINED_TEMPORALSCALE = 'USERDEFINED_TEMPORALSCALE'

    ECONOMIC_INDICATOR = 'ECONOMIC_INDICATOR'
    ENVIRONMENTAL_INDICATOR = 'ENVIRONMENTAL_INDICATOR'
    SOCIAL_INDICATOR = 'SOCIAL_INDICATOR'
    RESILIENT_INDICATOR = 'RESILIENT_INDICATOR'
    COMPOSITE_INDICATOR = 'COMPOSITE_INDICATOR'

    RAWDATA = 'RAWDATA'
    ASSESSDATAQUALITY = 'ASSESSDATAQUALITY'
    SPATIAL_SUS_ASSESS = 'SPATIAL_SUS_ASSESS'

    # Results Visualization
    AHP_WEIGHT_FILE = "AHP_WEIGHT_FILE"
    UNCERTAINTY_RES_VECTOR = 'UNCERTAINTY_RES_VECTOR'  # INPUT UNCERTAINTY RESULT LAYER
    UNCERTAINTY_RES_VECTOR_KEY = 'UNCERTAINTY_RES_VECTOR_KEY'  #
    SENSITIVITY_FILE = 'SENSITIVITY_FILE'
    VISULIZATION_OUTPUTDIR = "VISULIZATION_OUTPUTDIR"

    # Setting Panel
    DEFALUT_CSVFILE = 'DEFALUT_CSVFILE'
    defalutPath = './data/DefaultIndicators.csv'
    OUTPUT_AS_TEXT = 'OUTPUT_AS_TEXT'

    # Sharable Variables
    SHARABLE_VARIABLES = "SHARABLE_VARIABLES" # store all the id from default
    def __init__(self,actions,algs):
        super(Wizard,self).__init__()
        self.actions = actions
        self.algList = algs # algs is dict {"algname":alg instance}
    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Wizard/Start Sustainability Evaluation"
        self.name, self.i18n_name = self.trAlgorithm('Start Sustainability Evaluation')
        self.group, self.i18n_group = self.trAlgorithm('Wizard')
        self.TYPES = {self.OBJECT_DES: "string", self.SPATIALSCALE: "string", self.USERDEFINED_SPATIALSCALE: "string",
                 self.TEMPORALSCALE: "string", self.USERDEFINED_TEMPORALSCALE: "string", self.ECONOMIC_INDICATOR: "[[]]",
                 self.ENVIRONMENTAL_INDICATOR: "[[]]", self.SOCIAL_INDICATOR: "[[]]", self.RESILIENT_INDICATOR: "[[]]",
                 self.COMPOSITE_INDICATOR: "[[]]",self.RAWDATA:"[[]]", self.ASSESSDATAQUALITY: "[[]]",
                 self.DEFALUT_CSVFILE: "string", self.OUTPUT_AS_TEXT: "string"}
        self.addParameter(ParameterObjectDesription(self.OBJECT_DES, self.tr('Define Object of Sustainability Assessment:'),optional=True))
        self.addParameter(ParameterSelection(self.SPATIALSCALE, self.tr('Define Spatial Scale:'),self.SPATIALSCALE_OPTIONS,0,optional=True))
        self.addParameter(ParameterString(self.USERDEFINED_SPATIALSCALE, self.tr('Input User Defined/Others Spatial Scale:'),optional=True))
        self.addParameter(ParameterSelection(self.TEMPORALSCALE, self.tr('Define Temporal Scale:'), self.TEMPORALSCALE_OPTIONS, 0,optional=True))
        self.addParameter(ParameterNumber(self.USERDEFINED_TEMPORALSCALE, self.tr('Input User Defined Temporal Scale (Years):'),minValue=0,default=0.0,optional=True))
        self.addParameter(ParameterIndicator(self.ECONOMIC_INDICATOR, self.tr('Select Economic Indicators:'),shortdes='Economic',optional=True))
        self.addParameter(ParameterIndicator(self.ENVIRONMENTAL_INDICATOR, self.tr('Select Environmental Indicators:'),shortdes='Environmental',optional=True))
        self.addParameter(ParameterIndicator(self.SOCIAL_INDICATOR, self.tr('Select Social Indicators:'),shortdes='Social',optional=True))
        self.addParameter(ParameterIndicator(self.RESILIENT_INDICATOR, self.tr('Select Resilient Indicators:'),shortdes='Resilient',optional=True))
        self.addParameter(ParameterIndicator(self.COMPOSITE_INDICATOR, self.tr('Select Others Indicators:'),shortdes='Others',optional=True))
        self.addParameter(ParameterRawData(self.RAWDATA,self.tr('Select Raw Data:'),shortdes='Rawdata',optional=True))
        self.addParameter(
            ParameterAssessDataQuality(self.ASSESSDATAQUALITY, self.tr('Manually Data Quality Check Table:'), shortdes='AssessDataQuality', optional=True))

        # Results Visualization ========================================================================================
        self.addParameter(ParameterFile(self.AHP_WEIGHT_FILE, self.tr('AHP Weight File'), optional=False, ext='weight'))
        self.addParameter(ParameterVector_RDBMS(self.UNCERTAINTY_RES_VECTOR,
                                          self.tr('Input Uncertainty Result Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.UNCERTAINTY_RES_VECTOR_KEY,
                                          self.tr('Key Field of Uncertainty Result Layer'),self.UNCERTAINTY_RES_VECTOR))
        self.addParameter(
            ParameterFile(self.SENSITIVITY_FILE, self.tr('Sensitivity Results File'), optional=False, ext='txt'))
        self.addOutput(OutputDirectory(self.VISULIZATION_OUTPUTDIR, self.tr('Directory to Save Charts')))

        # ==============================================================================================================
        self.addParameter(ParameterFile(self.DEFALUT_CSVFILE, self.tr('Default Indicators File:'),ext="csv",optional=False))
        self.addParameter(ParameterShareable(self.SHARABLE_VARIABLES,"this is used for shareable variables",[self.ECONOMIC_INDICATOR, self.ENVIRONMENTAL_INDICATOR, self.SOCIAL_INDICATOR,
                           self.RESILIENT_INDICATOR,self.COMPOSITE_INDICATOR,"maxid"],optional=True))
        self.addOutput(OutputFile(self.OUTPUT_AS_TEXT, self.tr('Output Results File'), 'susta'))

        self.dimentions = [self.ECONOMIC_INDICATOR, self.ENVIRONMENTAL_INDICATOR, self.SOCIAL_INDICATOR,
                           self.RESILIENT_INDICATOR,self.COMPOSITE_INDICATOR]
        # set maxid
        # read in this csv file

        # import rpdb2
        # rpdb2.start_embedded_debugger("liu")
        # f1 = open(os.path.join(pluginPath,self.defalutPath), "r")  # 二进制格式读文件
        # while True:
        #     line = f1.readline()
        #     if not line:
        #         break
        #     else:
        #         try:
        #             # print(line.decode('utf8'))
        #             line.decode('utf8')
        #             # 为了暴露出错误，最好此处不print
        #         except:
        #             print(str(line))
        # f1.close()
        f = open(os.path.join(pluginPath,self.defalutPath), "r")
        data_ = []
        csvreader = csv.reader(f, delimiter=',', quotechar="\"")
        for row in csvreader:
            try:
                data_.append(row)
            except:
                # import rpdb2
                # rpdb2.start_embedded_debugger("liu")
                pass
        f.close()
        # import rpdb2
        # rpdb2.start_embedded_debugger("liu")
        ind = data_[0].index("id")
        ids = [int(d[ind]) for d in data_[1:]]
        maxid = max(ids)
        self.getParameterFromName(self.SHARABLE_VARIABLES).setValue("maxid", maxid)
    def getCustomParametersDialog(self):
        self.dlg = WizardDialog(self)
        return self.dlg
    def processAlgorithm(self, progress):
        pass
    def generateChart(self,progress):
        source_param = self.getParameterFromName(self.UNCERTAINTY_RES_VECTOR)
        m_IDField = self.getParameterValue(self.UNCERTAINTY_RES_VECTOR_KEY)
        m_AHP_WEIGHT_FILE = self.getParameterValue(self.AHP_WEIGHT_FILE)
        m_SENSITIVITY_FILE = self.getParameterValue(self.SENSITIVITY_FILE)
        filedir = self.getOutputValue(self.VISULIZATION_OUTPUTDIR)

        # ['Radar', 'SunBurst', 'Stratified Bar', 'Line']
        if progress.isChecked('Radar'):
            algname = 'Radar Chart'
            alg = algList[algname]
            dir = os.path.join(filedir, "radar")
            if not os.path.exists(dir):
                os.mkdir(dir)
            progress.setText("Generate Radar Chart...")
            alg.processAlgorithm(progress,source_param,m_IDField,dir)
        if progress.isChecked('SunBurst'):
            algname = 'Sunburst Chart'
            alg = algList[algname]
            dir = os.path.join(filedir, "sunburst")
            if not os.path.exists(dir):
                os.mkdir(dir)
            progress.setText("Generate Sunburst Chart...")
            alg.processAlgorithm(progress,source_param,m_IDField,m_AHP_WEIGHT_FILE,dir)

        if progress.isChecked('Stratified Bar'):
            algname = 'Stratified Bar Chart'
            alg = algList[algname]
            dir = os.path.join(filedir, "stratifiedbar")
            if not os.path.exists(dir):
                os.mkdir(dir)
            progress.setText("Generate Stratified Bar Chart...")
            alg.processAlgorithm(progress,source_param,m_IDField,m_AHP_WEIGHT_FILE,dir)

        if progress.isChecked('Line'):
            algname = 'Line Chart'
            alg = algList[algname]
            dir = os.path.join(filedir, "line")
            if not os.path.exists(dir):
                os.mkdir(dir)
            progress.setText("Generate Line Chart...")
            alg.processAlgorithm(progress,source_param,m_IDField,
                                 m_AHP_WEIGHT_FILE,m_SENSITIVITY_FILE,dir)
        progress.setText("Done!")
        progress.setPercentage(100)

    def saveParamters2file(self):
        try:
            p_output = self.getOutputValue(self.OUTPUT_AS_TEXT)
            if p_output is None:
                p_output = os.path.join(pluginPath,"data","temp%s.susta"%(datetime.datetime.now().strftime("%Y_%m_%d")))
            outfile = open(p_output,"w")

            name = self.OBJECT_DES
            outfile.write(name+"\n")
            val =self.getParameterValue(name)
            outfile.write(str(val)+"\n")

            name = self.SPATIALSCALE
            outfile.write(name+"\n")
            val =self.SPATIALSCALE_OPTIONS[self.getParameterValue(name)]
            outfile.write(val+"\n")

            name = self.USERDEFINED_SPATIALSCALE
            outfile.write(name+"\n")
            val =self.getParameterValue(name)
            outfile.write(str(val)+"\n")

            name = self.TEMPORALSCALE
            outfile.write(name + "\n")
            val = self.TEMPORALSCALE_OPTIONS[self.getParameterValue(name)]
            outfile.write(val + "\n")

            name = self.USERDEFINED_TEMPORALSCALE
            outfile.write(name + "\n")
            val = self.getParameterValue(name)
            outfile.write(str(val) + "\n")

            csvwriter = csv.writer(outfile, delimiter=',',
                                    quotechar='"', quoting=csv.QUOTE_MINIMAL,lineterminator='\n')

            names = [self.ECONOMIC_INDICATOR,self.ENVIRONMENTAL_INDICATOR,
                     self.SOCIAL_INDICATOR,self.RESILIENT_INDICATOR,
                     self.COMPOSITE_INDICATOR]
            for name in names:
                outfile.write(name + "\n")
                vals = self.getParameterValue(name)
                for val in vals:
                    csvwriter.writerow([str(v) for v in val])

            name = self.RAWDATA
            outfile.write(name + "\n")
            vals = self.getParameterValue(name)
            for val in vals:
                csvwriter.writerow([str(v) for v in val])

            name = self.ASSESSDATAQUALITY
            outfile.write(name + "\n")
            vals = self.getParameterValue(name)
            for val in vals:
                csvwriter.writerow([str(v) for v in val])

            name = self.AHP_WEIGHT_FILE
            outfile.write(name + "\n")
            val = self.getParameterValue(name)
            outfile.write(str(val) + "\n")

            name = self.SENSITIVITY_FILE
            outfile.write(name + "\n")
            val = self.getParameterValue(name)
            outfile.write(str(val) + "\n")

            name = self.VISULIZATION_OUTPUTDIR
            outfile.write(name + "\n")
            val = self.getOutputValue(name)
            outfile.write(str(val) + "\n")

            name = self.DEFALUT_CSVFILE
            outfile.write(name + "\n")
            val = self.getParameterValue(name)
            outfile.write(val + "\n")

            name = self.OUTPUT_AS_TEXT
            outfile.write(name + "\n")
            outfile.write(p_output + "\n")

            outfile.close()
        except Exception as e:
            # If something goes wrong and is not caught in the
            # algorithm, we catch it here and wrap it
            lines = [self.tr('Uncaught error while executing algorithm')]
            lines.append(traceback.format_exc())

            try:
                message = str(e)
            except UnicodeDecodeError:
                # Try with the 'replace' mode (requires e.message instead of e!)
                message = str(e.message)
            ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "\n".join(lines))
            ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, message + self.tr(' \nQingsong See log for more details'))
            raise GeoAlgorithmExecutionException(
                message + self.tr(' \nSee log for more details'), lines, e)
        finally:
            outfile.close()
        return True
    def readParamterFromFile(self,filename):
        keywords = self.TYPES.keys()
        infile = open(filename,"r")
        line = infile.readline().strip(" \n\r")
        cur_keyword = None
        cur_rawdata_ = None
        cur_type = None
        while True:
            if not line:
                break
            if line in keywords:
                cur_keyword = line
                if cur_keyword==self.OUTPUT_AS_TEXT:
                    break
                cur_type = self.TYPES[cur_keyword]
                data_ = self.initCurrentData(cur_type)
                while True:
                    line = infile.readline().strip(" \n\r")
                    if line not in keywords:
                        data_ = self.addCurrentData(data_,line,cur_type)
                    else:
                        break
                if cur_keyword== self.SPATIALSCALE:
                    data_ = self.SPATIALSCALE_OPTIONS.index(data_)
                if cur_keyword == self.TEMPORALSCALE:
                    data_ = self.TEMPORALSCALE_OPTIONS.index(data_)

                if not self.getParameterFromName(cur_keyword).setValue(data_):
                    self.getOutputFromName(cur_keyword).setValue(data_)
            else:
                line = infile.readline().strip(" \n\r")
        return True
    def initCurrentData(self,type):
        if type=="string":
            return str("")
        elif type=="[[]]":
            return []
        else:
            #unknown type
            return None
    def addCurrentData(self,data,line,type):
        if type == "string":
            if line:
                if data:
                    line += "\n"+line
                data += line.decode('utf-8')
        elif type == "[[]]":
            with BytesIO(line) as input_file:
                csv_reader = csv.reader(input_file, delimiter=",", quotechar='"')
                for row in csv_reader:
                    data.append(row)
        else:
            pass
        return data
    def show(self):
        dlg = self.getCustomParametersDialog()
        dlg.show()
        dlg.exec_()
class WizardDialog(BASE,WIDGET):
    def __init__(self, alg):
        super(WizardDialog, self).__init__(iface.mainWindow())
        self.setupUi(self)
        self.alg = alg
        self.setWindowTitle(self.alg.displayName())
        self.executed = False
        self.Widgets_dlg = {}
        self.TreeItems_list = {}
        self.Widgets_label = []
        self.current_label = None
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.textShortHelp.setOpenLinks(True)
        def linkClicked(url):
            webbrowser.open(url.toString())
        self.textShortHelp.anchorClicked.connect(linkClicked)
        self.setupWidgets()
        self.setshortHelp(self.current_label)

    def treeWidgetChanged(self,item_cur,item_pre):
        des = item_cur.text(0)
        # des = des.lstrip("-")
        if des=="Indicators":
            return
        wid_stacked = self.Widgets_dlg[des]
        self.stackedWidget.setCurrentWidget(wid_stacked)
        wid_pre = self.Widgets_dlg[self.current_label]
        wid_pre.setParametersValue()
        if isinstance(wid_stacked,AssessDataQualityDlg):
            wid_stacked.btn_reload_clicked()
        self.current_label = des
        self.setshortHelp(self.current_label)
    def reject(self):
        self.done(0)
    def closeEvent(self, evt):
        super(WizardDialog, self).closeEvent(evt)

    def setupWidgets(self):
        # add object dlg
        label = "Object&Scale"
        self.Widgets_label.append(label)
        dlg = ObjectScaleDlg(self.alg)
        self.Widgets_dlg[label] = dlg
        top_item = QTreeWidgetItem([label])
        self.TreeItems_list[label] = top_item
        self.treeWidget.addTopLevelItem(top_item)
        self.stackedWidget.addWidget(dlg)

        # add Indicators dlg
        label = "Indicators"
        top_item = QTreeWidgetItem([label])
        self.treeWidget.addTopLevelItem(top_item)
        # add dimentions
        params = [self.alg.getParameterFromName(dim) for dim in self.alg.dimentions]
        for param in params:
            label = param.shortdes
            self.Widgets_label.append(label)
            dlg = IndicatorsDlg(param,self.alg) #TODO
            self.Widgets_dlg[label] = dlg
            item_t = QTreeWidgetItem([label])
            self.TreeItems_list[label] = item_t
            self.stackedWidget.addWidget(dlg)
            top_item.addChild(item_t)
        self.treeWidget.currentItemChanged.connect(self.treeWidgetChanged)

        # raw data panel
        label = "Raw Data"
        self.Widgets_label.append(label)
        dlg = RawDlg(self.alg)
        self.Widgets_dlg[label] = dlg
        top_item = QTreeWidgetItem([label])
        self.TreeItems_list[label] = top_item
        self.treeWidget.addTopLevelItem(top_item)
        self.stackedWidget.addWidget(dlg)

        # Assess Data Quality panel
        label = "Assess Data Quality"
        self.Widgets_label.append(label)
        dlg = AssessDataQualityDlg(self.alg)
        self.Widgets_dlg[label] = dlg
        top_item = QTreeWidgetItem([label])
        self.TreeItems_list[label] = top_item
        self.treeWidget.addTopLevelItem(top_item)
        self.stackedWidget.addWidget(dlg)

        # Spatial Sustainability Assessment panel
        label = "Spatial Sustainability Assessment"
        self.Widgets_label.append(label)
        dlg = SpatialSusDlg(self.alg)
        self.Widgets_dlg[label] = dlg
        top_item = QTreeWidgetItem([label])
        self.TreeItems_list[label] = top_item
        self.treeWidget.addTopLevelItem(top_item)
        self.stackedWidget.addWidget(dlg)

        # Results Analysis panel
        label = "Results Analysis"
        self.Widgets_label.append(label)
        dlg = ResultsAnalysisDlg(self.alg)
        self.Widgets_dlg[label] = dlg
        top_item = QTreeWidgetItem([label])
        self.TreeItems_list[label] = top_item
        self.treeWidget.addTopLevelItem(top_item)
        self.stackedWidget.addWidget(dlg)

        # Results Visualization panel
        label = "Results Visualization"
        self.Widgets_label.append(label)
        dlg = ResultsVisualizationDlg(self.alg)
        self.Widgets_dlg[label] = dlg
        top_item = QTreeWidgetItem([label])
        self.TreeItems_list[label] = top_item
        self.treeWidget.addTopLevelItem(top_item)
        self.stackedWidget.addWidget(dlg)

        # setting panel
        label = "Settings"
        self.Widgets_label.append(label)
        dlg = SettingDlg(self.alg)
        self.Widgets_dlg[label] = dlg
        top_item = QTreeWidgetItem([label])
        self.TreeItems_list[label] = top_item
        self.treeWidget.addTopLevelItem(top_item)
        self.stackedWidget.addWidget(dlg)
        self.btn1.setText("Save")
        self.btn1.clicked.connect(self.SaveAndExit_clicked)
        self.btn2.clicked.connect(self.Next_clicked)
        self.btn3.clicked.connect(self.Load_clicked)
        self.current_label = self.Widgets_label[0]
    def setParametersValue(self):
        # for all the Dlg, trigger the setParametersValue function
        for dlg in self.Widgets_dlg.values():
            if not dlg.setParametersValue():
                QMessageBox.warning(self, "Failed Parameter setting", "Failed Parameter setting in "+dlg.name+" !")
                return False
        return True
    def getValueFromParameter(self):
        # parameter --> widget
        # for all the Dlg, trigger the setParametersValue function
        for dlg in self.Widgets_dlg.values():
            if not dlg.getValueFromParameter():
                QMessageBox.warning(self, "Failed to Load Parameter setting", "Failed to Load Parameter setting in "+dlg.name+" !")
                return False
        return True

    def SaveAndExit_clicked(self):
        # assign values to the alg parameters
        if not self.setParametersValue():
            return False
        if not self.alg.saveParamters2file():
            QMessageBox.warning(self, "Failed Saving", "Failed Saving!")
            return False
    def Next_clicked(self):
        cur_ind = self.Widgets_label.index(self.current_label)
        if cur_ind==len(self.Widgets_label)-1:
            # the end label
            return
        next_label = self.Widgets_label[cur_ind+1]
        wid_stacked = self.Widgets_dlg[next_label]
        self.stackedWidget.setCurrentWidget(wid_stacked)
        if isinstance(wid_stacked,AssessDataQualityDlg):
            wid_stacked.btn_reload_clicked()
        self.treeWidget.setCurrentItem(self.TreeItems_list[next_label])

        wid_pre = self.Widgets_dlg[self.current_label]
        wid_pre.setParametersValue()
        self.current_label = next_label
        self.setshortHelp(self.current_label)
    def Load_clicked(self):
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        if settings.contains('/Processing/LastInputPath'):
            path = str(settings.value('/Processing/LastInputPath'))
        else:
            path = ''
        filename,ext = QFileDialog.getOpenFileName(self, self.tr('Select Susta file'),
                                               path, self.tr('susta files (*.susta);;'))

        if filename:
            if not self.alg.readParamterFromFile(filename):
                QMessageBox.warning(self, "Failed Reading Parameters from File", "Failed Reading Parameters from File!")
                return False
            # assign values to the alg parameters
            if not self.getValueFromParameter():
                return False
        return True

    def setshortHelp(self,name):
        #[TODO]
        help_text = ""
        text_url = os.path.join(pluginPath,'algs','help',"wizard."+name+".html")
        if os.path.exists(text_url):
            f = open(text_url,'r')
            hs = f.readlines()
            help_text = ''
            for line in hs:
                # 添加img的绝对路径
                curpos = 0
                while True:
                    lineE = len(line)
                    imgS = line.find("<img",curpos,lineE)
                    if imgS==-1: break
                    imgE = line.find('>',imgS,lineE)
                    srcS = line.find("src",imgS,imgE)
                    if srcS==-1: break
                    quoteS = line.find("\"",srcS,imgE)
                    quoteE = line.find("\"", quoteS+1, imgE)
                    path = line[quoteS+1:quoteE]
                    newpath = os.path.join(pluginPath,'algs','help',path)
                    newpath = newpath.replace("\\",'/')
                    newline = line[0:quoteS]+"\""+newpath+"\""+line[quoteE:lineE]
                    line = newline
                    curpos=srcS

                help_text+=line


            # text = shortHelp.get(self.commandLineName(), None)
            # if text is not None:
            #     text = self._formatHelp(text)
        if help_text is None:
            self.textShortHelp.setVisible(False)
        else:
            localpath = os.path.dirname(__file__).replace("\\", "/")
            self.textShortHelp.document().setMetaInformation(QTextDocument.DocumentUrl,
                                                             os.path.join(pluginPath,'algs','help'))
            self.textShortHelp.setHtml(help_text)

        return True
class ParameterObjectDesription(Parameter):
    def __init__(self, name='', description='', default=None, optional=False):
        Parameter.__init__(self, name, description, default, optional)
    def setValue(self, value):
        if value is None or value.strip() == '':
            if not self.optional:
                return False
            self.value = None if value is None else value.strip()
            return True
        self.value = str(value)
        return True

class ParameterShareable(Parameter):
    def __init__(self, name='', description='', variablenames = [], default=None, optional=False):
        Parameter.__init__(self, name, description, default, optional)
        self.values = {}
        for v in variablenames:
            self.values[v] = None
    def setValue(self, name, value):
        if name not in self.values.keys():
            return False
        if value is None:
            if not self.optional:
                return False
            self.values = None if value is None else value
            return True
        self.values[name] = value
        return True

    def getValue(self,name):
        if name in self.values.keys():
            return self.values[name]
        else:
            return None

class ObjectScaleDlg(QWidget):
    def __init__(self,alg):
        self.alg = alg
        self.name = "Object Dialog"
        QWidget.__init__(self)
        self.setupPanel()
    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 600, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}
        self.labels = {}

        # add TEXT BOX of object description ====================================================================
        name = self.alg.OBJECT_DES
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        # label.setToolTip(tooltip)
        item = QTextEdit()
        item.setMinimumHeight(300)
        self.add2Mainlayout(name,label,item)

        # add spatial scale COMBOX =======================================================================
        name = self.alg.SPATIALSCALE
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        item = QComboBox()
        item.addItems(param.options)
        if param.default:
            item.setCurrentIndex(param.default)
        self.add2Mainlayout(name,label,item)
        item.currentIndexChanged.connect(self.spatialscalechanged)

        # add user defined spatial scale TEXTBOX ================================================================
        name = self.alg.USERDEFINED_SPATIALSCALE
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        item = QLineEdit()
        if param.default:
            item.setText(str(param.default))
        self.add2Mainlayout(name,label,item)
        label.setDisabled(True)
        item.setDisabled(True)

        # add temporal scale COMBOX ========================================================================
        name = self.alg.TEMPORALSCALE
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        item = QComboBox()
        item.addItems(param.options)
        showUserdefined = True
        if param.default is not None:
            item.setCurrentIndex(param.default)
            if param.default==0: # "Not Considered"
                showUserdefined = False
        self.add2Mainlayout(name,label,item)
        item.currentIndexChanged.connect(self.temporalchanged)

        # add user defined temporal scale textbox
        name = self.alg.USERDEFINED_TEMPORALSCALE
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        item = NumberInputPanel(param.default, param.min, param.max, param.isInteger)
        self.add2Mainlayout(name,label,item)
        label.setDisabled(not showUserdefined)
        item.setDisabled(not showUserdefined)

    def spatialscalechanged(self,ind):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        curText = sender.currentText()
        if curText=="User Defined/Others":
            self.labels[self.alg.USERDEFINED_SPATIALSCALE].setDisabled(False)
            self.widgets[self.alg.USERDEFINED_SPATIALSCALE].setDisabled(False)
        else:
            self.labels[self.alg.USERDEFINED_SPATIALSCALE].setDisabled(True)
            self.widgets[self.alg.USERDEFINED_SPATIALSCALE].setDisabled(True)

    def temporalchanged(self,ind):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        curText = sender.currentText()
        if curText=="User Defined":
            self.labels[self.alg.USERDEFINED_TEMPORALSCALE].setDisabled(False)
            self.widgets[self.alg.USERDEFINED_TEMPORALSCALE].setDisabled(False)
        else:
            self.labels[self.alg.USERDEFINED_TEMPORALSCALE].setDisabled(True)
            self.widgets[self.alg.USERDEFINED_TEMPORALSCALE].setDisabled(True)

    def add2Mainlayout(self,name,label,item):
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, item)
        self.widgets[name] = item
        self.labels[name] = label

    def setParametersValue(self):
        # process TEXT BOX of object description ====================================================================
        name = self.alg.OBJECT_DES
        param = self.alg.getParameterFromName(name)
        text = self.widgets[name].toPlainText() #item = QTextEdit()
        if not param.setValue(text): return False

        # process spatial scale COMBOX =======================================================================
        name = self.alg.SPATIALSCALE
        param = self.alg.getParameterFromName(name)
        ind = self.widgets[name].currentIndex() #item = QComboBox()
        if not param.setValue(ind): return False

        # process user defined spatial scale TEXTBOX ================================================================
        name = self.alg.USERDEFINED_SPATIALSCALE
        param = self.alg.getParameterFromName(name)
        text = self.widgets[name].text()        #item = QLineEdit()
        if not param.setValue(text): return False

        # process temporal scale COMBOX ========================================================================
        name = self.alg.TEMPORALSCALE
        param = self.alg.getParameterFromName(name)
        ind = self.widgets[name].currentIndex() # item = QComboBox()
        if not param.setValue(ind): return False

        # process user defined temporal scale textbox
        name = self.alg.USERDEFINED_TEMPORALSCALE
        param = self.alg.getParameterFromName(name)
        val = self.widgets[name].getValue()# item = NumberInputPanel(param.default, param.min, param.max, param.isInteger)
        if not param.setValue(val): return False
        return True
    def getValueFromParameter(self):
        # parameter --> widget
        # add TEXT BOX of object description ====================================================================
        name = self.alg.OBJECT_DES
        val = self.alg.getParameterValue(name)
        self.widgets[name].setText(val)

        # add spatial scale COMBOX =======================================================================
        name = self.alg.SPATIALSCALE
        val = self.alg.getParameterValue(name)
        # item = QComboBox()
        self.widgets[name].setCurrentIndex(val)
        isUserdefined = False
        if self.alg.SPATIALSCALE_OPTIONS[val]=="User Defined/Others":
            isUserdefined = True

        # add user defined spatial scale TEXTBOX ================================================================
        name = self.alg.USERDEFINED_SPATIALSCALE
        val = self.alg.getParameterValue(name)
        # item = QLineEdit()
        self.widgets[name].setText(val)

        if not isUserdefined:
            self.labels[name].setDisabled(True)
            self.widgets[name].setDisabled(True)

        # add temporal scale COMBOX ========================================================================
        name = self.alg.TEMPORALSCALE
        val = self.alg.getParameterValue(name)
        # item = QComboBox()
        self.widgets[name].setCurrentIndex(val)
        isUserdefined = False
        if self.alg.TEMPORALSCALE_OPTIONS[val]=="User Defined":
            isUserdefined = True

        # add user defined temporal scale textbox
        name = self.alg.USERDEFINED_TEMPORALSCALE
        val = self.alg.getParameterValue(name)
        # item = NumberInputPanel(param.default, param.min, param.max, param.isInteger)
        if val is None: val = 0.0
        self.widgets[name].spnValue.setValue(float(val))
        if not isUserdefined:
            self.labels[name].setDisabled(True)
            self.widgets[name].setDisabled(True)
        return True

class ParameterIndicator(Parameter):
    def __init__(self, name='', description='', shortdes = '', default=None, optional=False):
        Parameter.__init__(self, name, description, default, optional)
        self.shortdes = shortdes
    def setValue(self, value):
        if value is None:
            if not self.optional:
                return False
            self.value = None if value is None else value
            return True
        self.value = value
        return True

class IndicatorsDlg(QWidget):
    def __init__(self,param,alg):
        self.param = param
        self.alg = alg
        self.name = param.shortdes + " Dialog"
        QWidget.__init__(self)

        filename = self.alg.defalutPath
        curpath = os.path.join(pluginPath, filename)
        self.titles, self.defaultdata = self.readCSV(curpath)
        self.setupPanel()
        self.setupSignals()
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.cursor_position_add = None
        self.cur_data = []

    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")

        self.verticalLayout0 = QVBoxLayout(myForm)
        label = QLabel(self.param.description)
        self.verticalLayout0.addWidget(label)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.tableWidget = QTableWidget(myForm)
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(len(self.titles))
        self.tableWidget.setHorizontalHeaderLabels(self.titles)  # set header
        # self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # disable edit
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setSelectionMode(QAbstractItemView.MultiSelection)

        self.horizontalLayout.addWidget(self.tableWidget)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.btn_add = QPushButton(myForm)
        self.btn_add.setSizePolicy(sizePolicy)
        self.btn_add.setMaximumSize(QSize(20, 20))
        self.btn_add.setText(_fromUtf8(""))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","plus.png"))
        curIcon = QIcon(pixmap)
        self.btn_add.setIcon(curIcon)
        self.btn_add.setIconSize(QSize(20,20))
        self.btn_add.setObjectName(_fromUtf8("btn_add"))
        self.verticalLayout.addWidget(self.btn_add)

        self.btn_minus = QPushButton(myForm)
        self.btn_minus.setText(_fromUtf8(""))
        self.btn_minus.setSizePolicy(sizePolicy)
        self.btn_minus.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","minus.png"))
        curIcon = QIcon(pixmap)
        self.btn_minus.setIcon(curIcon)
        self.btn_minus.setIconSize(QSize(20, 20))
        self.btn_minus.setObjectName(_fromUtf8("btn_minus"))
        self.verticalLayout.addWidget(self.btn_minus)

        self.btn_up = QPushButton(myForm)
        self.btn_up.setText(_fromUtf8(""))
        self.btn_up.setSizePolicy(sizePolicy)
        self.btn_up.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","uparrow.png"))
        curIcon = QIcon(pixmap)
        self.btn_up.setIcon(curIcon)
        self.btn_up.setIconSize(QSize(20, 20))
        self.btn_up.setObjectName(_fromUtf8("btn_up"))
        self.verticalLayout.addWidget(self.btn_up)

        self.btn_down = QPushButton(myForm)
        self.btn_down.setText(_fromUtf8(""))
        self.btn_down.setSizePolicy(sizePolicy)
        self.btn_down.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","downarrow.png"))
        curIcon = QIcon(pixmap)
        self.btn_down.setIcon(curIcon)
        self.btn_down.setIconSize(QSize(20, 20))
        self.btn_down.setObjectName(_fromUtf8("btn_down"))
        self.verticalLayout.addWidget(self.btn_down)

        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout.addLayout(self.verticalLayout)

        self.verticalLayout0.addLayout(self.horizontalLayout)
    def updateTableWidget(self):
        self.tableWidget.setRowCount(0)
        for drow in self.cur_data:
            self.tableWidget.insertRow(self.tableWidget.rowCount())
            i = self.tableWidget.rowCount() - 1
            for j, dj in enumerate(drow):
                item = QTableWidgetItem(str(dj))
                item.setToolTip(str(dj))
                self.tableWidget.setItem(i, j, item)
    def readCSV(self,filename):
        f = open(filename, "r")
        data_ = []
        csvreader = csv.reader(f, delimiter=',', quotechar="\"")
        for row in csvreader:
            data_.append(row)
        f.close()
        return data_[0],data_[1:]

    def setupSignals(self):
        self.btn_add.clicked.connect(self.btn_add_clicked)
        self.btn_minus.clicked.connect(self.btn_minus_clicked)
        self.btn_up.clicked.connect(self.btn_up_clicked)
        self.btn_down.clicked.connect(self.btn_down_clicked)
        self.tableWidget.itemChanged.connect(self.editTableCell)
    def btn_add_clicked(self):
        popupMenu = QMenu()
        actionOpenfromDefault = QAction(self.tr('Select from Default Indicators File...'), self.btn_add)
        actionOpenfromDefault.triggered.connect(self.selectFromDefault)
        popupMenu.addAction(actionOpenfromDefault)

        actionOpenfromFile = QAction(self.tr('Open from Other CSV...'), self.btn_add)
        actionOpenfromFile.triggered.connect(self.openFromCSV)
        popupMenu.addAction(actionOpenfromFile)

        actionOpenFromPostgres = QAction(
            self.tr('Open from PostGIS Table...'), self.btn_add)
        actionOpenFromPostgres.triggered.connect(self.openFromPostgres)
        popupMenu.addAction(actionOpenFromPostgres)

        actionNewEntry = QAction(
            self.tr('Add New Indicator Manually...'), self.btn_add)
        actionNewEntry.triggered.connect(self.addNewEntry)
        popupMenu.addAction(actionNewEntry)

        if hasattr(iface, "standalone"):
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            settings = QSettings()
        settings.beginGroup('/PostgreSQL/connections/')
        names = settings.childGroups()
        settings.endGroup()
        actionOpenFromPostgres.setEnabled(bool(names))
        self.cursor_position_add = QCursor.pos()
        popupMenu.exec_(QCursor.pos())

    def btn_minus_clicked(self):
        # adjust the rows of the self.selectedData and tableWidget
        indj = self.titles.index("id")
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            [self.cur_data.pop(sel.row()) for sel in sels]
            self.updateTableWidget()
    def btn_up_clicked(self):
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            if len(sels)>1:
                QMessageBox.warning(self, "Only support One selection", "Please move one entry at a time!")
            sel = sels[0].row()
            if sel>0:
                temp = self.cur_data.pop(sel)
                self.cur_data.insert(sel-1,temp)
                self.updateTableWidget()
                self.tableWidget.selectRow(sel-1)
        # adjust the row sequence of the self.selectedData and tableWidget
    def btn_down_clicked(self):
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            if len(sels)>1:
                QMessageBox.warning(self, "Only support One selection", "Only support One selection!")
            sel = sels[0].row()
            if sel<len(self.cur_data)-1:
                temp = self.cur_data.pop(sel)
                self.cur_data.insert(sel+1,temp)
                self.updateTableWidget()
                self.tableWidget.selectRow(sel+1)
        # adjust the row sequence of the self.selectedData and tableWidget
    def editTableCell(self,item):
        row = item.row()
        col = item.column()
        self.cur_data[row][col] = self.tableWidget.item(row,col).text()
    def selectFromDefault(self):
        filename = self.alg.defalutPath
        curpath = os.path.join(pluginPath, filename)
        self.titles,self.defaultdata = self.readCSV(curpath)
        data_ = self.Applyfilter(self.defaultdata)
        selectDlg = DataSelectionPanel(self.titles,data_)
        flag = selectDlg.exec_()
        if flag == QDialog.Accepted:
            inds = selectDlg.selection
            data_select = [data_[d] for d in inds]
            self.cur_data.extend(data_select)
            self.updateTableWidget()

    def openFromCSV(self):
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        if settings.contains('/Processing/LastInputPath'):
            path = str(settings.value('/Processing/LastInputPath'))
        else:
            path = ''

        filename,ext = QFileDialog.getOpenFileName(self, self.tr('Select CSV file'),
                                               path, self.tr('csv files (*.csv);;'))
        data_ = []
        if filename:
            settings.setValue('/Processing/LastInputPath',
                              os.path.dirname(str(filename)))
            # read in this csv file
            _,data_ = self.readCSV(filename)

            data_ = self.Applyfilter(data_)
            selectDlg = DataSelectionPanel(self.titles,data_)
            flag = selectDlg.exec_()
            if flag== QDialog.Accepted:
                inds = selectDlg.selection
                data_select = [data_[d] for d in inds]
                self.cur_data.extend(data_select)
                self.updateTableWidget()

    def openFromPostgres(self):
        ind = self.titles.index('id')
        dlg = SQLTableSelectorPanel(self.titles,["ROADNETWORK"])
        flag = dlg.exec_()
        if flag == QDialog.Accepted:
            data_ = dlg.getValue() #[[1,...],[2,...],[3,...]]
            data_ = self.Applyfilter(data_)
            maxid = self.alg.getParameterFromName(self.alg.SHARABLE_VARIABLES).getValue("maxid")
            len_temp = len(data_)
            for i in range(len_temp):
                data_[i][ind] = maxid + i + 1

            selectDlg = DataSelectionPanel(self.titles, data_)
            flag = selectDlg.exec_()
            if flag == QDialog.Accepted:
                inds = selectDlg.selection
                self.alg.getParameterFromName(self.alg.SHARABLE_VARIABLES).setValue("maxid", maxid + len(inds))
                data_select = [data_[d] for d in inds]
                self.cur_data.extend(data_select)
                self.updateTableWidget()
    def addNewEntry(self):
        maxid = self.alg.getParameterFromName(self.alg.SHARABLE_VARIABLES).getValue("maxid")
        newEntryDlg = NewEntryPanel(maxid+1,self.param.shortdes,self.titles,self.alg)
        flag = newEntryDlg.exec_()
        entry = []
        if flag == QDialog.Accepted:
            entry = newEntryDlg.value
            self.cur_data.extend([entry])
            self.tableWidget.insertRow(self.tableWidget.rowCount())
            i = self.tableWidget.rowCount() - 1
            for j, dj in enumerate(entry):
                item = QTableWidgetItem(str(dj))
                item.setToolTip(str(dj))
                self.tableWidget.setItem(i, j, item)
            self.alg.getParameterFromName(self.alg.SHARABLE_VARIABLES).setValue("maxid", maxid+1)

    def Applyfilter(self,data):
        # get ind of dimentions
        res = []
        ind = self.titles.index("dimensions")
        # filter dimentions
        for dr in data:
            if self.param.shortdes.lower() in dr[ind].strip(" ").lower():
                res.append(dr)
        # remove duplicate
        ind = self.titles.index("id")
        currentids = [dr[ind] for dr in self.cur_data]
        i=0
        while i<len(res):
            if res[i][ind] in currentids:
                res.pop(i)
                i-=1
            i+=1

        # filter spatial scale
        ind = self.titles.index("spatialscale")
        name = self.alg.SPATIALSCALE
        val = self.alg.SPATIALSCALE_OPTIONS[self.alg.getParameterValue(name)]
        if val=="User Defined/Others":
            name = self.alg.USERDEFINED_SPATIALSCALE
            val = self.alg.getParameterValue(name)
        spatialFiter = val
        if spatialFiter:
            i = 0
            while i < len(res):
                if spatialFiter not in res[i][ind]:
                    res.pop(i)
                    i -= 1
                i += 1

        # filter temporal scale
        # ind = titles.index("temporalscale")
        # name = self.alg.TEMPORALSCALE
        # val = self.alg.TEMPORALSCALE_OPTIONS[self.alg.getParameterValue(name)]
        # if val == "User Defined":
        #     name = self.alg.USERDEFINED_TEMPORALSCALE
        #     val = self.alg.getParameterValue(name)
        #     tempFiter = val
        #     if spatialFiter:
        #         i = 0
        #         while i < len(res):
        #             if tempFiter not in res[i][ind]:
        #                 res.pop(i)
        #                 i -= 1
        #             i += 1

        return res #without title in the [0],only the data

    def setParametersValue(self):
        # set data with title[[]]

        temp = [self.titles]
        temp.extend(self.cur_data)
        return self.param.setValue(temp)
    def getValueFromParameter(self):
        # parameter --> widget
        #data_=[[id,...],[1,...],[2,...]]
        name = self.param.name
        data_ = self.alg.getParameterValue(name)
        self.titles,self.cur_data = data_[0],data_[1:]
        self.updateTableWidget()
        return True

class SettingDlg(QWidget):
    def __init__(self,alg):
        self.alg = alg
        self.name = "Setting Dialog"
        QWidget.__init__(self)
        self.setupPanel()
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.setParametersValue()

    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 600, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()
        self.widgets = {}
        self.labels = {}
        # Defalut path
        name = self.alg.DEFALUT_CSVFILE
        param = self.alg.getParameterFromName(name)
        label = QLabel(param.description)
        # # label.setToolTip(tooltip)
        # item = FileSelectionPanel(param.isFolder, param.ext)
        # item.setText(self.alg.defalutPath)
        hlayout = QHBoxLayout()
        item = QLineEdit(self)
        item.setText(self.alg.defalutPath)
        item.setDisabled(True)
        hlayout.addWidget(item)
        btn = QPushButton(self)
        btn.setText("Default Indicators File")
        hlayout.addWidget(btn)

        self.layoutMain.insertWidget(self.layoutMain.count() - 1, label)
        self.layoutMain.insertLayout(self.layoutMain.count() - 1, hlayout)
        self.widgets[name] = item
        self.labels[name] = label
        btn.clicked.connect(self.editingIndiCSV)
        # Output path
        name = self.alg.OUTPUT_AS_TEXT
        param = self.alg.getOutputFromName(name)
        label = QLabel(param.description)
        item = OutputSelectionPanel(param, self.alg)
        self.add2Mainlayout(name, label, item)

    def editingIndiCSV(self):
        name = self.alg.DEFALUT_CSVFILE
        param = self.alg.getParameterFromName(name)
        curpath = self.widgets[name].text()
        curpath = os.path.join(pluginPath,curpath)
        dlg = EditingExistingIndicatorPanel(curpath)
        if dlg.exec_()==QDialog.Accepted:
            pass

    def add2Mainlayout(self,name,label,item):
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 1, item)
        self.widgets[name] = item
        self.labels[name] = label

    def setParametersValue(self):
        # Defalut path
        name = self.alg.DEFALUT_CSVFILE
        param = self.alg.getParameterFromName(name)
        curpath = self.widgets[name].text()
        if os.path.exists(curpath):
            param.setValue(curpath)
        else:
            curpath = os.path.join(pluginPath,curpath)
            if os.path.exists(curpath):
                param.setValue(curpath)
                # QMessageBox.warning(self, "Invalide Default CSV", "Found it.")
            else:
                QMessageBox.warning(self, "Invalide Default CSV", "Can't Find the Default CSV file "+curpath)
                return False
        # Output path
        name = self.alg.OUTPUT_AS_TEXT
        param = self.alg.getOutputFromName(name)
        curpath = self.widgets[name].getValue()
        # if curpath==None, it sets to
        param.setValue(curpath)
        # QMessageBox.warning(self, "Wrong selection", "Select a schema item in the tree")
        return True

    def getValueFromParameter(self):
        # parameter --> widget
        # Defalut path
        name = self.alg.DEFALUT_CSVFILE
        # param = self.alg.getParameterFromName(name)
        val = self.alg.getParameterValue(name)
        if val is None:
            val = ""
        if not os.path.exists(val):
            val = ""
        self.widgets[name].setText(val)

        # # Output path
        # name = self.alg.OUTPUT_AS_TEXT
        # val = self.alg.getParameterValue(name)
        return True

class ParameterRawData(Parameter):
    def __init__(self, name='', description='', shortdes = '', default=None, optional=False):
        Parameter.__init__(self, name, description, default, optional)
        self.shortdes = shortdes
    def setValue(self, value):
        if value is None:
            if not self.optional:
                return False
            self.value = None if value is None else value
            return True
        self.value = value
        return True
class RawDlg(QWidget):
    def __init__(self,alg):
        self.alg = alg
        self.name ="Raw Data Dialog"
        QWidget.__init__(self)

        filename = self.alg.defalutPath
        curpath = os.path.join(pluginPath, filename)
        self.titles = ["Filename","Type","CRS","Path"]
        self.layer_meta = [] # [["counties","line","ESPG:4326","c:/data/counties.shp"],[...],[...]]
        self.layer_fields = {}#{"counties":[[field0,type,notes]]}
        self.layers={} # {"counties":LayerObject}
        self.setupPanel()
        self.setupSignals()
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.cursor_position_add = None

    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")

        self.verticalLayout0 = QVBoxLayout(myForm)
        label = QLabel("Select Raw Data:")
        self.verticalLayout0.addWidget(label)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.tableWidget = QTableWidget(myForm)
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(len(self.titles))
        # self.tableWidget.setColumnWidth(0,15)
        # self.tableWidget.setColumnWidth(1, 150)
        # self.tableWidget.setColumnWidth(4, 250)
        self.tableWidget.setHorizontalHeaderLabels(self.titles)  # set header
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # disable edit
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setSelectionMode(QAbstractItemView.MultiSelection)

        self.horizontalLayout.addWidget(self.tableWidget)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.btn_add = QPushButton(myForm)
        self.btn_add.setSizePolicy(sizePolicy)
        self.btn_add.setMaximumSize(QSize(20, 20))
        self.btn_add.setText(_fromUtf8(""))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","plus.png"))
        curIcon = QIcon(pixmap)
        self.btn_add.setIcon(curIcon)
        self.btn_add.setIconSize(QSize(20,20))
        self.btn_add.setObjectName(_fromUtf8("btn_add"))
        self.verticalLayout.addWidget(self.btn_add)

        self.btn_minus = QPushButton(myForm)
        self.btn_minus.setText(_fromUtf8(""))
        self.btn_minus.setSizePolicy(sizePolicy)
        self.btn_minus.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","minus.png"))
        curIcon = QIcon(pixmap)
        self.btn_minus.setIcon(curIcon)
        self.btn_minus.setIconSize(QSize(20, 20))
        self.btn_minus.setObjectName(_fromUtf8("btn_minus"))
        self.verticalLayout.addWidget(self.btn_minus)

        self.btn_up = QPushButton(myForm)
        self.btn_up.setText(_fromUtf8(""))
        self.btn_up.setSizePolicy(sizePolicy)
        self.btn_up.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","uparrow.png"))
        curIcon = QIcon(pixmap)
        self.btn_up.setIcon(curIcon)
        self.btn_up.setIconSize(QSize(20, 20))
        self.btn_up.setObjectName(_fromUtf8("btn_up"))
        self.verticalLayout.addWidget(self.btn_up)

        self.btn_down = QPushButton(myForm)
        self.btn_down.setText(_fromUtf8(""))
        self.btn_down.setSizePolicy(sizePolicy)
        self.btn_down.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","downarrow.png"))
        curIcon = QIcon(pixmap)
        self.btn_down.setIcon(curIcon)
        self.btn_down.setIconSize(QSize(20, 20))
        self.btn_down.setObjectName(_fromUtf8("btn_down"))
        self.verticalLayout.addWidget(self.btn_down)

        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout.addLayout(self.verticalLayout)

        self.verticalLayout0.addLayout(self.horizontalLayout)
    def updateTableWidget(self):
        indfilename = self.titles.index("Filename")
        self.tableWidget.setRowCount(0)
        for drow in self.layer_meta:
            self.tableWidget.insertRow(self.tableWidget.rowCount())
            i = self.tableWidget.rowCount() - 1
            for j, dj in enumerate(drow):
                item = QTableWidgetItem(str(dj))
                item.setToolTip(str(dj))
                self.tableWidget.setItem(i, j, item)
            # if drow[0]=="-":
            #     # expend
            #     if drow[indfilename] in self.layer_fields.keys():
            #         tempFields = self.layer_fields[drow[indfilename]]
            #         for field in tempFields:
            #             self.tableWidget.insertRow(self.tableWidget.rowCount())
            #             for j, dj in enumerate(field):
            #                 item = QTableWidgetItem(str(dj))
            #                 item.setToolTip(str(dj))
            #                 self.tableWidget.setItem(i, j+1, item)

    def setupSignals(self):
        self.btn_add.clicked.connect(self.btn_add_clicked)
        self.btn_minus.clicked.connect(self.btn_minus_clicked)
        self.btn_up.clicked.connect(self.btn_up_clicked)
        self.btn_down.clicked.connect(self.btn_down_clicked)
        # self.tableWidget.doubleClicked.connect(self.table_doubleclicked)
    def btn_add_clicked(self):
        popupMenu = QMenu()
        actionOpenfromDefault = QAction(self.tr('Select from Current Layers...'), self.btn_add)
        actionOpenfromDefault.triggered.connect(self.selectFromCurrentLayer)
        popupMenu.addAction(actionOpenfromDefault)

        actionOpenfromFile = QAction(self.tr('Select from File...'), self.btn_add)
        actionOpenfromFile.triggered.connect(self.selectFromFile)
        popupMenu.addAction(actionOpenfromFile)

        actionOpenFromPostgres = QAction(
            self.tr('Select from PostGIS Table...'), self.btn_add)
        actionOpenFromPostgres.triggered.connect(self.selectFromPostGIS)
        popupMenu.addAction(actionOpenFromPostgres)

        if hasattr(iface, "standalone"):
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            settings = QSettings()
        settings.beginGroup('/PostgreSQL/connections/')
        names = settings.childGroups()
        settings.endGroup()
        actionOpenFromPostgres.setEnabled(bool(names))
        self.cursor_position_add = QCursor.pos()
        popupMenu.exec_(QCursor.pos())

    def btn_minus_clicked(self):
        # adjust the rows of the self.selectedData and tableWidget
        # self.titles = ["Filename","Type","CRS","Path"]
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            for sel in sels:
                temp = self.layer_meta.pop(sel.row())
                del self.layers[temp[0]]
            self.updateTableWidget()
    def btn_up_clicked(self):
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            if len(sels)>1:
                QMessageBox.warning(self, "Only support One selection", "Please move one entry at a time!")
            sel = sels[0].row()
            if sel>0:
                temp = self.layer_meta.pop(sel)
                self.layer_meta.insert(sel-1,temp)
                self.updateTableWidget()
                self.tableWidget.selectRow(sel-1)

    def btn_down_clicked(self):
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            if len(sels)>1:
                QMessageBox.warning(self, "Only support One selection", "Only support One selection!")
            sel = sels[0].row()
            if sel<len(self.cur_data)-1:
                temp = self.layer_meta.pop(sel)
                self.layer_meta.insert(sel+1,temp)
                self.updateTableWidget()
                self.tableWidget.selectRow(sel+1)

    # def table_doubleclicked(self,item):
    #     row = item.row()
    #     col = item.column()
    #     temp_text = self.tableWidget.item(row,col).text()
    #     self.updateTableWidget()
    def selectFromCurrentLayer(self):
        # self.titles = ["","Filename","Type","CRS","Path"]
        # self.layer_meta = [] # [["+","counties","line","ESPG:4326","c:/data/counties.shp"],[...],[...]]
        # self.layer_fields = {}#{"counties":[[field0,type,notes]]}
        # self.layers={} # {"counties":LayerObject}
        t_titles = ["id","name"]
        layers = dataobjects.getVectorLayers(sorting=False)
        # opts = [self.getExtendedLayerName(opt) for opt in layers]
        names = []
        for i, l in enumerate(layers):
            if l.name() not in self.layers.keys():
                names.append([str(i),l.name()])
        t_data = names

        dlg = DataSelectionPanel(t_titles,t_data)
        if dlg.exec_() == QDialog.Accepted:
            inds = dlg.selection
            sel_layers = [layers[i] for i in inds]
            # layer = dataobjects.getObjectFromUri(paramInput["data"])
            # filename,type,crs,path
            # filename: lay.name()
            # path: lay.dataProvider().dataSourceUri()
            # type: lay.geometryType()
            # crs: authid = layer.crs().authid()

            for sel in sel_layers:
                # temp = ["+"]
                temp = []
                self.layers[sel.name()]=sel
                temp.append(sel.name())
                temp.append(QgsWKBTypes.displayString(int(sel.wkbType())))
                temp.append(sel.crs().authid())
                temp.append(sel.dataProvider().dataSourceUri())
                self.layer_meta.append(temp)
                self.updateTableWidget()

    def selectFromFile(self):
        ind_path = self.titles.index("Filename")
        if self.standalone:
            #it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            #it is run in QGIS
            settings = QSettings()
        if settings.contains('/Processing/LastInputPath'):
            path = str(settings.value('/Processing/LastInputPath'))
        else:
            path = ''

        filename,ext = QFileDialog.getOpenFileName(self, self.tr('Select CSV file'),
                                               path, self.tr('Shapefile file (*.shp);;csv files (*.csv);;'))
        data_ = []
        if filename:
            settings.setValue('/Processing/LastInputPath',
                              os.path.dirname(str(filename)))
            name,ext = os.path.basename(filename).split(".")
            if ext.lower()=='csv':
                # self.titles = ["Filename", "Type", "CRS", "Path"]
                # check if the filename exists
                for layer in self.layer_meta:
                    if layer[ind_path]==name:
                        # if exists, pop message
                        QMessageBox.warning(self, "Already exists", "Selection exsits!")
                        return
                # add if not exists
                temp = [name,"CSV","",filename]
                self.layer_meta.append(temp)
            elif ext.lower()=='shp':
                for layer in self.layer_meta:
                    if layer[ind_path]==name:
                        # if exists, pop message
                        QMessageBox.warning(self, "Already exists", "Selection exsits!")
                        return
                # add if not exists
                layer1 = QgsVectorLayer(filename, name, "ogr")
                temp = []
                self.layers[name]= layer1
                temp.append(name)
                temp.append(QgsWKBTypes.displayString(int(layer1.wkbType())))
                temp.append(layer1.crs().authid())
                temp.append(layer1.dataProvider().dataSourceUri())

                self.layer_meta.append(temp)
            self.updateTableWidget()

    def selectFromPostGIS(self):
        ind = self.titles.index('Filename')
        dlg = SQLTableSelectorPanel(self.titles,[SQLTableSelectorPanel.BASE]) #TODO,revise
        flag = dlg.exec_()
        if flag == QDialog.Accepted:
            uriObj = dlg.getValue()
            schema = uriObj.schema()
            tablename = uriObj.table()
            name = schema+"."+tablename
            layerObj = QgsVectorLayer(uriObj.uri(),name, "postgres")
            if layerObj is not None:
                temp = []
                self.layers[name]=layerObj
                temp.append(name)
                temp.append(dlg.type)
                temp.append(layerObj.crs().authid())
                temp.append(layerObj.dataProvider().dataSourceUri())

                for layer in self.layer_meta:
                    if layer[ind] == temp[ind]:
                        # if exists, pop message
                        QMessageBox.warning(self, "Already exists", "Selection exsits!")
                        return
                # add if not exists
                self.layer_meta.append(temp)
                self.updateTableWidget()

    def setParametersValue(self):
        # set data with title[[]]
        temp = [self.titles]
        temp.extend(self.layer_meta)
        return self.alg.getParameterFromName(self.alg.RAWDATA).setValue(temp)
    def getValueFromParameter(self):
        # parameter --> widget
        # data_=[[id,...],[1,...],[2,...]]
        name = self.alg.RAWDATA
        data_ = self.alg.getParameterValue(name)
        self.titles,self.layer_meta = data_[0],data_[1:]
        self.updateTableWidget()
        return True

class ParameterAssessDataQuality(Parameter):
    def __init__(self, name='', description='', shortdes = '', default=None, optional=False):
        Parameter.__init__(self, name, description, default, optional)
        self.shortdes = shortdes
    def setValue(self, value):
        if value is None:
            if not self.optional:
                return False
            self.value = None if value is None else value
            return True
        self.value = value
        return True
class AssessDataQualityDlg(QWidget):
    def __init__(self,alg):
        self.alg = alg
        self.name ="Assess Data Quality Dialog"
        QWidget.__init__(self)

        filename = self.alg.defalutPath
        curpath = os.path.join(pluginPath, filename)
        self.titles = ["Data Name","High(3)","Medium(2)","Low(1)","Scores"]
        self.layer_meta = [] # [["counties","line","ESPG:4326","c:/data/counties.shp"],[...],[...]]
        self.value = [] #[["counties",1],[...],...]
        self.total = ["Total",0,0,0,0]
        self.widgets = []
        self.setupPanel()
        self.setupSignals()
        self.updataLayersData()
        self.updateTableWidget()
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.cursor_position_add = None

    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")

        self.verticalLayout0 = QVBoxLayout(myForm)
        label = QLabel(self.alg.getParameterFromName(self.alg.ASSESSDATAQUALITY).description)
        self.verticalLayout0.addWidget(label)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.tableWidget = QTableWidget(myForm)
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setRowCount(0)
        # set table header -------------------------
        self.tableWidget.setColumnCount(len(self.titles))
        self.tableWidget.setHorizontalHeaderLabels(self.titles)  # set header
        # set table header -------------------------
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # disable edit
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setSelectionMode(QAbstractItemView.MultiSelection)

        self.horizontalLayout.addWidget(self.tableWidget)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        sizePolicy = QSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        self.btn_reload = QPushButton(myForm)
        self.btn_reload.setText(_fromUtf8(""))
        self.btn_reload.setSizePolicy(sizePolicy)
        self.btn_reload.setMaximumSize(QSize(20, 20))
        pixmap = QPixmap(os.path.join(pluginPath,"icons","reload.png"))
        curIcon = QIcon(pixmap)
        self.btn_reload.setIcon(curIcon)
        self.btn_reload.setIconSize(QSize(20, 20))
        self.btn_reload.setObjectName(_fromUtf8("btn_reload"))
        self.verticalLayout.addWidget(self.btn_reload)

        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout.addLayout(self.verticalLayout)

        self.verticalLayout0.addLayout(self.horizontalLayout)

    def updataLayersData(self):
        # update self.layer_meta = [] # [["counties","line","ESPG:4326","c:/data/counties.shp"],[...],[...]]
        #        self.value = [] #[["counties",1],[...],...]
        newdata_ = self.alg.getParameterValue(self.alg.RAWDATA)
        if newdata_ is None: return
        newdata_ = newdata_[1:]
        newValue = []
        index = []
        if len(self.layer_meta)!=0:
            bool_new=[] #[True,False,True,...]
            # compare with self.layer_meta
            keys = [ele[3] for ele in self.layer_meta]
            for i,layer in enumerate(newdata_):
                if layer[3] in keys:
                    #already exist
                    bool_new.append(False)
                    index.append(keys.index(layer[3]))
                else:
                    bool_new.append(True)
                    index.append(None)
            # update self.value
            for i,up in enumerate(bool_new):
                if up==True:# need update
                    newValue.append([newdata_[i][0],False,False,False,None])
                else: # don't need update
                    newValue.append(self.value[index[i]])
            self.layer_meta = newdata_
            self.value = newValue
        else:
            self.layer_meta = newdata_
            self.value = []
            for ele in self.layer_meta:
                self.value.append([ele[0],False,False,False,None])
        #update self.total
        self.total = ["Total", 0, 0, 0, 0]
        for ele in self.value:
            if ele[1]==True:
                self.total[1] = self.total[1] + 1 * 3
            if ele[2] == True:
                self.total[2] = self.total[2] + 1 * 2
            if ele[3] == True:
                self.total[3] = self.total[3] + 1 * 1
            if ele[4] is not None:
                self.total[4] = self.total[4] + ele[4]
    def updateTableWidget(self):
        row = len(self.value)+1
        self.tableWidget.setRowCount(0)
        self.widgets = []
        for drow in self.value:
            self.tableWidget.insertRow(self.tableWidget.rowCount())
            i = self.tableWidget.rowCount() - 1
            name= str(drow[0])
            item = QTableWidgetItem(name)
            item.setToolTip(name)
            self.tableWidget.setItem(i, 0, item)

            chboxs = []
            for j in [1,2,3]:
                checkBox = QCheckBox()
                checkBox.setChecked(drow[j])
                checkBox.stateChanged.connect(self.checkBoxChanged)
                chboxs.append(checkBox)
                self.tableWidget.setCellWidget(i, j, checkBox)

            self.widgets.append(chboxs)
            scorestr = ""
            if drow[4] is not None:
                scorestr = str(drow[4])
            item = QTableWidgetItem(scorestr)
            item.setToolTip(scorestr)
            self.tableWidget.setItem(i, 4, item)

        self.tableWidget.insertRow(self.tableWidget.rowCount())
        i = self.tableWidget.rowCount() - 1
        for j,ele in enumerate(self.total):
            item = QTableWidgetItem(str(ele))
            item.setToolTip(str(ele))
            self.tableWidget.setItem(i, j, item)

    def setupSignals(self):
        self.btn_reload.clicked.connect(self.btn_reload_clicked)
    def checkBoxChanged(self,state):
        sender = self.sender()
        if not isinstance(sender, QCheckBox):
            return
        row,col = -1,-1
        for i,chboxes in enumerate(self.widgets):
            for j,chb in enumerate(chboxes):
                if sender==chb:
                    row,col = i,j
                    break
        if row==-1: return
        if state == Qt.Checked:
            temp = list(range(3))
            temp.pop(col)
            for t in temp:
                self.widgets[row][t].setChecked(False)
            self.value[row][4] = 3-col
            self.value[row][col+1] = True
        else:
            self.value[row][4] = None
            self.value[row][col+1] = False

        if self.value[row][4] is not None:
            item = QTableWidgetItem(str(self.value[row][4]))
            item.setToolTip(str(self.value[row][4]))
            self.tableWidget.setItem(row, 4, item)

        #update self.total
        self.total = ["Total",0,0,0,0]
        for ele in self.value:
            if ele[1]==True:
                self.total[1] = self.total[1] + 1 * 3
            if ele[2] == True:
                self.total[2] = self.total[2] + 1 * 2
            if ele[3] == True:
                self.total[3] = self.total[3] + 1 * 1
            if ele[4] is not None:
                self.total[4] = self.total[4] + ele[4]
        i = self.tableWidget.rowCount()-1
        for j,ele in enumerate(self.total):
            item = QTableWidgetItem(str(ele))
            item.setToolTip(str(ele))
            self.tableWidget.setItem(i, j, item)
    def btn_reload_clicked(self):
        self.updataLayersData()
        self.updateTableWidget()
    def setParametersValue(self):
        # set data with title[[]]
        temp = [self.titles]
        temp.extend(self.value)
        temp.append(self.total)
        return self.alg.getParameterFromName(self.alg.ASSESSDATAQUALITY).setValue(temp)
    def getValueFromParameter(self):
        # parameter --> widget
        # data_=[[id,...],[1,...],[2,...]]
        name = self.alg.ASSESSDATAQUALITY
        data_ = self.alg.getParameterValue(name)
        self.titles,self.value,self.total = data_[0],data_[1:-1],data_[-1]
        name = self.alg.RAWDATA
        data_ = self.alg.getParameterValue(name)
        _,self.layer_meta = data_[0],data_[1:]
        if len(data_)>2:
            for ele in self.value:
                ele[1] = bool(ele[1]=="True")
                ele[2] = bool(ele[2]=="True")
                ele[3] = bool(ele[3]=="True")
                ele[4] = int(ele[4])
            self.updateTableWidget()
        return True

class SpatialSusDlg(QWidget):
    def __init__(self,alg):
        self.alg = alg
        self.name ="Spatial Sustainability Dialog"
        self.eventActions = self.alg.actions
        QWidget.__init__(self)

        filename = self.alg.defalutPath
        curpath = os.path.join(pluginPath, filename)
        self.setupPanel()
        self.setupSignals()
        self.initTree()
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.cursor_position_add = None
    def initTree(self):
        treeStruct = {} #{"top1":[treeitem,{"sub1":[treeitem,action]}],"top2":{treeitem,action}}
        actionsMap = {} # name ---> action
        self.ReverseActionMap = {} # treeitem ---> action
        actionsOrd = []
        for act in self.eventActions:
            actionname = act.objectName()
            if actionname.split("/")[1] not in ["Results Analysis","Results Visualization"]:
                actionsMap[actionname] = act
                actionsOrd.append(actionname)
        for actname in actionsOrd:
            topname,subnames = actname.split("/")[1],actname.split("/")[2:]
            if topname not in treeStruct.keys():
                top_item = QTreeWidgetItem([topname])
                self.treeWidget.addTopLevelItem(top_item)
                treeStruct[topname] = [top_item,{}]
            cur_item = treeStruct[topname]
            for nm in subnames[0:-1]:
                if nm not in cur_item[1].keys():
                    item = QTreeWidgetItem([nm])
                    cur_item[0].addChild(item)
                    cur_item[1][nm] = [item,{}]
                cur_item = cur_item[1][nm]

            # for the last menu
            nm = subnames[-1]
            if nm not in cur_item[1].keys():
                item = QTreeWidgetItem([nm])
                item.setIcon(0,actionsMap[actname].icon())
                cur_item[0].addChild(item)
                cur_item[1][nm] = [item,actionsMap[actname]]
                self.ReverseActionMap[item] = actionsMap[actname]
    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")

        self.verticalLayout0 = QVBoxLayout(myForm)
        label = QLabel("Spatial Sustainability Assessment Tools:")
        self.verticalLayout0.addWidget(label)

        self.treeWidget = QTreeWidget(myForm)
        self.treeWidget.setObjectName(_fromUtf8("treeWidget"))
        self.treeWidget.header().setVisible(False)
        self.verticalLayout0.addWidget(self.treeWidget)

    # def treeWidgetChanged(self):
    #     pass
    # def itemExpanded(self):
    #     pass
    # def on_click_tree(self):
    #     pass
    def on_double_click_tree(self):
        item = self.treeWidget.currentItem()
        if item in self.ReverseActionMap.keys():
            action = self.ReverseActionMap[item]
            action.trigger()
    def setupSignals(self):
        # self.treeWidget.currentItemChanged.connect(self.treeWidgetChanged)
        # self.treeWidget.itemExpanded.connect(self.itemExpanded)
        # self.treeWidget.clicked.connect(self.on_click_tree)
        self.treeWidget.itemDoubleClicked.connect(self.on_double_click_tree)

    def getValueFromParameter(self):
        return True
    def setParametersValue(self):
        return True

class ResultsAnalysisDlg(QWidget):
    def __init__(self,alg):
        self.alg = alg
        self.name ="Results Analysis Dialog"
        self.eventActions = self.alg.actions
        QWidget.__init__(self)
        self.actionsMap = {} # name ---> action
        self.actionsOrd = ["Uncertainty","Sensitivity"]

        filename = self.alg.defalutPath
        curpath = os.path.join(pluginPath, filename)
        self.setupPanel()
        self.setupSignals()
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.cursor_position_add = None
    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")

        self.verticalLayout_2 = QVBoxLayout(myForm)
        label = QLabel("Results Analysis Tools:")
        self.verticalLayout_2.addWidget(label)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.btn1 = QPushButton(myForm)
        self.btn1.setObjectName(_fromUtf8("btn1"))
        self.horizontalLayout.addWidget(self.btn1)
        self.btn2 = QPushButton(myForm)
        self.btn2.setObjectName(_fromUtf8("btn2"))
        self.horizontalLayout.addWidget(self.btn2)
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.verticalLayout_2.addLayout(self.horizontalLayout)
        spacerItem1 = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.verticalLayout_2.addItem(spacerItem1)
        self.btn1.setText("Uncertainty Analysis")
        self.btn2.setText("Sensitivity Analysis")


        for act in self.eventActions:
            actionname = act.objectName()
            if actionname.split("/")[2] in ["Uncertainty Analysis"]:
                self.actionsMap["Uncertainty"] = act
            elif actionname.split("/")[2] in ["Sensitivity Analysis"]:
                self.actionsMap["Sensitivity"] = act
    def setupSignals(self):
        self.btn1.clicked.connect(self.btn1_clicked)
        self.btn2.clicked.connect(self.btn2_clicked)
    def btn1_clicked(self):
        # Uncertainty Analysis
        self.actionsMap["Uncertainty"].trigger()
    def btn2_clicked(self):
        self.actionsMap["Sensitivity"].trigger()
    def getValueFromParameter(self):
        return True
    def setParametersValue(self):
        return True
class FieldType(object):
    DATA_TYPE_ID = 0
    DATA_TYPE_NUMERIC = 1
    DATA_TYPE_ALL = -1
class ResultsVisualizationDlg(QWidget):
    def __init__(self,alg):
        self.alg = alg
        self.name ="Results Visualization Dialog"
        self.eventActions = self.alg.actions
        QWidget.__init__(self)
        self.checkBoxes = {}
        self.dependentItems = {}
        self.iterateButtons = {}
        self.widgets = {}
        self.labels = {}
        filename = self.alg.defalutPath
        curpath = os.path.join(pluginPath, filename)
        self.setupPanel()
        self.setupSignals()
        self.standalone = False
        if hasattr(iface, 'standalone'):
            self.standalone = True
        self.cursor_position_add = None

    def setupPanel(self):
        myForm = self
        myForm.setObjectName("From")
        self.verticalLayout = QVBoxLayout(myForm)
        self.verticalLayout.setSpacing(2)
        self.verticalLayout.setMargin(0)
        self.verticalLayout.setObjectName("verticalLayout")
        self.scrollArea = QScrollArea(myForm)
        self.scrollArea.setFrameShape(QFrame.NoFrame)
        self.scrollArea.setWidgetResizable(True)
        self.scrollArea.setObjectName("scrollArea")
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 400, 200))
        self.scrollAreaWidgetContents.setObjectName("scrollAreaWidgetContents")
        self.layoutMain = QVBoxLayout(self.scrollAreaWidgetContents)
        self.layoutMain.setObjectName("verticalLayout_2")
        self.grpAdvanced = QgsCollapsibleGroupBox(self.scrollAreaWidgetContents)
        self.grpAdvanced.setFlat(True)
        self.grpAdvanced.setCollapsed(True)
        self.grpAdvanced.setObjectName("grpAdvanced")
        self.grpAdvanced.setTitle("Advanced parameters")
        self.layoutAdvanced = QVBoxLayout(self.grpAdvanced)
        self.layoutAdvanced.setSpacing(2)
        self.layoutAdvanced.setContentsMargins(0, 9, 0, 0)
        self.layoutAdvanced.setObjectName("verticalLayout_3")
        self.layoutMain.addWidget(self.grpAdvanced)
        spacerItem = QSpacerItem(20, 100, QSizePolicy.Minimum, QSizePolicy.Preferred)
        self.layoutMain.addItem(spacerItem)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.verticalLayout.addWidget(self.scrollArea)

        self.grpAdvanced.hide()

        # Results Visualization ========================================================================================
        label = QLabel("Visualization Charts")
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        # Setup Checkboxes to indicate which chart will be produced
        h_layout = QHBoxLayout()
        check1 = QCheckBox()
        check1.setText(self.tr('Radar'))
        check1.setChecked(False)
        h_layout.addWidget(check1)

        check2 = QCheckBox()
        check2.setText(self.tr('SunBurst'))
        check2.setChecked(False)
        h_layout.addWidget(check2)

        check3 = QCheckBox()
        check3.setText(self.tr('Stratified Bar'))
        check3.setChecked(False)
        h_layout.addWidget(check3)

        check4 = QCheckBox()
        check4.setText(self.tr('Line'))
        check4.setChecked(False)
        h_layout.addWidget(check4)
        self.checkBoxes['Radar'] = check1
        self.checkBoxes['SunBurst'] = check2
        self.checkBoxes['Stratified Bar'] = check3
        self.checkBoxes['Line'] = check4
        self.layoutMain.insertLayout(self.layoutMain.count() - 2,h_layout)

        # add 1 parameter AHP_WEIGHT_FILE = "AHP_WEIGHT_FILE" ==========================================================
        param = self.alg.getParameterFromName(self.alg.AHP_WEIGHT_FILE)
        item = FileSelectionPanel(param.isFolder, param.ext)
        desc = param.description
        label = QLabel(desc)
        self.labels[param.name] = label
        self.widgets[param.name] = item
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        # UNCERTAINTY_RES_VECTOR = 'UNCERTAINTY_RES_VECTOR'  # INPUT UNCERTAINTY RESULT LAYER
        # add 2 parameter ParameterVector_RDBMS======(self.alg.UNCERTAINTY_RES_VECTOR)=========================================
        param = self.alg.getParameterFromName(self.alg.UNCERTAINTY_RES_VECTOR)
        layers = dataobjects.getVectorLayers(param.shapetype) # 2 Polygon
        items = []
        for layer in layers:
            items.append((layer.name(), layer))
        widget = InputLayerRDBMSelectorPanel(items, param)
        widget.cmbText.name = param.name
        widget.cmbText.currentIndexChanged.connect(self.updateDependentFields)

        desc = param.description
        label = QLabel(desc)
        self.labels[param.name] = label
        self.widgets[param.name] = widget
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)

        # UNCERTAINTY_RES_VECTOR_KEY = 'UNCERTAINTY_RES_VECTOR_KEY'  #
        # add 3 parameter ParameterTableField======(self.alg.UNCERTAINTY_RES_VECTOR_KEY)================================
        param = self.alg.getParameterFromName(self.alg.UNCERTAINTY_RES_VECTOR_KEY)
        item = QComboBox()
        desc = param.description
        label = QLabel(desc)
        self.addDependParam(param)
        self.labels[param.name] = label
        self.widgets[param.name] = item
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        # add 4 parameter File======(self.alg.SENSITIVITY_FILE)=========================================================
        # SENSITIVITY_FILE = 'SENSITIVITY_FILE'
        param = self.alg.getParameterFromName(self.alg.SENSITIVITY_FILE)
        item = FileSelectionPanel(param.isFolder, param.ext)
        desc = param.description
        label = QLabel(desc)
        self.labels[param.name] = label
        self.widgets[param.name] = item
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, item)

        # add 5 parameter File======(self.alg.VISULIZATION_OUTPUTDIR)===================================================
        # VISULIZATION_OUTPUTDIR = "VISULIZATION_OUTPUTDIR"
        name = self.alg.VISULIZATION_OUTPUTDIR
        param = self.alg.getOutputFromName(name)
        label = QLabel(param.description)
        widget = OutputSelectionPanel(param, self.alg)
        self.labels[param.name] = label
        self.widgets[param.name] = widget
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, label)
        self.layoutMain.insertWidget(self.layoutMain.count() - 2, widget)

        # add progress bar =============================================================================================
        self.lblProgress = QLabel("")
        self.layoutMain.insertWidget(self.layoutMain.count(), self.lblProgress)
        h2_layout = QHBoxLayout()
        self.progress = QProgressBar(self)
        self.progress.setMaximum(100)
        self.progress.setValue(0)
        self.btn_OK = QPushButton()
        self.btn_OK.setText("Generate Charts")
        h2_layout.addWidget(self.progress)
        h2_layout.addWidget(self.btn_OK)
        self.layoutMain.insertLayout(self.layoutMain.count(), h2_layout)

        self.widgets[self.alg.UNCERTAINTY_RES_VECTOR].cmbText.currentIndexChanged.emit(0)

    def setupSignals(self):
        self.btn_OK.clicked.connect(self.btn_OK_clicked)
    def btn_OK_clicked(self):
        self.setParametersValue()
        self.alg.generateChart(self)
    def setPercentage(self, value):
        if self.progress.maximum() == 0:
            self.progress.setMaximum(100)
        self.progress.setValue(value)
        QCoreApplication.processEvents()

    def isChecked(self,name):
        # ['Radar', 'SunBurst', 'Stratified Bar', 'Line']
        if name not in ['Radar', 'SunBurst', 'Stratified Bar', 'Line']:
            raise GeoAlgorithmExecutionException("Plot Key Error!")
        return self.checkBoxes[name].isChecked()

    def setText(self, text):
        self.lblProgress.setText(text)
        QCoreApplication.processEvents()
    def getValueFromParameter(self):
        value = self.alg.getParameterValue(self.alg.AHP_WEIGHT_FILE)
        widget = self.widgets[self.alg.AHP_WEIGHT_FILE]
        widget.setText(value)

        value = self.alg.getParameterValue(self.alg.SENSITIVITY_FILE)
        widget = self.widgets[self.alg.SENSITIVITY_FILE]
        widget.setText(value)

        name = self.alg.VISULIZATION_OUTPUTDIR
        value = self.alg.getOutputValue(name)
        widget = self.widgets[name]
        widget.leText.setText(widget.getValue())
        return True
    def setParametersValue(self):
        param = self.alg.getParameterFromName(self.alg.AHP_WEIGHT_FILE)
        value = self.widgets[self.alg.AHP_WEIGHT_FILE].getValue()
        param.setValue(value)

        param = self.alg.getParameterFromName(self.alg.UNCERTAINTY_RES_VECTOR)
        value = self.widgets[self.alg.UNCERTAINTY_RES_VECTOR].getValue()
        param.setValue(value)

        param = self.alg.getParameterFromName(self.alg.UNCERTAINTY_RES_VECTOR_KEY)
        widget = self.widgets[self.alg.UNCERTAINTY_RES_VECTOR_KEY]
        if param.optional and widget.currentIndex() == 0:
            param.setValue(None)
        param.setValue(widget.currentText())

        param = self.alg.getParameterFromName(self.alg.SENSITIVITY_FILE)
        widget = self.widgets[self.alg.SENSITIVITY_FILE]
        param.setValue(widget.getValue())

        name = self.alg.VISULIZATION_OUTPUTDIR
        param = self.alg.getOutputFromName(name)
        widget = self.widgets[name]
        param.setValue(widget.getValue())

        return True

    def addDependParam(self,param):
        if isinstance(param.parent,list):
            for parent in param.parent:
                if parent in self.dependentItems:
                    items = self.dependentItems[parent]
                else:
                    items = []
                    self.dependentItems[parent] = items
                items.append(param)
        else:
            if param.parent in self.dependentItems:
                items = self.dependentItems[param.parent]
            else:
                items = []
                self.dependentItems[param.parent] = items
            items.append(param)

    def updateDependentFields(self):
        sender = self.sender()
        if not isinstance(sender, QComboBox):
            return
        if sender.name not in self.dependentItems:
            return
        layer = sender.itemData(sender.currentIndex())
        if not layer:
            return

        children = self.dependentItems[sender.name]
        for child in children:
            if (isinstance(child, ParameterTableField)):
                widget = self.widgets[child.name]
                widget.clear()
                child_param = self.alg.getParameterFromName(child.name)
                datatype = child_param.datatype
                fieldTypes = []
                if datatype == FieldType.DATA_TYPE_ID:
                    fieldTypes = [QVariant.String, QVariant.Int, QVariant.LongLong,
                               QVariant.UInt, QVariant.ULongLong]
                elif datatype == FieldType.DATA_TYPE_NUMERIC:
                    fieldTypes = [QVariant.Int, QVariant.Double, QVariant.LongLong,
                                  QVariant.UInt, QVariant.ULongLong]

                def Spatialite2qgis(type):
                    typeTrans = {"INT": QVariant.Int, "INTEGER": QVariant.Int, "TINYINT": QVariant.Int,
                                 "SMALLINT": QVariant.Int, "MEDIUMINT": QVariant.LongLong, "BIGINT": QVariant.LongLong,
                                 "UNSIGNED BIG INT": QVariant.LongLong, "INT2": QVariant.Int, "INT8": QVariant.LongLong,
                                 "INTEGER": QVariant.LongLong, "CHARACTER": QVariant.String, "VARCHAR": QVariant.String,
                                 "VARYING CHARACTER": QVariant.String, "NCHAR": QVariant.String,
                                 "NATIVE CHARACTER": QVariant.String,
                                 "NVARCHAR": QVariant.String, "TEXT": QVariant.String, "REAL": QVariant.Double,
                                 "DOUBLE": QVariant.Double, "DOUBLE PRECISION": QVariant.Double, "FLOAT": QVariant.Double,
                                 "REAL": QVariant.Double, "NUMERIC": QVariant.Double, "DECIMAL": QVariant.Double,
                                 "BOOLEAN": QVariant.Int, "DATE": QVariant.String, "DATETIME": QVariant.String}
                    ind = type.find("(")
                    if ind > 0:
                        type = type[0:ind]
                    if type in typeTrans.keys():
                        return typeTrans[type]
                    else:
                        return None
                def Postg2qgis(type):
                    Postg2qgis = {"bigint": QVariant.LongLong, "varbinary": QVariant.ByteArray,
                                  "char": QVariant.String, "varchar": QVariant.String, "integer": QVariant.Int,
                                  "numeric": QVariant.Double, "decimal": QVariant.Double, "real": QVariant.Double,
                                  "double": QVariant.Double, "date": QVariant.String, "time": QVariant.Time,
                                  "timestamp": QVariant.String, "int": QVariant.Int, "int2": QVariant.Int,
                                  "int4": QVariant.Int, "int8": QVariant.LongLong, "text": QVariant.String,
                                  "float4": QVariant.Double, "float8": QVariant.Double, "float64": QVariant.Double}

                    ind = type.find("(")
                    if ind > 0:
                        type = type[0:ind]
                    if type in Postg2qgis.keys():
                        return Postg2qgis[type]
                    else:
                        return None

                fieldNames = []
                idfieldNames = []
                idfieldTypes = []
                # ============for ParameterVector_RDBMS
                if isinstance(layer, dict):
                    if "uri" in layer.keys():
                        uri = layer["uri"]
                        if uri.startswith(u"spatialite:"):
                            uri = uri[len(u"spatialite:"):]
                            uri = QgsDataSourceUri(uri)
                            try:
                                db = spatialite.GeoDB(uri)
                            except postgis.DbError as e:
                                raise GeoAlgorithmExecutionException(
                                    "Couldn't connect to database:\n%s" % e.message)
                                # return False
                            sql_fields = 'pragma table_info(%s)' % (uri.table())
                            c = db.con.cursor()
                            c.execute(sql_fields)
                            fields = c.fetchall()
                            for field in fields:
                                type = field[2]
                                if not fieldTypes or (Spatialite2qgis(type) is not None and Spatialite2qgis(type) in fieldTypes):
                                    fieldNames.append(field[1])
                        elif uri.startswith(u"postgis:"):
                            uri = uri[len(u"postgis:"):]
                            uri = QgsDataSourceUri(uri)
                            try:
                                db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                                                   dbname=uri.database(), user=uri.username(), passwd=uri.password())
                            except postgis.DbError as e:
                                raise GeoAlgorithmExecutionException(
                                    "Couldn't connect to database:\n%s" % e.message)
                                # return False
                            fields = db.get_table_fields(uri.table(), uri.schema())
                            for field in fields:
                                type = field.data_type
                                if not fieldTypes or (Postg2qgis(type) is not None and Postg2qgis(type) in fieldTypes):
                                    fieldNames.append(field.name)
                        else:
                            layer = dataobjects.getObjectFromUri(uri)
                            for field in layer.fields():
                                if not fieldTypes or field.type() in fieldTypes:
                                    fieldNames.append(str(field.name()))
                else:
                    for field in layer.fields():
                        if not fieldTypes or field.type() in fieldTypes:
                            fieldNames.append(str(field.name()))
                nrow = len(fieldNames)
                widget.addItems(fieldNames)
#=======================================================================================================================
class DataSelectionPanel(QDialog):
    def __init__(self,titles,data):
        self.titles = titles #list [id,..]
        self.data_ = data # data(2D list)[[1,...],[2,...]]
        QDialog.__init__(self)
        self.setupPanel()
        self.updataTableWidget()
        self.selection = [] # store the row index of selections
    def setupPanel(self):
        self.resize(591, 409)
        self.horizontalLayout = QHBoxLayout(self)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.tableWidget = QTableWidget(self)
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setColumnCount(len(self.titles))
        self.tableWidget.setColumnWidth(0,50)
        self.tableWidget.setRowCount(0)
        self.horizontalLayout.addWidget(self.tableWidget)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.btn_addselection = QPushButton(self)
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.btn_addselection.sizePolicy().hasHeightForWidth())
        self.btn_addselection.setSizePolicy(sizePolicy)
        self.btn_addselection.setObjectName(_fromUtf8("btn_addselection"))
        self.verticalLayout.addWidget(self.btn_addselection)
        self.btn_cancel = QPushButton(self)
        self.btn_cancel.setObjectName(_fromUtf8("btn_cancel"))
        self.verticalLayout.addWidget(self.btn_cancel)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout.addLayout(self.verticalLayout)

        self.btn_addselection.setText("Add Selection")
        self.btn_cancel.setText("Cancel")

        self.btn_addselection.clicked.connect(self.accept)
        self.btn_cancel.clicked.connect(self.reject)
    def updataTableWidget(self):
        rows = len(self.data_)
        cols = len(self.titles)
        # update the tableWidget (https://wiki.qt.io/How_to_Use_QTableWidget)
        self.tableWidget.setRowCount(rows)

        self.tableWidget.setColumnCount(cols)
        self.tableWidget.setHorizontalHeaderLabels(self.titles)  # set header
        self.tableWidget.verticalHeader().setVisible(False)  # no row name
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # disable edit
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setSelectionMode(QAbstractItemView.MultiSelection)
        # insert data
        for i, dt in enumerate(self.data_):
            for j, d in enumerate(dt):
                self.tableWidget.setItem(i, j, QTableWidgetItem(str(d)))
    def accept(self):
        indj = self.titles.index("id")
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            sels = select.selectedRows()
            self.selection = [sel.row() for sel in sels]
        # self.done(QDialog.Accepted)
        super(DataSelectionPanel,self).accept()

class SQLTableSelectorPanel(QDialog):
    POINT = 1
    POLYGON = 2
    LINESTRING = 3
    BASE = 4
    ROADNETWORK = 5
    UNKNOWN = 6
    ALL = -1

    POINT_TYPE = ['POINT', 'MULTIPOINT']
    POLYGON_TYPE = ['POLYGON', 'MULTIPOLYGON']
    LINESTRING_TYPE = ['LINESTRING', 'MULTILINESTRING']
    BASE_TYPE = ["BASE"]
    ROADNETWORK_TYPE = ['ROADNETWORK']
    UNKNOWN_TYPE = ["UNKNOWN"]
    ALL = ["ALL"]

    def __init__(self,titles,types):
        QDialog.__init__(self)
        # here types must be a list, like [POINT,POLYGON]
        assert type(types) is list,"SQLTableSelectorPanel.__init__():input types must be list []"
        self.types = types
        if types==[-1]:
            self.types = ["POINT", "POLYGON", "LINESTRING", "BASE", "ROADNETWORK", "UNKNOWN"]
        self.connection = None
        self.table = None
        self.schema = None
        self.geofield = None
        self.setupPanel()
        self.setUpSignal()
        self.parent = self
        self.standalone = False
        self.titles = titles
        self.value = None #QgsDataSourceUri()
        if hasattr(iface, 'standalone'):
            self.standalone = True
        if self.standalone:
            # it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            # it is run in QGIS
            settings = QSettings()
        settings.beginGroup("/PostgreSQL/connections/")
        stored_connections = settings.childGroups()
        settings.endGroup()

        self.treeWidget.itemExpanded.connect(self.itemExpanded)

        baseKey = "/PostgreSQL/connections/"
        conname = settings.value(baseKey + "selected")
        if (conname is not None) and conname in stored_connections:
            item = self.ConnectionItem(conname,'db')
            self.treeWidget.addTopLevelItem(item)
            self.treeWidget.setItemExpanded(item,True)

    def setupPanel(self):
        self.resize(483, 445)
        self.verticalLayout = QVBoxLayout(self)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.treeWidget = QTreeWidget(self)
        self.treeWidget.setObjectName(_fromUtf8("treeWidget"))
        self.treeWidget.header().setVisible(False)
        self.verticalLayout.addWidget(self.treeWidget)
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.horizontalLayout.addItem(spacerItem)
        self.btn_select = QPushButton(self)
        self.btn_select.setObjectName(_fromUtf8("btn_select"))
        self.horizontalLayout.addWidget(self.btn_select)
        self.btn_cancel = QPushButton(self)
        self.btn_cancel.setObjectName(_fromUtf8("btn_cancel"))
        self.horizontalLayout.addWidget(self.btn_cancel)
        self.verticalLayout.addLayout(self.horizontalLayout)

        self.btn_select.setText("Select")
        self.btn_cancel.setText("Cancel")

    def populate(self, item):
        if item.childCount() != 0:
            return
        if self.standalone:
            # it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            # it is run in QGIS
            settings = QSettings()
        baseKey = "/PostgreSQL/connections/" + item.connection
        service = settings.value(baseKey + "/service")
        host = settings.value(baseKey + "/host")
        port = settings.value(baseKey + "/port")
        database = settings.value(baseKey + "/database")
        username = settings.value(baseKey + "/username")
        password = settings.value(baseKey + "/password")
        authcfg = settings.value(baseKey + "/authcfg")
        publicOnly = settings.value(baseKey + "/publicOnly")
        geometryColumnsOnly = settings.value(baseKey + "/geometryColumnsOnly")
        dontResolveType = settings.value(baseKey + "/dontResolveType")
        allowGeometrylessTables = settings.value(baseKey + "/allowGeometrylessTables")
        sslmode = settings.value(baseKey + "/sslmode")
        saveUsername = settings.value(baseKey + "/saveUsername")
        savePassword = settings.value(baseKey + "/savePassword")
        estimatedMetadata = settings.value(baseKey + "/estimatedMetadata")
        uri = QgsDataSourceUri()
        authcfg = ""
        if (service):
            uri.setConnection(service, database,
                              username, password,
                              sslmode,
                              authcfg)
        else:
            uri.setConnection(host, port, database,
                              username, password,
                              sslmode, authcfg)
        try:
            db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                               dbname=uri.database(), user=uri.username(), passwd=uri.password())
        except postgis.DbError as e:
            QMessageBox.information(self, "Test connection",
                                    "Connection failed - consult message log for details.\n\nCouldn't connect to database:\n%s" % e.message)
            # raise GeoAlgorithmExecutionException(
            #     "Couldn't connect to database:\n%s" % e.message)
            return False
        if item.level == 'db':
            schemas = db.list_schemas()
            for schema in schemas:
                childitem = self.SchemaItem(item.connection, schema[1], 'schema')
                item.addChild(childitem)
        elif item.level == 'schema':
            # select all tables' name
            sql = "Select * from information_schema.tables where table_schema='%s' and table_type like 'BASE%%';"%(item.schema)
            c = db.con.cursor()
            c.execute(sql)
            tables = c.fetchall()
            alltable = []
            for t in tables:
                # table_catalog,table_schema,table_name,table_type
                alltable.append(t[2])
            alltables_types = {self.POINT:[],self.POLYGON:[],self.LINESTRING:[],self.BASE:[],
                               self.UNKNOWN:[],self.ROADNETWORK:[]}
            geoNames = []
            geoDic = []
            for tbl in ['geography_columns', 'geometry_columns']:
                table_sql = "Select * from %s where f_table_schema='%s';" % (tbl, item.schema)
                c = db.con.cursor()
                c.execute(table_sql)
                tables = c.fetchall()
                for table in tables:
                    name, geofield, type, srid = table[2], table[3], table[6], table[5]
                    geoNames.append(name)
                    geoDic.append([name, geofield, type, srid])
            # pop alltables_types: POINT, POLYGON, LINESTRING
            i = 0
            while i<len(geoNames):
                tbl = geoNames[i]
                if geoDic[i][2] in self.LINESTRING_TYPE:
                    #check if the road network
                    if tbl+"_vertices_pgr" in geoNames:
                        if tbl not in [e[0] for e in alltables_types[self.ROADNETWORK]]:
                            alltables_types[self.ROADNETWORK].append([geoDic[i][0],geoDic[i][1],"ROADNETWORK",geoDic[i][3]])
                    else:
                        # not road network
                        alltables_types[self.LINESTRING].append(geoDic[i])
                elif geoDic[i][2] in self.POINT_TYPE:
                    # check if the road network
                    if ("_vertices_pgr" in tbl) and (tbl.rsplit("_vertices_pgr")[0] in geoNames):
                        if tbl.rsplit("_vertices_pgr")[0] not in [e[0] for e in alltables_types[self.ROADNETWORK]]:
                            alltables_types[self.ROADNETWORK].append([tbl.rsplit("_vertices_pgr")[0],geoDic[i][1],"ROADNETWORK",geoDic[i][3]])
                    else:
                        # not road network
                        alltables_types[self.POINT].append(geoDic[i])
                elif geoDic[i][2] in self.POLYGON_TYPE:
                    alltables_types[self.POLYGON].append(geoDic[i])
                else:
                    geoDic[i][2] = "UNKNOWN"
                    alltables_types[self.UNKNOWN].append(geoDic[i])
                i = i + 1
            for table in alltable:
                if table not in geoNames:
                    # [name, geofield, type, srid]
                    alltables_types[self.BASE].append([table,None,"BASE",None])
                    # connection, schema, table, geofield, type, srid, level='table'
            for tp in self.types:
                for tbl in alltables_types[tp]:
                    # tbl = [name, geofield, type, srid]
                    childitem = self.TableItem(item.connection, item.schema, tbl[0], tbl[1], tbl[2],
                                          tbl[3], 'table')
                    item.addChild(childitem)

        db.con.close()
    def itemExpanded(self, item):
        try:
            self.populate(item)
        except Exception as e:
            print(e.message)
            pass
    def btn_select_clicked(self):
        # get data to value
        self.value = []
        if self.standalone:
            # it is standalone application
            settings = QSettings("HKEY_CURRENT_USER\\Software\\QGIS\\SustainAssess",
                                 QSettings.NativeFormat)
        else:
            # it is run in QGIS
            settings = QSettings()

        baseKey = "/PostgreSQL/connections/" + self.connection
        service = settings.value(baseKey + "/service")
        host = settings.value(baseKey + "/host")
        port = settings.value(baseKey + "/port")
        database = settings.value(baseKey + "/database")
        username = settings.value(baseKey + "/username")
        password = settings.value(baseKey + "/password")
        authcfg = settings.value(baseKey + "/authcfg")
        publicOnly = settings.value(baseKey + "/publicOnly")
        geometryColumnsOnly = settings.value(baseKey + "/geometryColumnsOnly")
        dontResolveType = settings.value(baseKey + "/dontResolveType")
        allowGeometrylessTables = settings.value(baseKey + "/allowGeometrylessTables")
        sslmode = settings.value(baseKey + "/sslmode")
        saveUsername = settings.value(baseKey + "/saveUsername")
        savePassword = settings.value(baseKey + "/savePassword")
        estimatedMetadata = settings.value(baseKey + "/estimatedMetadata")
        uri = QgsDataSourceUri()
        authcfg = ""
        if (service):
            uri.setConnection(service, database,
                              username, password,
                              sslmode,
                              authcfg)
        else:
            uri.setConnection(host, port, database,
                              username, password,
                              sslmode, authcfg)
        try:
            db = postgis.GeoDB(host=uri.host(), port=int(uri.port()),
                               dbname=uri.database(), user=uri.username(), passwd=uri.password())
        except postgis.DbError as e:
            QMessageBox.information(self, "Test connection",
                                    "Connection failed - consult message log for details.\n\nCouldn't connect to database:\n%s" % e.message)
            # raise GeoAlgorithmExecutionException(
            #     "Couldn't connect to database:\n%s" % e.message)
            return False

        #uri_text = "postgis:" + uri.uri()
        uri.setDataSource(self.schema, self.table, self.geofield)
        uri.setSrid(str(self.srid))
        self.value = uri
        self.accept()

    def btn_cancel_clicked(self):
        self.reject()
    def getValue(self):
        return self.value #QgsDataSourceUri()
    def setUpSignal(self):
        self.btn_select.clicked.connect(self.btn_select_clicked)
        self.btn_cancel.clicked.connect(self.btn_cancel_clicked)
        self.treeWidget.itemExpanded.connect(self.itemExpanded)
        self.treeWidget.clicked.connect(self.on_click_tree)
        self.treeWidget.itemDoubleClicked.connect(self.on_double_click_tree)
    def on_click_tree(self):
        item = self.treeWidget.currentItem()
        if isinstance(item,self.TableItem):
            self.connection = item.connection
            self.schema = item.schema
            self.table = item.table
            self.geofield = item.geofield
            self.type = item.type
            self.srid = item.srid
    def on_double_click_tree(self):
        item = self.treeWidget.currentItem()
        if isinstance(item,self.TableItem):
            self.connection = item.connection
            self.schema = item.schema
            self.table = item.table
            self.geofield = item.geofield
            self.type = item.type
            self.srid = item.srid
            self.btn_select.click()
    class TableItem(QTreeWidgetItem):
        def __init__(self, connection, schema, table, geofield, type, srid, level='table'):
            # level='db','schema','table', However, in Spatialite, schema is different with PostGIS.
            if type in ['POINT', 'MULTIPOINT']:
                self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_point.png'))
            elif type in ['POLYGON', 'MULTIPOLYGON']:
                self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_polygon.png'))
            elif type in ['LINESTRING', 'MULTILINESTRING']:
                self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_line.png'))
            elif type in ["ROADNETWORK"]:
                self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_line.png'))
            elif type in ["BASE"]:
                self.tableIcon = QIcon(os.path.join(pluginPath,'images','table.png'))
            elif type in ["UNKNOWN"]:
                self.tableIcon = QIcon(os.path.join(pluginPath, 'images', 'layer_unknown.png'))
            else:
                assert False,"TableItem:Please check the program here."
            self.level = level
            self.schema = schema
            self.table = table
            self.geofield = geofield
            self.type = type
            self.srid = srid
            QTreeWidgetItem.__init__(self)
            self.connection = connection
            self.setText(0, table)
            self.setIcon(0, self.tableIcon)
            self.standalone = False
            if hasattr(iface, 'standalone'):
                self.standalone = True
    class SchemaItem(QTreeWidgetItem):
        def __init__(self, connection, schema='public', level='schema'):
            # level='db','schema','table', However, in Spatialite, schema is different with PostGIS.
            self.Icon = QIcon(os.path.join(pluginPath, 'images', 'namespace.png'))
            self.level = level
            self.schema = schema
            QTreeWidgetItem.__init__(self)
            self.setChildIndicatorPolicy(QTreeWidgetItem.ShowIndicator)
            self.connection = connection
            self.setText(0, schema)
            self.setIcon(0, self.Icon)
            self.standalone = False
            if hasattr(iface, 'standalone'):
                self.standalone = True
    class ConnectionItem(QTreeWidgetItem):
        def __init__(self, connection, level):
            # level='db','schema','table', However, in Spatialite, schema is different with PostGIS.
            self.connIcon = QIcon(os.path.join(pluginPath, 'images', 'postgis.png'))
            self.level = level
            QTreeWidgetItem.__init__(self)
            self.setChildIndicatorPolicy(QTreeWidgetItem.ShowIndicator)
            self.connection = connection
            self.setText(0, connection)
            self.setIcon(0, self.connIcon)
            self.standalone = False
            if hasattr(iface, 'standalone'):
                self.standalone = True

class NewEntryPanel(QDialog):
    def __init__(self,id,dimension,titles,alg):
        self.alg = alg
        self.id = id
        self.dimension = dimension
        QDialog.__init__(self)
        self.fieldsnames = titles
        #["id", "dimensions", "categories", "sub_category", "indicators", "notes", "spatialscale",
        #                "temporalscale"]
        self.widgets = {}
        self.labels = {}
        self.value = [] # without titles
        self.setupPanel()

    def setupPanel(self):
        self.setWindowTitle("New Indicator")
        self.resize(357, 272)
        self.verticalLayout = QVBoxLayout(self)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))

        # id, dimensions, "categories","sub_category","indicators","notes","spatialscale","temporalscale"
        for name in self.fieldsnames:
            hlayout = QHBoxLayout()
            label = QLabel(self)
            label.setText(name)
            hlayout.addWidget(label)
            item = QLineEdit(self)
            hlayout.addWidget(item)
            self.verticalLayout.addLayout(hlayout)
            self.widgets[name] = item
            self.labels[name] = label
        # id
        name = self.fieldsnames[0]
        self.widgets[name].setText(str(self.id))
        self.widgets[name].setDisabled(True)

        # dimensions
        name = self.fieldsnames[1]
        self.widgets[name].setText(str(self.dimension))
        self.widgets[name].setDisabled(True)

        # spatialscale
        name = self.alg.SPATIALSCALE
        val = self.alg.SPATIALSCALE_OPTIONS[self.alg.getParameterValue(name)]
        if val=="User Defined/Others":
            name = self.alg.USERDEFINED_SPATIALSCALE
            val = self.alg.getParameterValue(name)
        spatialscale = val
        self.widgets["spatialscale"].setText(str(spatialscale))
        self.widgets["spatialscale"].setDisabled(True)

        # temporalscale
        temporalscale = "Not Considered"

        name = self.alg.TEMPORALSCALE
        val = self.alg.TEMPORALSCALE_OPTIONS[self.alg.getParameterValue(name)]
        if val == "User Defined":
            name = self.alg.USERDEFINED_TEMPORALSCALE
            val = self.alg.getParameterValue(name)
            temporalscale = val
        self.widgets["temporalscale"].setText(str(temporalscale))
        self.widgets["temporalscale"].setDisabled(True)

        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        # button
        hlayout = QHBoxLayout()
        spacerItem = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
        hlayout.addItem(spacerItem)
        self.btn_OK = QPushButton(self)
        self.btn_OK.setText("OK")
        hlayout.addWidget(self.btn_OK)
        self.btn_Cancel = QPushButton(self)
        self.btn_Cancel.setText("Cancel")
        hlayout.addWidget(self.btn_Cancel)
        self.verticalLayout.addLayout(hlayout)
        self.btn_OK.clicked.connect(self.btn_OK_clicked)
        self.btn_Cancel.clicked.connect(self.btn_Cancel_clicked)

        for label in self.labels.values():
            label.setMaximumWidth(65)
            label.setMinimumWidth(65)
    def btn_OK_clicked(self):
        for name in self.fieldsnames:
            self.value.append(self.widgets[name].text())
        # self.value = [self.fieldsnames,self.value]
        self.accept()
    def btn_Cancel_clicked(self):
        self.reject()

class EditingExistingIndicatorPanel(QDialog):
    def __init__(self,filename):
        self.csvpath = filename
        QDialog.__init__(self)
        self.setupPanel()
        self.titles,self.data = self.readDatafromCSV(filename)
        self.selected = []
        self.updataTableWidget()

    def setupPanel(self):
        self.resize(591, 409)
        self.horizontalLayout = QHBoxLayout(self)
        self.horizontalLayout.setObjectName(_fromUtf8("horizontalLayout"))
        self.tableWidget = QTableWidget(self)
        self.tableWidget.setObjectName(_fromUtf8("tableWidget"))
        self.tableWidget.setColumnCount(0)
        self.tableWidget.setRowCount(0)
        self.horizontalLayout.addWidget(self.tableWidget)
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.btn_import = QPushButton(self)
        sizePolicy = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.btn_import.sizePolicy().hasHeightForWidth())
        self.btn_import.setSizePolicy(sizePolicy)
        self.btn_import.setObjectName(_fromUtf8("btn_import"))
        self.verticalLayout.addWidget(self.btn_import)
        self.btn_delete = QPushButton(self)
        self.verticalLayout.addWidget(self.btn_delete)
        self.btn_OK = QPushButton(self)
        self.verticalLayout.addWidget(self.btn_OK)
        self.btn_cancel = QPushButton(self)
        self.btn_cancel.setObjectName(_fromUtf8("btn_cancel"))
        self.verticalLayout.addWidget(self.btn_cancel)
        spacerItem = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.verticalLayout.addItem(spacerItem)
        self.horizontalLayout.addLayout(self.verticalLayout)

        self.btn_import.setText("Import...")
        self.btn_delete.setText("Delete Selected")
        self.btn_OK.setText("OK")
        self.btn_cancel.setText("Cancel")
        #[TODO] add manually
        self.btn_import.clicked.connect(self.btn_import_clicked)
        self.btn_delete.clicked.connect(self.btn_delete_clicked)
        self.btn_OK.clicked.connect(self.accept)
        self.btn_cancel.clicked.connect(self.reject)
    def readDatafromCSV(self,filename):
        titles_ = []
        data_= []
        f = open(filename,"r")
        csvreader = csv.reader(f, delimiter=',', quotechar="\"")
        for row in csvreader:
            data_.append(row)
        f.close()
        titles_ = data_.pop(0)
        return titles_,data_
    def updataTableWidget(self):
        if len(self.data) == 0: return
        rows = len(self.data)-len(self.selected)
        cols = len(self.titles)
        ind = self.titles.index("id")
        # update the tableWidget (https://wiki.qt.io/How_to_Use_QTableWidget)
        #clear all the previous data first
        self.tableWidget.setRowCount(0)
        # update
        self.tableWidget.setRowCount(rows)
        self.tableWidget.setColumnCount(cols)
        self.tableWidget.setHorizontalHeaderLabels(self.titles)  # set header
        self.tableWidget.verticalHeader().setVisible(False)  # no row name
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)  # disable edit
        self.tableWidget.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tableWidget.setSelectionMode(QAbstractItemView.MultiSelection)
        # insert data
        i = 0
        for dt in self.data:
            if dt[ind] not in self.selected:
                for j, d in enumerate(dt):
                    self.tableWidget.setItem(i, j, QTableWidgetItem(str(d)))
                i+=1
    def btn_import_clicked(self):
        pass
    def btn_delete_clicked(self):
        indj = self.titles.index("id")
        select = self.tableWidget.selectionModel()
        if select.hasSelection():
            select_rows = select.selectedRows()
            select_rows = [sel.row() for sel in select_rows]
            for row in select_rows:
                self.selected.append(self.tableWidget.item(row,indj).text())
        self.updataTableWidget()
    def accept(self):
        #save editing to defaut csv
        indj = self.titles.index("id")
        f = open(self.csvpath+"sss","w")
        csvwriter = csv.writer(f, delimiter=',',
                               quotechar='"', quoting=csv.QUOTE_MINIMAL, lineterminator='\n')
        csvwriter.writerow(self.titles)
        for dt in self.data:
            if dt[indj] not in self.selected:
                csvwriter.writerow(dt)
        f.close()
        super(EditingExistingIndicatorPanel, self).accept()

