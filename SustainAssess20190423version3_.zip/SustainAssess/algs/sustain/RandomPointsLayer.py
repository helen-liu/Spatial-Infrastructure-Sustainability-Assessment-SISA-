# -*- coding: utf-8 -*-
__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

import os
import random

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant
from qgis.core import (Qgis, QgsGeometry, QgsFields, QgsField, QgsSpatialIndex,
                       QgsPointXY, QgsFeature, QgsFeatureRequest,QgsWkbTypes)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.parameters import ParameterVector
from SustainAssess.core.parameters import ParameterNumber
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.outputs import OutputVector
from SustainAssess.tools import dataobjects, vector

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class RandomPointsLayer(GeoAlgorithm):

    VECTOR = 'VECTOR'
    POINT_NUMBER = 'POINT_NUMBER'
    MIN_DISTANCE = 'MIN_DISTANCE'
    OUTPUT = 'OUTPUT'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'ftools', 'random_points.png'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Geoprocess/Create Random Points"
        self.name, self.i18n_name = self.trAlgorithm('Create Random Points')
        self.group, self.i18n_group = self.trAlgorithm('Vector creation tools')
        self.addParameter(ParameterVector_RDBMS(self.VECTOR,
                                          self.tr('Input Boundary Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterNumber(self.POINT_NUMBER,
                                          self.tr('Points Number'), 1, None, 1))
        self.addParameter(ParameterNumber(self.MIN_DISTANCE,
                                          self.tr('Minimum Distance'), 0.0, None, 0.0))

        self.addOutput(OutputVector(self.OUTPUT, self.tr('Random Points Output')))

    def processAlgorithm(self, progress):
        paramInput = self.getParameterFromName(self.VECTOR)
        self.m_VECTOR = None
        if paramInput.value is not None:
            self.m_VECTOR = paramInput.getLayerObject()

        pointCount = int(self.getParameterValue(self.POINT_NUMBER))
        minDistance = float(self.getParameterValue(self.MIN_DISTANCE))

        bbox = self.m_VECTOR.extent()
        idxLayer = vector.spatialindex(self.m_VECTOR)

        fields = QgsFields()
        fields.append(QgsField('id', QVariant.Int, 'integer', 10, 0))
        writer = self.getOutputFromName(self.OUTPUT).getVectorWriter(
            fields, QgsWkbTypes.Point, self.m_VECTOR.crs(),{"pk":"id"})

        nPoints = 0
        nIterations = 0
        maxIterations = pointCount * 200
        total = 100.0 / pointCount if pointCount > 0 else 1

        index = QgsSpatialIndex()
        points = dict()

        # request = QgsFeatureRequest()

        random.seed()

        while nIterations < maxIterations and nPoints < pointCount:
            rx = bbox.xMinimum() + bbox.width() * random.random()
            ry = bbox.yMinimum() + bbox.height() * random.random()

            pnt = QgsPointXY(rx, ry)
            geom = QgsGeometry.fromPointXY(pnt)
            ids = idxLayer.intersects(geom.buffer(5, 5).boundingBox())
            if len(ids) > 0 and \
                    vector.checkMinDistance(pnt, index, minDistance, points):
                request = QgsFeatureRequest().setFilterFids(ids).setSubsetOfAttributes([])
                # for i in ids:
                for f in self.m_VECTOR.getFeatures(request):
                    # f = next(self.m_VECTOR.getFeatures(request.setFilterFid(i)))
                    tmpGeom = QgsGeometry(f.geometry())
                    if geom.within(tmpGeom):
                        f = QgsFeature(nPoints)
                        f.initAttributes(1)
                        f.setFields(fields)
                        f.setAttribute('id', nPoints)
                        f.setGeometry(geom)
                        writer.addFeature(f)
                        index.insertFeature(f)
                        points[nPoints] = pnt
                        nPoints += 1
                        progress.setPercentage(int(nPoints * total))
            nIterations += 1

        if nPoints < pointCount:
            ProcessingLog.addToLog(ProcessingLog.LOG_INFO,
                                   self.tr('Can not generate requested number of random points. '
                                           'Maximum number of attempts exceeded.'))

        del writer
