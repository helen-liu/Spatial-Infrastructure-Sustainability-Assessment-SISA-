# -*- coding: utf-8 -*-

__author__ = 'Qmm'
__date__ = 'July 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import time

from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtCore import QVariant
from qgis.core import (QgsGeometry, NULL, QgsField, QgsSpatialIndex,
                       QgsPointXY, QgsFeature,QgsWkbTypes)

from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.ProcessingLog import ProcessingLog
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.parameters import ParameterTableField,ParameterCreateField
from SustainAssess.core.parameters import ParameterVector_RDBMS,ParameterNumber
from SustainAssess.core.outputs import OutputVector,OutputVector_liu
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException
from networkx import DiGraph,dijkstra_path_length,single_source_dijkstra
from igraph import Graph
from networkx.exception import NetworkXNoPath
from SustainAssess.tools.utility import createFields,idTypes_map,getFeildsTypes
pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]


class FacilitieswithinDistance(GeoAlgorithm):

    SOURCE_LAYER = 'SOURCE_LAYER'
    SOURCE_LAYER_ID = 'SOURCE_LAYER_ID'
    TARGET_LAYER = 'TARGET_LAYER'
    TARGET_LAYER_ID = 'TARGET_LAYER_ID'
    TARGET_LAYER_INPUTFIELD = "TARGET_LAYER_INPUTFIELD"
    POWERGRAVITY = 'POWERGRAVITY'
    SEARCH_RADIUS = 'SEARCH_RADIUS'
    RD_EDGE_LAYER = 'RD_EDGE_LAYER'
    RD_EDGE_LAYER_SOURCE_FIELD = 'RD_EDGE_LAYER_SOURCE_FIELD'
    RD_EDGE_LAYER_TARGET_FIELD = 'RD_EDGE_LAYER_TARGET_FIELD'
    RD_EDGE_LAYER_COST_FIELD = 'RD_EDGE_LAYER_COST_FIELD'
    RD_EDGE_LAYER_REVERSE_COST_FIELD = 'RD_EDGE_LAYER_REVERSE_COST_FIELD'
    HIGHWAY = 'HIGHWAY'

    OUTPUT_FIELD = 'OUTPUT_FIELD'
    OUTPUT_LAYER_SUM = 'OUTPUT_LAYER_SUM'
    OUTPUT_LAYER = 'OUTPUT_LAYER' # output each roads

    NetworkPackage = 'IGRAPH' # or 'NETWORKX'

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Network Analysis/Accessiblity/Facilities within Distance"
        self.name, self.i18n_name = self.trAlgorithm('Facilities within Distance')
        self.group, self.i18n_group = self.trAlgorithm('Network Analysis tools')

        self.addParameter(ParameterVector_RDBMS(self.SOURCE_LAYER,
                                                self.tr('Source Layer (POINT)'), [ParameterVector_RDBMS.VECTOR_TYPE_POINT]))
        self.addParameter(ParameterTableField(self.SOURCE_LAYER_ID,
                                              self.tr('Source Layer ID'), self.SOURCE_LAYER))
        self.addParameter(ParameterVector_RDBMS(self.TARGET_LAYER,
                                                self.tr('Target Layer'),[ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.TARGET_LAYER_ID,
                                              self.tr('Target Layer ID'), self.TARGET_LAYER))
        self.addParameter(ParameterTableField(self.TARGET_LAYER_INPUTFIELD,
                                              self.tr('Target Layer Attractiveness Field'), self.TARGET_LAYER))
        self.addParameter(ParameterNumber(self.SEARCH_RADIUS,
                                          self.tr('Search Radius'), default=500.0))
        self.addParameter(ParameterNumber(self.POWERGRAVITY,
                                          self.tr('Power of Gravity'), default=2.0))

        self.addParameter(ParameterVector_RDBMS(self.RD_EDGE_LAYER,
                                                self.tr('Roads\' Layer'), [ParameterVector_RDBMS.VECTOR_ROAD_NETWORK]))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_SOURCE_FIELD,
                                              self.tr('Roads\' Source Field'), self.RD_EDGE_LAYER, defalut="source"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_TARGET_FIELD,
                                              self.tr('Roads\' Target Field'), self.RD_EDGE_LAYER, defalut="target"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_COST_FIELD,
                                              self.tr('Roads\' Cost Field'), self.RD_EDGE_LAYER, defalut="cost"))
        self.addParameter(ParameterTableField(self.RD_EDGE_LAYER_REVERSE_COST_FIELD,
                                              self.tr('Roads\' Reverse Cost Field'), self.RD_EDGE_LAYER, defalut="reverse_cost"))
        self.addParameter(ParameterTableField(self.HIGHWAY,
                                              self.tr('Highway Indicator(1 or 0)'), self.RD_EDGE_LAYER, optional=True))

        self.addParameter(ParameterCreateField(self.OUTPUT_FIELD, self.tr('Field Name of Accessibility'),self.SOURCE_LAYER))
        self.addOutput(OutputVector_liu(self.OUTPUT_LAYER_SUM, self.tr('Output Accessibility Layer')))
        self.addOutput(OutputVector(self.OUTPUT_LAYER, self.tr('Output Available Choice Set')))


    def Geom2Points(self,fGeom, ftype):
        # if fGeom.isMultipart():
        #     raise GeoAlgorithmExecutionException("Features can not be Multiple part! Please convert it to single part.")
        if QgsWkbTypes.geometryType(ftype) == QgsWkbTypes.PointGeometry:
            point = fGeom.asPoint()  # multi_geom is a point
            return point
        elif QgsWkbTypes.geometryType(ftype) == QgsWkbTypes.PolygonGeometry:
            line = fGeom.asPolygon()
            if len(line) == 0:
                return []
            else:
                return line[0][0:-1]
        elif QgsWkbTypes.geometryType(ftype) == QgsWkbTypes.LineGeometry:
            line = fGeom.asPolyline()
            return line
        else:
            raise GeoAlgorithmExecutionException("Error in Geom2Points function: geometry type is %s."% str(ftype))
    def isHighWay(self,a):
        try:
            a_int = int(a)
        except:
            raise GeoAlgorithmExecutionException("Error: Highway field must be int type(1: is highway, 0: is not highway).")
        if a is None: return None
        if a!=1 and a!=0:
            raise GeoAlgorithmExecutionException("Error: Highway field must be (1: is highway, 0: is not highway).")
        isHW = True
        if a_int==0:
            ## if speed < 80km/h, then it is not highway
            isHW = False
        return isHW

    def check(self):
        if self.m_SOURCE_LAYER.crs().authid() != self.m_EDGE_LAYER.crs().authid() or \
            self.m_SOURCE_LAYER.crs().authid() != self.m_TARGET_LAYER.crs().authid():
            raise GeoAlgorithmExecutionException("Projection inconsistency among input layers!")

        if QgsWkbTypes.isMultiType(self.m_SOURCE_LAYER.wkbType()) or \
                QgsWkbTypes.isMultiType(self.m_TARGET_LAYER.wkbType()) or \
                   QgsWkbTypes.isMultiType(self.m_EDGE_LAYER.wkbType()):
            raise GeoAlgorithmExecutionException("Please convert the multipart geometry to singles of input layers!")
        if self.m_OUTPUT_FIELD=="num":
            raise GeoAlgorithmExecutionException("The Field Name of Accessibility can not be 'num',Please get another name!")

    def processAlgorithm(self, progress):
        source_param = self.getParameterFromName(self.SOURCE_LAYER)
        self.m_SOURCE_LAYER = source_param.getLayerObject()
        self.m_SOURCE_LAYER_ID = self.getParameterValue(self.SOURCE_LAYER_ID)

        target_param = self.getParameterFromName(self.TARGET_LAYER)
        self.m_TARGET_LAYER = target_param.getLayerObject()
        self.m_TARGET_LAYER_ID = self.getParameterValue(self.TARGET_LAYER_ID)
        self.m_TARGET_LAYER_INPUTFIELD = self.getParameterValue(self.TARGET_LAYER_INPUTFIELD)

        self.m_POWERGRAVITY = self.getParameterValue(self.POWERGRAVITY)
        self.m_SEARCH_RADIUS = self.getParameterValue(self.SEARCH_RADIUS)

        edge_param = self.getParameterFromName(self.RD_EDGE_LAYER)
        self.m_EDGE_LAYER = edge_param.getLayerObject()
        self.m_RD_EDGE_LAYER_SOURCE_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_SOURCE_FIELD)
        self.m_RD_EDGE_LAYER_TARGET_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_TARGET_FIELD)
        self.m_RD_EDGE_LAYER_COST_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_COST_FIELD)
        self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD = self.getParameterValue(self.RD_EDGE_LAYER_REVERSE_COST_FIELD)
        self.m_HIGHWAY =self.getParameterValue(self.HIGHWAY)

        self.m_OUTPUT_FIELD = self.getParameterValue(self.OUTPUT_FIELD)
        self.m_OUTPUT_LAYER_SUM = self.getOutputFromName(self.OUTPUT_LAYER_SUM)
        self.m_OUTPUT_LAYER = self.getOutputFromName(self.OUTPUT_LAYER)

        self.check()
        self.straighLine = False
        # init m_OUTPUT_LAYER file =============================================================================================
        v_OUTPUT_ID = "id"
        v_OUTPUT_SOURCEID = "sid"
        v_OUTPUT_TARGETID = "tid"
        v_OUTPUT_DISTANCE = 'dis'
        v_OUTPUT_ACCESSIBILITY = 'acssblty'

        field_names = [v_OUTPUT_ID,v_OUTPUT_SOURCEID,
                       v_OUTPUT_TARGETID,
                       v_OUTPUT_DISTANCE,v_OUTPUT_ACCESSIBILITY]
        field_names_type = [QVariant.LongLong,getFeildsTypes(self.m_SOURCE_LAYER,[self.m_SOURCE_LAYER_ID])[0],
                            getFeildsTypes(self.m_TARGET_LAYER, [self.m_TARGET_LAYER_ID])[0],
                            QVariant.Double, QVariant.Double]

        # idTypes_map = {'10': "text", '2': "int4", '4': "int8",
        #                '3': "int4", '5': "int8",'6': "numeric(20,8)"}
        # create new Layer------------
        geometryType = QgsWkbTypes.LineGeometry
        fields = []
        for i,field_name in enumerate(field_names):
            type = field_names_type[i]
            len_, prec_ = 0, 0
            if idTypes_map[str(type)] == "real":
                len_ = -1
                prec_ = -1
            elif idTypes_map[str(type)] == "numeric(20,8)":
                len_ = 20
                prec_ = 8
            fields.append(QgsField(field_name, type, idTypes_map[str(type)], len_, prec_))

        writer = self.m_OUTPUT_LAYER.getVectorWriter(fields, geometryType, self.m_SOURCE_LAYER.crs(),{"pk":v_OUTPUT_ID})
        outFeat = QgsFeature()
        progress.setPercentage(int(5))


        # init m_OUTPUT_LAYER_SUM layer===========================================================================================
        v_OUTPUT_SUM = self.m_OUTPUT_FIELD #'acc_sum'
        v_OUTPUT_NUM = "num"
        save2input = self.m_OUTPUT_LAYER_SUM.value == "save2input:"
        if save2input:
            # add field to the Input Source LAYER====================================================
            field_names_sum = [v_OUTPUT_SUM,v_OUTPUT_NUM]
            field_names_type_sum = [QVariant.Double,QVariant.Int]
            field_name_index_sum = {}
            if not self.m_SOURCE_LAYER.isEditable():
                self.m_SOURCE_LAYER.startEditing()
            # Start: create new field =======================================================================================
            self.m_SOURCE_LAYER.beginEditCommand("Added attribute")
            field_name_index_sum = createFields(field_names_sum,field_names_type_sum,self.m_SOURCE_LAYER)
            # End: create new field ========================================================================================
        else:
            # create new Layer
            geometryType = self.m_SOURCE_LAYER.wkbType()
            field_names_sum = ["id", v_OUTPUT_SUM,v_OUTPUT_NUM]
            field_names_type_sum = [getFeildsTypes(self.m_SOURCE_LAYER,[self.m_SOURCE_LAYER_ID])[0],
                                QVariant.Double,QVariant.Int]
            fields = []
            for i, field_name in enumerate(field_names_sum):
                type = field_names_type_sum[i]
                len_, prec_ = 0, 0
                if idTypes_map[str(type)] == "real":
                    len_ = -1
                    prec_ = -1
                elif idTypes_map[str(type)] == "numeric(20,8)":
                    len_ = 20
                    prec_ = 8
                fields.append(QgsField(field_name, type, idTypes_map[str(type)], len_, prec_))
            writer_sum = self.m_OUTPUT_LAYER_SUM.getVectorWriter(fields, geometryType, self.m_SOURCE_LAYER.crs(),
                                                                 {"pk":"id"})
            outFeat_sum = QgsFeature()
        progress.setPercentage(int(10))

        # create index on the Target Layers=============================================================================
        # for each feature in Target
        # --------- convert geom to points
        # --------- add to indexing
        idx_target = QgsSpatialIndex()
        idxId2targetId = {} # {id1:[targetID1,QgsPointXY,value], id2:[targetID2,QgsPointXY,value]}
        feats = self.m_TARGET_LAYER.getFeatures()
        count = int(self.m_TARGET_LAYER.featureCount())
        targetGeometryType = self.m_TARGET_LAYER.wkbType()

        # da = QgsDistanceArea()
        # da.setSourceCrs(self.m_TARGET_LAYER.crs().srsid())

        idx_id = 0
        for ft in feats:
            targetID = ft[self.m_TARGET_LAYER_ID]
            t_value =  ft[self.m_TARGET_LAYER_INPUTFIELD]
            fGeom = QgsGeometry(ft.geometry())
            points = self.Geom2Points(fGeom,targetGeometryType)
            # area = da.measureArea(fGeom)
            for pt in points:
                pnt = QgsPointXY(pt[0],pt[1])
                geom = QgsGeometry.fromPointXY(pnt)
                f = QgsFeature(idx_id)
                f.setGeometry(geom)
                idx_target.insertFeature(f)
                idxId2targetId[idx_id] = [targetID,pnt,t_value]
                idx_id+=1
        # end  the Target spatial indexing==============================================================================

        # create the road network and its vertices indexing=============================================================
        feats = self.m_EDGE_LAYER.getFeatures()
        count = int(self.m_EDGE_LAYER.featureCount())
        start_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM,
                               "Start to Construct the Road Network and its spatial indexing:\n" )
        progress.setInfo("Start to Construct the Road Network and its spatial indexing:...")
        # init points spatial index---------------------------
        idx = QgsSpatialIndex()
        edge_data = {} # {id:[source,target,cost,reverse_cost,ishighway,geometry],...}
        reverse_edge_data = {} #{(source,target):id,...} id is the id in Igraph
        # graph2data={} #{(source,target):id, (target,source):id,...}
        # create spatial index for the edge ends without the highway ends
        idset = []
        highwayPointSet = set()
        for i,ft in enumerate(feats):
            id = ft.id()
            edge_data[id] = [ft[self.m_RD_EDGE_LAYER_SOURCE_FIELD], ft[self.m_RD_EDGE_LAYER_TARGET_FIELD],
                                  ft[self.m_RD_EDGE_LAYER_COST_FIELD], ft[self.m_RD_EDGE_LAYER_REVERSE_COST_FIELD],
                                  self.isHighWay(ft[self.m_HIGHWAY] if self.m_HIGHWAY else None),
                                  QgsGeometry(ft.geometry())]
            idset.append(id)
            # find the points set which on the highway
            if self.m_HIGHWAY:
                e = edge_data[id]
                if e[4]:
                    highwayPointSet.add(e[0])
                    highwayPointSet.add(e[1])

        indexPointSset = set()
        indPointsData = {} #sourceID--> QgsPointXY
        for id in idset:
            e = edge_data[id]
            sourceID, targetID, fGeom = e[0], e[1], e[5]
            vertices = fGeom.asPolyline()
            startP, endP = vertices[0], vertices[-1]

            if sourceID not in indexPointSset:
                indexPointSset.add(sourceID)
                pnt = QgsPointXY(startP.x(), startP.y())
                indPointsData[sourceID] = pnt
                if sourceID not in highwayPointSet:
                    geom = QgsGeometry.fromPointXY(pnt)
                    f = QgsFeature(sourceID)
                    f.setGeometry(geom)
                    idx.insertFeature(f)

            if targetID not in indexPointSset:
                indexPointSset.add(targetID)
                pnt = QgsPointXY(endP.x(), endP.y())
                indPointsData[targetID] = pnt
                if targetID not in highwayPointSet:
                    geom = QgsGeometry.fromPointXY(pnt)
                    f = QgsFeature(targetID)
                    f.setGeometry(geom)
                    idx.insertFeature(f)
        # create road network===========================================================================================

        if self.NetworkPackage=="NETWORKX":
            d_network = DiGraph()
            for id in idset:
                e = edge_data[id]
                source, target, cost, reverse_cost, _, _ = e
                if (cost < 10000 and cost > 0):
                    d_network.add_edge(source, target, weight=cost)
                if (reverse_cost < 10000 and reverse_cost > 0):
                    d_network.add_edge(target, source, weight=reverse_cost)

        elif self.NetworkPackage=="IGRAPH":
            # d_network = Graph()
            edges = []
            for id in idset:
                e = edge_data[id]
                source, target, cost, reverse_cost, _, _ = e
                if (cost < 10000 and cost > 0):
                    edges.append({"source":source,"target":target,"weight":cost})
                    reverse_edge_data[(source, target)] = id
                if (reverse_cost < 10000 and reverse_cost > 0):
                    edges.append({"source": target, "target": source, "weight": reverse_cost})
                    reverse_edge_data[(target, source)] = id
            d_network = Graph.DictList({}, edges, directed=True)
            p_dict = {}  # Source ID(Target ID) --> graph_id(start from 0)
            for i in range(d_network.vcount()):
                v_t = d_network.vs[i]["name"]
                p_dict[v_t] = i
        end_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM, "Road Network Complete and its spatial indexing:%s\n" %
                               (str(end_time - start_time)))
        progress.setInfo("Road Network Complete and its spatial indexing:%s" %
                               (str(end_time - start_time)))
        progress.setPercentage(int(15))
        # end create the road network and its spatial indexing==========================================================

        # iterate on the Source Layer features==========================================================================
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_SOURCE_LAYER.selectedFeatureCount() > 0:
            sourceFeats = self.m_SOURCE_LAYER.getSelectedFeatures()
            count = int(self.m_SOURCE_LAYER.selectedFeatureCount())
        else:
            sourceFeats = self.m_SOURCE_LAYER.getFeatures()
            count = int(self.m_SOURCE_LAYER.featureCount())

        start_time = time.time()
        ProcessingLog.addToLog(ProcessingLog.LOG_ALGORITHM,"Find the Facilities within distance on Road Network...\n" )
        progress.setInfo("Find the Facilities within distance on Road Network...")
        # distance = QgsDistanceArea()
        # distance.setSourceCrs(self.m_EDGE_LAYER.crs().srsid())
        # project_ellipsoid = QgsProject.instance().readEntry('Measure', '/Ellipsoid',
        #                                                     'NONE')[0]
        # distance.setEllipsoid(project_ellipsoid)
        out_id = 0
        for current,ft in enumerate(sourceFeats):
            fGeom = QgsGeometry(ft.geometry())
            sourceID = ft[self.m_SOURCE_LAYER_ID]
            s_point = fGeom.asPoint() # as source in road network (QgsPointXY)
            sInd = idx.nearestNeighbor(s_point, 1)
            # because I can not deal with the units very well(for example, distance(m) for time(second,hour,min)),so I
            # set 0 here [TODO]
            dis_source = 0 #distance.measureLine(s_point, indPointsData[sInd[0]])

            visited_points = set()
            visited_IDs = set()
            iter_ = 1
            abondonIndex = 0
            acc_sum = 0.0
            acc_num = 0
            while abondonIndex<2:
                # get the 100 nearest
                nearest_inds = idx_target.nearestNeighbor(s_point,iter_*50)
                for nind in nearest_inds:
                    if nind in visited_points:
                        continue
                    t_ID,t_point,t_value = idxId2targetId[nind] # as target in road network(QgsPointXY)

                    if t_ID not in visited_IDs:
                        tInd = idx.nearestNeighbor(t_point,1)
                        if self.NetworkPackage == "NETWORKX":
                            if self.straighLine:
                                # calculate the shortest distance
                                try:
                                    pathlen = dijkstra_path_length(d_network, sInd[0], tInd[0], "weight")
                                except NetworkXNoPath as e:
                                    ProcessingLog.addToLog(ProcessingLog.LOG_WARNING, str(e))
                                    progress.setInfo(str(e))
                                    pathlen=NULL
                            else:
                                # calculate the shortest path
                                try:
                                    pathlen,paths = single_source_dijkstra(d_network, sInd[0], tInd[0], "weight")
                                except NetworkXNoPath as e:
                                    ProcessingLog.addToLog(ProcessingLog.LOG_WARNING, str(e))
                                    progress.setInfo(str(e))
                                    pathlen,paths=NULL,NULL
                        elif self.NetworkPackage=="IGRAPH":
                            try:
                                newpaths = []
                                paths = d_network.get_shortest_paths(p_dict[sInd[0]], p_dict[tInd[0]], "weight", "OUT", "vpath")[0]
                                pathlen = 0.0
                                if paths is None or len(paths)==0:
                                    progress.setInfo(str("No path found for %s,%s"%(sInd[0],tInd[0])))
                                    pathlen=NULL
                                else:
                                    for res_ind in range(len(paths)-1):
                                        note1,note2 = paths[res_ind],paths[res_ind+1]
                                        note1 = d_network.vs[note1]["name"]
                                        note2 = d_network.vs[note2]["name"]
                                        newpaths.append(note1)
                                        e_id = reverse_edge_data[(note1,note2)]
                                        e_data = edge_data[e_id]
                                        s,t,c,r_c,_,_= e_data
                                        if note1==s:
                                            pathlen += c
                                        else:
                                            pathlen += r_c
                                    newpaths.append(note2)
                                    paths = newpaths
                            except Exception as e:
                                raise GeoAlgorithmExecutionException("%s"%(str(e)))

                        # total distance
                        if pathlen!=NULL:
                            dis_target = 0 # distance.measureLine(indPointsData[tInd[0]],t_point)
                            route_dis = dis_source + pathlen + dis_target
                            # straight_dis = distance.measureLine(s_point, t_point)
                            if route_dis<self.m_SEARCH_RADIUS:
                                vals = {}
                                # field_names = [v_OUTPUT_ID, v_OUTPUT_SOURCEID,
                                #                v_OUTPUT_TARGETID,
                                #                v_OUTPUT_DISTANCE, v_OUTPUT_ACCESSIBILITY]
                                vals[v_OUTPUT_ID] = out_id
                                vals[v_OUTPUT_SOURCEID] = sourceID
                                vals[v_OUTPUT_TARGETID] = t_ID
                                vals[v_OUTPUT_DISTANCE] = route_dis
                                vals[v_OUTPUT_ACCESSIBILITY] = t_value / pow(route_dis, self.m_POWERGRAVITY)
                                acc_sum += vals[v_OUTPUT_ACCESSIBILITY]
                                acc_num += 1
                                # update fields
                                attr = []
                                for field_name in field_names:
                                    attr.append(vals[field_name])
                                outFeat.setAttributes(attr)
                                if self.straighLine:
                                    outFeat.setGeometry(QgsGeometry.fromPolylineXY([s_point,t_point]))
                                else:
                                    polyline = []
                                    for i in range(len(paths)-1):
                                        node1,node2 = paths[i],paths[i+1]
                                        e_id = reverse_edge_data[(node1,node2)]
                                        e_data = edge_data[e_id]
                                        s,t,c,r_c,_,fGeom= e_data
                                        vertices = fGeom.asPolyline()
                                        if node1==s:
                                            polyline.extend(vertices)
                                        else:
                                            polyline.extend(vertices[::-1])
                                    # polyline = [indPointsData[ptid] for ptid in paths]
                                    outFeat.setGeometry(QgsGeometry.fromPolylineXY(polyline))
                                writer.addFeature(outFeat)
                                out_id+=1
                            else:
                                abondonIndex+=1
                    visited_IDs.add(t_ID)
                    visited_points.add(nind)
                iter_+=1
            #field_names = [self.m_OUTPUT_ID,self.m_OUTPUT_DIS,self.m_OUTPUT_AREA]
            # update fields
            if save2input==True:
                self.m_SOURCE_LAYER.changeAttributeValue(ft.id(), field_name_index_sum[v_OUTPUT_SUM],
                                                            acc_sum,acc_num)
            else:
                attr = [sourceID,acc_sum,acc_num]
                outFeat_sum.setAttributes(attr)
                outFeat_sum.setGeometry(ft.geometry())
                writer_sum.addFeature(outFeat_sum)
            progress.setPercentage(int(15+current*1.0/count*80))

        del writer
        # save the update OUTPUT_SUM===============================================================================================
        if save2input==True:
            # commit changes
            self.m_SOURCE_LAYER.endEditCommand()
            modify = self.m_SOURCE_LAYER.isModified()
            if modify:
                suc = self.m_SOURCE_LAYER.commitChanges()
                suc = self.m_SOURCE_LAYER.commitChanges()
                if not suc:
                    errors = self.m_SOURCE_LAYER.commitErrors()
                    msg = ''
                    for err in errors:
                        msg += str(err) + "\n"
                    ProcessingLog.addToLog(ProcessingLog.LOG_ERROR, msg)
                    raise GeoAlgorithmExecutionException(
                                         ("Failed to update Random Points Layer,Please check the processingliu.log for more details."))
            self.m_OUTPUT_LAYER_SUM.layer = self.m_SOURCE_LAYER
            self.m_OUTPUT_LAYER_SUM.description = self.m_SOURCE_LAYER.name()
        else:
            del writer_sum
        progress.setPercentage(int(100))

