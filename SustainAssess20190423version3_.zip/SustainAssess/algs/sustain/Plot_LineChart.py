# -*- coding: utf-8 -*-

"""
***************************************************************************
    Plot_Histogram.py
    ---------------------
    Date                 : Jan 2019
    Copyright            : Mengmeng Liu and Qingsong Liu'
    Email                : qliu20@kent.edu
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os
import share
import numpy as np
import rpy2.robjects as robjects
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import QgsFeatureRequest
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS,ParameterFile
from SustainAssess.core.outputs import OutputDirectory
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException


pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
# os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class Plot_LineChart(GeoAlgorithm):
    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    WEIGHT_FILE = "WEIGHT_FILE"
    POLY_INPUT_FIELD = 'POLY_INPUT_FIELD'  #
    SENSITIVITY_FILE = 'SENSITIVITY_FILE'
    OUTPUTDIR = "OUTPUTDIR"

    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Results Visualization/Line Chart"
        self.name, self.i18n_name = self.trAlgorithm('Line Chart')
        self.group, self.i18n_group = self.trAlgorithm('Results Visualization')
        self.addParameter(ParameterFile(self.WEIGHT_FILE, self.tr('AHP Weight File'), optional=False, ext='weight'))
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Uncertainty Result Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_ANY]))
        self.addParameter(ParameterTableField(self.POLY_INPUT_FIELD,
                                          self.tr('Key Field'),self.POLY_VECTOR))
        self.addParameter(
            ParameterFile(self.SENSITIVITY_FILE, self.tr('Sensitivity Results File'), optional=False, ext='txt'))
        self.addOutput(OutputDirectory(self.OUTPUTDIR,
                                       self.tr('Directory to Save Charts')))
    def processAlgorithm(self, progress,
                         source_param=None,m_IDField=None,
                         m_WEIGHT_FILE = None,m_SENSITIVITY_FILE = None,
                         filedir = None):
        if not source_param:
            source_param = self.getParameterFromName(self.POLY_VECTOR)
            m_IDField = self.getParameterValue(self.POLY_INPUT_FIELD)
            self.m_WEIGHT_FILE = self.getParameterValue(self.WEIGHT_FILE)
            self.m_SENSITIVITY_FILE = self.getParameterValue(self.SENSITIVITY_FILE)
            filedir = self.getOutputValue(self.OUTPUTDIR)
        else:
            self.m_WEIGHT_FILE = m_WEIGHT_FILE
            self.m_SENSITIVITY_FILE = m_SENSITIVITY_FILE

        sourceLayer = source_param.getLayerObject()

        # get the weight data
        f_weight = open(self.m_WEIGHT_FILE,"r")
        # get top dimentions
        # top_dims = ["Economic','Environmental','Social']
        line = f_weight.readline().rstrip("\r\n")
        tier1_dims  = line.split(",")[1:]
        nrows = len(tier1_dims)

        # tier2_names = [Eco_1,Eco_2,Eco_3,Env_1,Env_2,Env_3,Env_4,Soc_1,Soc_2,Soc_3,Soc_4]
        line = f_weight.readline().rstrip("\r\n")
        tier2_names = line.split(",")[1:]
        n_col = len(tier2_names)

        # # top_dims_positions = [[1,1,1,1,1,1,1,1,0,0,0,0,0,0]
        # #                       [0,0,0,0,0,0,0,0,1,1,1,0,0,0]
        # #                       [0,0,0,0,0,0,0,0,0,0,0,1,1,1]]
        # n_top_dims = len(top_dims)
        # top_dims_positions = [[0] * n_col for i in range(n_top_dims)]
        # for i in range(len(fields_names)):
        #     j_dim = top_dims.index(fields_names[i].split("_")[0])
        #     top_dims_positions[j_dim][i] = 1
        # overall_weight = [0.1156237051214135,0.09293824481282241,0.036719040459988625,0.018637110997602832,0.1156237051214135,0.09293824481282241,0.036719040459988625,0.018637110997602832,0.17551395029424272,0.11056684929525253,0.046435138818353955,0.07371119552034461,0.046435138818353955,0.019501524469797707]
        line = f_weight.readline().rstrip("\r\n")
        overall_weight = line.split(",")[1:]
        overall_weight = [float(i) for i in overall_weight]
        tier2_weights = [[0] * n_col for i in range(nrows)]
        tier1_names = [] # [Economic,Environmental,Social]
        tier1_weights = [0] * nrows
        for i in range(nrows):
            line = f_weight.readline().rstrip("\r\n")
            line = line.split(",")
            name, weights = line[0].split(" ")[0],line[1:]
            tier1_names.append(name)
            weights = [float(w) for w in weights]
            for j,w in enumerate(weights):
                tier2_weights[i][j] = w
                if w>0:
                    tier1_weights[i] = overall_weight[j]/w
        # tier2_weights = np.array(tier2_weights)
        f_weight.close()

        # get the sensitivity data
        f_sensitivity = open(self.m_SENSITIVITY_FILE,"r")
        line = f_sensitivity.readline().rstrip("\r\n")
        for r in line.split(",")[1:]:
            if r not in tier2_names:
                raise GeoAlgorithmExecutionException("Sensitivity and ")
        line = f_sensitivity.readline().rstrip("\r\n")
        s1 = line.split(",")[1:]
        line = f_sensitivity.readline().rstrip("\r\n")
        s1_cont = line.split(",")[1:]
        line = f_sensitivity.readline().rstrip("\r\n")
        st = line.split(",")[1:]
        line = f_sensitivity.readline().rstrip("\r\n")
        st_conf = line.split(",")[1:]
        f_sensitivity.close()

        fields = sourceLayer.fields()
        topITEMS = share.TOPITEMS   #["Economic","Environmental","Social","Resilient","Composite"]
        topITEMS_ALIAS = share.TOPITEMS_ALIAS # {"Economic":"Eco", "Environmental":"Env", "Social":"Soc", "Resilient":"Res", "Composite":"Comp"}

        filedir = filedir.replace("\\","/")
        dimensions = []
        for fi in fields:
            for item in topITEMS:
                if item.lower().startswith(str(fi.name()).lower()):
                    dimensions.append(fi.name())
        if len(dimensions)!=len(tier1_names):
            raise GeoAlgorithmExecutionException("Weights file and Input Layer inconsistency!")
        for d in dimensions:
            if sum([name.startswith(d) for name in tier1_names])!=1:
                raise GeoAlgorithmExecutionException("Weights file and Input Layer inconsistency!")

        m_MULTIFIELDS = []
        m_MULTIFIELDS.append(m_IDField)
        m_MULTIFIELDS.append("E0")
        m_MULTIFIELDS.append("e0_cil")
        m_MULTIFIELDS.append("e0_cih")
        for d in dimensions:
            m_MULTIFIELDS.append(d)
            name = d[0:3]
            m_MULTIFIELDS.append(name.lower() + "_cil")
            m_MULTIFIELDS.append(name.lower() + "_cih")
        for name in tier2_names:
            m_MULTIFIELDS.append(name)
        m_MULTIFIELDS.append("conflel")
        # m_MULTIFIELDS = [id,E0,Economic,eco_cil,eco_cih,...,conflel]
        field_indexes = [sourceLayer.fields().indexFromName(f) for f in m_MULTIFIELDS]
        checkfields = [True if idx==-1 else False for idx in field_indexes]
        if sum(checkfields)>0:
            msg = ""
            for i,ch in enumerate(checkfields):
                if ch:
                    msg+=" "+m_MULTIFIELDS[i]
                msg+=" don't exist, please make sure that this layer is from Uncertainty Analysis tool!"
            raise GeoAlgorithmExecutionException(msg)

        request = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes(field_indexes)
        feats = sourceLayer.getFeatures(request)
        count = int(sourceLayer.featureCount())
        dim = len(dimensions)

        metafile = os.path.join(filedir, "StratifiedBarChart.meta")
        out = open(metafile,"w")
        out.write("Input Uncertainty Layer= "+sourceLayer.dataProvider().dataSourceUri()+"\n")
        out.write("Input AHP Weights= " + self.m_WEIGHT_FILE + "\n")
        # out.write("num_axes=%d\n"%(dim))
        # out.write("order_=%s\n" % (",".join(['"'+str(d)+'"' for d in dimensions])))

        tier2weights_strlist = []
        for i,name in enumerate(dimensions):
            tempdata = tier2_weights[i]
            temp = "%s=c(%s)" % (name, ",".join([str(t) for t in tempdata]))
            tier2weights_strlist.append(temp)

        # "Economic","Environmental","Social","Resilient","Composite"
        color_pre = {"Economic":'c("#F4B183","#F8CBAD")',"Environmental":'c("#A9D18E","#C5E0B4")',
                 "Social":'c("#FFD966","#FFE699")', "Resilient":'c("#9DC3E6","#BDD7EE")',
                 "Composite":'c("#A9D18E","#C5E0B4")'}
        color = []
        for i, name in enumerate(dimensions):
            for cname in color_pre.keys():
                if cname.startswith(name):
                    color.append(color_pre[cname])
                    break
        color_strlist = []
        for i,name in enumerate(dimensions):
            temp = "%s=%s" % (name, color[i])
            color_strlist.append(temp)

        args = {"tier1names": ",".join(['"' + str(name) + '"' for name in dimensions]),
                "tier1namesfull": ",".join(['"' + str(name) + '"' for name in tier1_names]),
                "tier1weights": ",".join([str(d) for d in tier1_weights]),
                "tier2names": ",".join(['"' + str(name) + '"' for name in tier2_names]),
                "tier2weights": ",".join(tier2weights_strlist),
                "datanames": ",".join(['"' + str(name) + '"' for name in m_MULTIFIELDS]),
                "colors": ",".join(color_strlist),
                "s1":"c("+",".join(s1)+")",
                "st": "c(" + ",".join(st) + ")"
                }

        for i,inFeat in enumerate(feats):
            data_ = [inFeat[idx] for idx in field_indexes]
            id_ = data_[0]
            good_ = True
            for d_ in data_:
                if str(d_)!= "nan" or str(d_)!="NULL":
                    continue
                else:
                    if float(d_)>1 or float(d_)<0:
                        good_ = False
                        QMessageBox.critical(None, ("Error"),
                                             ("Please make sure this layer is normalised and all value are from 0 to 1!"))
                        break
            if good_ ==False:
                break
            # if str(id_) != "13089023115":
            #     continue
            args["filename1"] = filedir + "/" + "line_1_" + str(id_) + ".png"
            args["filename2"] = filedir + "/" + "line_2_" + str(id_) + ".png"
            args["filename3"] = filedir + "/" + "line_3_" + str(id_) + ".png"
            args["data_"] = ",".join([str(d) for d in data_])

            r_command='''
                    library(ggplot2)
                    # library(ggrepel)
                    
                    tier1names = c(%(tier1names)s)
                    tier1namesfull = c(%(tier1namesfull)s)
                    tier1weights = c(%(tier1weights)s)
                    names(tier1weights) = tier1names
                    colors = data.frame(%(colors)s)
                    names(colors) = tier1names
                    
                    tier2names = c(%(tier2names)s)  
                    tier2weights= data.frame(%(tier2weights)s)
                    s1 = %(s1)s
                    st = %(st)s
                    outputname = "%(filename1)s"
                    
                    data_ = c(%(data_)s)
                    names(data_) = c(%(datanames)s)
                    
                    labels = character()
                    for (v in seq(1,length(tier1names))) {
                      key = tier1names[v]
                      name = tier1namesfull[v]
                      name_s = tolower(substr(name,1,3))
                      labels = append(labels,  
                                      sprintf("%%s
                                              C=%%2.0f%%%%,CI=[%%0.2f,%%0.2f]",name,data_["conflel"]*100,data_[paste(name_s,"_cil",sep = "")],data_[paste(name_s,"_cih",sep = "")]))
                    }
                    names(labels) = tier1names
                    
                    drawPoly<- function(gplot,bd,linecolor="#A6A6A6",type="dashed",size=1) 
                      # bd = c(left,right,bottom,right)
                    {
                      x1 = bd[1] # left
                      x2 = bd[2] # right
                      y1 = bd[3] # bottom
                      y2 = bd[4] # right
                      poly_1 = data.frame(x = c(x1,x1,x2,x2,x1),
                                          y = c(y1,y2,y2,y1,y1))
                      g <- gplot + geom_polygon(aes(x=x,y=y),data = poly_1,fill=NA,size=size,colour=linecolor,linetype=type)
                      return(g)
                    }
                    drawLine<- function(gplot,startP,endP,ci,fillcolor="#ABB2B9",size=1) 
                      # bd = c(left,right,bottom,right)
                    {
                      ci_low = ci[1]-0.05
                      ci_hi = ci[2]+0.05
                      df <- data.frame(x = c(startP[1],endP[1]), y = c(startP[2],endP[2]))
                      g <- gplot + geom_path(aes(x=x,y=y),data = df,colour=fillcolor,size=size)
                      df <- data.frame(x = c(endP[1]), y = c(endP[2]))
                      g <- g + geom_point(aes(x=x,y=y),data = df,colour=fillcolor,size=size+2)
                      g = drawPoly(g,c(ci_low,ci_hi,endP[2]-0.05,endP[2]+0.05)) 
                      return(g)
                    }
                    
                    
                    g <- ggplot()+xlim(-0.3,1.5) +ylim(-1.2,0)
                    
                    g <- g+scale_x_continuous(limits = c(-0.3,1.5))+
                      scale_y_continuous(limits = c(-1.2,0))
                    len = length(tier1names)
                    margin_ = 1.0/(len+1)
                    breaks_ = character(0)
                    labels_ = character(0)
                    starty = 0
                    labels = character()
                    labels_ends = character()
                    for (v in seq(1,length(tier1names))) {
                      key = tier1names[v]
                      name = tier1namesfull[v]
                      name_s = tolower(substr(name,1,3))
                      start_lable = sprintf("%%s",name)
                      end_label = sprintf("CI=[%%0.2f,%%0.2f],C=%%2.0f%%%%",data_[paste(name_s,"_cil",sep = "")],
                              data_[paste(name_s,"_cih",sep = "")],data_["conflel"]*100)
                      labels = append(labels,start_lable)
                      labels_ends = append(labels_ends,end_label)
                      starty = starty - margin_
                      g<-drawLine(g,c(0,starty),c(data_[key],starty),
                                  c(data_[paste(name_s,"_cil",sep = "")],data_[paste(name_s,"_cih",sep = "")]),
                                  fillcolor = colors[key][1,1],size=1.5)
                    }
                    
                    key = "E0"
                    name_s = tolower(key)
                    start_lable = sprintf("%%s",key)
                    end_label = sprintf("CI=[%%0.2f,%%0.2f],C=%%2.0f%%%%",data_[paste(name_s,"_cil",sep = "")],
                                        data_[paste(name_s,"_cih",sep = "")],data_["conflel"]*100)
                    labels = append(labels,start_lable)
                    labels_ends = append(labels_ends,end_label)
                    starty = starty - margin_
                    g<-drawLine(g,c(0,starty),c(data_[key],starty),
                                c(data_[paste(name_s,"_cil",sep = "")],data_[paste(name_s,"_cih",sep = "")]),
                                fillcolor = "#7F7F7F",size=1.5)
                    
                    # add label in the end
                    starty = 0
                    for (v in seq(1,length(labels_ends))) {
                      starty = starty - margin_
                      g <- g + annotate("text", x=1.05, y=starty, label=labels_ends[v], color="black",size=4,hjust = 0)
                    }
                    # add label in the front
                    starty = 0
                    for (v in seq(1,length(labels))) {
                      starty = starty - margin_
                      g <- g + annotate("text", x=-0.05, y=starty, label=labels[v], color="black",size=4,hjust = 1)
                    }
                    
                    # add top labels
                    g <- g + annotate("text", x=0, y=-margin_/4, label="0", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=1, y=-margin_/4, label="1", color="black",size=4,hjust = 0)
                    # add boarder
                    df <- data.frame(x = c(0,0), y = c(-margin_/2,-1))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.5)
                    df <- data.frame(x = c(0,1), y = c(-margin_/2,-margin_/2))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.5)
                    df <- data.frame(x = c(01,1), y = c(-margin_/2,-1))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.5,linetype="dashed")
                    # p + scale_y_discrete(breaks=c(printf("%%f",),"1","2"),
                    #                      labels=c("Dose 0.5", "Dose 1", "Dose 2"))
                    g <- g + theme_void()#theme(panel.background = element_rect(fill = "white", colour = "grey50"))
                    
                    png(file="%(filename1)s",width = 800, height = 600)
                    par(mar=c(0,0,0,0)+0.1)
                    plot(g)
                    dev.off()
            #==Second Figure=================================================================================================
                    ycol = length(tier2names)
                    starty = 0
                    margin_ = 1/8.0
                    labels = character()
                    labels_ends = character()
                    g <- ggplot()+xlim(-1.5,1.5) +ylim(-ycol*margin_-0.1,0)
                    for (v in seq(1,length(tier1names))) {
                      key = tier1names[v]
                      name = tier1namesfull[v]
                      inds = which(tier2weights[key]>0)
                      for (idx in inds) {
                        key_2 = tier2names[idx]
                        d = data_[key_2]
                        w = tier2weights[key][idx,1]
                        starty = starty - margin_
                        g<-drawLine(g,c(0.01,starty),c(d,starty),
                                    numeric(),
                                    fillcolor = colors[key][1,1],size=1.0)
                        g<-drawLine(g,c(-0.01,starty),c(-1*w,starty),
                                    numeric(),
                                    fillcolor = colors[key][1,1],size=1.0)
                      }
                    }
                    # add boarder
                    df <- data.frame(x = c(-1,1), y = c(-margin_/2,-margin_/2))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.0)
                    df <- data.frame(x = c(0,0), y = c(-margin_/2,-ycol*margin_))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.0)
                    df <- data.frame(x = c(-1,-1), y = c(-margin_/2,-ycol*margin_))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.0,linetype="dashed")
                    df <- data.frame(x = c(1,1), y = c(-margin_/2,-ycol*margin_))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.0,linetype="dashed")
                    # add top labels
                    g <- g + annotate("text", x=-1, y=-margin_/5, label="-1", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=1, y=-margin_/5, label="1", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=0, y=-margin_/5, label="0", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=-0.8, y=0, label="Weight", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=0.8, y=0, label="Values", color="black",size=4,hjust = 1)
                    
                    g <- g + theme_void()
                    png(file="%(filename2)s",width = 800, height = 600)
                    par(mar=c(0,0,0,0)+0.1)
                    plot(g)
                    dev.off()

                #==Third Figure======================================================================================
                    ycol = length(tier2names)
                    starty = 0
                    margin_ = 1/8.0
                    labels = character()
                    labels_ends = character()
                    g <- ggplot()+xlim(-1.5,1.5) +ylim(-ycol*margin_-0.1,0)
                    for (v in seq(1,length(tier1names))) {
                      key = tier1names[v]
                      name = tier1namesfull[v]
                      inds = which(tier2weights[key]>0)
                      for (idx in inds) {
                        idx = 1
                        key_2 = tier2names[idx]
                        s1_i = s1[idx]
                        st_i = st[idx]
                        sts1_v = st_i - s1_i
                        starty = starty - margin_
                        g<-drawLine(g,c(0.01,starty),c(sts1_v,starty),
                                    numeric(),
                                    fillcolor = colors[key][1,1],size=1.0)
                        g<-drawLine(g,c(-0.01,starty),c(-1*s1_i,starty),
                                    numeric(),
                                    fillcolor = colors[key][1,1],size=1.0)
                      }
                    }
                    # add boarder
                    df <- data.frame(x = c(-1,1), y = c(-margin_/2,-margin_/2))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.0)
                    df <- data.frame(x = c(0,0), y = c(-margin_/2,-ycol*margin_))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.0)
                    df <- data.frame(x = c(-1,-1), y = c(-margin_/2,-ycol*margin_))
                    g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.0,linetype="dashed")
                    # df <- data.frame(x = c(1,1), y = c(-margin_/2,-ycol*margin_))
                    # g <- g + geom_path(aes(x=x,y=y),data = df,colour="#D9D9D9",size=1.0,linetype="dashed")
                    # add top labels
                    g <- g + annotate("text", x=-1, y=-margin_/5, label="-1", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=1, y=-margin_/5, label="1", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=0, y=-margin_/5, label="0", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=-0.8, y=0, label="Si", color="black",size=4,hjust = 0)
                    g <- g + annotate("text", x=0.8, y=0, label="(Sti-Si)", color="black",size=4,hjust = 1)
                    
                    g <- g + theme_void()
                    png(file="%(filename3)s",width = 800, height = 600)
                    par(mar=c(0,0,0,0)+0.1)
                    plot(g)
                    dev.off()
            '''%(args)
            # out.write(r_command)
            res = robjects.r(r_command)
            progress.setPercentage(int(0.0+i*1.0/count*100))
        out.close()



