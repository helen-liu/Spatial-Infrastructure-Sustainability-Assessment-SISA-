# -*- coding: utf-8 -*-

"""
***************************************************************************
    RandomPointsLayer.py
    ---------------------
    Date                 : April 2014
    Copyright            : (C) 2014 by Alexander Bruy
    Email                : alexander dot bruy at gmail dot com
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

__author__ = 'Qmm'
__date__ = 'Aug 2018'
__copyright__ = '(C) 2018, Mengmeng Liu and Qingsong Liu'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

import os

import rpy2
import rpy2.robjects as robjects
import rpy2.rlike.container as rlc

from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsFeatureRequest,NULL
from SustainAssess.core.GeoAlgorithm import GeoAlgorithm

from SustainAssess.core.parameters import ParameterBoolean,ParameterFile
from SustainAssess.core.parameters import ParameterTableField
from SustainAssess.core.parameters import ParameterVector_RDBMS
from SustainAssess.core.parameters import ParameterSelection
from SustainAssess.core.outputs import OutputFile

from SustainAssess.tools.postgis import TableField
from SustainAssess.core.ProcessingConfig import ProcessingConfig
from SustainAssess.core.GeoAlgorithmExecutionException import GeoAlgorithmExecutionException

pluginPath = os.path.split(os.path.split(os.path.dirname(__file__))[0])[0]

#[TODO] need to check before running
# before running, please install spdep, sp, sf in R
# os.environ['R_HOME'] = 'C:\\Program Files\\R\\R-3.5.1'
class MoranI(GeoAlgorithm):

    POLY_VECTOR = 'POLY_VECTOR' #poly_layer
    POLY_INPUT_FIELD = 'POLY_INPUT_FIELD'  #

    WEIGHT_OBJECT = "WEIGHT_OBJECT"

    VARIANCE_ASSUMPTION = "VARIANCE_ASSUMPTION"
    VARIANCE_ASSUMPTION_OPTIONS = ['RANDOMISATION', 'NORMALITY']

    ALTERNATIVE_HYPOTHESIS= 'ALTERNATIVE_HYPOTHESIS'
    ALTERNATIVE_HYPOTHESIS_OPTIONS = ['GREATER','LESS']#,'TWO.SIDED']

    RANKED_DATA = 'RANKED_DATA'
    RANKED_DATA_OPTIONS = ['TRUE','FALSE']

    OUTPUT_AS_TEXT = 'OUTPUT_AS_TEXT'



    def getIcon(self):
        return QIcon(os.path.join(pluginPath, 'images', 'qgis.svg'))

    def defineCharacteristics(self):
        self.menu_path = "Sustainability/Spatial Statistics/Moran\'s I"
        self.name, self.i18n_name = self.trAlgorithm('Moran\'s I')
        self.group, self.i18n_group = self.trAlgorithm('Spatial Statistics')
        self.addParameter(ParameterVector_RDBMS(self.POLY_VECTOR,
                                          self.tr('Input Layer'), [ParameterVector_RDBMS.VECTOR_TYPE_POLYGON]))
        self.addParameter(ParameterTableField(self.POLY_INPUT_FIELD,
                                          self.tr('Input Field'),self.POLY_VECTOR))

        self.addParameter(ParameterFile(self.WEIGHT_OBJECT, self.tr('Weights File'),optional=False,ext='gal'))
        self.addParameter(ParameterSelection(self.VARIANCE_ASSUMPTION,
                                             self.tr('Moran Test: Variance Assumption'),
                                             self.VARIANCE_ASSUMPTION_OPTIONS, 1))

        self.addParameter(ParameterSelection(self.ALTERNATIVE_HYPOTHESIS,
                                             self.tr('Moran Test: Alternative Hypothesis'),
                                             self.ALTERNATIVE_HYPOTHESIS_OPTIONS, 0))
        self.addParameter(ParameterSelection(self.RANKED_DATA,
                                             self.tr('Moran Test: Ranked Data'),
                                             self.RANKED_DATA_OPTIONS, 1))

        self.addOutput(OutputFile(self.OUTPUT_AS_TEXT, self.tr('Moran\'s I Output to File'), 'txt'))

    def processAlgorithm(self, progress):

        paramInput = self.getParameterFromName(self.POLY_VECTOR)
        self.m_POLY_VECTOR = paramInput.getLayerObject()
        self.m_POLY_INPUT_FIELD = self.getParameterValue(self.POLY_INPUT_FIELD)

        self.m_WEIGHT_OBJECT = self.getParameterValue(self.WEIGHT_OBJECT)

        self.m_VARIANCE_ASSUMPTION = \
            self.VARIANCE_ASSUMPTION_OPTIONS[self.getParameterValue(self.VARIANCE_ASSUMPTION)]

        self.m_ALTERNATIVE_HYPOTHESIS = \
            self.ALTERNATIVE_HYPOTHESIS_OPTIONS[self.getParameterValue(self.ALTERNATIVE_HYPOTHESIS)]
        self.m_RANKED_DATA = \
            self.RANKED_DATA_OPTIONS[self.getParameterValue(self.RANKED_DATA)]

        self.m_OUTPUT_AS_TEXT = self.getOutputValue(self.OUTPUT_AS_TEXT)

        provider = self.m_POLY_VECTOR.dataProvider()
        sRs = provider.crs()
        projString = str(sRs.toProj4())
        # 2. get r function
        robjects.r("require(%s)" % ("sp"))[0]
        robjects.r("require(%s)" % ("spdep"))[0]
        self.CRS_ = robjects.r.get('CRS', mode='function')
        self.Polygon_ = robjects.r.get('Polygon', mode='function')
        self.Polygons_ = robjects.r.get('Polygons', mode='function')
        self.SpatialPolygons_ = robjects.r.get('SpatialPolygons', mode='function')
        self.Line_ = robjects.r.get('Line', mode='function')
        self.Lines_ = robjects.r.get('Lines', mode='function')
        self.SpatialLines_ = robjects.r.get('SpatialLines', mode='function')
        self.SpatialPoints_ = robjects.r.get('SpatialPoints', mode='function')
        self.SpatialPointsDataFrame_ = robjects.r.get('SpatialPointsDataFrame', mode='function')
        self.SpatialLinesDataFrame_ = robjects.r.get('SpatialLinesDataFrame', mode='function')
        self.SpatialPolygonsDataFrame_ = robjects.r.get('SpatialPolygonsDataFrame', mode='function')

        self.as_character_ = robjects.r.get('as.character', mode='function')
        self.data_frame_ = robjects.r.get('data.frame', mode='function')
        self.matrix_ = robjects.r.get('matrix', mode='function')
        self.unlist_ = robjects.r.get('unlist', mode='function')

        self.poly2nb_ = robjects.r.get('poly2nb', mode='function')
        self.nb2listw_ = robjects.r.get('nb2listw', mode='function')
        # moran.test(x, listw, randomisation=TRUE, zero.policy = NULL,alternative = "greater", rank = FALSE, na.action = na.fail, spChk = NULL, adjust.n = TRUE)
        self.moran_test_ = robjects.r.get('moran.test', mode='function')

        progress.setPercentage(int(25))
        req = QgsFeatureRequest()
        req.setFlags(QgsFeatureRequest.NoGeometry)
        if ProcessingConfig.getSetting(ProcessingConfig.USE_SELECTED) \
                and self.m_POLY_VECTOR.selectedFeatureCount() > 0:
            feats = self.m_POLY_VECTOR.getSelectedFeatures(req)
            count = int(self.m_POLY_VECTOR.selectedFeatureCount())
        else:
            feats = self.m_POLY_VECTOR.getFeatures(req)
            count = int(self.m_POLY_VECTOR.featureCount())

        fields = self.m_POLY_VECTOR.fields()
        if fields.count() <= 0:
            raise Exception("Error: Attribute table must have at least one field")
        df = {}
        types = {}
        order = []
        fid = {"fid": []}
        Coords = []
        for field in fields:
            # initial read in has correct ordering...
            name = str(field.name())
            if name==self.m_POLY_INPUT_FIELD:
                df[name] = []
                types[name] = int(field.type())
                order.append(name)
        # rpdb2.start_embedded_debugger("liu")
        for current, feat in enumerate(feats):
            val = feat[self.m_POLY_INPUT_FIELD]
            if val!= NULL:
                df[self.m_POLY_INPUT_FIELD].append(feat[self.m_POLY_INPUT_FIELD])
            else:
                df[self.m_POLY_INPUT_FIELD].append(robjects.NA_Real)
                # df[self.m_POLY_INPUT_FIELD].append(0)
            fid["fid"].append(feat.id())

        progress.setPercentage(int(50))
        tmp = []
        for key in order:
            if types[key] == 10:
                tmp.append((str(key), self.as_character_(robjects.StrVector(df[key]))))
            else:
                tmp.append((str(key), robjects.FloatVector(df[key])))
        try:
            data_frame = rlc.OrdDict(tmp)
        except:
            data_frame = rlc.OrdDict(tmp)

        data_frame = robjects.DataFrame(data_frame)
        #spds = self.createSpatialDataset(feat.geometry().type(), Coords, data_frame, projString)

        robjects.r.assign(str("r_input"), data_frame)
        # version 1

        # r_command = '''saveRDS(r_input,"C:/Users/qliu20/Kent/temp/r_input.rds")'''
        # robjects.r(r_command)
        # function of reading gal.wht file
        r_fun='''
                read.galwht <- function(file, region.id=NULL) 
                {
                  con <- file(file, open="r")
                  line <- unlist(strsplit(readLines(con, 1), " "))
                  x <- subset(line, nchar(line) > 0)
                  if (length(x) == 1L) {
                    n <- as.integer(x[1])
                    shpfile <- as.character(NA)
                    ind <- as.character(NA)
                  } else if (length(x) == 4L) {
                    n <- as.integer(x[2])
                    shpfile <- as.character(x[3])
                    ind <- as.character(x[4])
                  } else stop ("Invalid header line in GAL.WGT file")
                  if (n < 1) stop("Non-positive number of regions")
                  if (!is.null(region.id))
                    if (length(unique(region.id)) != length(region.id))
                      stop("non-unique region.id given")
                  if (is.null(region.id)) region.id <- as.character(1:n)
                  if (n != length(region.id))
                    stop("Mismatch in dimensions of GAL.WGT file and region.id")
                  rn <- character(n)
                  res <- vector(mode="list", length=n)
                  for (i in 1:n) {
                    line <- unlist(strsplit(readLines(con, 1), " "))
                    x <- subset(line, nchar(line) > 0)
                    rn[i] <- x[1]
                    line <- unlist(strsplit(readLines(con, 1), " "))
                    y <- subset(line, nchar(line) > 0)
                    if(length(y) != as.integer(x[2])) {
                      close(con)
                      stop(paste("GAL.WGT file corrupted at region", i))
                    }
                    res[[i]] <- y
                  }
                  close(con)
                  if (length(region.id)>0) {
                    if (!all(rn %in% region.id)) {
                      stop("GAL.WGT file IDs and region.id differ")
                    }
                  }
                  mrn <- match(rn, region.id)
                  res1 <- vector(mode="list", length=n)
                  for (i in 1:n) {
                    if (length(res[[i]]) > 0) {    
                      x <- res[[i]]
                      res1[[mrn[i]]] <- as.double(x)
                    } else {
                      res1[[mrn[i]]] <- as.integer(c(0))
                    }
                  }
                
                  res1
                }
        '''
        robjects.r(r_fun)
        r_moran_fun = '''
        moran.test.liu <- function(x, listw, randomisation=TRUE, zero.policy=NULL,
                       alternative="greater", rank = FALSE, na.action=na.fail, spChk=NULL, 
                       adjust.n=TRUE, drop.EI2=FALSE) {
                  alternative <- match.arg(alternative, c("greater", "less", "two.sided"))
                  if (!inherits(listw, "listw")) stop(paste(deparse(substitute(listw)),
                                                            "is not a listw object"))
                  if (!is.numeric(x)) stop(paste(deparse(substitute(x)),
                                                 "is not a numeric vector"))
                  if (is.null(zero.policy))
                    zero.policy <- get("zeroPolicy", envir = .spdepOptions)
                  stopifnot(is.logical(zero.policy))
                  if (is.null(spChk)) spChk <- get.spChkOption()
                  if (spChk && !chkIDs(x, listw))
                    stop("Check of data and weights ID integrity failed")
                  #	if (any(is.na(x))) stop("NA in X")
                  xname <- deparse(substitute(x))
                  wname <- deparse(substitute(listw))
                  NAOK <- deparse(substitute(na.action)) == "na.pass"
                  x <- na.action(x)
                  na.act <- attr(x, "na.action")
                  if (!is.null(na.act)) {
                    subset <- !(1:length(listw$neighbours) %in% na.act)
                    listw$neighbours <- subset(listw$neighbours, subset, zero.policy=zero.policy)
                    listw$weights <- subset(listw$weights, subset, zero.policy=zero.policy)
                  }
                  n <- length(listw$neighbours)
                  if (n != length(x)) stop("objects of different length")
                  
                  wc <- spweights.constants(listw, zero.policy=zero.policy, 
                                            adjust.n=adjust.n)
                  S02 <- wc$S0*wc$S0
                  res <- moran(x, listw, wc$n, wc$S0, zero.policy=zero.policy, 
                               NAOK=NAOK)
                  I <- res$I
                  K <- res$K
                  if (rank) K <- (3*(3*wc$n^2 -7))/(5*(wc$n^2 - 1))
                  EI <- (-1) / wc$n1
                  if(randomisation) {
                    VI <- wc$n*(wc$S1*(wc$nn - 3*wc$n + 3) - wc$n*wc$S2 + 3*S02)
                    tmp <- K*(wc$S1*(wc$nn - wc$n) - 2*wc$n*wc$S2 + 6*S02)
                    if (tmp > VI) warning("Kurtosis overflow,\ndistribution of variable does not meet test assumptions")
                    VI <- (VI - tmp) / (wc$n1*wc$n2*wc$n3*S02)
                    if (!drop.EI2) VI <- (VI - EI^2)
                    if (VI < 0) warning("Negative variance,\ndistribution of variable does not meet test assumptions")
                  } else {
                    VI <- (wc$nn*wc$S1 - wc$n*wc$S2 + 3*S02) / (S02*(wc$nn - 1))
                    if (!drop.EI2) VI <- (VI - EI^2)
                    if (VI < 0) warning("Negative variance,\ndistribution of variable does not meet test assumptions")
                  }
                  ZI <- (I - EI) / sqrt(VI)
                  statistic <- ZI
                  names(statistic) <- "Moran I statistic standard deviate"
                  if (alternative == "two.sided") 
                    PrI <- 2 * pnorm(abs(ZI), lower.tail=FALSE)
                  else if (alternative == "greater")
                    PrI <- pnorm(ZI, lower.tail=FALSE)
                  else PrI <- pnorm(ZI)
                  if (!is.finite(PrI) || PrI < 0 || PrI > 1) 
                    warning("Out-of-range p-value: reconsider test arguments")
                  vec <- c(I, EI, VI)
                  names(vec) <- c("Moran I statistic", "Expectation", "Variance")
                  method <- paste("Moran I test under", ifelse(randomisation,
                                                               "randomisation", "normality"))
                  data.name <- paste(xname, ifelse(rank,
                                                   "using rank correction",""), "\nweights:",
                                     wname, ifelse(is.null(na.act), "", paste("\nomitted number:",length(which(!subset)),"\nomitted ID:", 
                                                                              paste(attr(listw,"region.id")[!subset], collapse=", "))),
                                     ifelse(adjust.n && isTRUE(any(sum(card(listw$neighbours) == 0L))),
                                            "n reduced by no-neighbour observations\n", ""),
                                     ifelse(drop.EI2, "EI^2 term dropped in VI", ""), "\n")
                  res <- list(statistic=statistic, p.value=PrI, estimate=vec, 
                              alternative=alternative, method=method, data.name=data.name)
                  # if (!is.null(na.act)) attr(res, "na.action") <- na.act #revise qliu
                  if (!is.null(na.act)) attr(res, "na.action") <- attr(listw,"region.id")[subset]
                  class(res) <- "htest"
                  res
                }
        '''
        robjects.r(r_moran_fun)
        arg1 = {"input": "r_input",
                "weight_object": self.m_WEIGHT_OBJECT,
                "input_field": self.m_POLY_INPUT_FIELD,
                "randomisation": (self.m_VARIANCE_ASSUMPTION).lower(),
                "alternative": (self.m_ALTERNATIVE_HYPOTHESIS).lower(),
                "ranked": self.m_RANKED_DATA,
                "outputfile": self.m_OUTPUT_AS_TEXT.replace("\\","/")
                }
        r_command = '''
                library("spdep")
                input <- r_input
                # read *.gal,*.gal.wgt
                nb <- read.gal('%(weight_object)s',region.id=NULL,override.id = TRUE)
                hasWeight <- FALSE
                if(file.exists('%(weight_object)s.wgt'))
                    hasWeight <- TRUE
                dlist<-NULL
                if(hasWeight)
                    dlist = read.galwht('%(weight_object)s.wgt',region.id=attr(nb,"region.id"))
                # deal with NA, need to remove corresponding vertex from neighborhood list
                nalist <- which(is.na(input$%(input_field)s))
                nb_new = nb

                n<-length(nb_new)
                #remove vertex
                for (ind in nalist) {
                    neighb = nb_new[[ind]]
                    nb_new[[ind]]= as.integer(c(0))
                    if (length(neighb)==1 && neighb==0 )
                        next
                    for (ind_n in neighb) {
                        remains = !nb_new[[ind_n]] %%in%% c(ind)
                        nb_new[[ind_n]]<-nb_new[[ind_n]][remains]
                        if(hasWeight)
                            dlist[[ind_n]]<-dlist[[ind_n]][remains]
                    }
                }
                #make sure that the no neighbor vertex is 0
                for (i in 1:n) {
                    neighb = nb_new[[i]]
                    if(length(neighb)==0){
                        nb_new[[i]]=as.integer(c(0))
                    }
                }
                if(hasWeight){
                    for (i in 1:n) {
                        neighb = nb_new[[i]]
                        if(length(neighb)==1 && neighb==0){
                            dlist[[i]]=numeric()
                        }
                    }
                }
                style <- 'W'
                mlistw = nb2listw(nb_new, glist=dlist, style= style, zero.policy=TRUE)
                
                sink("%(outputfile)s", append=TRUE, split=FALSE)
                randomisation <- '%(randomisation)s'
                mt = moran.test.liu(input$%(input_field)s,mlistw , randomisation=ifelse('%(randomisation)s'=='randomisation',TRUE,FALSE),
                      alternative='%(alternative)s', rank=%(ranked)s,na.action=na.omit,zero.policy=TRUE)
                show(mt)
                # return output to the terminal 
                sink()
                ''' % arg1

        res = robjects.r(r_command)

        progress.setPercentage(int(100))

    def createSpatialDataset(self, vectType, Coords, data, projString):
        if vectType == 0:
            # For points, coordinates must be input as a matrix, hense the extra bits below...
            # Not sure if this will work for multipoint features?
            spatialData = self.SpatialPoints_(self.matrix_(self.unlist_(Coords), \
                                                           nrow=len(Coords), byrow=True),
                                              proj4string=self.CRS_(projString))
            return self.SpatialPointsDataFrame_(spatialData, data)  # , match_ID = True )
            # kwargs = {'match.ID':"FALSE"}
            # return SpatialPointsDataFrame( spatialData, data, **kwargs )
        elif vectType == 1:
            spatialData = self.SpatialLines_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialLinesDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        elif vectType == 2:
            spatialData = self.SpatialPolygons_(Coords, proj4string=self.CRS_(projString))
            # kwargs = {'match.ID':"FALSE"}
            return self.SpatialPolygonsDataFrame_(spatialData, data, match_ID=False)  # **kwargs)
        else:
            return ""

    # Helper function to get coordinates of input geometry
    # Does not require knowledge of input geometry type
    # Return: Appends R type geometry to input list
    def getNextGeometry(self, Coords, feat):
        geom = feat.geometry()
        if geom.type() == 0:
            Coords.append(self.getPointCoords(geom, feat.id()))
            return True
        elif geom.type() == 1:
            Coords.append(self.getLineCoords(geom, feat.id()))
            return True
        elif geom.type() == 2:
            Coords.append(self.getPolygonCoords(geom, feat.id()))
            return True
        else:
            return False

    # Function to retrieve QgsGeometry (point) coordinates
    # and convert to a format that can be used by R
    # Return: Item of class Matrix (R class)
    def getPointCoords(self, geom, fid):
        if geom.isMultipart():
            points = geom.asMultiPoint()  # multi_geom is a multipoint
            return [self.convertToXY(point) for point in points]
        else:
            point = geom.asPoint()  # multi_geom is a point
            return self.convertToXY(point)

        # Function to retrieve QgsGeometry (polygon) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Polygons (R class)

    def getPolygonCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            polygon = geom.asMultiPolygon()  # multi_geom is a multipolygon
            for lines in polygon:
                for line in lines:
                    keeps.append(self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                            nrow=len([self.convertToXY(point) for point in line]),
                                                            byrow=True)))
            return self.Polygons_(keeps, fid)
        else:
            lines = geom.asPolygon()  # multi_geom is a polygon
            Polygon = [self.Polygon_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                  nrow=len([self.convertToXY(point) for point in line]), byrow=True))
                       for line in lines]
            return self.Polygons_(Polygon, fid)

        # Function to retrieve QgsGeometry (line) coordinates
        # and convert to a format that can be used by R
        # Return: Item of class Lines (R class)

    def getLineCoords(self, geom, fid):
        if geom.isMultipart():
            keeps = []
            lines = geom.asMultiPolyline()  # multi_geom is a multipolyline
            for line in lines:
                for line in lines:
                    keeps.append(self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                                         nrow=len([self.convertToXY(point) for point in line]),
                                                         byrow=True)))
            return self.Lines_(keeps, str(fid))
        else:
            line = geom.asPolyline()  # multi_geom is a line
            Line = self.Line_(self.matrix_(self.unlist_([self.convertToXY(point) for point in line]), \
                                           nrow=len([self.convertToXY(point) for point in line]), byrow=True))
            return self.Lines_(Line, str(fid))

    def convertToXY(self, inPoint):
        return [inPoint.x(), inPoint.y()]

