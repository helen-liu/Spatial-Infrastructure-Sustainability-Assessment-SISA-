### Variable Distance Buffer

Create buffer for the "Input Layer" with variable distance defined by "Distance Field".



**Input Layer:**  layer or file you want to create buffer for.

**Distance Field**: use the value of  the "distance " field as the buffer distance, unit is same as coordinate system of "Input Layer" .

**Segments**: Number of quarter-circle for round joins at the end points. Default value is 5.

**Dissolve Result**: Dissolve the buffer if overlapped.

**Buffer Output**  : the buffer file created, default is "create temporary layer". The result can also be saved to file or database table (SpatiaLite table or PostGIS table). 



Example of Variable Distance Buffer (dissolved ).

![1546211485564](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546211485564.png)