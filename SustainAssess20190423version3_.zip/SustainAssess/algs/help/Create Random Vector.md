### Create Random Vectors

This tool **create random vectors ** in the boundary defined by "**Input Boundary Layer**".



**Input Boundary Layer**: files define the boundary of random points. Shapefiles **opened** in QGIS can be shown **automatically** in the droplist. Users can also choose "Input Boundary Layer" from files in other location or from database table (PostGIS table or SpatiaLite table).

**Vectors Number**: number of random vectors to be generated, default value is 1.

**Vector Length**: length of vectors.

**Random Vectors Output**: layer or file to save the generated random vectors. 



Example of Random Vectors in the boundary defined by orange polygon, with length of 1km (left) and 5km (right).

<img src = "C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1545937026907.png" width ="200px" />















