### Grid

This tool create **grid** in the study area.

**Grid Type:** There are three types. *Rectangle*, *Diamond*, *Hexagon*.

**Grid Extent**: Get the grid boundaries by Canvas or by Existing Layer.

**Horizontal Spacing**: The grid size in horizontal direction in map unit.

**Vertical Spacing**: The grid size in Vertical direction in map unit. If grid type is "**Hexagon**", **only the vertical spacing** controls the size of grid.

![1546208728910](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546208728910.png)

**Grid CRS**: Select Coordinate Reference System, it **must** the same as the Canvas or Existing Layer.

**Output Grid Layer**: The destination output Grid Layer.



Example of **Rectangle** grid in the extent defined by the orange polygon.

![1545931093898](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1545931093898.png)



Example of **Diamond** grid in the extent defined by the orange polygon.

![1545931113064](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1545931113064.png)



Example of **Hexagon** grid in the extent defined by the orange polygon.

![1545930995509](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1545930995509.png)