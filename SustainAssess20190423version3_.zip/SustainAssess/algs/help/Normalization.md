## Normalization

Normalize the selected fields of Input Layer.



**Input Zone Layer**: Polygon vector file.  It can be files opened in QGIS or "Open from file" or "open from database table" (SpatiaLite table or PostGIS table)

**ID Field**: ID field of the "Input Zone Layer"

**Normalization Method**:  Available normalization methods in this tool include:

* Min-Max
* Standard (Z-Score)
* Ranking
* Distance-to-Reference
* Categorical Scales

**Selected Fields**: normalize value of these selected fields. In the "**Alias**" field, users can type in the alias of the selected fields. "**Effect**" field designate the "*Positive*" or "*Negative*" effect of the corresponding field to the "Sustainability assessment".

**Normalization Results Layer**: save normalization results to temporal file or to file, or to database table (SpatiaLite table or PostGIS table).

____

Min-Max Normalization: 
$$
x_i^{'} = \frac{x_i - min(x_i)}{max(x_i)- min(x_i)}		\qquad  \in [0,1]
$$
Standard (Z-Score)  Normalization:
$$
x_i^{'} = \frac{x_i - \mu}{\sigma_i}	\\
\overline{x_i^{'}} = 0;	\qquad		S(x_i^{'}) = 1
$$
Ranking Normalization:
$$
x_i^{'} = Rank(x_i)
$$


Distance-to-Reference Normalization:
$$
x_i^{'} = \frac{x_i^{'} - x_i^{ref}}{x_i^{ref}}		\qquad \text{or} \qquad
x_i^{'} = \frac{x_i^{'}}{x_i^{ref}}
$$


Categorical Scales Normalization:
$$
x_i^{'} = \begin{cases}
	v_1 	\qquad \text{if $x_i$ in range } [r_0, r_1)		\\
	v_2 	\qquad \text{if $x_i$ in range } [r_1, r_2)		\\
	v_3 	\qquad \text{if $x_i$ in range } [r_3, r_4)		\\
	\cdots		\qquad \cdots	\\
	v_k 	\qquad \text{if $x_i$ in range } [r_{k-1}, r_k]	
\end{cases}
$$


**Explanation of symbols in the above equations*:, 
$$
\text{$x_i^{'} $ is the normalized value of  $x_i$,} \\
\text{$max(x_i)$ is the maximum value of $x_i$,} \\
\text{$min(x_i)$ is the minimum value of $x_i$,}	\\
\text{$\mu$ is the mean value of $x_i$,}	\\
\text{$\sigma_i $ is the square-root of the standard deviation of $x_i$,}	\\
\text{$\overline{x_i^{'}}$ is the average value of $x_i^{'}$,}	\\
\text{$x_i^{ref}$ is the reference value of $x_i$, it should be a meaningful value defiend by users}	\\
\text{$v_i \space (i = 1,2,...,k)$ is the categorical scores of $x_i$ afeter Categorical Scales normalization}	\\
$$
