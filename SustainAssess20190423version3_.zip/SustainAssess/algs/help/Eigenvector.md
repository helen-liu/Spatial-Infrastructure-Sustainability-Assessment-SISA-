## Eigenvector Centrality

Calculate the **Eigenvector  Centrality ** of  all nodes in the directed network using [eigenvector_centrality](https://igraph.org/python/doc/igraph-pysrc.html#Graph.evcent) functions in package "**Igraph**".



**Roads Nodes Layer**: nodes/ vertices table of "roads network".

**Node ID Field**: ID field of "Roads Node Layer".

**Roads Edge Layer**: edges table of "roads network".

**Edge ID Field**: ID field of "Roads Edge Layer".

**Edge Source Field**: source field of "Roads Edge Layer".

**Edge Target Field**: target field of "Roads Edge Layer".

**Edge Weight Field**: weight field of "Roads Edge Layer".

**Edge Reverse Weight Field**: reverse weight field of "Roads Edge Layer".

**Eigenvector Result's Field in Node Layer**: the field name of "Eigenvector Centrality" results.