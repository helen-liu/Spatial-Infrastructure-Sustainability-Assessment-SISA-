## Local Moran's I

Calculate the Local Moran's I of Input Layer, and add 4 new fields named "li" (Local Moran's I), "sim_pr" (P-value of Simulations), "hi_lo"(spatial cluster status), "moranlag" (weighted average value of its neighbors).



**Input Layer**: raster or vector file.  It can be files opened in QGIS or "Open from file" or "open from database table" (SpatiaLite table or PostGIS table)

**Input Field**:  field of the "Input Layer", for which to calculate the Local Moran's I value.

**Neighborhood File**:  file of "Spatial Weight" (*.gal)

**Alternative Hypothesis**:  Greater or Less.

**Number of Simulation**: Default value is 99.

