## Path Counts

Calculate the number of traffic flows on each edge in the road network.



**Origin-Destination (OD) Pairs Layer**: Origin-Destination pairs.

**Origin-Destination (OD) Pairs Weight Field**: weight field of  "OD pairs layer".

**Road Layer**: vector layer of roads network.

**Source Field in Road Layer**: Source field of "roads layer".

**Target Field in Road Layer**: Target field of "roads layer".

**Cost Field in Road Layer**: cost field of "roads layer".

**Reverse Cost Field in Road Layer**: Reverse cost field of "roads layer".

**Output: PathCount Field Name in Road Layer**: field name of "path count".

**Output:  Set the Accumulated Length Field Name in OD Layer [optional]**: field name of "accumulated length".

**Output: Set the Accumulated Cost Field Name in OD Layer [optional]**: field name of "accumulated Cost".


