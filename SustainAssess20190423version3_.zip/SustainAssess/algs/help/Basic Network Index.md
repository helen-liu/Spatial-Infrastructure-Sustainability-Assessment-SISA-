## Basic Network Index

Calculate the following basic road index for network analysis:

* **E**: number of edges in the network.
* **V**: number of nodes in the network.
* **P**: number of non-connected subgraphs in the network.



**Input Zone Layer**: polygon layer defined the boundary of calculating **E, V, P**. Each polygon in the "Input Zone Layer" will have a "Basic Road Index" value.  It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**ID Field**: ID field of the "Input Zone Layer"

**Roads Layer**: road network file. It <u>must be selected from database table (SpatiaLite or PostGIS table)</u>. 

**Source Field**: source field of "Roads Layer". If field name ‘source’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Target Field**: target field of "Roads Layer". If field name ‘target’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Cost Field**: cost field of "Roads Layer". When creating the **directed network**, "cost" is treated as "weight" of one edge segment. 

If field name ‘cost’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Reverse Cost Field**:  reverse cost field of "Roads Layer". When creating the **directed network**, "reverse cost" is treated as "weight" of one edge segment.

If field name ‘reverse_cost’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

-----

Optional parameters, if one of the E, V, P field name is "**[not set]**", then the tool will calculate the e, v, p values of the “Roads Layer”, and **create field "e_net", "v_net", "p_net" in the output layer**.

**E Field: [Optional]**:  field name of E value of network. Default value is: "**e_net**".

**V Field: [Optional]**:  field name of V value of network. Default value is: "**v_net**".

**P Field: [Optional]**:  field name of P value of network. Default value is: "**p_net**".

----

* Check "Create New Output Layer", users can save the **E, V, P** results to **<u>other files</u>**. Otherwise, results will be saved to fieds "**e_net**", "**v_net**", "**p_net**"  in the  "Input Zone Layer".

**Output Layer**: this tool can save results to temporary layer, shapefile (*.shp), database tables (SpatiaLite table or PostGIS table), or new fields in "Input Zone Layer".



* Check "Open output file after running algorithm", the results will be open in QGIS automatically after finish calculation.