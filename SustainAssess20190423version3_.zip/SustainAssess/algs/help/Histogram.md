## Create Histogram

Create histogram for the input field of the input file.



**Input Layer**:  Polygon vector file.  It can be files opened in QGIS or "Open from file" or "open from database table" (SpatiaLite table or PostGIS table).

**Input Field**: field of the "Input Layer", based on which to create histogram.

**Break Calculation**:  methods to calculate breaks (number of bins in histogram), available methods include:

- **Sturges**: [default value] use <u>Sturges' formula</u> to determine bin sizes on the number of data points (**n >30**). It  implicitly assumes an approximately normal distribution of data. It may also *perform poorly* if the data are not normally distributed. 
- **Scott**: use Scott's normal reference rule to determine bin sizes.  Scott's normal reference rule is optimal for random samples of normally distributed data, in the sense that it minimizes the integrated mean squared error of the density estimate.
- **Freedman-Diaconis**: use " interquartile range" to determine bin sizes.

**Plot Type**: values to plot in the histogram, **frequency** (default, number of data points in each bin) or **density** (probability densities).

**Main Title**: Main title of the histogram plot, default is "Histogram".

**Sub Title**: Sub title of the histogram plot.

**X Axis Label:** label of X Axis, default is <u>"Input Field Name".</u>

**Add Probability Distribution**: if add probability distribution in the histogram plot. Users can choose **True** or **False**. Default value is False.

**Line Style**: line type of the "probability distribution". This tool support 6 different types of lines, including solid, dashed, dotted, dotdash, longdash, and twodash.

