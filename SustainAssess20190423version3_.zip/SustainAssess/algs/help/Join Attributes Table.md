## Joint Attributes Table

Join attributes table of "input layer 2" to "input layer 1" by their key field, and output a layer with joined attributes.



**Input Layer 1** : the base layer of joined table. It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Input Layer 1's Key Field**:  the key field of "input layer". 

**Input Layer 2**: vector layer. It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Input Layer 2's Key Field**:  the key field of "input layer 2".

**Joined Layer Output **: output layer with joined attributes of these two input layers.