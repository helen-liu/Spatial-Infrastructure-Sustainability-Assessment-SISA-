## Uncertainty Analysis

Conduct uncertainty analysis of indicators’ weights ( in the weight file) to the sustainability assessment results (in the AHP result layer).  This function uses **Latin Hypercube Sampling (LHS)** to generate random samples for the uncertainty analysis.



**AHP Result Layer**: aggregation results obtained in the AHP function.

**AHP Weight File**: file of weight for each indicator, obtained in the AHP function.

**Uncertainty Range**: change weight of indicators in the uncertainty range.

**Number of Samples**: number of samples generated to calculate uncertainty. 

**Confidence Level**: confidence Interval of uncertainty analysis results is evaluated at the confidence Level.

**Uncertainty Results Layer**: save the uncertainty analysis results of the weight to temporary file or to file or to database table (SpatiaLite table or PostGIS table).

