## Moran Scatter Plot

Create Moran scatter plot for the input field of input layer.



**Input Layer**:  vector file, can be layers currently opened in QGIS, shapefile (*.shp), or PostGIS table.

**Input Field**: one field of the "Input Layer".

**Weights File**:  file describe the neighborhood relationship between features of the input layer (*.gal). It can be created by "Create Spatial Weight" tool.

**Main Title**: Main title of the Moran's I Scatterplot, default is "Morans I Scatter Plot".

**Sub Title**: Sub title of the histogram plot.

**X Axis Label:** label of X Axis, default is  same as "Input Field Name".

**Bounding Box**:  7 different types of bounding box, including "outline", "l-shape", "7-shape", "c-shape", "u-shape", "]-shape", and "none". Default is "outline".



Check "**Scale the Plot**", the scatterplot will be scaled to range [-10, 10].

----

* Examples of 7 different types of *bounding box* are shown in figures below.

![1546640975405](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546640975405.png)