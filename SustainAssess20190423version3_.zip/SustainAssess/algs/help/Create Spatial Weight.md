## Create Spatial Weight

Create Spatial Weight matrix for the input file, which can be used to calculate Moran's I or Local Moran's I. (using functions in [**spdep**](https://cran.r-project.org/web/packages/spdep/index.html) package )

The spatial weight matrix contains information about the neighborhood structure for each feature or observation of the "Input Layer". 



**Input Layer**: vector polygon file.

**ID Field**: ID field of the "Input Layer"

**Spatial Neighborhood Type**:  types of contiguity or neighborhood relation. There are four types of spatial neighborhood:

* **Queen’s Contiguity**: neighboring polygons are those that share a vertex with the focal polygon.
* **Rook’s Contiguity**: neighboring polygons are those that share a line segment with the focal polygon.
* **Fixed Distance**: Distance-based neighbors are those within a given proximity threshold to a focal polygon. distances are measured between polygon centroids.
* **k-Nearest **: Neighbor relationships is constructed so that each feature is assessed within the spatial context of **K** number of its closest neighbors. If **K** (the number of neighbors) is 8, then the 8 closest neighbors to the target feature will be included in computations for that feature.

**Distance or K Neighbors or K Lags**: parameters of the "neighborhood type". 

If neighborhood type is "**Queen's** Contiguity" or "**Rook's** Contiguity", this parameter value is for "**K lags**" (order of neighbors). If "k>1", then higher order neighbors are created. Example of 2-lags queen's or rook's contiguity neighbors are shown in figures below. 

If neighborhood type is "**Fixed Distance**", then this parameter controls the **distance threshold**. Its unit is in **kilometers**. Distances are measured between polygon centroids.

If neighborhood type is "**K-Nearest**", then this parameter controls number of nearest neighbors.

**Weighting Schema**: values of spatial weight, which can be "**Binary**" or "**Inverse Distance**".

* In **Binary Schema**, if observation *i* and observation *j* are neighbors or adjacent, then their spatial weigh is 1, otherwise the spatial weight is 0.

* In "**Inverse Distance**" **Schema**, the spatial weight between observation/feature *i* and observation/feature  *j* is the inverse of distance between these two features. Thus, nearby neighbors getting larger weights than neighbors farther away. 

**Distance Decay**: parameters of the "inverse-distance schema".

**Output File**: output spatial weight file.



____

* Rook's Contiguity Neighbors for yellow polygon (focal polygon).

  1-lag Neighbors : Orange polygons

  2-lag Neighbors : Orange polygons + Blue polygons



![1546277937153](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546277937153.png)

* Queen's Contiguity Neighbors for yellow polygon.

1-lag Neighbors : Orange polygons

2-lag Neighbors : Orange polygons + Blue polygons

![1546278070438](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546278070438.png)



* Fixed-Distance neighbors of the Yellow polygon. The fixed distance is defined by the radius of the black circle. 

![1546285157537](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546285157537.png)



* 8-Nearest Neighbors of the Yellow polygon.

![1546283946823](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546283946823.png)



___

**Reference**

* http://personal.tcu.edu/kylewalker/spatial-neighbors-in-r.html
* 