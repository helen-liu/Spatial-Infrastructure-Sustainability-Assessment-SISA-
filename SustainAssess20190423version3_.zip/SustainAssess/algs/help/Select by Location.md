## Select by Location

This tool select features from a vector layer based on their spatial relationships to another layer .



**Select Feature From Layer**: vector layer that users want to select features from. It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Based on Layer**:  the vector layer that defines the boundaries of selected features.

**Spatial Relations**: the spatial relations applied to select features. For example, if check "within", then all the features in "Select Feature From Layer" that are located within "Based on Layer" will be selected.

This tool supports many "Spatial Relations", including:

* Intersects: 
* contains:  
* disjoint:
* equals: 
* touches: 
* overlaps: 
* within: 
* crosses:

**Precision**:  parameters to control the precision of spatial relations operations.

**Output Selected Layer**: output layer with selected features. This tool can save results to temporary layer, shapefile (*.shp), or database tables (SpatiaLite table or PostGIS table).

check "Open output file after running algorithm", the results layer will be opened in QGIS automatically after completing the calculation.