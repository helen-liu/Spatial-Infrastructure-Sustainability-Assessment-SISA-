## Closeness Centrality

Calculate the **edge closeness centrality** of  all nodes in the directed network using [closeness](https://igraph.org/python/doc/igraph.GraphBase-class.html#closeness) functions in package "**Igraph**".



**Roads Nodes Layer**: nodes/ vertices table of "roads network".

**Node ID Field**: ID field of "Roads Node Layer".

**Roads Edge Layer**: edges table of "roads network".

**Edge ID Field**: ID field of "Roads Edge Layer".

**Edge Source Field**: source field of "Roads Edge Layer".

**Edge Target Field**: target field of "Roads Edge Layer".

**Edge Weight Field**: weight field of "Roads Edge Layer".

**Edge Reverse Weight Field**: reverse weight field of "Roads Edge Layer".

**Cutoff Value of Path Length**:   if it is an integer, only paths less than or equal to this length are considered, effectively resulting in an estimation of the betweenness values. If `0`, the exact betweennesses are returned (i.e. consider all paths).

**Closeness Result's Field in Node Layer**: the field name of "Closeness Centrality" results.

----

The closeness centerality of a vertex measures how easily other vertices can be reached from it (or the other way: how easily it can be reached from the other vertices). It is defined as the number of vertices minus one divided by the sum of the lengths of all geodesics from/to the given vertex.

If the graph is not connected, and there is no path between two vertices, the number of vertices is used instead the length of the geodesic. This is always longer than the longest possible geodesic.