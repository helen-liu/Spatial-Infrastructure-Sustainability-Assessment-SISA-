## Moran's I

Calculate the Global Moran's I among features of Input Layer.



**Input Layer**: vector file.  It can be files opened in QGIS or "Open from file" or "open from database table" (SpatiaLite table or PostGIS table)

**Input Field**: field of the "Input Layer", for which to calculate the Moran's I value.

**Neighborhood File**:  file of "Spatial Weight" (*.rds)

**Variance Assumption**: Normality or  Randomization.

**Alternative Hypothesis**:  Greater, Less or Two-Sided.

**Ranked Data**: False or True

**Output File**: output Moran's I results to file.



____

**Moran's I** is a cross-product statistic between deviation of a variable and its spatial lag, and can be calculated by Equation below. Its **null hypothesis** states that the attribute being analyzed is randomly distributed among the features in the "Input Layer". 



