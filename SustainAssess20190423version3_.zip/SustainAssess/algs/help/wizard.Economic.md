### Select Indicators for Sustainability Assessment

Select indicators for each dimension of sustainability. There are four dimensions of sustainability: **Economic, Environmental, Social, and Resilient** Dimension. If users cannot determine one indicator belongs to which dimension of sustainability, then the indicator should be put in the **Composite** "dimension" .



Click on "**+**", users can add or select indicators from the **"Default Indicators File", "Other CSV File", "PostGIS Table", or "Add New Indicators Manually " ** to the table. 

"Default Indicators File" is stored in the data folder of the plugin, which is <u>"..\SustainAssess\data\DefaultIndicators.csv"</u>

If "Add New Indicators Manually", users can type in the following information to the indicator:

* **Categories**

* **Sub Category**

* **Indicator Name**

* **Notes**


Each indicator has a unique ID, when manually add new indicator, its ID is generated automatically. Its "spatial" and "temporal" scales are same as the value defined in "Object&Scale" module, they are also filled automatically.



Select one or multiple indicator records and click **"─"** ""button, users can remove the selected indicators from the table.

Select one indicator record in the table and click **↑** or **↓** button, users can move the record.