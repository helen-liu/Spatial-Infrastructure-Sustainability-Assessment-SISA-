## Radar Chart

This tool create a radar chart for each feature in the input layer. The radar chart will show the sustainability assessment results and uncertainty analysis result. 



**Input Uncertainty Result Layer:** the file that are generated after uncertainty analysis. It includes all the sustainability assessment results and uncertainty analysis result.  It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Key Field**:  the key field of "input layer". 

**Directory to Save Charts**: a file folder in which you want to save the radar charts. 

