### Setting of Wizard

Set the "**Default Indicators File**” and sustainability assessment results file ("**Output Results File**"). After setting, if users click save button, all the information will be saved to the "Output Results File".