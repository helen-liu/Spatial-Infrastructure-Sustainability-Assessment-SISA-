## Betweenness Centrality

Calculate the **edge betweenness centrality** of directed network using [edge_betweenness](https://igraph.org/python/doc/igraph.GraphBase-class.html#edge_betweenness) functions in package "**Igraph**".



**Roads Edge Layer**: edges table of "roads network".

**Edge ID Field**: ID field of "Roads Edge Layer".

**Edge Source Field**: source field of "Roads Edge Layer".

**Edge Target Field**: target field of "Roads Edge Layer".

**Edge Weight Field**: weight field of "Roads Edge Layer".

**Edge Reverse Weight Field**: reverse weight field of "Roads Edge Layer".

**Cutoff Value of Path Length**:   if it is an integer, only paths less than or equal to this length are considered, effectively resulting in an estimation of the betweenness values. If `0`, the exact betweennesses are returned (i.e. consider all paths).

**Betweenness Result's Field in Road Layer**: the field name of "Betweenness Centrality" results.


