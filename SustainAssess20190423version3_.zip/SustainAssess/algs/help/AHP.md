## AHP

This tool calculates the weight of the selected fields (indicators) using Analytic Hierarchy Process (AHP) step by step, and aggregates indicators by "Linear Additive model" or "Geometric Mean Model".



**Input Layer**: Polygon vector file.  It can be files opened in QGIS or "Open from file" or "open from database table" (SpatiaLite table or PostGIS table).

**Select fields**: fields of indicators. Their "Alias" names are shown in the "Pairwise Comparison Matrix".

**Pairwise Comparison Matrix A** : In the matrix **A**, users need to type in the pair-wise comparison scales between each pair of indicators to reflect their relative importance. The pair-wise comparison scales are the factor of preference defined in AHP literatures, they are in range (0,9]. Details information are shown in the table below. 

e.g.: **In matrix A, if A(i,j) = 9, then it means indicator i is extremely important than indicator j.** 



| Factor of   Preference, ρ | Importance   Definition                                      |
| ------------------------- | ------------------------------------------------------------ |
| 1                         | Equal   importance: two indicators contribute equally to the objective |
| 3                         | Moderate   importance of one over another                    |
| 5                         | Strong   or essential importance of one over another         |
| 7                         | Very   strong or demonstrated importance of one over another |
| 9                         | Extreme   importance of one over another                     |
| 2,   4, 6, 8              | Intermediate   values, use this when compromise is needed    |
| Reciprocals,   1/ρ        | Reciprocal   for inverse comparison. If one indicator *i*   has one of the above numbers (factor of preference) assigned to it when   compared with indicator *j*, then *j* has the reciprocal value when   compared with *i*. |



**AHP Indicators**: **max λ** (principal eigenvalue of priority matrix A), **CI** (Consistency Index), **CR** (Consistency Ratio).  If CR < 0.1, then the priority matrix A is consistent, and can be used to extract weights of indicators.

____

**Output**

* **Select Combination Method**: method to aggregate indicators. Two methods are available: "**Linear Additive**" and "**Geometric Mean**".
* **Output Results Layer**: save the aggregation results of indicators to temporary file or to file or to database table (SpatiaLite table or PostGIS table).
* **Output Weights File **: save the weights of all the selected fields to temporary file or to file or to database table (SpatiaLite table or PostGIS table).



____

![1545962812732](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1545962812732.png)