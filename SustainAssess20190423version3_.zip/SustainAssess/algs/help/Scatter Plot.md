## Scatter Plot

Create Scatter Plot for the input field of the input file.



**Input Layer**: vector file

**Input X Field**: field of the "Input Layer"

**Input Y Field**: field of the "Input Layer"

**Main Title**: Main title of the Scatterplot, default is "Scatter Plot".

**Sub Title**: Sub title of the scatterplot.

**X Axis Label:** label showing below X Axis.

**Y Axis Label:** label showing besides Y Axis.

**Bounding Box**:  7 different types of bounding box, including "outline", "l-shape", "7-shape", "c-shape", "u-shape", "]-shape", and "none". Default is "outline".

**X Axis Ticks:** number of ticks on X Axis.

**Y Axis Ticks:** number of ticks on Y Axis.

**Style of Axis Labels**: available values are : 0,1,2,3. Default is 1 (always horizontal).

- 0: always parallel to the axis ,
- 1: always horizontal [*default*],s
- 2: always perpendicular to the axis,
- 3: always vertical.

**Add Trend Line**: if add trend line in the scatterplot, **True** or **False** (Default).

**Trend Line Style**: line type of the trend line. This tool support 6 different types of lines, including <u>solid, dashed, dotted, dotdash, longdash, and twodash</u>.



---

* Examples of different styles of Axis Labels are shown in figures below.

![1546641814099](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546641814099.png)mor

* Examples of  7 different types of *Bounding Box*.

![1546640608206](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546640608206.png)

