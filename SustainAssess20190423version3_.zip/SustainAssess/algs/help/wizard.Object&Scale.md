### Setting Object & Scale for Sustainability Assessment



In the "**Define Object of Sustainability Assessment**" text box, type in descriptions of the object of sustainability assessment.



Choose "Spatial Scales" from the drop list, available spatial scales include:

* Global
* Nation
* Region
* Division
* State/Province
* Countries
* Census Tracts
* Census Block Groups
* Census Blocks
* Traffic Analysis Zones



**Temporal Scales** have to be <u>defined by users</u> (*type in the number of years in the box*) or are <u>not considered</u> in the sustainability assessment. 



Click "**Save**" button to save all the information to file. Users can set the "**Output Results File**" parameter in "**Settings**" to change the filename or location.

Click "**Load**" button to load previous saved information from file.

Click "**Next**" button to switch to next module or step of sustainability assessment ("**Select Indicators**").

