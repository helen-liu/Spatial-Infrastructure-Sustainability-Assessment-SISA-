### Assess Raw Data Quality

Evaluate the quality of raw data in the data quality check table. 



Users can manually check the data quality box of each data to mark the corresponding data is "**High**", "**Medium**", or "**Low**" quality.

Scores of each data will be calculated automatically and shown in the "**Scores**" column. The **total** scores of each category of data are also calculated, and are shown in the "**Total**" row.

____

Example of data quality check table.

![1546007172304](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1546007172304.png)