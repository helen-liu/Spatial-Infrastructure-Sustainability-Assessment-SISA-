### Create Random Points

This tool **create random points** in the **boundary** defined by "**Input Boundary Layer**".



**Input Boundary Layer**: files define the boundary of random points. Shapefiles **opened** in QGIS can be shown **automatically** in the droplist. Users can also choose "Input Boundary Layer" from files in other location or from database table (PostGIS table or SpatiaLite table).

**Points Number**: number of random points to be generated, default value is 1.

**Minimum Distance**: minimum distance between any two random points, the distance between random points must be larger than this value. Units of the distance is same as the coordinate system of "Input Boundary Layer". Setting this parameter can avoid the random points too close to each other.

**Random Points Output**: layer or file to save the generated random points. 



Example of Random Points in the boundary defined by orange polygon, with minimum distance of 1km (left) and 5km (right).

![1545936523315](C:\Users\mliu301\AppData\Roaming\Typora\typora-user-images\1545936523315.png)