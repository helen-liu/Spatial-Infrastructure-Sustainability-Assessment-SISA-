## Detour Index

Calculate the Detour Index of Random Vectors in the directed network:



**Input Random Vector Layer**:  file includes random vectors (pair of points). The function calculate the "Detour Index" of each pair of points. It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**ID Field of Input Random Vector Layer**:  field with unique ID for each random vector.

**Roads Layer**: road network file. It <u>must be selected from database table (SpatiaLite or PostGIS table)</u>. It must have correct topology relationships.  (Roads nodes and edges table can be generated automatically after building topology for the road network).

**Source Field**: source field of "Roads Layer". If field name ‘source’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Target Field**: target field of "Roads Layer". If field name ‘target’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Cost Field**: cost field of "Roads Layer". When creating the **directed network**, "cost" is treated as "weight" of one edge segment. 

If field name ‘cost’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Reverse Cost Field**:  reverse cost field of "Roads Layer". When creating the **directed network**, "reverse cost" is treated as "weight" of one edge segment.

If field name ‘reverse_cost’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Highway Field [optional]:** optional parameters. Field indicates whether one road is highway or not. 

**Output Field Name**: name of the field that saves "Detour Index" values.

**Output Layer**: this tool can save results to temporary layer, shapefile (*.shp), database tables (SpatiaLite table or PostGIS table), or new field in "Input Zone Layer".

* If check "Open output file after running algorithm", the results will be open in QGIS automatically after finish calculation.

---

**Detour Index (DI)** is also called **Pedestrian Route Directness (PRD)**. DI measures the efficiency of a transport network in terms of how well it overcomes distance or the friction of distance (Rodrigue et. al.,2017). It is the ratio of route distance to straight-line distance for two selected points. "Route distance" of point *i* and point *j* is the real distance between them in the directed road network. "Straight-line distance" of point *i* and point *j* is the Euclidean distance between them. See Equation below.
$$
DI_{ij} = \frac{d_R(i,j)}{d_E(i,j)}		\qquad	DI_{ij} \ge 1	\\


\text{where, } DI_{ij} \space \text{is the detour index from node } i \space \text{to node } j \space, \\
d_R(i,j) \space \text{is the route distance from node } i \space \text{to node } j \space \\
d_E(i,j) \space \text{is the straight-line distance from node } i \space \text{to node } j \space
$$

---

**Reference**:

* Rodrigue, J. P., Comtois, C., & Slack, B. (2017). The Geography of Transport Systems. Fourth Edition. New York: Routledge, 440 pages. ISBN 978-1138669574.