## Katz Centrality

Calculate the **Katz Centrality ** for  all nodes in the directed network using [Katz_centrality](https://networkx.github.io/documentation/networkx-1.10/reference/generated/networkx.algorithms.centrality.katz_centrality.html) functions in package "**Networkx**". 



**Roads Nodes Layer**: nodes/ vertices table of "roads network".

**Node ID Field**: ID field of "Roads Node Layer".

**Roads Edge Layer**: edges table of "roads network".

**Edge ID Field**: ID field of "Roads Edge Layer".

**Edge Source Field**: source field of "Roads Edge Layer".

**Edge Target Field**: target field of "Roads Edge Layer".

**Edge Weight Field**: weight field of "Roads Edge Layer".

**Edge Reverse Weight Field**: reverse weight field of "Roads Edge Layer".

**Alpha**:   Attenuation factor which controls the penalty of connections of distant neighbors. It should be strictly less than *inverse largest eigenvalue of the adjacency matrix* in order for the Katz centrality to be computed correctly.  Default is 0.1.

**Beta**:  Parameter to control the weight attributed to the immediate neighborhood. . Default is 1.0. 

**Number of Iterations**: Maximum number of iterations in power method. Default is 1000.

**Katz Result's Field in Node Layer**: the field name of "Katz Centrality" results.



----

Katz centrality computes the centrality for a node based on the centrality of its neighbors. It is a generalization of the eigenvector centrality. The Katz centrality for node *i* is defined by equation below.


$$
x_i = \alpha\sum_j{A_{ij}x_j} + \beta	\\
\alpha < \frac{1}{\lambda_{max}}	\\
\text{Where }, \alpha \space \text{is attenuation factor. It defines the penalty factor of connections of distant neighbors, }	\\
A \space \text{is the adjacency matrix of the graph }  G \space \text{with eigenvalues } \lambda	\\
\lambda_{max} \space \text{is the maximum eigenvalue of graph } G  \\
\beta \space \text{ is the extra weight of immediate neighbors.}
$$


Katz centrality computes the relative influence of a node within a network by measuring the number of the immediate neighbors (first degree nodes) and also all other nodes in the network that connect to the node under consideration through these immediate neighbors. More information can be found in reference [1] below.



[1] Mark E. J. Newman: Networks: An Introduction. Oxford University Press, USA, 2010, p. 720.