Aggregate Attributes

This tool aggregate features of source layer based on spatial relationships or value of one field in the source layer.



**Source Layer ** : vector layer that users want to aggregate its features. It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Aggregate By:**  ID or LOCATION. 

* **Aggregate by ID**:  users need to select the "ID Field of Source Layer". This tool will aggregate the selected fields in "Source Layer" by their IDs. Features with the same ID will be aggregate together.
* **Aggregate by LOCATION**:  users need to select the "Reference Layer". This tool will aggregate the selected fields in "Source Layer" by their spatial relationships (**Intersect**) to the "Reference Layer". 

**ID Field of Source Layer**: one field of source layer, based on which to aggregate the selected fields.

**Reference Layer**:  the vector layer that defines the boundaries of aggregate features.

**Key Field of Reference Layer**:  Key field of the " Reference Layer".

**Select Fields to Aggregate**: double click one field in the "Available Fields" table, it will be selected and shown in the "Selected Fields" table.

**Aggregation Method**:  methods to calculate the aggregated value of the selected fields.

* sum
* min
* max
* median
* arithmetic mean
* geometric mean
* Midmean:  (interquartile mean (IQM)) 

**Output Aggregation Layer**: output layer with aggregation value of the selected features. This tool can save results to **temporary layer, shapefile (*.shp), or database tables (SpatiaLite table or PostGIS table).**



check "Open output file after running algorithm", the results layer will be opened in QGIS automatically after completing the calculation.



----

Midmean  Equations: 
$$
x_{IQM} = \frac{2}{n}(\sum_{ i=  \Bigl\lceil\dfrac{n}{4}\Bigr\rceil + 1}^{ \Bigl\lfloor\dfrac{3n}{4}\Bigr\rfloor } x_i	+ 
\frac{x_{\Bigl\lceil\dfrac{n}{4}\Bigr\rceil} + x_{(\Bigl\lfloor\dfrac{3n}{4}\Bigr\rfloor + 1)} }{2}	\times 
(\frac{n}{2} - (\Bigl\lfloor\dfrac{3n}{4}\Bigr\rfloor - \Bigl\lceil\dfrac{n}{4}\Bigr\rceil)))	\\
x_{IQM} =\frac{2}{n}(\sum_{i=4}^{8}x_i + \frac{x_3 + x_9}{2} \times (\frac{11}{2} - (8-3)))	\qquad	n = 11
$$
