## Beta Index

Calculate the Beta index of directed network:

**Beta Index** measures relationships between the number of links and the number of nodes. The greater the value of beta index, the greater the connectivity.  A perfect grid has β value of 2.5 (Dill, 2004).



**Input Zone Layer**: polygon layer defined the boundary of calculating **Beta Index**. Each polygon in the "input zone layer" will have an "Beta Index" value.  It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**ID Field**: ID field of the "Input Zone Layer"

**Roads Layer**: road network file. It <u>must be selected from database table (SpatiaLite or PostGIS table)</u>. 

**Source Field**: source field of "Roads Layer". If field name ‘source’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Target Field**: target field of "Roads Layer". If field name ‘target’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Cost Field**: cost field of "Roads Layer". When creating the **directed network**, "cost" is treated as "weight" of one edge segment. 

If field name ‘cost’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Reverse Cost Field**:  reverse cost field of "Roads Layer". When creating the **directed network**, "reverse cost" is treated as "weight" of one edge segment.

If field name ‘reverse_cost’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**Output Field Name**: name of the field that saves "Beta Index" values.

**Output Layer**: this tool can save results to temporary layer, shapefile (*.shp), database tables (SpatiaLite table or PostGIS table), or new field in "Input Zone Layer".



* If check "Open output file after running algorithm", the results will be open in QGIS automatically after finish calculation.

------

<u>Optional parameters</u>, if one of the E, V, P field name is "**[not set]**", then the tool will calculate the e, v, p values of the “Roads Layer”, and **create field "e_net", "v_net", "p_net" in the output layer**.

**E Field Name [Optional]**:  one field of "Roads Layer", recording "e" value of “Roads Layer”.  If field name ‘e_net’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.

**V Field Name [Optional]**: one field of "Roads Layer", recording "v" value of “Roads Layer”.  If field name ‘v_net’ exists in the “Roads Layer”, it will be selected automatically after selecting "Road Layer" from database.



___

Beta Index is calculated  by the equation below.
$$
\beta = \frac{|E|}{|V|} = \frac{m}{n}	\qquad  \beta \ge 1
$$
where,  ***n = |V|*** is the number of nodes in the graph, ***m=|E|*** is the number of edges in the graph. 



___

**Reference**:

Dill, J. (2004). Measuring Network Connectivity for Bicycling and Walking. Washington DC: Transportation Research Board 2004 Annual
Meeting (CD-ROM), 131-139.