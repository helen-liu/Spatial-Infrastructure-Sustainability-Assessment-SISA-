## Accessibility to Nearest Facility

Calculate the "Hansen (1959) potential **Attraction-accessibility** " of the source layer features to the nearest **network-distance** feature of  "source layer".



**Source Layer (POINT)**:  Random points layer, which accessibility to be calculated.  It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Source Layer ID**:  ID field of the "Source Layer".

**Target Layer**: points or polygon layer which includes the facilities features.  It can be selected from **current-opened layers in QGIS, files, or database tables (PostGIS table or SpatiaLite table)**.

**Target Layer ID **: ID field of the "Target Layer"

**Target Layer Attractiveness Field**: field  which defines attraction of features in target layer.



**Roads' Layer**:  the edges table of "roads network". It **must** be selected from **PostGIS** table.

**Roads' Source Field**: source field of "Roads' Layer".

**Roads' Target Field**: target field of "Roads' Layer".

**Roads' Cost Field**: cost field of "Roads' Layer".

**Roads' Reverse Cost Field**: reverse cost field of "Roads' Layer".

**Roads' Speed Field (Km/h) [optional]** : speed field of "Roads' Layer". This tool use the "speed field" to identify highways (speed >=80km/h). Default value is "[not set]".

**Field Name of Accessibility**:  Field name of the "accessibility results" for each source point.

**Output Accessibility Layer**: layer saves the "accessibility results" for each source point, including source point ID and its accessibility.



If check "Open output file after running algorithm", the results will be open in QGIS automatically after finish calculation.



------

**Attraction-accessibility** considers the spatial interactions between origins and destinations. It computes a summary score for an individual or place based on the attractiveness of potential activity
locations and their required travel costs (e.g. travel distance, time or money).  <u>"Hansen (1959) potential attraction-accessibility measure"</u>  assumes that accessibility is likely to decrease as the cost of reaching it increases. It can be calculated by the Equation below.​


$$
A_i = \sum_{j \in K_i}{w_j \times f(c_{ij})}     = \sum_{j \in K_i}{w_j \times d_{ij}^{-\alpha}}     = \sum_{j \in K_i}{w_j \times d_{ij}^{-2.0}}
$$


Where,

* $A_i$ is the accessibility of travel origin *i* to destination *j*;  

* $w_j​$  is the attractiveness of destination *j*, it is often estimated as the number of opportunities. 

* $f(c_{ij})$  is a general function describing the travel cost or travel impedance between origin *i* and destination *j*. $f(c_{ij})$can be distance, time or money. It is usually estimated by straight-line Euclidean distance, **network distance**, actual traveling time or distance, and so on. 

  According to the First Law of Geography, we assume that the attractiveness of destination *j to* origin *i* will decrease with increases of the distance to destination. For simplify, we use the simplest inverse power gravity formulation (Bhat et al., 2001) as our travel cost function, 
  $$
  f(c_{ij}) = d_{ij}^{-\alpha}	\\
  \text{where, } d_{ij} \space \text{is the real distance from location } i \space \text{to location} j,\\
  \alpha \space \text{is the power of gravity model}
  $$

* $K_i$ is the choice set available to origin point *i*. We also assume people’s choice set
  will not change after **reach some distance threshold**, according to the First Law
  of Geography. In other words, people is unlikely to use services or facilities
  very far away, thus those far facilities are not in their choice set. For
  example, Alshuwaikhat and Aina (2006) assumes that services must be within 400
  meters of citizens for the services to be accessible by walking. Thus services
  which are located more 400 meters are not within citizens’ choice set for
  walking.

