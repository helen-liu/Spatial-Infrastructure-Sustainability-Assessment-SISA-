# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SpatialSustainAssess
                                 A QGIS plugin
 Evaluating sustainability of objects from multiple dimensions
                             -------------------
        begin                : 2018-06-25
        copyright            : (C) 2018 by Mengmeng Helen Liu / Georgia Insitute of Technology
        email                : mengmeng.liu@gatech.edu
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load SpatialSustainAssess class from file SpatialSustainAssess.

    :param iface: A QGIS interface instance.
    :type iface: QgisInterface
    """
    #from SpatialSustainAssess import SpatialSustainAssess
    #return SpatialSustainAssess(iface)
    from SustainAssess.SpatialSustainAssess_qs import SpatialSustainAssess_qs
    return SpatialSustainAssess_qs(iface)
